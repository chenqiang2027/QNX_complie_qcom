/*===========================================================================

*//** @file devman.c
  This file implements the device manager

Copyright (c) 2010 - 2019 QUALCOMM Technologies, Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*===========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/ioctl/ioctlServer/src/devman.c#1 $

when       who        what, where, why
--------   --------   ------------------------------------------------------- 
05/15/19   jz         Use message thread to handle device detach requests
04/03/19   jz         Call device_detach() directly instead of send PULSE message when detach device
01/02/18   rz         Fix MISRA warning 
03/24/17   rz         Remove unused video function declaration
02/05/17   rz         Fix compilation warnings with printf format check
05/20/14   am         Add dm_dev_write function for passing cmd line settings to driver.
04/03/14   rs         Fix an issue with potential memory access past array size
03/14/14   hc         Backward compatible for tools version 6.5
07/16/13   dp         Client authentication on ioctlServer
07/15/13   uc         Use std typedefs.
04/19/13   rz         Changed RM creation flag to enable UI playback
04/16/13   uc         Removed warnings.
04/09/13   hc         Replace printf by slog
02/27/12   sk         Fixed KW compiler warnings
10/20/11   che        If videoCore is started at the same time qnpcore is still loading
                      diag initialization might fail. need to delay diag initialization
                      until first playback request
04/27/11   wyun       Adding thread naming
02/03/11   rz         Replace shared mem with mq
11/13/10   che        Initial version
============================================================================*/

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include <sys/neutrino.h>
#include <sys/iomsg.h>
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <process.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <mqueue.h>
#include <dlfcn.h>
#include "AEEstd.h" /* std typedefs, ie. byte, uint16, uint32, etc. and memcpy, memset */
#include "ioctlMsg.h"
#include "ioctlServer.h"
#include "ioctlServerPriv.h"
#include "MMThread.h"
#include "MMDebugMsg.h"
#include "MMCriticalSection.h"
#include "MMTimer.h"
/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */
#define MSG_THREAD_NAME "devman-msg-thread"

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */
typedef struct ioctl_device_manager_s
{
   iofunc_attr_t attr;
   dispatch_t* dpp;
   dispatch_context_t* ctp;
   resmgr_connect_funcs_t connect_funcs;
   resmgr_io_funcs_t io_funcs;

   unsigned int count;
   int chid;
   int coid;
   MM_HANDLE dm_thread;
   MM_HANDLE msg_thread;
   int pathID;
} ioctl_device_manager_t;

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

char server_name[MAX_NAME_LENGTH];           /* name of this device manager server */
ioctl_device_manager_t devman;
static ioctl_device_node_t* devices = NULL;  /* registered devices */
static unsigned int dcount = 0;              /* registered device count */

/* -----------------------------------------------------------------------
**                 FUNCTION DECLARATIONS
** ----------------------------------------------------------------------- */

static ioctl_dcb_t* device_attach(const char *name);
static int device_detach(ioctl_dcb_t* dcb);


/*===========================================================================

                        FUNCTION DEFINITIONS

===========================================================================*/

int add_dcb(ioctl_device_node_t* dnode, ioctl_dcb_t* dcb)
{
   ioctl_dcb_t* curr = NULL;
   ioctl_dcb_t* prev = NULL;

   IOCTL_SRV_MSG_LOW("ioctlSrv: %s enter", __FUNCTION__);

   curr = dnode->dcbs;

   /* add the dcb in the increasing order of the devid */
   while ( curr )
   {
      if ( curr->devid > dcb->devid )
      {
         break;
      }
      prev = curr;
      curr = curr->next;
   }

   if ( prev )
   {
      dcb->next = prev->next;
      prev->next = dcb;
   }
   else
   {
      dcb->next = dnode->dcbs;
      dnode->dcbs = dcb;
   }

   if ( ( 0 == dnode->count ) &&
        ( dnode->device.vtbl.attach ) )
   {
      dnode->device.vtbl.attach();
   }
   dnode->count++;
   IOCTL_SRV_MSG_LOW("ioctlSrv: %s exit", __FUNCTION__);
   return 0;
}

int del_dcb(ioctl_device_node_t* dnode, ioctl_dcb_t* dcb)
{
   ioctl_dcb_t* curr = NULL;
   ioctl_dcb_t* prev = NULL;

   IOCTL_SRV_MSG_LOW("ioctlSrv: %s enter", __FUNCTION__);

   curr = dnode->dcbs;

   /* add the dcb in the increasing order of the devid */
   while ( curr )
   {
      if ( curr == dcb )
      {
         break;
      }
      prev = curr;
      curr = curr->next;
   }

   if ( NULL == curr )
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: Current node is NULL");
      return -1;
   }

   if ( prev )
   {
      prev->next = dcb->next;
   }
   else
   {
      dnode->dcbs = dcb->next;
   }
   dnode->count--;
   if ( ( 0 == dnode->count ) &&
        ( dnode->device.vtbl.detach ) )
   {
      dnode->device.vtbl.detach();
   }
   IOCTL_SRV_MSG_LOW("ioctlSrv: %s exit", __FUNCTION__);
   return 0;
}

int register_ioctl_device(ioctl_device_t* aDevice)
{
   ioctl_device_node_t* dnode = (ioctl_device_node_t*) IOCTL_SRV_Malloc(sizeof(ioctl_device_node_t));

   IOCTL_SRV_MSG_LOW("ioctlSrv: %s enter", __FUNCTION__);

   if ( dnode == NULL )
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: malloc for dnode failed");
      return -1;
   }
   IOCTL_SRV_MEMSET(dnode, 0, sizeof(ioctl_device_node_t));
   dnode->device = *aDevice;
   dnode->next = devices;
   devices = dnode;
   dcount++;

   IOCTL_SRV_MSG_LOW("ioctlSrv: %s exit", __FUNCTION__);

   return 0;
}

ioctl_device_node_t* find_device_by_name(const char* name)
{
   ioctl_device_node_t* dnode = devices;
   IOCTL_SRV_MSG_LOW("ioctlSrv: %s enter", __FUNCTION__);
   while ( dnode )
   {
      if ( 0 == std_strncmp(name, dnode->device.name, std_strlen(dnode->device.name)) )
      {
         break;
      }
      dnode = dnode->next;
   }
   IOCTL_SRV_MSG_LOW("ioctlSrv: %s exit", __FUNCTION__);
   return dnode;
}

static ioctl_dcb_t* device_attach(const char *name)
{
   ioctl_dcb_t* dcb = NULL;
   ioctl_device_node_t* dnode = find_device_by_name(name);

   IOCTL_SRV_MSG_LOW("ioctlSrv: %s enter", __FUNCTION__);

   if ( dnode )
   {
      // start an instance of this device
      dcb = start_ioctl_device(dnode);
   }
   else
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: device driver %s did not register", name);
      return NULL;
   }

   if ( dcb )
   {
      add_dcb(dnode, dcb);
   }
   devman.count++;

   IOCTL_SRV_MSG_LOW("ioctlSrv: %s exit", __FUNCTION__);

   return dcb;
}

static int dm_dev_write(resmgr_context_t *ctp, io_write_t *msg, RESMGR_OCB_T *ocbp)
{
   ioctl_ocb_t *ocb = (ioctl_ocb_t*)ocbp;
   ioctl_device_node_t *dcb = (ioctl_device_node_t*)devices;
   int         status = EOK;
   char        *pBuff = NULL;
   ioctl_device_node_t* dnode = (ioctl_device_node_t*) devices;

   IOCTL_SRV_MSG_LOW("ioctlSrv: %s enter", __FUNCTION__);

   status = iofunc_write_verify (ctp, msg, ocbp, NULL);
   if ( EOK != status )
   {
      return (status);
   }

   if ( _IO_XTYPE_NONE != (msg->i.xtype & _IO_XTYPE_MASK) )
   {
      return (ENOSYS);
   }

   pBuff = (char *) IOCTL_SRV_Malloc(msg->i.nbytes + 1);
   if ( NULL == pBuff )
   {
      return (ENOMEM);
   }

   _IO_SET_WRITE_NBYTES (ctp, msg->i.nbytes);

   /*
    *  Reread the data from the sender's message buffer.
    *  We're not assuming that all of the data fit into the
    *  resource manager library's receive buffer.
    */
   resmgr_msgread(ctp, pBuff, msg->i.nbytes, sizeof(msg->i));
   pBuff [msg->i.nbytes] = '\0'; /* just in case the text is not NULL terminated */

   if ( ( dnode != NULL ) && ( dcount > 0 ) )
   {
       if ( dcb )
       {
             if ( dcb->device.vtbl.write )
             {
                dcb->device.vtbl.write(ocb->drvHandle, (uint8*)pBuff, msg->i.nbytes);
             }
       }
   }

   if ( msg->i.nbytes > 0 )
   {
      ocbp->attr->flags |= IOFUNC_ATTR_MTIME | IOFUNC_ATTR_CTIME;
   }
   IOCTL_SRV_Free(pBuff);

   IOCTL_SRV_MSG_LOW("ioctlSrv: %s exit", __FUNCTION__);

   return (_RESMGR_NPARTS(0));
}
static int dm_dev_msg(resmgr_context_t *ctp, io_msg_t *msgp, RESMGR_OCB_T *ocbp)
{
   char rxBuf[64];
   io_msg_type_t msg;

   IOCTL_SRV_MSG_LOW("ioctlSrv: %s enter", __FUNCTION__);

   int bytes = MsgRead(ctp->rcvid, &msg, sizeof(msg), 0);

   if ( bytes == -1 )
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: MsgRead failed");
      MsgError(ctp->rcvid, EFAULT);
      return (_RESMGR_NOREPLY);
   }

   if ( msg.buf.hdr.type == MSG_TYPE_ATTACH )
   {
      bytes = MsgRead(ctp->rcvid, rxBuf, sizeof(rxBuf), sizeof(io_msg_type_t));
      if ( bytes == -1 )
      {
         IOCTL_SRV_MSG_ERROR("ioctlSrv: MsgRead failed");
         MsgError(ctp->rcvid, EIO);
      }
      else
      {
         /* terminate the string */
         if ( bytes < sizeof(rxBuf) )
         {
            rxBuf[bytes] = 0;
         }
         else
         {
            /* exactly sizeof(rxBuf) bytes were received. Make sure this is null terminated
            by setting the last char to 0 */
            rxBuf[ ( sizeof(rxBuf) - 1 ) ] = 0;
         }
         if ( msg.buf.hdr.type == MSG_TYPE_ATTACH )
         {
            ioctl_dcb_t* dcb = device_attach(rxBuf);

            if ( dcb )
            {
               MsgReply(ctp->rcvid, EOK, &dcb->devid, sizeof(dcb->devid));
            }
         }
      }
   }
   else
   {
      // ignore unknown message queries
      MsgReply(ctp->rcvid, ENOSYS, NULL, 0);
   }

   IOCTL_SRV_MSG_LOW("ioctlSrv: %s exit", __FUNCTION__);

   return (_RESMGR_NOREPLY);
}
#if (_NTO_VERSION > 650)
static int dm_dev_acl(resmgr_context_t *ctp, io_acl_t *msg, iofunc_ocb_t *ocb_t)
{
   IOCTL_SRV_MSG_LOW("ioctlSrv: %s enter", __FUNCTION__);
   return iofunc_acl(ctp, msg, ocb_t, ocb_t->attr);
}
#endif
static int device_detach(ioctl_dcb_t* dcb)
{
   int status = EOK;

   IOCTL_SRV_MSG_LOW("ioctlSrv: %s enter", __FUNCTION__);

   if ( dcb == NULL )
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: NULL dcb passed");
      return -1;
   }
   status = stop_ioctl_device(dcb);

   IOCTL_SRV_MSG_LOW("ioctlSrv: %s exit", __FUNCTION__);

   return status;
}

static int msg_handler(void* data)
{
    struct _pulse pulse;
    int rcvid;
    ioctl_dcb_t* dcb;

    while(1)
    {
        rcvid = MsgReceive(devman.chid, &pulse, sizeof(pulse), NULL);
        if (rcvid > 0)
        {
            if (DEVICE_DETACH_PULSE == pulse.code)
            {
                IOCTL_SRV_MSG_LOW("DEVICE_DETACH_PULSE msg received");
                dcb = (ioctl_dcb_t*) pulse.value.sival_ptr;
                device_detach(dcb);
            }
            MsgReply(rcvid, EOK, NULL, 0);
        }
        else
        {
            IOCTL_SRV_MSG_ERROR("Error in receiving messages");
        }
    }

    return 0;
}

static int dm_dispatcher(void* ctxt)
{
   dispatch_context_t* ctp = (dispatch_context_t*)ctxt;
   dispatch_context_t* new_ctp;

   IOCTL_SRV_MSG_LOW("ioctlSrv: %s enter", __FUNCTION__);

   while(1)
   {
      new_ctp = dispatch_block(ctp);
      if ( new_ctp )
      {
         IOCTL_SRV_MSG_LOW("ioctlSrv: dispatch_block called");
         ctp = new_ctp;
         dispatch_handler(ctp);
         IOCTL_SRV_MSG_LOW("ioctlSrv: dispatch_handler called");
      }
      else if ( EINTR != errno )
      {
         IOCTL_SRV_MSG_ERROR("ioctlSrv: error exiting");
         return -1;
      }
      else
      {
         IOCTL_SRV_MSG_LOW("ioctlSrv: dispatch_block interrupted; retrying...");
      }
   }
   IOCTL_SRV_MSG_LOW("ioctlSrv: %s exit", __FUNCTION__);
   return 0;
}

int send_device_detach(ioctl_dcb_t* dcb)
{
    int ret = 0;
    struct _pulse pulse;
    pulse.value.sival_ptr = dcb;
    pulse.code = DEVICE_DETACH_PULSE;

   IOCTL_SRV_MSG_LOW("ioctlSrv: %s enter", __FUNCTION__);
   if ( -1 == MsgSend(devman.coid, &pulse, sizeof(pulse), NULL, 0))
   {
       IOCTL_SRV_MSG_ERROR("ioctlSrv: error sending DEVICE_DETACH_PULSE msg: %s", strerror(errno));
       ret = -1;
   }
   IOCTL_SRV_MSG_LOW("ioctlSrv: %s exit", __FUNCTION__);
   return ret;
}

int start_device_manager(const char* server, void *pGroupList)
{
   resmgr_attr_t  rattr;
   int            status = 0;
   char           name[MAX_NAME_LENGTH];
   char           path[PATH_MAX + 1];

   IOCTL_SRV_MSG_LOW("ioctlSrv: %s enter", __FUNCTION__);

   std_strlprintf(server_name, MAX_NAME_LENGTH, "%s", server);
   IOCTL_SRV_MEMSET(&rattr, 0, sizeof (rattr)); /* using the defaults for rattr */
   rattr.nparts_max = 1;
   rattr.msg_max_size = sizeof(io_msg_type_t);

   iofunc_func_init (_RESMGR_CONNECT_NFUNCS, &devman.connect_funcs,
                     _RESMGR_IO_NFUNCS, &devman.io_funcs);

   IOCTL_SRV_MSG_LOW("ioctlSrv: iofunc_func_init called");

   devman.io_funcs.msg = dm_dev_msg;
   devman.io_funcs.write = dm_dev_write;

#if (_NTO_VERSION > 650)
   devman.io_funcs.acl = dm_dev_acl;
#endif

   /* Workaround to change to 0666. Should remove it after setfacl supported */
   iofunc_attr_init (&devman.attr, S_IFCHR | 0666, NULL, NULL);

   IOCTL_SRV_MSG_LOW("ioctlSrv: iofunc_attr_init called");

   devman.dpp = dispatch_create();
   if ( NULL == devman.dpp )
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: dispatch_create failed");
      status = -1;
      goto cleanup;
   }

   IOCTL_SRV_MSG_LOW("ioctlSrv: dispatch_create called");

   //devices->device.pGroupList = pGroupList;
   IOCTL_SRV_MSG_LOW("ioctlSrv: strlength(server) = %ld", strlen(server));

   std_strlprintf(path, PATH_MAX + 1, "/dev/%s/devmgr", server);
   IOCTL_SRV_MSG_LOW("ioctlSrv: path = %s for resmgr_attach", path);
   devman.pathID = resmgr_attach( devman.dpp, &rattr, path, _FTYPE_ANY, 0,
                             &devman.connect_funcs, &devman.io_funcs,
                             (RESMGR_HANDLE_T *) &devman );
   if ( -1 == devman.pathID )
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: resmgr_attach failed");
      status = -1;
      goto cleanup;
   }
   IOCTL_SRV_MSG_LOW("ioctlSrv: resmgr_attach called");

   if (-1 == (devman.chid = ChannelCreate(0)))
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: devman ChannelCreate failed");
      status = -1;
      goto cleanup;
   }

   if (-1 == (devman.coid = ConnectAttach(0, 0, devman.chid, _NTO_SIDE_CHANNEL, 0)))
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: devman ConnectAttach failed");
      status = -1;
      goto cleanup;
   }

   if ( 0 != MM_Thread_CreateEx ( MM_Thread_RealtimePriority, 0,
                                  msg_handler, NULL, IOCTL_SRV_THREAD_STACK_SIZE,
                                  MSG_THREAD_NAME, &devman.msg_thread ) )
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: devman thread creation failed");
      status = -1;
      goto cleanup;
   }

   devman.ctp = dispatch_context_alloc(devman.dpp);
   std_strlprintf(name, MAX_NAME_LENGTH, "%s-devmgr", server);
   IOCTL_SRV_MSG_LOW("ioctlSrv: dispatch_context_alloc called");
   if ( 0 != MM_Thread_CreateEx ( MM_Thread_RealtimePriority, 0,
                                  dm_dispatcher, devman.ctp, IOCTL_SRV_THREAD_STACK_SIZE,
                                  name, &devman.dm_thread ) )
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: devman dm_thread creation failed");
      status = -1;
      goto cleanup;
   }

   IOCTL_SRV_MSG_LOW("ioctlSrv: dm_dispatcher thread created");

   IOCTL_SRV_MSG_LOW("ioctlSrv: %s exit", __FUNCTION__);

   return 0;

cleanup:
   if ( devman.dpp )
   {
      dispatch_destroy(devman.dpp);
      devman.dpp = NULL;
   }
   if ( devman.ctp )
   {
      dispatch_context_free(devman.ctp);
      devman.ctp = NULL;
   }
   
   if ( devman.coid > 0 )
   {
      ConnectDetach(devman.coid);
      devman.coid = -1;
   }

   if ( devman.chid > 0 )
   {
      ChannelDestroy(devman.chid);
      devman.chid = -1;
   }

   return status;
}

int join_device_manager()
{
   IOCTL_SRV_MSG_LOW("ioctlSrv: %s enter", __FUNCTION__);

   if ( devman.msg_thread )
   {
      return MM_Thread_Join(devman.msg_thread, NULL);
   }

   if ( devman.dm_thread )
   {
      return MM_Thread_Join(devman.dm_thread, NULL);
   }

   return EOK;
}
