 /*===========================================================================

*//** @file ioctServerPriv.h
  This file declares datatypes and prototypes for ioctl server

Copyright (c) 2010 - 2017,2021 QUALCOMM Technologies, Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/


/*===========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/ioctl/ioctlServer/src/ioctlServerPriv.h#1 $

when       who        what, where, why
--------   --------   -------------------------------------------------------
07/13/21   dr         Fix static tool analysis issue
02/05/17   rz         Fix compilation warnings with printf format check
05/28/14   dp         Null out memory pointer after free
07/10/13   dp         Client authentication on ioctlServer
                      Create error log message
07/03/13   dp         Redirect msg from slog to QXDM video task
04/09/13   hc         Replace printf by slog
02/03/11   yugangz    Replace shared mem with mq
11/30/10   che        Initial version

============================================================================*/

#ifndef IOCT_SERVER_PRIV_H_
#define IOCT_SERVER_PRIV_H_

#include "AEEstd.h" /* std typedefs, ie. byte, uint16, uint32, etc. and memcpy, memset */
#include "MMMalloc.h"
#include "MMDebugMsg.h"

#define IOCTL_SRV_MSG_LOW( xx_fmt, ...)         MM_MSG_PRIO_EX(MM_VIDEO_TASK, MM_PRIO_LOW, xx_fmt, ## __VA_ARGS__)
#define IOCTL_SRV_MSG_ERROR( xx_fmt, ...)       MM_MSG_PRIO_EX(MM_VIDEO_TASK, MM_PRIO_ERROR, xx_fmt, ## __VA_ARGS__)

#define IOCTL_SRV_Malloc(n)                     MM_Malloc((n))
#define IOCTL_SRV_Free(p)                       { if((p)) MM_Free((p)); \
                                                  (p) = NULL; }

/* general utility for memory set and copy */
#define IOCTL_SRV_MEMSET(src, value, len)       std_memset((src), (value), (len))
#define IOCTL_SRV_MEMCPY(dest, src, len)        std_memmove((dest), (src), (len))

#define IOCTL_SRV_MIN(a, b)                     STD_MIN((a), (b))

#define IOCTL_SRV_THREAD_STACK_SIZE             (16*1024)

typedef struct ioctl_dcb_t ioctl_dcb_t;
typedef struct ioctl_ocb_t ioctl_ocb_t;
typedef struct ioctl_cb_msg_t ioctl_cb_msg_t;
typedef struct ioctl_device_node_t ioctl_device_node_t;

// multiple instances can be opened for the same physical device,
// each instance is considered as a seperate device with its own dcb.
struct ioctl_dcb_t
{
   iofunc_attr_t attr;
   dispatch_t* dpp;
   dispatch_context_t* ctp;
   resmgr_connect_funcs_t connect_funcs;
   resmgr_io_funcs_t io_funcs;

   int opened;    // true if open called to disable next open
   int devid;     // instance id of the device
   int linkid;    // linkid returned by resmgr_attach

   char devPathName[PATH_MAX + 1];
   ioctl_device_t* device;

   void* thread;

   int ref_cnt;
   volatile int done;

   ioctl_dcb_t* next;
};

typedef struct list_head list_head;
struct list_head
{
   list_head* next;
   list_head* prev;
};

#define list_add(new, prev, next) \
   (next)->prev = (new); \
   (new)->next = (next); \
   (new)->prev = (prev); \
   (prev)->next = (new);

#define list_del(node) \
   (node)->next->prev = (node)->prev; \
   (node)->prev->next = (node)->next;

struct ioctl_cb_msg_t
{
   list_head link;

   uint32 buf_size;        // buffer size;
   uint32 msg_size;        // msg size
   uint8* buffer;
};

// per open control block
struct ioctl_ocb_t
{
   iofunc_ocb_t ocb;

   uint8* rxBuf;
   uint32 rxSize;

   uint8* txBuf;
   uint32 txSize;

   IO_HANDLE drvHandle;    // device driver handle
   pid_t pid;
   int deliver_event;
   struct sigevent event;  // callback event

   list_head fq;           // free msg q
   list_head pq;           // pending msg q

   int rcvid;
   void* lock;

   unsigned int size;      // how many bytes the read can return
};

struct ioctl_device_node_t
{
   ioctl_device_t device;
   ioctl_dcb_t* dcbs;      // control block for for opened instances. for example vdec0, vdec1... etc

   uint32 count;
   ioctl_device_node_t* next;
};

extern char server_name[MAX_NAME_LENGTH];

extern ioctl_dcb_t* start_ioctl_device(ioctl_device_node_t* dnode);
extern int stop_ioctl_device(ioctl_dcb_t* dcb);
extern int send_device_detach(ioctl_dcb_t* dcb);
extern int add_dcb(ioctl_device_node_t* dnode, ioctl_dcb_t* dcb);
extern int del_dcb(ioctl_device_node_t* dnode, ioctl_dcb_t* dcb);

extern int resmgr_dispatcher(void* ctxt);
extern int start_device_manager(const char* server, void *pGroupList);
extern ioctl_device_node_t* find_device_by_name(const char* name);

#endif /* IOCTSERVERPRIV_H_ */
