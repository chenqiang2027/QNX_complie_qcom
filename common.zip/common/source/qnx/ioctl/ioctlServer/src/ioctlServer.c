/*===========================================================================

*//** @file ioctlServer.c
  This file implements the ioctl server

Copyright (c) 2010 - 2018, 2022 QUALCOMM Technologies, Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*==========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/ioctl/ioctlServer/src/ioctlServer.c#1 $

when       who        what, where, why
--------   --------   ------------------------------------------------------- 
02/22/22   xg         dispatch thread when device_open failed and revert previous change
10/12/21   yc         Ensure device dispatcher terminated even if device_open failed
01/02/18   rz         Fix MISRA warning 
02/05/17   rz         Fix compilation warnings with printf format check
10/25/16   rz         Suppport videoCore warm boot with dummy session with echo command
07/26/16   rz         Add debug msg for MsgDeliverEvent failure
06/22/16   am         Fix compiler warnings 
03/14/14   hc         Backward compatible for tools version 6.5 
08/01/13   dp         Do not pass session pointers across the processes.
07/30/13   dp         Temporarily disable ioctlserver authentication
07/10/13   dp         Client authentication on ioctlServer
06/21/13   rz         Added device_ping
04/19/13   rz         Changed RM creation flag to enable UI playback
04/16/13   uc         Removed warnings.
04/09/13   hc         Replace printf by slog
10/29/12   rz         Fixed incorrect buffer address update when realloc happens
04/02/12   am         Close the session if the client terminates.
02/27/12   sk         Fixed KW compiler warnings
07/22/11   dwp        Fixed leak when cancelling ioctl_device_loop
04/27/11   wyun       Adding thread naming
02/03/11   yugangz    Replace shared mem with mq
11/13/10   che        Initial version

============================================================================*/

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include <sys/neutrino.h>
#include <sys/iomsg.h>
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <process.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <mqueue.h>

#include "AEEstd.h" /* std typedefs, ie. byte, uint16, uint32, etc. and memcpy, memset */
#include "ioctlMsg.h"
#include "ioctlServer.h"
#include "ioctlServerPriv.h"
#include "MMThread.h"
#include "MMCriticalSection.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */
#define IOCTL_RX_TX_BUFF_SIZE                      (128)
/* Max elements of ngroups is 32 */
#define IOCTL_SRV_NGROUPS_MAX                      (32)

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
**                 FUNCTION DECLARATIONS
** ----------------------------------------------------------------------- */
static void put_free_msg(ioctl_ocb_t* ocb, ioctl_cb_msg_t* msg);
static ioctl_cb_msg_t* get_next_pending_msg(ioctl_ocb_t* ocb);
static int ioctl_server_verify_client(resmgr_context_t *ctp, void *pGroupList);
static int get_next_devid(ioctl_device_node_t* dnode);
static ioctl_cb_msg_t* get_free_msg(ioctl_ocb_t* ocb, uint32 size);

/*===========================================================================

                        FUNCTION DEFINITIONS

===========================================================================*/

static IOFUNC_OCB_T * ioctl_ocb_calloc (resmgr_context_t *ctp, IOFUNC_ATTR_T *attr)
{
   struct ioctl_ocb_t *ocb = calloc(1, sizeof(*ocb));

   if ( NULL == ocb )
   {
      return NULL;
   }

   /* allocate buffers */
   ocb->rxSize = IOCTL_RX_TX_BUFF_SIZE;
   ocb->txSize = IOCTL_RX_TX_BUFF_SIZE;
   ocb->rxBuf = IOCTL_SRV_Malloc(ocb->rxSize);
   ocb->txBuf = IOCTL_SRV_Malloc(ocb->txSize);

   if ( ocb->rxBuf == NULL || ocb->txBuf == NULL )
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: out of memory");
      if ( ocb->rxBuf )
      {
         IOCTL_SRV_Free(ocb->rxBuf);
      }
      if ( ocb->txBuf )
      {
         IOCTL_SRV_Free(ocb->txBuf);
      }
      free(ocb);
      ocb = NULL;
   }
   else
   {
      MM_CriticalSection_Create(&ocb->lock);
      ocb->fq.next = ocb->fq.prev = &ocb->fq;
      ocb->pq.next = ocb->pq.prev = &ocb->pq;
   }

   return ((IOFUNC_OCB_T*)ocb);
}

static void ioctl_ocb_free (IOFUNC_OCB_T *ocbp)
{
   ioctl_ocb_t *ocb = (ioctl_ocb_t *)ocbp;
   ioctl_cb_msg_t* msg = NULL;

   if (ocb->rxBuf)
   {
      IOCTL_SRV_Free(ocb->rxBuf);
   }
   if (ocb->txBuf)
   {
      IOCTL_SRV_Free(ocb->txBuf);
   }
   ocb->rxBuf = NULL;
   ocb->rxSize = 0;
   ocb->txBuf = NULL;
   ocb->txSize = 0;

   while ( ocb->fq.next != &(ocb->fq) )
   {
      msg = (ioctl_cb_msg_t *)ocb->fq.next;
      list_del(&msg->link);

      IOCTL_SRV_Free(msg);
   }

   while ( ocb->pq.next != &(ocb->pq) )
   {
      msg = (ioctl_cb_msg_t *)ocb->pq.next;
      list_del(&msg->link);

      IOCTL_SRV_Free(msg);
   }
   if ( ocb->lock )
   {
      MM_CriticalSection_Release(ocb->lock);
   }
   free(ocb);
   ocb = NULL;
}

static iofunc_funcs_t ioctl_ocb_funcs =
{
   _IOFUNC_NFUNCS,
   ioctl_ocb_calloc,
   ioctl_ocb_free
};

static iofunc_mount_t ioctl_mount =
{
   0, 0, 0, 0, &ioctl_ocb_funcs
};

static int device_io_close_ocb(resmgr_context_t *ctp, void *reserved, RESMGR_OCB_T *ocbp)
{
   ioctl_ocb_t* ocb = (ioctl_ocb_t*)ocbp;
   ioctl_dcb_t* dcb = (ioctl_dcb_t*)ocbp->attr;

   if ( ocb->drvHandle )
   {
      if ( dcb->device->vtbl.close )
      {
         dcb->device->vtbl.close(ocb->drvHandle);
      }

      dcb->done = 1;
   }

   return (iofunc_close_ocb_default (ctp, reserved, ocbp));
}

static int device_io_read
(
   resmgr_context_t  *ctp,
   io_read_t         *msg,
   RESMGR_OCB_T      *ocbp
)
{
   ioctl_ocb_t* ocb = (ioctl_ocb_t*)ocbp;
   ioctl_dcb_t* dcb = (ioctl_dcb_t*)ocbp->attr;
   int status = EOK;
   int nBytes = 0;
   int nLeft = 0;

   status = iofunc_read_verify (ctp, msg, ocbp, NULL);
   if ( EOK != status )
   {
      return (status);
   }
   if ( _IO_XTYPE_NONE != (msg->i.xtype & _IO_XTYPE_MASK) )
   {
      return (ENOSYS);
   }
   if ( NULL == dcb->device->vtbl.read )
   {
      return (ENOSYS);
   }

   if ( 0 == ocb->size )
   {
      ocb->size = dcb->device->vtbl.read(ocb->drvHandle, NULL, 0);
   }

   nLeft = ocb->size - ocbp->offset;
   nBytes = IOCTL_SRV_MIN (nLeft, msg->i.nbytes);

   if ( nBytes )
   {
      uint8* pBuff = (uint8*)IOCTL_SRV_Malloc(nBytes);

      if ( NULL == pBuff )
      {
         return (ENOMEM);
      }
      nBytes = dcb->device->vtbl.read(ocb->drvHandle, pBuff, nBytes);

      /* return it to the client */
      MsgReply (ctp->rcvid, nBytes, pBuff, nBytes);
      IOCTL_SRV_Free(pBuff);

      /* update flags and offset */
      ocbp->attr->flags |= IOFUNC_ATTR_ATIME | IOFUNC_ATTR_DIRTY_TIME;
      ocbp->offset += nBytes;
   }
   else
   {
      /* nothing to return, indicate End Of File */
      MsgReply (ctp->rcvid, EOK, NULL, 0);
   }

   /* already done the reply ourselves */
   return (_RESMGR_NOREPLY);
}

static int device_io_write
(
   resmgr_context_t  *ctp,
   io_write_t        *msg,
   RESMGR_OCB_T      *ocbp
)
{
   ioctl_ocb_t *ocb = (ioctl_ocb_t*)ocbp;
   ioctl_dcb_t *dcb = (ioctl_dcb_t*)ocbp->attr;
   int         status = EOK;
   char        *pBuff = NULL;

   status = iofunc_write_verify (ctp, msg, ocbp, NULL);
   if ( EOK != status )
   {
      return (status);
   }
   if ( _IO_XTYPE_NONE != (msg->i.xtype & _IO_XTYPE_MASK) )
   {
      return (ENOSYS);
   }
   if ( NULL == dcb->device->vtbl.write )
   {
      return (ENOSYS);
   }

   pBuff = (char *) IOCTL_SRV_Malloc(msg->i.nbytes + 1);
   if ( NULL == pBuff )
   {
      return (ENOMEM);
   }
   _IO_SET_WRITE_NBYTES (ctp, msg->i.nbytes);

   /*
    *  Reread the data from the sender's message buffer.
    *  We're not assuming that all of the data fit into the
    *  resource manager library's receive buffer.
    */
   resmgr_msgread(ctp, pBuff, msg->i.nbytes, sizeof(msg->i));
   pBuff [msg->i.nbytes] = '\0'; /* just in case the text is not NULL terminated */
   dcb->device->vtbl.write(ocb->drvHandle, (uint8*)pBuff, msg->i.nbytes);
   if ( msg->i.nbytes > 0 )
   {
      ocbp->attr->flags |= IOFUNC_ATTR_MTIME | IOFUNC_ATTR_CTIME;
   }
   IOCTL_SRV_Free(pBuff);

   return (_RESMGR_NPARTS(0));
}

static int device_io_msg
(
   resmgr_context_t  *ctp,
   io_msg_t          *msgp,
   RESMGR_OCB_T      *ocbp
)
{
   ioctl_ocb_t    *ocb = (ioctl_ocb_t*)ocbp;
   ioctl_dcb_t    *dcb = (ioctl_dcb_t*)ocbp->attr;
   io_msg_type_t  msg;
   int            status = 0;
   int            nBytes = 0;

   nBytes = MsgRead(ctp->rcvid, &msg, sizeof(msg), 0);
   if ( -1 == nBytes )
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: MsgRead failed");
      MsgError(ctp->rcvid, EIO);
   }

   if ( MSG_TYPE_OPEN == msg.buf.hdr.type )
   {
      /* Authenticate */
      if ( EOK != ioctl_server_verify_client(ctp, dcb->device->pGroupList) )
      {
         IOCTL_SRV_MSG_ERROR("ioctlSrv: client is not privileged!");
         status = MsgError(ctp->rcvid, EACCES);
      }
      else
      {
         IO_HANDLE handle = NULL;

         ocb->pid = msg.buf.open.pid;
         ocb->deliver_event = msg.buf.open.deliver_event;
         ocb->event = msg.buf.open.event;

         handle = dcb->device->vtbl.open((ioctl_session_t*)ocb);

         ocb->drvHandle = handle;
         ocb->rcvid = ctp->rcvid;

         if ( NULL == handle )
         {
            dcb->done = 1;
            status = MsgError(ctp->rcvid, ENOMEM);
         }
         else
         {
             MsgReply(ctp->rcvid, EOK, NULL, 0);
         }
      }
   }
   else if ( MSG_TYPE_IOCTL == msg.buf.hdr.type )
   {
      uint8* aRxBuf = ocb->rxBuf;
      uint8* aTxBuf = ocb->txBuf;

      /* Check if there is INPUT data from the message */
      if ( msg.buf.hdr.inSize > ocb->rxSize )
      {
         uint8 *aNewBuf = (uint8 *) realloc(ocb->rxBuf, msg.buf.hdr.inSize);

         if ( NULL == aNewBuf )
         {
            IOCTL_SRV_MSG_ERROR("ioctlSrv: Rx realloc failed");
            aRxBuf = NULL;
            status = MsgError(ctp->rcvid, ENOMEM);
         }
         else
         {
            aRxBuf = aNewBuf;
            ocb->rxBuf = aNewBuf;
            ocb->rxSize = msg.buf.hdr.inSize;
         }
      }

      if ( msg.buf.hdr.outSize > ocb->txSize )
      {
         uint8 *aNewBuf = (uint8 *) realloc(ocb->txBuf, msg.buf.hdr.outSize);

         if ( NULL == aNewBuf )
         {
            IOCTL_SRV_MSG_ERROR("ioctlSrv: Tx realloc failed");
            aTxBuf = NULL;
            status = MsgError(ctp->rcvid, ENOMEM);
         }
         else
         {
            aTxBuf = aNewBuf;
            ocb->txBuf = aNewBuf;
            ocb->txSize = msg.buf.hdr.outSize;
         }
      }

      if ( msg.buf.hdr.inSize && aRxBuf )
      {
         /* Read the INPUT data */
         nBytes = MsgRead(ctp->rcvid, aRxBuf, msg.buf.hdr.inSize, sizeof(io_msg_type_t));
      }
      if ( -1 == nBytes )
      {
         IOCTL_SRV_MSG_ERROR("ioctlSrv: MsgRead failed");
         status = MsgError(ctp->rcvid, EFAULT);
      }
      else if ( aRxBuf && aTxBuf && ocb->drvHandle && dcb->device->vtbl.ioctl )
      {
         status = dcb->device->vtbl.ioctl(ocb->drvHandle,
                                          msg.buf.ioctl.command,
                                          aRxBuf, msg.buf.hdr.inSize,
                                          aTxBuf, msg.buf.hdr.outSize, (uint32*) &nBytes);
         status = MsgReply(ctp->rcvid, status, aTxBuf, nBytes);
      }
   }
   else if ( MSG_TYPE_PING == msg.buf.hdr.type )
   {
      uint8* aRxBuf = ocb->rxBuf;

      /* Check if there is INPUT data from the message */
      if (msg.buf.hdr.inSize > ocb->rxSize)
      {
         uint8 *aNewBuf = (uint8 *) realloc(ocb->rxBuf, msg.buf.hdr.inSize);

         if ( NULL == aNewBuf )
         {
            IOCTL_SRV_MSG_ERROR("ioctlSrv: Rx realloc failed");
            aRxBuf = NULL;
            status = MsgError(ctp->rcvid, ENOMEM);
         }
         else
         {
            aRxBuf = aNewBuf;
            ocb->rxBuf = aNewBuf;
            ocb->rxSize = msg.buf.hdr.inSize;
         }
      }

      if ( msg.buf.hdr.inSize && aRxBuf )
      {
         /* Read the INPUT data */
         nBytes = MsgRead(ctp->rcvid, aRxBuf, msg.buf.hdr.inSize, sizeof(io_msg_type_t));
      }
      if ( -1 == nBytes )
      {
         IOCTL_SRV_MSG_ERROR("ioctlSrv: MsgRead failed");
         status = MsgError(ctp->rcvid, EFAULT);
      }
      else if ( aRxBuf && ocb->drvHandle && dcb->device->vtbl.ping )
      {
         status = MsgReply(ctp->rcvid, EOK, NULL, 0);

         status = dcb->device->vtbl.ping(ocb->drvHandle,
                                         msg.buf.ioctl.command,
                                         aRxBuf, msg.buf.hdr.inSize);
      }
   }
   else if ( MSG_TYPE_GET_CB_MSG == msg.buf.hdr.type )
   {
      /* read the next cb msg */
      ioctl_cb_msg_t* cbmsg = get_next_pending_msg(ocb);

      if ( cbmsg && cbmsg->msg_size <= msg.buf.hdr.outSize )
      {
         status = MsgReply(ctp->rcvid, cbmsg->msg_size, cbmsg->buffer, cbmsg->msg_size);
      }
      else
      {
         status = MsgReply(ctp->rcvid, EOK, NULL, 0);
      }

      /* reuse the msg buffer */
      if ( cbmsg )
      {
         put_free_msg(ocb, cbmsg);
      }
   }
   else
   {
      /* ignore unknown message queries */
      status = MsgReply(ctp->rcvid, ENOSYS, NULL, 0);
   }

   return (_RESMGR_NOREPLY);
}
#if (_NTO_VERSION > 650)
static int device_io_acl(resmgr_context_t *ctp, io_acl_t *msg, IOFUNC_OCB_T *ocb_t)
{
   return iofunc_acl(ctp, msg, ocb_t, (iofunc_attr_t*)ocb_t->attr);
}
#endif
static int get_next_devid(ioctl_device_node_t* dnode)
{
   ioctl_dcb_t* curr = dnode->dcbs;
   int devid = 1;

   /* dcb are added in the increasing order of the devid */
   curr = dnode->dcbs;
   while ( curr )
   {
      if ( curr->devid == devid )
      {
         devid++;
      }
      else
      {
         break;
      }

      curr = curr->next;
   }

   return devid;
}

static int ioctl_device_dispatcher(void* dcbp)
{
   int         sts = EOK;
   ioctl_dcb_t *dcb = (ioctl_dcb_t*)dcbp;

   while ( !dcb->done )
   {
      dispatch_context_t* ctp = dispatch_block (dcb->ctp);

      if ( ctp )
      {
         dispatch_handler(ctp);
      }
      else if (errno != EFAULT)
      {
         IOCTL_SRV_MSG_ERROR("ioctlSrv: error exiting");
         break;
      }
   }

   sts = resmgr_detach(dcb->dpp, dcb->linkid, _RESMGR_DETACH_ALL );
   dispatch_context_free(dcb->ctp);
   if ( EOK == sts )
   {
      sts = dispatch_destroy(dcb->dpp);
   }
   if ( EOK != sts )
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: failed to dispatch_destroy");
   }

   send_device_detach(dcb);
   return 0;
}

static int ioctl_server_verify_client(resmgr_context_t *ctp, void *pGroupList)
{
#if defined( _AUTHENTICATE_ )

   struct _client_info  *pClientInfo;
   gid_t                *pGroupIdList = (gid_t *)pGroupList;
   int                  nRetVal = EACCES;

   IOCTL_SRV_MSG_LOW("ioctl_server_verify_client: entry; pid = 0x%x", ctp->info.pid);

   if ( ( NULL == pGroupList ) ||
        ( pGroupIdList[0] > IOCTL_SRV_NGROUPS_MAX ) )
   {
      IOCTL_SRV_MSG_ERROR("ioctl_server_verify_client: Invalid group list 0x%p, ngroups %d", pGroupIdList, ( NULL == pGroupList ) ? 0 : pGroupIdList[0]);
   }
   else
   {
      if ( EOK != iofunc_client_info_ext(ctp, 0/*O_REALIDS*/, &pClientInfo, _NTO_CLIENTINFO_GETGROUPS) )
      {
         IOCTL_SRV_MSG_ERROR("ioctl_server_verify_client: ConnectClientInfoExt failed with error %d: %s", errno, strerror(errno));
         nRetVal = EINVAL;
      }
      else
      {
         /* Non root need to authenticate */
         if ( pClientInfo->cred.egid != 0 )
         {
            uint32 nAaIndex;

            for ( nAaIndex = 1; ( nAaIndex < ( pGroupIdList[0] + 1 ) ) &&
                                ( EOK != nRetVal ); nAaIndex++ )
            {
               if ( pGroupIdList[nAaIndex] == pClientInfo->cred.suid )
               {
                  /* Exit authenticate for loop */
                  IOCTL_SRV_MSG_LOW("ioctl_server_verify_client: got a match!");
                  nRetVal = EOK;
               } /* End if correct group */
            }
         }
         else
         {
            /* Allow process from root */
            nRetVal = EOK;
         }
         iofunc_client_info_ext_free(&pClientInfo);
         pClientInfo = NULL;
      }
   }

#else

   int nRetVal = EOK;

#endif

   return ( nRetVal );
}

ioctl_dcb_t* start_ioctl_device(ioctl_device_node_t* dnode)
{
   resmgr_attr_t  rattr;
   char           *pThreadName = NULL;
   ioctl_dcb_t    *dcb;

   dcb = (ioctl_dcb_t*)IOCTL_SRV_Malloc(sizeof(ioctl_dcb_t));

   if ( NULL == dcb )
   {
      return NULL;
   }

   IOCTL_SRV_MEMSET(dcb, 0, sizeof(ioctl_dcb_t));
   dcb->devid = get_next_devid(dnode);
   std_strlprintf(dcb->devPathName, PATH_MAX + 1, "/dev/%s/%s%d",
                  server_name, dnode->device.name, dcb->devid);

   dcb->linkid = -1;
   dcb->device = &dnode->device;
   dcb->dpp = dispatch_create();

   if ( NULL == dcb->dpp )
   {
      goto cleanup;
   }

   IOCTL_SRV_MEMSET(&rattr, 0, sizeof (rattr)); /* using the defaults for rattr */
   //rattr.nparts_max = 2;
   //rattr.msg_max_size = 4096;
   rattr.nparts_max = 1;
   rattr.msg_max_size = sizeof(io_msg_type_t);

   iofunc_func_init (_RESMGR_CONNECT_NFUNCS, &dcb->connect_funcs, _RESMGR_IO_NFUNCS, &dcb->io_funcs);
   // dcb->connect_funcs.open = device_io_open;
   dcb->io_funcs.close_ocb = device_io_close_ocb;
   dcb->io_funcs.read = device_io_read;
   dcb->io_funcs.write = device_io_write;
   dcb->io_funcs.msg = device_io_msg;
   
#if (_NTO_VERSION > 650)
   dcb->io_funcs.acl = device_io_acl;
#endif
   /* Workaround to change to 0666. Should remove it after setfacl supported*/
   iofunc_attr_init(&dcb->attr, S_IFCHR | 0666, NULL, NULL);
   dcb->attr.mount = &ioctl_mount;

#if (_NTO_VERSION > 650)
   iofunc_acl_init(&dcb->attr, iofunc_acl_posix_ctrl, 0);
#endif
   dcb->linkid = resmgr_attach( dcb->dpp, &rattr, dcb->devPathName, _FTYPE_ANY, 0,
                                &dcb->connect_funcs, &dcb->io_funcs, (RESMGR_HANDLE_T *)&dcb->attr );
   if ( -1 == dcb->linkid )
   {
      goto cleanup;
   }

   dcb->ctp = dispatch_context_alloc(dcb->dpp);

   if ( NULL == dcb->ctp )
   {
      goto cleanup;
   }

   pThreadName = std_strrchr(dcb->devPathName, '/') + 1;
   if ( 0 != MM_Thread_CreateEx ( dcb->device->priority, 0,
                                  ioctl_device_dispatcher, dcb, dcb->device->stackSize,
                                  pThreadName, &dcb->thread ) )
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: IOCTL DEVICE MANAGER thread creation failed");
      goto cleanup;
   }

   return dcb;

cleanup:
   if ( -1 != dcb->linkid )
   {
      resmgr_detach(dcb->dpp, dcb->linkid, _RESMGR_DETACH_ALL);
      dcb->linkid = -1;
   }
   if ( dcb->ctp )
   {
      dispatch_context_free(dcb->ctp);
   }
   if ( dcb->dpp )
   {
      dispatch_destroy(dcb->dpp);
   }
   IOCTL_SRV_Free(dcb);
   dcb = NULL;

   return NULL;
}

int stop_ioctl_device(ioctl_dcb_t* dcb)
{
   int status = 0;

   status = MM_Thread_Release(dcb->thread);

   if ( 0 != status )
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: MM_Thread_Release failed");
      return status;
   }
   status = del_dcb((ioctl_device_node_t*)dcb->device, dcb);
   if ( 0 != status )
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: del_dcb failed");
      return status;
   }
   IOCTL_SRV_Free(dcb);
   return 0;
}

static ioctl_cb_msg_t* get_free_msg(ioctl_ocb_t* ocb, uint32 size)
{
   list_head      *buf = NULL;
   ioctl_cb_msg_t *msg = NULL;

   /* reuse a msg buffer if there is one with proper size */
   MM_CriticalSection_Enter(ocb->lock);
   buf = ocb->fq.next;
   while ( buf != &ocb->fq )
   {
      msg = (ioctl_cb_msg_t*)buf;
      if ( msg->buf_size >= size )
      {
         list_del(buf);
         break;
      }
      buf = buf->next;
   }
   MM_CriticalSection_Leave(ocb->lock);

   if ( NULL == msg )
   {
      /* allocate a new msg */
      msg = (ioctl_cb_msg_t*)IOCTL_SRV_Malloc(sizeof(ioctl_cb_msg_t)+size);
   }
   if ( msg )
   {
      msg->buf_size = size;
      msg->buffer = (uint8*)(msg + 1);
      msg->msg_size = 0;
   }

   return msg;
}

static void put_free_msg(ioctl_ocb_t* ocb, ioctl_cb_msg_t* msg)
{
   list_head      *prev = NULL;
   list_head      *next = NULL;
   ioctl_cb_msg_t *curr = NULL;

   MM_CriticalSection_Enter(ocb->lock);
   prev = &ocb->fq;
   next = ocb->fq.next;

   while ( next != &ocb->fq )
   {
      curr = (ioctl_cb_msg_t*)next;
      if ( curr->buf_size <= msg->buf_size )
      {
         break;
      }
      prev = next;
      next = next->next;
   }

   list_add(((list_head*)msg), prev, next);
   MM_CriticalSection_Leave(ocb->lock);
}

ioctl_cb_msg_t* get_next_pending_msg(ioctl_ocb_t* ocb)
{
   ioctl_cb_msg_t *msg = NULL;

   MM_CriticalSection_Enter(ocb->lock);
   if ( ocb->pq.next != &ocb->pq )
   {
      msg = (ioctl_cb_msg_t*)ocb->pq.next;
      list_del((list_head*)msg);
   }
   MM_CriticalSection_Leave(ocb->lock);

   return msg;
}

int send_callback_messaage
(
   ioctl_session_t   *aIoSession,
   uint8             *aCallbackMsg,
   uint32            aMsgLength
)
{
   ioctl_ocb_t    *ocb = (ioctl_ocb_t *)aIoSession;
   ioctl_cb_msg_t *msg = NULL;
   list_head      *prev = NULL;
   list_head      *next = NULL;

   msg = get_free_msg(ocb, aMsgLength);
   if ( NULL == msg )
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: out of memory");
      return -1;
   }
   IOCTL_SRV_MEMCPY(msg->buffer, aCallbackMsg, aMsgLength);
   msg->msg_size = aMsgLength;

   /* add this callback to the tail of the pending q */
   MM_CriticalSection_Enter(ocb->lock);
   next = &(ocb->pq);
   prev = next->prev;
   list_add( (&(msg->link)), prev, next);
   MM_CriticalSection_Leave(ocb->lock);

   if ( -1 == MsgDeliverEvent(ocb->rcvid, &ocb->event) )
   {
      IOCTL_SRV_MSG_ERROR("ioctlSrv: MsgDeliverEvent failed %s", strerror(errno));
      return -1;
   }

   return 0;
}

pid_t ioctl_server_get_client_pid(ioctl_session_t* aIoSession)
{
   if ( NULL == aIoSession  ) 
   {
      return 0;
   }
   else
   {
      ioctl_ocb_t* ocb = (ioctl_ocb_t *)aIoSession;
      return ocb->pid;
   }

}
