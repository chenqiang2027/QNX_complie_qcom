/*===========================================================================

*//** @file ioctlClient_shim.c
  This file implements the ioctl client

  Copyright (c) 2009-2018,2021 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
  QUALCOMM Proprietary. Export of this technology or software is regulated
  by the U.S. Government, Diversion contrary to U.S. law prohibited.
*//*========================================================================*/


/*===========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/1.0/source/qnx/ioctl/ioctlClient/shim/src/ioctlClient_shim.c#none $

when        who       what, where, why
--------   --------   -------------------------------------------------------
03/17/21     sw       Fix static analysis tool reported issues
01/02/18     rz       Fix MISRA warning 
10/04/17     sm       Update hypervisor intercept lib location on target
09/19/17     sm       Simplify detection of loading video hypervisor intercept lib
05/18/17     sm       Link to hypervisor intercept lib when QNX is a guest
02/05/17     rz       Fix compilation warnings with printf format check
08/03/16     rz       Dynamically loading hypervisor or native ioctl lib 
06/22/16     am       Fix compiler warnings in 64 bit environment.
11/05/13     am       Fix function name in function header comment.
10/24/13     rs       Added device_get_last_error function
06/21/13     rz       Added device_ping
04/08/13     am       Use mutex for global variables protection.
03/06/13     am       Clear global variables once library is unloaded if 
                      device_open fails.
01/12/13     am       Unload library when no clients.
11/06/12     sk       Added mode for opening library
10/29/12     sk       Initial version

============================================================================*/
#include <string.h>
#include <dlfcn.h>
#include <pthread.h>
#include <unistd.h>

#include "comdef.h"
#include "ioctlClient.h"
#include "ioctlClient_shimPriv.h"
#include "qmmUtils.h"

static IOCTL_CLT_LIB_HANDLE  g_hICLib;
static struct ioctl_clt_fn_t g_hICFnTbl;
static int gRefCnt = 0;
#define IOCTL_CLT_LIB "ioctlClient"

#define VIDEO_IOCTL_METAL_CLT_LIB "libioctlClient.so"
#define VIDEO_IOCTL_HYP_CLT_LIB "libhypv_intercept.so"
#define VIDEO_HYP_DOMU_SIGNATURE "/lib64/"VIDEO_IOCTL_HYP_CLT_LIB

static pthread_mutex_t gioctlClientCS = PTHREAD_MUTEX_INITIALIZER;

/* -----------------------------------------------------------------------
**                 FUNCTION DECLARATIONS
** ----------------------------------------------------------------------- */

static int device_load(void);

/*===========================================================================

                        FUNCTION DEFINITIONS

===========================================================================*/


/*==========================================================================

         FUNCTION:      device_load

         DESCRIPTION:
*//**       This function will load asic specific lib

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out]
*//**       @param[in]

**//*     RETURN VALUE:
*//**       @return  : Returns status, 0 for success & 1 for failure

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static int device_load()
{
   // Temporary library loading detection for video-only. Will need to refactor it when uname() is supported

   /* Load dependent ioctl lib in metal or hypervisor */
   bool bLoadHypIoctlLib = false;

   // load hypervisor intercept libs for domU and dom0/PVM/metal emulation 
   // dom0/PVM - need to pull in libhyp_video_fe.so, libhypv_intercept.so and
   //              libhabmm.so to target and create /base/etc/VIDEO_HYP_TEST on target 
   // metal - need to pull in hyp_video_be, libhyp_video_fe.so, libhypv_intercept.so and
   //           libhabmm.so to target and create /base/etc/VIDEO_HYP_TEST on target 
   if ( !access((char *)VIDEO_HYP_DOMU_SIGNATURE, R_OK) )
   {
      bLoadHypIoctlLib = true;
   }

   if ( bLoadHypIoctlLib  )
   {
      g_hICLib = qmmUtil_LoadLib_Ex(VIDEO_IOCTL_HYP_CLT_LIB, QMM_MODE_LOCAL);
   }
   else
   {
      g_hICLib = qmmUtil_LoadLib_Ex(VIDEO_IOCTL_METAL_CLT_LIB, QMM_MODE_LOCAL);
   }


  if (NULL == g_hICLib)
  {
    IOCTL_SHIM_MSG_ERROR("ioctlClientShim::device_load:failed in opening %s lib bLoadHypIoctlLib %d",
                 bLoadHypIoctlLib?VIDEO_IOCTL_HYP_CLT_LIB:VIDEO_IOCTL_METAL_CLT_LIB, bLoadHypIoctlLib);
    return 1;
  }

  IOCTL_SHIM_MSG_HIGH("ioctlClientShim::device_loaded %s lib bLoadHypIoctlLib %d",
                  bLoadHypIoctlLib?VIDEO_IOCTL_HYP_CLT_LIB:VIDEO_IOCTL_METAL_CLT_LIB, bLoadHypIoctlLib);

  /*  get ioctl client lib  symbols*/
  memset(&g_hICFnTbl, 0x0, sizeof(g_hICFnTbl));

  g_hICFnTbl.ioctl_device_open  = qmmUtil_MapLibSym( g_hICLib, "device_open" );
  g_hICFnTbl.ioctl_device_close = qmmUtil_MapLibSym( g_hICLib, "device_close" );
  g_hICFnTbl.ioctl_device_read  = qmmUtil_MapLibSym( g_hICLib, "device_read" );
  g_hICFnTbl.ioctl_device_write = qmmUtil_MapLibSym( g_hICLib, "device_write" );
  g_hICFnTbl.ioctl_device_ioctl = qmmUtil_MapLibSym( g_hICLib, "device_ioctl" );
  g_hICFnTbl.ioctl_device_ping  = qmmUtil_MapLibSym( g_hICLib, "device_ping" );

  if((NULL == g_hICFnTbl.ioctl_device_open)
     || (NULL == g_hICFnTbl.ioctl_device_close)
     || (NULL == g_hICFnTbl.ioctl_device_write)
     || (NULL == g_hICFnTbl.ioctl_device_ioctl) 
     || (NULL == g_hICFnTbl.ioctl_device_ping))
  {
     IOCTL_SHIM_MSG_ERROR("ioctlClientShim::device_load: qmmUtil_MapLibSym failed for lib %s !!",
                    IOCTL_CLT_LIB);
     qmmUtil_UnloadLib(g_hICLib);
     g_hICLib = NULL;
     memset(&g_hICFnTbl, 0x0, sizeof(g_hICFnTbl));

     return 1;
  }
  IOCTL_SHIM_MSG_HIGH("ioctlClientShim::device_load: open %s succeeded: g_hICLib: 0x%p  g_hICFnTbl: 0x%p",
                 IOCTL_CLT_LIB, g_hICLib, &g_hICFnTbl);

  return 0;

}

/*==========================================================================

         FUNCTION:      device_load

         DESCRIPTION:
*//**       This function will load asic specific lib

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out]
*//**       @param[in]  name
*//**       @param[in]  callback

**//*     RETURN VALUE:
*//**       @return  : Returns ptr to the ioctl session (ioctl_session_t) for success OR NULL for failure

@par     SIDE EFFECTS:
                        None

===========================================================================*/
ioctl_session_t* device_open(char* name, ioctl_callback_t* callback)
{
  ioctl_session_t* pSession = NULL;

  pthread_mutex_lock(&gioctlClientCS);

  /* Check if lib is loaded */
  if (NULL == g_hICLib)
  {
    if (device_load())
    {
       IOCTL_SHIM_MSG_ERROR("ioctlClientShim::device_open: device_load failed");
       pthread_mutex_unlock(&gioctlClientCS);
       return NULL;
    }
  }
  else
  {
    IOCTL_SHIM_MSG_HIGH("ioctlClientShim::device_open: %s already loaded g_hICLib: 0x%p  g_hICFnTbl: 0x%p",
           IOCTL_CLT_LIB, g_hICLib, &g_hICFnTbl);
  }
  
  pSession = g_hICFnTbl.ioctl_device_open(name,callback);

  if (NULL != pSession)
  {
     gRefCnt++;
  }
  else
  {
     /* if first client ioctl_device_open failed, unload ioctl client library */
     if ( 0 == gRefCnt )
     {
        int sts;
        sts = qmmUtil_UnloadLib(g_hICLib);

        if (sts)
        {
          IOCTL_SHIM_MSG_ERROR("ioctlClientShim::device_close: Failed to unload ioctlClient library");
        }
        else
        {
            g_hICLib = NULL;
            memset(&g_hICFnTbl, 0x0, sizeof(g_hICFnTbl));
        }
     }
  }
  
  pthread_mutex_unlock(&gioctlClientCS);
  
  return pSession;
}

/*==========================================================================

         FUNCTION:      device_close

         DESCRIPTION:
*//**       This function will close asic specific lib

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out]
*//**       @param[in]  aIoSession

**//*     RETURN VALUE:
*//**       @return  : Returns 0 for success OR -1 for failure

@par     SIDE EFFECTS:
                        None

===========================================================================*/
int device_close(ioctl_session_t* aIoSession)
{
   int retSts = 0;

   pthread_mutex_lock(&gioctlClientCS);

  /* Check if lib is loaded */
  if (NULL == g_hICLib)
  {
    IOCTL_SHIM_MSG_ERROR("ioctlClientShim::device_close: Failed !!");
    retSts = -1;
  }
  
  if ( (gRefCnt > 0) && (0 == retSts))
  {
     gRefCnt--;
     
     retSts = g_hICFnTbl.ioctl_device_close(aIoSession);

     if ( 0 != retSts )
     { 
       IOCTL_SHIM_MSG_ERROR("ioctlClientShim::device_close: ioctl_device_close Failed ");
     }	 
	 
    // best effort clean up as there is no recovery from close failure
    if ( 0 == gRefCnt )
    {
       int sts;
       
       sts = qmmUtil_UnloadLib(g_hICLib);

       if ( sts )
       {
         IOCTL_SHIM_MSG_ERROR("ioctlClientShim::device_close: Failed to unload ioctlClient library");
         retSts = -1;
         
         // increment reference count to indicate the library is still loaded.
         gRefCnt++;
       }
       else
       {
         g_hICLib = NULL;
         memset(&g_hICFnTbl, 0x0, sizeof(g_hICFnTbl));
       }
    }
  }
  pthread_mutex_unlock(&gioctlClientCS);
  return (retSts);
}

/*==========================================================================

         FUNCTION:      device_read

         DESCRIPTION:
*//**       This function will read msg from server

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out]
*//**       @param[in]  aIoSession
*//**       @param[in]  aBuf
*//**       @param[in]  aBufSize


**//*     RETURN VALUE:
*//**       @return  : Returns 0 success OR -1 for failure

@par     SIDE EFFECTS:
                        None

===========================================================================*/
int device_read
(
    ioctl_session_t* aIoSession,
    uint8 *aBuf,
    uint32 aBufSize
)
{
   int sts = 0;
  
  pthread_mutex_lock(&gioctlClientCS);
   
   /* Check if lib is loaded */
   if (NULL == g_hICLib)
   {
     IOCTL_SHIM_MSG_ERROR("ioctlClientShim::device_read: Failed !!");
     sts = -1;
   }

   if (0 == sts)
   {
      sts = g_hICFnTbl.ioctl_device_read(aIoSession, aBuf, aBufSize);
   }

   pthread_mutex_unlock(&gioctlClientCS);

   return sts;
}

/*==========================================================================

         FUNCTION:      device_write

         DESCRIPTION:
*//**       This function will write msg to server

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out]
*//**       @param[in]  aIoSession
*//**       @param[in]  aBuf
*//**       @param[in]  aBufSize


**//*     RETURN VALUE:
*//**       @return  : Returns 0 for success OR -1 for failure

@par     SIDE EFFECTS:
                        None

===========================================================================*/
int device_write
(
    ioctl_session_t* aIoSession,
    uint8 *aBuf,
    uint32 aBufSize
)
{
  int sts = 0;
  
  pthread_mutex_lock(&gioctlClientCS);

  /* Check if lib is loaded */
  if (NULL == g_hICLib)
  {
    IOCTL_SHIM_MSG_ERROR("ioctlClientShim::device_write: Failed");
    sts = -1;
  }

  if (0 == sts)
  {
     sts = g_hICFnTbl.ioctl_device_write(aIoSession, aBuf, aBufSize);
  }
  
  pthread_mutex_unlock(&gioctlClientCS);
  
  return sts;

}

/*==========================================================================

         FUNCTION:      device_ioctl

         DESCRIPTION:
*//**       This function handles ioctl for server

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out]
*//**       @param[in]  aIoSession
*//**       @param[in]  aCommand
*//**       @param[in]  aInBuf
*//**       @param[in]  aInBufSize
*//**       @param[in]  aOutBuf
*//**       @param[in]  aOutBufSize

**//*     RETURN VALUE:
*//**       @return  : Returns 0 for success OR -1 for failure

@par     SIDE EFFECTS:
                        None

===========================================================================*/
int device_ioctl
(
    ioctl_session_t* aIoSession,
    uint32 aCommand,
    uint8 *aInBuf,
    uint32 aInBufSize,
    uint8* aOutBuf,
    uint32 aOutBufSize
)
{
  int sts = 0;
  
  pthread_mutex_lock(&gioctlClientCS);
  
  /* Check if lib is loaded */
  if (NULL == g_hICLib)
  {
    IOCTL_SHIM_MSG_ERROR("ioctlClientShim::device_ioctl: Failed !!");
    sts = -1;
  }

  if (0 == sts)
  {
     sts = g_hICFnTbl.ioctl_device_ioctl(aIoSession, aCommand, aInBuf, aInBufSize, aOutBuf, aOutBufSize);
  }
  pthread_mutex_unlock(&gioctlClientCS);
  return sts;
}

/*==========================================================================

         FUNCTION:      device_ping

         DESCRIPTION:
*//**       This function ping the device with cmd and input data. 
            Once receiving the ping, the device is expected to return the
            response in order to unblock client followed by processing 
            input data

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out]
*//**       @param[in]  aIoSession
*//**       @param[in]  aCommand
*//**       @param[in]  aBuf
*//**       @param[in]  aBufSize

**//*     RETURN VALUE:
*//**       @return  : Returns 0 for success OR -1 for failure

@par     SIDE EFFECTS:
                        None

===========================================================================*/
int device_ping
(
    ioctl_session_t* aIoSession,
    uint32 aCommand,
    uint8 *aBuf,
    uint32 aBufSize
)
{
  int sts = 0;
  
  pthread_mutex_lock(&gioctlClientCS);
  
  /* Check if lib is loaded */
  if (NULL == g_hICLib)
  {
    IOCTL_SHIM_MSG_ERROR("ioctlClientShim::device_ping: Failed !!");
    sts = -1;
  }

  if (0 == sts)
  {
     sts = g_hICFnTbl.ioctl_device_ping(aIoSession, aCommand, aBuf, aBufSize);
  }
  pthread_mutex_unlock(&gioctlClientCS);
  return sts;
}

/*==========================================================================

         FUNCTION:      device_get_last_error

         DESCRIPTION:
*//**       This function return the error code from the previous ioctl call

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out]
*//**       @param[in]  aIoSession

**//*     RETURN VALUE:
*//**       @return  : Returns error code or -1 for failure

@par     SIDE EFFECTS:
                        None

===========================================================================*/
int device_get_last_error(ioctl_session_t *aIoSession)
{
   int sts = 0;
   
   pthread_mutex_lock(&gioctlClientCS);
   
   /* Check if lib is loaded */
   if (NULL == g_hICLib)
   {
     IOCTL_SHIM_MSG_ERROR("ioctlClientShim::device_get_last_error: Failed !!");
     sts = -1;
   }
   
   if (0 == sts)
   {
      sts = g_hICFnTbl.ioctl_device_get_last_error(aIoSession);
   }
   pthread_mutex_unlock(&gioctlClientCS);
   return sts;
}



