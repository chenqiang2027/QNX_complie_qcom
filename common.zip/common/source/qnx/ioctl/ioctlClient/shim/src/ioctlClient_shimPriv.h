#ifndef IOCTL_CLIENT_SHIMPRIV_H_
#define IOCTL_CLIENT_SHIMPRIV_H_
/*========================================================================

*//** @file ioctlClient_shimPriv.h

@par DESCRIPTION:
   This file contains MM specific utility functions.




@par EXTERNALIZED FUNCTIONS:
     See below.

   Copyright (c) 2012-2017 QUALCOMM Technologies, Incorporated. All Rights Reserved.
   QUALCOMM Proprietary. Export of this technology or software is regulated
   by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                      Edit History

$Header: //components/rel/multimedia_common.qxa_qa/1.0/source/qnx/ioctl/ioctlClient/shim/src/ioctlClient_shimPriv.h#none $

when       who    what, where, why
--------   ---    -------------------------------------------------------
02/05/17   rz     Fix compilation warnings with printf format check
08/03/16   rz     Add error mesage macro
10/24/13   rs     Added device_get_last_error function
07/03/13   dp     Redirect msg from slog to QXDM video task
06/21/13   rz     Added device_ping
11/01/12   sk     Created file.

========================================================================== */

/* =======================================================================

                INCLUDE FILES FOR MODULE

========================================================================== */
#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */

#include "MMDebugMsg.h"

/*===========================================================================

                 DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */
#define IOCTL_SHIM_MSG_HIGH( xx_fmt, ...)       MM_MSG_PRIO_EX(MM_VIDEO_TASK, MM_PRIO_HIGH, xx_fmt, ## __VA_ARGS__)
#define IOCTL_SHIM_MSG_ERROR( xx_fmt, ...)      MM_MSG_PRIO_EX(MM_VIDEO_TASK, MM_PRIO_ERROR, xx_fmt, ## __VA_ARGS__)


/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */
/* open */
typedef ioctl_session_t* (*shim_device_open)(char* name, ioctl_callback_t* cb);

/* close */
typedef int (*shim_device_close)(ioctl_session_t* aIoSession);

/* return the number of bytes actually read */
typedef int (*shim_device_read)(ioctl_session_t* aIoSession, uint8* aBuf, uint32 aBufSize);

/*  return the number of bytes actually write */
typedef int (*shim_device_write)(ioctl_session_t* aIoSession, uint8* aBuf, uint32 aBufSize);

/* ioctl */
typedef int (*shim_device_ioctl)
(
    ioctl_session_t* aIoSession,
    uint32 aCommand,
    uint8 *aInBuf,
    uint32 aInBufSize,
    uint8* aOutBuf,
    uint32 aOutBufSize
);

/* ping */
typedef int (*shim_device_ping)
(
    ioctl_session_t* aIoSession,
    uint32 aCommand,
    uint8 *aBuf,
    uint32 aBufSize
);

/* get last error */
typedef int (*shim_device_get_last_error)
(
    ioctl_session_t* aIoSession
);


/* Function ptr table to store the ioctl functions */
struct ioctl_clt_fn_t
{
      shim_device_open   ioctl_device_open;
      shim_device_close  ioctl_device_close;
      shim_device_read   ioctl_device_read;
      shim_device_write  ioctl_device_write;
      shim_device_ioctl  ioctl_device_ioctl;
      shim_device_ping   ioctl_device_ping;
      shim_device_get_last_error ioctl_device_get_last_error;
};

#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */

#endif /* IOCTL_CLIENT_SHIMPRIV_H_ */
