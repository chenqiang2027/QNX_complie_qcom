/*===========================================================================

*//** @file ioctlClientPriv.h
  This file declares datatypes and prototypes for ioctl client

Copyright (c) 2010 - 2017, 2021 QUALCOMM Technologies, Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/


/*===========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/1.0/source/qnx/ioctl/ioctlClient/ioctlClient/src/ioctlClientPriv.h#none $

when       who         what, where, why
--------   --------    -------------------------------------------------------
07/28/21   xg          Add sigevent to ioctl_session_t
12/24/18   jz          Add error log level
11/06/18   rz          Fix cb thread handle type
02/05/17   rz          Fix compilation warnings with printf format check
07/05/16   hl          Isolate video data from ioctl
06/29/16   hl          Support dynamic buffer mode
06/01/16   hl          Add support to hypervisor
10/24/13   rs          Add lastError to ioctl_session_t struct
07/08/13   dp          Use std typedefs.
07/03/13   dp          Redirect msg from slog to QXDM video task
04/09/13   hc          Replace printf by slog
02/03/11   yugangz     Replace shared mem with mq
11/30/10   che         Initial version

============================================================================*/

#ifndef IOCTL_CLIENT_PRIV_H_
#define IOCTL_CLIENT_PRIV_H_

#include "AEEstd.h" /* std typedefs, ie. byte, uint16, uint32, etc. and memcpy, memset */
#include "MMMalloc.h"
#include "MMDebugMsg.h"
#include "ioctlMsg.h"
#ifdef WIN32
#include "queue.h"
#endif

#define IOCTL_CLT_MSG( xx_fmt, ...) \
    MM_MSG_PRIO_EX(MM_VIDEO_TASK, MM_PRIO_HIGH, xx_fmt, ## __VA_ARGS__)
#define IOCTL_CLT_ERR( xx_fmt, ...) \
    MM_MSG_PRIO_EX(MM_VIDEO_TASK, MM_PRIO_ERROR, xx_fmt, ## __VA_ARGS__)

#define IOCTL_CLT_Malloc(n)                     MM_Malloc((n))
#define IOCTL_CLT_FreeIf(p)                     { if((p)) MM_Free(p); \
                                                  (p) = NULL; }


/* general utility for memory set and copy */
#define IOCTL_CLT_MEMSET(src, value, len)       std_memset((src), (value), (len))
#define IOCTL_CLT_MEMCPY(dest, src, len)        std_memmove((dest), (src), (len))

#define MAX_MSG_SIZE                            (256)
#define MAX_NUM_MSG                             (64)
#define IOCTLCLIENT_THREAD_STACK_SIZE           (8192)



typedef struct ioctl_ccb_t ioctl_ccb_t;


typedef struct
{
   uint8 msg_buf[MAX_MSG_SIZE];
   int msg_len;
}ioctlClientMsgType;

#ifdef WIN32
typedef struct
{
   q_link_type          link;
   ioctlClientMsgType   msg;
}ioctlClientMsgQType;
#endif

struct ioctl_session_t
{
   char server[MAX_NAME_LENGTH];  // the server name
   char device[MAX_NAME_LENGTH];  // device driver name
   IO_HANDLE handle;              // device driver handle
   int fd;                        // driver connection id
   ioctl_callback_t callback;     // registered client callback
   int devid;                     // device instance id
   MM_HANDLE thread;              // callback manager thread
   int chid;                      // callback channel id
   int coid;                      // callback connection id
   int lastError;                 // caches the last IOCTL communication error
   ioctl_session_t *next;
   struct sigevent open_event;
#ifdef WIN32
   q_type msgQClient;
   q_type msgQServer;
   ioctlClientMsgQType msgBuff[MAX_NUM_MSG];
   MM_HANDLE msgSignalQ;
   MM_HANDLE msgSignal;
#endif
   void *private_data;
};

int add_client_session(ioctl_session_t* aIoSession);
int delete_client_session(ioctl_session_t* aIoSession);
#endif /* IOCTLCLIENTPRIV_H_ */
