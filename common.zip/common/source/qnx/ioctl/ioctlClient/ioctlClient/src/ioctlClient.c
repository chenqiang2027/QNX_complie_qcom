/*===========================================================================

*//** @file ioctlClient.c
  This file implements the ioctl client

Copyright (c) 2010 - 2018, 2020 - 2021 QUALCOMM Technologies, Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/


/*===========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/1.0/source/qnx/ioctl/ioctlClient/ioctlClient/src/ioctlClient.c#none $

when       who        what, where, why
--------   --------   -------------------------------------------------------
08/02/21   xg         Add unregister event when device close
10/21/20   sm         Use registered events
12/24/18   jz         Add error log level
01/02/18   rz         Fix MISRA warning 
02/05/17   rz         Fix compilation warnings with printf format check 
07/26/16   rz         Fix close hang problem by destroying channel after releasing the callback thread
02/11/14   dp         Replace snprintf with std_strlprintf
10/24/13   rs         Return -1 instead of errno in case of IOCTL failure and
                      add device_get_last_error function
10/01/13   rs         Do best effort cleanup on close
09/25/13   dp         Fix error returned in device open message send fail case.
07/17/13   dp         Add back include string.h needed for strerror.
07/08/13   dp         Use std typedefs.
06/26/13   am         Fix klockworks warning.
06/21/13   rz         Added device_ping
04/09/13   hc         Replace printf by slog
04/05/13   rz         Fixed server name
04/03/13   dwp        Insert range check for snprintf() call
03/27/13   am         Fixed KW compiler warnings
02/27/12   sk         Fixed KW compiler warnings
02/10/12   yzgao      Add NULL pointer checking for ioctlClient to avoid NULL handle referenced.
02/03/11   che        Replace deprecated strncpy function with memcpy
02/03/11   yugangz    Replace shared mem with mq
11/13/10   che        Initial version

============================================================================*/

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include <sys/neutrino.h>
#include <sys/iomsg.h>
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#include <pthread.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <sys/select.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <string.h>
#include <mqueue.h>
#include <devctl.h>

#include "ioctlMsg.h"
#include "ioctlClient.h"
#include "ioctlClientPriv.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
**                 FUNCTION DECLARATIONS
** ----------------------------------------------------------------------- */
int start_callback_manager(ioctl_session_t* aIoSession);
int stop_callback_manager(ioctl_session_t* aIoSession);
static int device_attach(ioctl_session_t* aIoSession);


/*===========================================================================

                        FUNCTION DEFINITIONS

===========================================================================*/

// launch the device server if it is not started
static int device_attach(ioctl_session_t* aIoSession)
{
   iov_t          siov[2];
   iov_t          riov[1];
   int            status = -1;
   io_msg_type_t  msg;
   char           server[MAX_NAME_LENGTH];
   int            devid = -1;
   int            sfd = -1;

   std_strlprintf(server, MAX_NAME_LENGTH, "%s/devmgr", aIoSession->server);
   sfd = open(server, O_RDONLY);
   if ( -1 == sfd )
   {
      IOCTL_CLT_ERR("ioctlClient::device_attach: open devmgr server %s failed %s", server, strerror(errno));
      return -1;
   }

   msg.io.type = _IO_MSG;
   msg.io.combine_len = sizeof( msg.io );
   msg.io.mgrid = IOCTL_SERVER_MGR_ID;
   msg.io.subtype = 0;
   msg.buf.hdr.type = MSG_TYPE_ATTACH;
   msg.buf.hdr.inSize = std_strlen(aIoSession->device) + 1;
   msg.buf.hdr.outSize = 0;

   // setup the message as a two part iov (if necessary), first the header then the data
   SETIOV (&siov[0], &msg, sizeof(msg));
   SETIOV (&siov[1], aIoSession->device, msg.buf.hdr.inSize);
   SETIOV (&riov[0], &devid, sizeof(devid));

   status = MsgSendv(sfd, siov, 2, riov, 1);
   if ( -1 == status )
   {
      IOCTL_CLT_ERR("ioctlClient::device_attach::MsgSend failed %d", errno);
   }
   else
   {
      aIoSession->devid = devid;
   }

   close(sfd);
   IOCTL_CLT_MSG("ioctlClient::device_attach status %d instance id %d", status, devid);
   return status;
}

ioctl_session_t* device_open(char* pName, ioctl_callback_t* callback)
{
   ioctl_session_t   *aIoSession = NULL;
   int               fd = 0;
   int               status = 0;
   char              *pDeviceName = NULL;
   int               len = 0;
   int               str_length;
   int               errvalue = 0;

   if ( NULL == pName )
   {
      IOCTL_CLT_ERR("ioctlClient::device_open: invalid server/device name");
      return NULL;
   }

   IOCTL_CLT_MSG("ioctlClient::device_open %s", pName);

   // allocate an io session object
   aIoSession = (ioctl_session_t *)IOCTL_CLT_Malloc(sizeof(ioctl_session_t));
   if ( NULL == aIoSession )
   {
      errno = ENOMEM;
      IOCTL_CLT_ERR("ioctlClient::device_open::malloc FAIL %d", errno);
      return NULL;
   }
   IOCTL_CLT_MEMSET(aIoSession, 0, sizeof(ioctl_session_t));

   pDeviceName = std_strrchr(pName, '/');
   if ( NULL == pDeviceName )
   {
      IOCTL_CLT_ERR("ioctlClient::device_open::invalid name %s. device name format: server/device", pName);
      IOCTL_CLT_FreeIf(aIoSession);
      return NULL;
   }
   len = std_strlen(pName) - std_strlen(pDeviceName);
   if ( len >= MAX_NAME_LENGTH )
   {
      len = MAX_NAME_LENGTH - 1;
   }

   std_strlprintf(aIoSession->server, MAX_NAME_LENGTH, "/dev/%s", pName);

   str_length = len + 5;

   if ( (str_length <  0) || (str_length >= MAX_NAME_LENGTH) )
   {
      // handle std_strlprintf error or string truncation
      IOCTL_CLT_ERR("Error encountered extracting server name from device %s. str_length = %d", pName, str_length);
      IOCTL_CLT_FreeIf(aIoSession);
      return NULL;
   }

   aIoSession->server[str_length] = 0; // place EOS

   pDeviceName++;
   len = std_strlen(pDeviceName);
   if ( len <= 0 )
   {
      IOCTL_CLT_ERR("ioctlClient::device_open::invalid device name");
      IOCTL_CLT_FreeIf(aIoSession);
      return NULL;
   }
   IOCTL_CLT_MEMCPY(aIoSession->device, pDeviceName, len);
   aIoSession->device[len] = 0;

   // attach to device manager server to start the device if not started yet
   status = device_attach(aIoSession);

   if ( -1 == status )
   {
      IOCTL_CLT_FreeIf(aIoSession);
      IOCTL_CLT_ERR("ioctlClient::device_open:: device_attach FAIL %d", errno);
      return NULL;
   }
   else
   {
      std_strlprintf(aIoSession->device, MAX_NAME_LENGTH, "%s/%s%d",
                     aIoSession->server, pDeviceName, aIoSession->devid);
      fd = open(aIoSession->device, O_RDONLY);
   }
   if ( -1 == fd )
   {
      IOCTL_CLT_ERR("ioctlClient::device_open::unable to open device id = %d", aIoSession->devid);
      IOCTL_CLT_FreeIf(aIoSession);
      return NULL;
   }
   aIoSession->fd = fd;
   aIoSession->chid = -1;
   aIoSession->coid = -1;
   if ( callback )
   {
      aIoSession->callback = *callback;
      status = start_callback_manager(aIoSession);
   }

   if ( 0 == status )
   {
      io_msg_type_t msg;

      msg.io.type = _IO_MSG;
      msg.io.combine_len = sizeof( msg.io );
      msg.io.mgrid = IOCTL_SERVER_MGR_ID;
      msg.io.subtype = 0;
      msg.buf.hdr.type = MSG_TYPE_OPEN;
      msg.buf.hdr.inSize = 0;
      msg.buf.hdr.outSize = sizeof(aIoSession->handle);
      msg.buf.open.deliver_event = 0;
      msg.buf.open.pid = getpid();

      if ( callback )
      {
         msg.buf.open.deliver_event = 1;
         SIGEV_PULSE_INIT( &msg.buf.open.event, aIoSession->coid, SIGEV_PULSE_PRIO_INHERIT, CALLBACK_EVENT_PULSE, 0 );
         if ( (status = MsgRegisterEvent(&msg.buf.open.event, fd)) < 0 )
         {
            IOCTL_CLT_ERR("ioctlClient::device_open::Register event failed session 0x%p %s", aIoSession, strerror(errno));
            errvalue = errno;
         }
         aIoSession->open_event = msg.buf.open.event;
      }
      if ( 0 == status )
      {
         errno = EOK;
         status = MsgSend(fd, &msg, sizeof(msg), (uint8_t*)&(aIoSession->handle), sizeof(aIoSession->handle));
         errvalue = errno;
      }
   }
   else
   {
      close(fd);
      IOCTL_CLT_ERR("ioctlClient::device_open::start_callback_manager failed session 0x%p", aIoSession);
      IOCTL_CLT_FreeIf(aIoSession);
      return NULL;
   }

   if ( -1 == status )
   {
      close(fd);
      IOCTL_CLT_ERR("ioctlClient::device_open::MsgSend FAIL, error = %d", errvalue);
      IOCTL_CLT_FreeIf(aIoSession);
   }
   IOCTL_CLT_MSG("device %s open status %d session 0x%p", pName, status, aIoSession);
   return aIoSession;
}

int device_close(ioctl_session_t* aIoSession)
{
   int status = 0;
   int ret = 0;

   if ( NULL == aIoSession )
   {
      IOCTL_CLT_ERR("ioctlClient::device_close::null device handle");
      return -1;
   }

   status = stop_callback_manager(aIoSession);
   if ( -1 == status )
   {
      IOCTL_CLT_ERR("ioctlClient::device_close::stop callback manager::FAIL %d", errno);
      ret = -1; //failure - don't return. do best effort cleaning.
   }

   IOCTL_CLT_MSG("unregister event 0x%p", &aIoSession->open_event);
   if ( (status = MsgUnregisterEvent(&aIoSession->open_event)) < 0 )
   {
      IOCTL_CLT_ERR("ioctlClient::device_close::UnRegister event failed session 0x%p %s", aIoSession, strerror(errno));
      ret = errno;
   }

   status = close(aIoSession->fd);
   if ( -1 == status )
   {
      IOCTL_CLT_ERR("ioctlClient::device_close::close FAIL %d", errno);
      ret = -1; //failure - don't return. do best effort cleaning.
   }

   if ( -1 != aIoSession->coid )
   {
      ConnectDetach(aIoSession->coid);
   }
   if ( -1 != aIoSession->chid )
   {
      ChannelDestroy(aIoSession->chid);
   }

   IOCTL_CLT_FreeIf(aIoSession);


   return ret;
}

int device_read
(
   ioctl_session_t   *aIoSession,
   uint8             *aBuf,
   uint32            aBufSize
)
{
   int status = device_ioctl(aIoSession, _IO_READ, NULL, 0, aBuf, aBufSize);

   return status;
}

int device_write
(
   ioctl_session_t   *aIoSession,
   uint8             *aBuf,
   uint32            aBufSize
)
{
   int status = device_ioctl(aIoSession, _IO_WRITE, aBuf, aBufSize, NULL, 0);

   return status;
}

int device_ioctl
(
   ioctl_session_t   *aIoSession,
   uint32            aCommand,
   uint8             *aInBuf,
   uint32            aInBufSize,
   uint8             *aOutBuf,
   uint32            aOutBufSize
)
{
   iov_t          siov[2];
   iov_t          riov[1];
   int            status = -1;
   io_msg_type_t  msg;

   if ( NULL == aIoSession )
   {
      IOCTL_CLT_ERR("ioctlClient::device_ioctl got NULL handle !!");
      status = -1;  // return the error code
   }
   else
   {
      msg.io.type = _IO_MSG;
      msg.io.combine_len = sizeof( msg.io );
      msg.io.mgrid = IOCTL_SERVER_MGR_ID;
      msg.io.subtype = 0;
      msg.buf.hdr.type = MSG_TYPE_IOCTL;
      msg.buf.hdr.inSize = aInBufSize;
      msg.buf.hdr.outSize = aOutBufSize;
      msg.buf.ioctl.handle = aIoSession->handle;
      msg.buf.ioctl.command = aCommand;

      // setup the message as a two part iov (if necessary), first the header then the data
      SETIOV (&siov[0], &msg, sizeof(msg));
      SETIOV (&siov[1], aInBuf, aInBufSize);
      SETIOV (&riov[0], aOutBuf, aOutBufSize);

      // and send the message off to the server
      status = MsgSendv(aIoSession->fd, siov, 2, riov, 1);
      if ( -1 == status )
      {
         IOCTL_CLT_ERR("ioctlClient::device_ioctl: MsgSendv failed %d !!", errno);
         // IOCTL communication error.
         // Since this cannot be conveyed to the caller using the return value, just return -1 here
         // The actual error is cached in the context. The caller can obtain that by calling
         // device_get_last_error function
         aIoSession->lastError = errno;
      }
   }
   return status;
}

int device_ping
(
   ioctl_session_t   *aIoSession,
   uint32            aCommand,
   uint8             *aBuf,
   uint32            aBufSize
)
{
   iov_t          siov[2];
   int            status = -1;
   io_msg_type_t  msg;

   if ( NULL == aIoSession )
   {
      IOCTL_CLT_ERR("ioctlClient::device_ping got NULL handle!");
      status = -1;  // return the error code
   }
   else
   {
      msg.io.type = _IO_MSG;
      msg.io.combine_len = sizeof( msg.io );
      msg.io.mgrid = IOCTL_SERVER_MGR_ID;
      msg.io.subtype = 0;
      msg.buf.hdr.type = MSG_TYPE_PING;
      msg.buf.hdr.inSize = aBufSize;
      msg.buf.hdr.outSize = 0;
      msg.buf.ioctl.handle = aIoSession->handle;
      msg.buf.ioctl.command = aCommand;

      // setup the message as a two part iov (if necessary), first the header then the data
      SETIOV (&siov[0], &msg, sizeof(msg));
      SETIOV (&siov[1], aBuf, aBufSize);

      // and send the message off to the server
      status = MsgSendv(aIoSession->fd, siov, 2, NULL, 0);
      if ( -1 == status )
      {
         IOCTL_CLT_ERR("ioctlClient::device_ping: MsgSendv failed %d !!", errno);
         // IOCTL communication error.
         // Since this cannot be conveyed to the caller using the return value, just return -1 here
         // The actual error is cached in the context. The caller can obtain that by calling
         // device_get_last_error function
         aIoSession->lastError = errno;
      }
   }
   return status;
}

int device_get_last_error(ioctl_session_t *aIoSession)
{
   if ( NULL == aIoSession )
   {
      IOCTL_CLT_ERR("ioctlClient::device_get_last_error: null device handle");
      return -1;
   }

   return aIoSession->lastError;
}
