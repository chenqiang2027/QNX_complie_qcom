/*===========================================================================

*//** @file cbman.c
  This file implements the callback manger for ioctl libs

Copyright (c) 2010 - 2017, 2022 QUALCOMM Technologies, Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/


/*===========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/1.0/source/qnx/ioctl/ioctlClient/ioctlClient/src/cbman.c#none $

when       who        what, where, why
--------   ---        -------------------------------------------------------
11/21/22   xg         Disable thread cancel for external callback handler
09/13/22   xg         Avoid MsgSend crash when thread release
12/19/18   jz         Clean up thread when channel creation failure
11/06/18   rz         Fix cb thread handle type
02/05/17   rz         Fix compilation warnings with printf format check
10/27/16   rz         Fix 1 second sleep at device open
07/26/16   rz         Remove usage of global variable for hypervisor envioronment
06/22/16   am         Fix compiler warnings 
02/11/14   dp         Replace snprintf with std_strlprintf
07/08/13   dp         Use std lib and KW compiler warnings fixes
04/05/13   hc         Replace printf by slog
02/27/12   sk         Fixed KW compiler warnings
11/10/11   che        Need to change mq file permission for RIM's mm-renderer
04/27/11   wyun       Adding thread naming
02/03/11   yugangz    Replace shared mem with mq
11/30/10   che        Initial version
============================================================================*/

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include <sys/neutrino.h>
#include <sys/iomsg.h>
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#include <pthread.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <sys/select.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <string.h>
#include "ioctlMsg.h"
#include "ioctlClient.h"
#include "ioctlClientPriv.h"
#include "MMThread.h"
#include "MMTimer.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
**                 FUNCTION DECLARATIONS
** ----------------------------------------------------------------------- */
static int IoctlCallbackManager(void*);
/*===========================================================================

                        FUNCTION DEFINITIONS

===========================================================================*/

int start_callback_manager(ioctl_session_t* aIoSession)
{
   char aThreadName[MAX_NAME_LENGTH];
   char* pDeviceName = NULL;
   
   if ( aIoSession->thread )
   {
      IOCTL_CLT_MSG("start callback manager thread already started");
      return 0;
   }

   pDeviceName = std_strrchr(aIoSession->device, '/') + 1;
   if ( NULL == pDeviceName )
   {
      IOCTL_CLT_ERR("start callback manager: invalid device name %s. device name format: server/device",
                    aIoSession->device);
      return -1;
   }
   std_strlprintf(aThreadName, MAX_NAME_LENGTH, "%s-cbmgr", pDeviceName);

   if ( 0 != MM_Thread_CreateEx ( MM_Thread_DefaultPriority, 0,
                                  IoctlCallbackManager, (void*)aIoSession, IOCTLCLIENT_THREAD_STACK_SIZE,
                                  aThreadName, &aIoSession->thread ) )
   {
      IOCTL_CLT_ERR("start callback manager: thread creation failed");
      return -1;
   }

   /* Temporary: poll until IoctlCallbackManaag has created the chid and coid */
   int nTimeOut = 1000; // 1000 ms
   int nTimeSleep = 1; // 1 ms
   int nCurrTime = 0;
   while ( ( -1 == aIoSession->coid || -1 == aIoSession->chid ) && 
           (nCurrTime < nTimeOut ) ) 
   {
      MM_Timer_Sleep(nTimeSleep);
      nCurrTime += nTimeSleep;
   }

   if ( nCurrTime >= nTimeOut )
   {
      IOCTL_CLT_ERR("start callback manager failed on channel creation");

      if (aIoSession->thread)
      {
         MM_Thread_Release(aIoSession->thread);
      }

      if (aIoSession->fd != 0)
      {
         close(aIoSession->fd);
      }

      return -1;
   }

   return 0;
}

int stop_callback_manager(ioctl_session_t* aIoSession)
{
   // shut down the callback loop and free memory
   if ( aIoSession->thread )
   {
      MM_Thread_Release((MM_HANDLE)((long)aIoSession->thread));
      aIoSession->thread = 0;
   }

   return 0;
}

static int IoctlCallbackManager(void* pIoSession)
{
   ioctl_session_t* aIoSession = (ioctl_session_t*)pIoSession;
   int done = 0;
   int size;
   uint8 msg_buf[MAX_MSG_SIZE];

   if ( NULL == aIoSession )
   {
      IOCTL_CLT_ERR("ioctlClient: pIoSession is NULL");
      return -1;
   }

   /* we need a channel to receive the pulse notification on */
   aIoSession->chid = ChannelCreate( 0 );

   if ( -1 == aIoSession->chid )
   {
      IOCTL_CLT_ERR("ioctlClient: ChannelCreate failed %s", strerror(errno));
      return -1;
   }

   /* and we need a connection to that channel for the pulse to be delivered on */
   aIoSession->coid = ConnectAttach( 0, 0, aIoSession->chid, _NTO_SIDE_CHANNEL, 0 );

   if ( -1 == aIoSession->coid)
   {
      IOCTL_CLT_ERR("ioctlClient: ConnectAttach failed %s", strerror(errno));
      ChannelDestroy(aIoSession->chid);
      aIoSession->chid = -1;
      return -1;
   }

   while (!done)
   {
      struct _pulse pulse;
      int ret = 0;
      int rcvid = MsgReceivePulse( aIoSession->chid, &pulse, sizeof( pulse ), NULL );

      if ( -1 == rcvid )
      {
         if ( EINTR != errno)
         {
            IOCTL_CLT_ERR("MsgReceivePulse failed, error:%d, %s", errno, strerror(errno));
            break;
         }
         else
         {
            usleep(50); 
            IOCTL_CLT_ERR("MsgReceivePulse failed, error: %s, non-critical, continueing",
                          strerror(errno));
            continue;     
         }
      }
      if ( pulse.code != CALLBACK_EVENT_PULSE )
      {
         IOCTL_CLT_ERR("unknow pulse code rxd %d", pulse.code);
         continue;
      }

      /*thread shouldn't be canceled here, per we don't know if there is a thread cancel point in the callback 
	    and can't ensure system will cleanup all the resources in handler*/
      ret = pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);
      if ( 0 != ret )
      {
         IOCTL_CLT_ERR("setcancelstate DISABLE ret = %d", ret);
      }
      // get all callback msg from the server
      do
      {
         io_msg_type_t msg;

         msg.io.type = _IO_MSG;
         msg.io.combine_len = sizeof( msg.io );
         msg.io.mgrid = IOCTL_SERVER_MGR_ID;
         msg.io.subtype = 0;
         msg.buf.hdr.type = MSG_TYPE_GET_CB_MSG;
         msg.buf.hdr.inSize = 0;
         msg.buf.hdr.outSize = MAX_MSG_SIZE;

         IOCTL_CLT_MEMSET(msg_buf, 0, MAX_MSG_SIZE);
         size = MsgSendnc(aIoSession->fd, &msg, sizeof(msg), (uint8_t*)msg_buf, MAX_MSG_SIZE);
         if (size > 0)
         {
            // call the client callback
            aIoSession->callback.handler(msg_buf, size, aIoSession->callback.data);
         }
      } while (size > 0);

      ret = pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
      if ( 0 != ret )
      {
         IOCTL_CLT_ERR("setcancelstate ENABLE ret = %d", ret);
      }
   }
   return 0;
}
