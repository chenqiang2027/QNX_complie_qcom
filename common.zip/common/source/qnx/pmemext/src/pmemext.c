/*===========================================================================
 PMEM extension

 *//** @file pmemext.c
 This file provides functions to map the virtual address between source process/calling process

 Copyright (c) 2008 - 2019 QUALCOMM Technologies Incorporated.
 All Rights Reserved. Qualcomm Proprietary and Confidential.
 *//*========================================================================*/

/*===========================================================================
 Edit History

 $Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/pmemext/src/pmemext.c#1 $

 when       who         what, where, why
 --------   ---         -------------------------------------------------------
 02/21/19   rz          Remove unused header
 07/23/18   rz          Consolidate map_from(to)_pid/add_from(to)_pid
 06/12/18   rz          Add pmem_map_init/deinit APIs
 06/07/18   rz          Call MM_Debug_Initialize implicitly
 01/02/18   rz          Fix MISRA warning
 11/20/17   am          Initialize aEntry to linkhead under mutex in pmem_map_free
 11/15/17   am          Add mutex to lookup functions so do not run when
                        list being modified.
 01/17/17   rz          Fix compilation warning with printf format check
 11/07/16   rz          Add MAP_SHARED flag in mmap64 and mmap64_peer
 04/21/14   am          Added additional failure checks.
 01/25/13   yzgao       Clean up printf()/fprintf()

 ============================================================================*/

/*===========================================================================
 Include Files
 ============================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "pmemext.h"
#include "mmap_peer.h"

#include "MMDebugMsg.h"

#define MMAP_MASK_UVA 0x1
#define MMAP_MASK_KVA 0x2

typedef struct pmem_map_entry_t pmem_map_entry_t;
struct pmem_map_entry_t
{
    void* uva;    // user space virtual address in remote process
    uint32 upid;  // user space process id

    void* kva;    // virtual address in local kernel process

    void* phys;   // physical address of the pmem chunk

    uint32 size;
    uint32 mask;

    uint32 refcnt;
    pmem_map_entry_t* next;
};

static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
static pmem_map_entry_t* linkhead = NULL;
static pmem_map_entry_t* linktail = NULL;

static struct buffer_list *listhead = NULL;
static struct buffer_list *listtail = NULL;

static pmem_map_entry_t* pmem_map_lookup(void* virt, uint32 pid, int uva);
int pmem_map_cleanup();

static boolean gInitialized = FALSE;

static pmem_map_entry_t* pmem_map_lookup(void* virt, uint32 pid, int uva)
{
    pmem_map_entry_t* aEntry = linkhead;

    if (uva)
    {
        while (aEntry)
        {
            if (aEntry->uva == virt && aEntry->upid == pid)
            {
                break;
            }
            aEntry = aEntry->next;
        }
    }
    else
    {
        while (aEntry)
        {
            if (aEntry->kva == virt && aEntry->upid == pid)
            {
                break;
            }
            aEntry = aEntry->next;
        }
    }

    return aEntry;
}

int pmem_map_free(void* virt)
{
    int aStatus = -1;
    pmem_map_entry_t* aPrev = NULL;
    pmem_map_entry_t* aEntry;

    pthread_mutex_lock(&mutex);

    aEntry = linkhead;

    while (aEntry)
    {
        if (aEntry->kva == virt)
        {
            aStatus = 0;
            aEntry->refcnt -= 1;
            if (aEntry->refcnt != 0)
            {
                break;
            }

            // remove this entry
            if (aPrev)
            {
                aPrev->next = aEntry->next;
            }
            else
            {
                linkhead = aEntry->next;
            }
            if (linktail == aEntry)
            {
                linktail = aPrev;
            }

            if (aEntry->mask == MMAP_MASK_UVA)
            {
                munmap_peer(aEntry->upid, aEntry->uva, aEntry->size);
            }
            else if (aEntry->mask == MMAP_MASK_KVA)
            {
                munmap(aEntry->kva, aEntry->size);
            }

            free(aEntry);
            break;
        }
        aPrev = aEntry;
        aEntry = aEntry->next;
    }
    pthread_mutex_unlock(&mutex);

    return aStatus;
}

/**===========================================================================

FUNCTION pmem_map_init

@brief  This funcation initializes pmemext service including enabling logging

@param  None

@dependencies
        None

@return
        0 for success otherwise error code

===========================================================================*/
int pmem_map_init
(
   void
)
{
   if ( FALSE == gInitialized )
   {
      MM_Debug_Initialize();
      gInitialized = TRUE;
   }

   return 0;
}

/**===========================================================================

FUNCTION pmem_map_deinit

@brief  This funcation deinitializes pmemext service

@param  None

@dependencies
        None

@return
        0 for success otherwise error code

===========================================================================*/
int pmem_map_deinit
(
   void
)
{
   if ( TRUE == gInitialized )
   {
      MM_Debug_Deinitialize();
      gInitialized = FALSE;
   }

   return 0;
}


/**===========================================================================

FUNCTION pmem_map_from_pid

@brief  Given a virtual address from the address of the source process
  identified by the spid, map it into the address space of the calling process

@param [in] virt  the virtual address to map into the calling process
@param [in] size  Size of memory chunk to be mapped
@param [in] spid  process id for the source process.

@dependencies
  None

@return
  Returns virtual address pointer to mapped into the calling process

===========================================================================*/
void* pmem_map_from_pid
(
    void* virt,
    uint32 size,   /* Size of the memory chunk to be allocated */
    uint32 spid    /* the process id of the source process */
)
{
    return pmem_map_from_pid_ex( virt, size, spid, 0 );
}


/**===========================================================================

FUNCTION pmem_map_from_pid_ex

@brief  Given a virtual address from the address of the source process
  identified by the spid, map it into the address space of the calling process

@param [in] virt  the virtual address to map into the calling process
@param [in] size  Size of memory chunk to be mapped
@param [in] spid  process id for the source process
@param [in] flags flags containing map attributes 
 
@dependencies
  None

@return
  Returns virtual address pointer to mapped into the calling process

===========================================================================*/
void* pmem_map_from_pid_ex
(
    void* virt,
    uint32 size,   /* Size of the memory chunk to be allocated */
    uint32 spid,   /* the process id of the source process */
    uint32 flags   /* map attribute */
)
{
   off64_t phys = 0;

   pthread_mutex_lock(&mutex);

   pmem_map_entry_t* aEntry = pmem_map_lookup(virt, spid, 1);
   void* va = NULL;

  MM_MSG_PRIO3( MM_STATS_SLOG, MM_PRIO_HIGH, "virtual address = 0x%p, \
     for memory size = %d, spid = %d", virt, size, spid );			

   if (aEntry)
   {
       va = aEntry->kva;
       aEntry->refcnt += 1;
   }
   else if (size)
   {
       size_t mapped_len = 0;
       size_t trunk_len = 0;

       // reserve virtual address
       int mmap_flags = PROT_READ|PROT_WRITE|PROT_NOCACHE;
       if ( flags & PMEMEXT_MAP_FLAG_CACHE ) 
       {
          mmap_flags &= ~PROT_NOCACHE;
       }

       va = mmap64(NULL, size, mmap_flags, MAP_LAZY|MAP_SHARED, NOFD, 0);

       // map physical address to virtual address trunk by trunk,
       // each trunk is physically contiguous
       do
       {
           if (mem_offset64_peer(spid, (uintptr_t)((unsigned long)virt+mapped_len),
                 size-mapped_len, &phys, &trunk_len) == -1)
           {
               MM_MSG_PRIO3( MM_STATS_SLOG, MM_PRIO_ERROR, "mem_offset64_peer failed, spid = 0x%x, \
                  for memory size = %zd: %s", spid, size-mapped_len, strerror(errno) );
               pthread_mutex_unlock(&mutex);
               return NULL;
           }
        else
        {
               MM_MSG_PRIO5( MM_STATS_SLOG, MM_PRIO_LOW, "mem_offset64_peer spid = 0x%x, virtual address = 0x%lx, \
                  for memory size = %zd, phys addr = 0x%jx, trunk_len = %zd", spid, (unsigned long)virt+mapped_len, size-mapped_len, phys, trunk_len );			
        }

           // map the phys trunk into the local process
           if(mmap64(va+mapped_len, trunk_len, mmap_flags,
               MAP_PHYS|MAP_SHARED|MAP_FIXED, NOFD, phys) == MAP_FAILED)
           {
               MM_MSG_PRIO4( MM_STATS_SLOG, MM_PRIO_ERROR, "mmap64 failed, va = 0x%p, \
                    for memory size = %zd, phys = 0x%jx: %s", va+mapped_len, trunk_len, phys, strerror(errno) );
               pthread_mutex_unlock(&mutex);
               return NULL;
           }
        else
        {
               MM_MSG_PRIO3( MM_STATS_SLOG, MM_PRIO_LOW, "mmap64 va = 0x%p, \
                    for memory size = %zd, phys = 0x%jx", va+mapped_len, trunk_len, phys );			
        }

           mapped_len += trunk_len;
       } while(mapped_len < size);

       aEntry = malloc(sizeof(pmem_map_entry_t));
       if (aEntry == NULL)
       {
           MM_MSG_PRIO( MM_STATS_SLOG, MM_PRIO_ERROR, "pmem_map_add_from_pid(): out of memory" );
           pthread_mutex_unlock(&mutex);
           return NULL;
       }

       aEntry->uva = virt;
       aEntry->upid = spid;
       aEntry->kva = va;
       aEntry->phys = (void *)phys;
       aEntry->next = NULL;
       aEntry->size = size;
       aEntry->mask = MMAP_MASK_KVA;
       aEntry->refcnt = 1;

       if (linktail)
       {
           linktail->next = aEntry;
       }
       else
       {
           linkhead = aEntry;
       }
       linktail = aEntry;
   }

   pthread_mutex_unlock(&mutex);
   return va;
}

/**===========================================================================

FUNCTION pmem_map_to_pid

@brief  Given a virtual address in the calling process and its size,
   map it into the address space identified by the destination pid

@param [in] virt  the physical address to map into the destination process
@param [in] size  Size of memory chunk to be mapped
@param [in] dpid  process id for destination process.

@dependencies
  None

@return
  Returns virtual address pointer mapped into the destination process


===========================================================================*/
void* pmem_map_to_pid
(
    void* virt,
    uint32 size,   /* Size of the memory chunk to be allocated */
    uint32 dpid    /* the process id of the destination process */
)
{
    return pmem_map_to_pid_ex( virt, size, dpid, 0 );
}


/**===========================================================================

FUNCTION pmem_map_to_pid_ex

@brief  Given a virtual address in the calling process and its size,
   map it into the address space identified by the destination pid

@param [in] virt  the physical address to map into the destination process
@param [in] size  Size of memory chunk to be mapped
@param [in] dpid  process id for destination process 
@param [in] flags flags containing map attributes
 

@dependencies
  None

@return
  Returns virtual address pointer mapped into the destination process


===========================================================================*/
void* pmem_map_to_pid_ex
(
    void* virt,
    uint32 size,   /* Size of the memory chunk to be allocated */
    uint32 dpid,   /* the process id of the destination process */
    uint32 flags   /* map attributes */
)
{
   off64_t phys = 0;
   pthread_mutex_lock(&mutex);

   pmem_map_entry_t* aEntry = pmem_map_lookup(virt, dpid, 0);
   void* va = NULL;
   if (aEntry)
   {
       va = aEntry->uva;
       aEntry->refcnt += 1;
   }
   else if (size)
   {
       uint32 mapped_len = 0;
       uint32 trunk_len = 0;

       // reserve va in remote process
       int mmap_flags = PROT_READ|PROT_WRITE|PROT_NOCACHE;
       if ( flags & PMEMEXT_MAP_FLAG_CACHE ) 
       {
          mmap_flags &= ~PROT_NOCACHE;
       }

       va = mmap64_peer(dpid, NULL, size, mmap_flags, MAP_LAZY|MAP_SHARED, NOFD, 0);

       if ( MAP_FAILED == va )
       {
          MM_MSG_PRIO2( MM_STATS_SLOG, MM_PRIO_ERROR, "mmap64_peer failed, dpid = 0x%x \
                    : %s", dpid, strerror(errno) );
          pthread_mutex_unlock(&mutex);
          return NULL;
       }

       do
       {
           if (mem_offset64((void*)((unsigned long)virt+mapped_len), NOFD, size-mapped_len, &phys, (size_t *)&trunk_len) == -1)
           {
               MM_MSG_PRIO3( MM_STATS_SLOG, MM_PRIO_ERROR, "mem_offset64 failed, va = 0x%lx \
                    size = %d : %s", ((unsigned long)virt+mapped_len), size-mapped_len, strerror(errno) );
               pthread_mutex_unlock(&mutex);
               return NULL;
           }

           if ( -1 == phys )
           {
              MM_MSG_PRIO3( MM_STATS_SLOG, MM_PRIO_ERROR, "mem_offset64 failed, va = 0x%lx \
                    size = %d : %s", ((unsigned long)virt+mapped_len), size-mapped_len, strerror(errno) );
              pthread_mutex_unlock(&mutex);
              return NULL;
           }

           // map the phys trunk into the remote process
           if ( mmap64_peer(dpid, va+mapped_len, trunk_len, mmap_flags,
                  MAP_PHYS|MAP_SHARED|MAP_FIXED, NOFD, phys) == MAP_FAILED)
           {
               MM_MSG_PRIO5( MM_STATS_SLOG, MM_PRIO_ERROR, "mmap64_peer failed, dpid = 0x%x \
                    va = 0x%p, size = %d, phys = 0x%jx : %s", dpid, va+mapped_len, trunk_len, phys , strerror(errno) );
               pthread_mutex_unlock(&mutex);
               return NULL;
           }

           mapped_len += trunk_len;
       } while (mapped_len < size);

       aEntry = malloc(sizeof(pmem_map_entry_t));
       if (aEntry == NULL)
       {
           MM_MSG_PRIO( MM_STATS_SLOG, MM_PRIO_ERROR, "pmem_map_add_to_pid(): out of memory" );
           pthread_mutex_unlock(&mutex);
           return NULL;
       }

       aEntry->kva = virt;
       aEntry->upid = dpid;
       aEntry->uva = va;
       aEntry->phys = (void *)phys;
       aEntry->next = NULL;
       aEntry->size = size;
       aEntry->mask = MMAP_MASK_UVA;
       aEntry->refcnt = 1;

       if (linktail)
       {
           linktail->next = aEntry;
       }
       else
       {
           linkhead = aEntry;
       }
       linktail = aEntry;
   }

   pthread_mutex_unlock(&mutex);
   return va;
}

int pmem_map_cleanup()
{
    void* aPtr = NULL;
    pmem_map_entry_t* aEntry = NULL;

    pthread_mutex_lock(&mutex);
    aEntry = linkhead;
    while (aEntry)
    {
        if (aEntry->mask == MMAP_MASK_UVA)
        {
            munmap_peer(aEntry->upid, aEntry->uva, aEntry->size);
        }
        else if (aEntry->mask == MMAP_MASK_KVA)
        {
            munmap(aEntry->kva, aEntry->size);
        }

        aPtr = aEntry;
        aEntry = aEntry->next;
        free(aPtr);
    }

    linkhead = NULL;
    linktail = NULL;

    pthread_mutex_unlock(&mutex);
    return 0;
}


/**===========================================================================

FUNCTION pmem_map_lookup_from_pid

@brief

   Given a virtual address from the source process, this lookup the mapped virtual address
   in the calling process

@param [in] virt  the virtual address to map into the calling process
@param [in] spid  process id for the source process.

@dependencies
  None

@return
  Returns virtual address pointer to mapped into the calling process

===========================================================================*/
void* pmem_map_lookup_from_pid
(
    void* virt,
    uint32 spid    /* the process id of the source process */
)
{
   pthread_mutex_lock(&mutex);

   pmem_map_entry_t* aEntry = pmem_map_lookup(virt, spid, 1);
   pthread_mutex_unlock(&mutex);
   return aEntry ? aEntry->kva : NULL;
}


/**===========================================================================

FUNCTION pmem_map_lookup_to_pid

@brief

   Given a virtual address in the calling process, this lookup the virtual
   address mapped in the destination process

@param [in] virt  the virtual address to map into the calling process
@param [in] dpid  process id for the source process.

@dependencies
  None

@return
  Returns virtual address pointer to mapped into the calling process

===========================================================================*/
void* pmem_map_lookup_to_pid
(
    void* virt,
    uint32 dpid    /* the process id of the source process */
)
{
   pthread_mutex_lock(&mutex);

   pmem_map_entry_t* aEntry = pmem_map_lookup(virt, dpid, 0);
   pthread_mutex_unlock(&mutex);
   return aEntry ? aEntry->uva : NULL;
}


/*==========================================================================

         FUNCTION:      pmem_append_buffer

         DESCRIPTION:
*//**                   This function will append buffer to the linked list

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  buffer_info - pointer to buffer info structure

*//*     RETURN VALUE:
*//**       @return     None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void pmem_append_buffer
(
    struct buffer_list *buffer_info
)
{
   pthread_mutex_lock(&mutex);

   if (buffer_info)
   {
      if (listhead == NULL)
      {
         listhead = buffer_info;
         buffer_info->prev = NULL;
      }
      else
      {
         listtail->next = buffer_info;
         buffer_info->prev = listtail;
      }

      listtail = buffer_info;
      buffer_info->next = NULL;
   }

   pthread_mutex_unlock(&mutex);
}

/*==========================================================================

         FUNCTION:      pmem_delete_buffer

         DESCRIPTION:
*//**                   This function will remove buffer from the linked list

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  buffer_info - pointer to buffer info structure

*//*     RETURN VALUE:
*//**       @return     None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void pmem_delete_buffer
(
    struct buffer_list *buffer_info
)
{
   pthread_mutex_lock(&mutex);

   if (buffer_info)
   {
      if (buffer_info->prev == NULL)
      {
         listhead = buffer_info->next;
      }
      else
      {
         buffer_info->prev->next = buffer_info->next;
      }

      if (buffer_info->next == NULL)
      {
         listtail = buffer_info->prev;
      }
      else
      {
         buffer_info->next->prev = buffer_info->prev;
      }
   }

   pthread_mutex_unlock(&mutex);
}

/*==========================================================================

         FUNCTION:      pmem_get_buffer

         DESCRIPTION:
*//**                   This function will find a buffer from the linked list
                            by virtual address and pid of remote process

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param [in] va  the virtual address from remote process
            @param [in] pid  remote process pid

*//*     RETURN VALUE:
*//**       @return     buffer_list pointer

@par     SIDE EFFECTS:
                        None

===========================================================================*/
struct buffer_list *pmem_get_buffer
(
   uint32 va,
   uint32 pid
)
{
    struct buffer_list *pNode;

    pthread_mutex_lock(&mutex);

    pNode = listhead;

    while (pNode != NULL)
    {
       if ( ( pNode->va == va ) &&
            ( pNode->pid == pid ) )
       {
          break;
       }
       else
       {
          pNode = pNode->next;
       }
    }

    pthread_mutex_unlock(&mutex);

    return pNode;
}

