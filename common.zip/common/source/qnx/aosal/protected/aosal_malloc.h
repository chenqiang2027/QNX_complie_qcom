#ifndef AOSAL_MALLOC_H
#define AOSAL_MALLOC_H
/**================================================================================================

@file
   aosal_malloc.h

@brief
   This file defines a memory utility that can be used to abstract OS memory implementation.

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================

                     INCLUDE FILES FOR MODULE

================================================================================================**/
#include "AEEStdDef.h"
#include "aosal_error.h"

#ifdef __cplusplus
extern "C" {
#endif

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**********************************************************************************************//**
@brief
    Allocate memory

@param nSize
    The number of bytes to allocate.
 
@return
    Non-NULL pointer to the memory if success otherwise NULL
**************************************************************************************************/
void* AOMalloc
(
    uint64_t  nSize
);

/**********************************************************************************************//**
@brief
    Free memory

@param ptr
    Pointer to the memory
 
@return
    void
**************************************************************************************************/
void AOFree
(
    void *ptr
);

/**********************************************************************************************//**
@brief
    Memset memory

@param pDst
    A pointer to the memory to set
 
@param nVal
    The value to be store in each byte
 
@param nLength
    The number of bytes to set
 
@return
    NULL in case of failure, else a pointer to the destination buffer, i.e., pDst
**************************************************************************************************/
void* AOMemset
(
    void        *pDst,
    int32_t     nVal,
    uint64_t    nLength
);

/**********************************************************************************************//**
@brief
    Size bounded memory copy

@param pDst
    A pointer to the memory to be filled
 
@param nDstSize
    Destination memory size
 
@param [const] pSrc
    A pointer to the source memory
 
@param nSrcSize
    Number of bytes in the source memory to be copied
 
@return
    Number of bytes copied
**************************************************************************************************/
uint64_t  AOMemscpy
(
    void        *pDst,
    uint64_t    nDstSize,
    const void  *pSrc,
    uint64_t    nSrcSize
);

/**********************************************************************************************//**
@brief
    String copy

@param pDst
    A pointer to the destination string buffer
 
@param pSrc
    A pointer to the source memory
 
@param nDstSize
    Destination buffer size
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOStrlcpy
(
    char        *pDst,
    const char  *pSrc,
    uint64_t    nDstSize 
);

/**********************************************************************************************//**
@brief
    String concatenation

@param pDst
    A pointer to the destination string buffer
 
@param pSrc
    A pointer to the source string
 
@param nDstSize
    Destination buffer size
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOStrlcat
(
    char        *pDst,
    const char  *pSrc,
    uint64_t    nDstSize 
);

#ifdef __cplusplus
}
#endif

#endif // AOSAL_MALLOC_H
