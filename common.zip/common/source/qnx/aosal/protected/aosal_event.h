#ifndef AOSAL_EVENT_H
#define AOSAL_EVENT_H
/**================================================================================================

@file
   aosal_event.h

@brief
   This file defines functions to raise and receive an event typically for multi-thread
   synchronization.

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include "AEEStdDef.h"
#include "aosal_error.h"


#ifdef __cplusplus
extern "C" {
#endif

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/

/**================================================================================================
** Variables
================================================================================================**/

/**================================================================================================
** Typedefs
================================================================================================**/

#ifndef AO_HANDLE_DEFINED
typedef void *AOHandleType_t;
#define AO_HANDLE_DEFINED
#endif

/**********************************************************************************************//**
@brief
    Creates an Event

@param  phEvent
    Pointer to event handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOEventCreate
(
    AOHandleType_t  *phEvent
);

/**********************************************************************************************//**
@brief
    Destroys the Event

@param  hEvent
    Event handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOEventDestroy
(
    AOHandleType_t  hEvent
);

/**********************************************************************************************//**
@brief
    Sets the event state

@param  hEvent
    Event handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOEventSet
(
    AOHandleType_t  hEvent
);

/**********************************************************************************************//**
@brief
    Clears the event state

@param  hEvent
    Event handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOEventReset
(
    AOHandleType_t  hEvent
);

/**********************************************************************************************//**
@brief
    Configures the Event to Manual Reset mode. In Manual Reset mode, the Event Wait
    function does not reset event and does not wait on event since already set.

@param  hEvent
    Event handle
 
@param  bReset
    TRUE or FALSE

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOEventManualReset
(
    AOHandleType_t  hEvent,
    boolean         bReset
);

/**********************************************************************************************//**
@brief
    Waits on the event with timeout value.

@param  hEvent
    Event handle
 
@param  uTimeoutInMs
    Timeout in milliseconds. A value of 0 or 0xFFFFFFFFFFFFFFFF disables timeout

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOEventWait
(
    AOHandleType_t  hEvent,
    uint64_t        nTimeoutInMs
);

#ifdef __cplusplus
}
#endif
#endif // AOSAL_EVENT_H
