#ifndef AOSAL_TIME_H_
#define AOSAL_TIME_H_

/**================================================================================================

@file
   aosal_time.h

@brief
   This file defines functions that can be used to obtain and convert date and time

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#ifdef __cplusplus
extern "C" {
#endif

#include "AEEStdDef.h"
#include "aosal_error.h"

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/

/**================================================================================================
** Variables
================================================================================================**/

/**================================================================================================
** Typedefs
================================================================================================**/

/**********************************************************************************************//**
@brief
    Returns the system time (as a 64-bit value), the time elapsed since system was started.

@param pTime
    Pointer to the time in milliseconds
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOTimeGetTimeMilliSecond
(
    uint64_t *pTime
);

/**********************************************************************************************//**
@brief
    Returns the system time (as a 64-bit value), the time elapsed since system was started.

@param pTime
    Pointer to the time in microseconds
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOTimeGetTimeMicroSecond
(
    uint64_t *pTime
);

#ifdef __cplusplus
}
#endif

#endif // AOSAL_TIME_H_
