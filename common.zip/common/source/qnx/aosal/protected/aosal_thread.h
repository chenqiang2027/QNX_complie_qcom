#ifndef AOSAL_THREAD_H
#define AOSAL_THREAD_H
/**================================================================================================

@file
   aosal_thread.h

@brief
   This file defines a utility class that can be used to create and control threads.

Copyright (c) 2021-2022 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include <pthread.h>
#include "AEEStdDef.h"
#include "aosal_error.h"


#ifdef __cplusplus
extern "C" {
#endif

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/
extern const int32_t g_AOThreadCallingThreadPriority;
extern const int32_t g_AOThreadBackgroundPriority;
extern const int32_t g_AOThreadNormalPriority;
extern const int32_t g_AOThreadDefaultPriority;
extern const int32_t g_AOThreadNRTWorkerPriority;       // NRT: Non-RealTime
extern const int32_t g_AOThreadNRTHighPriority;
extern const int32_t g_AOThreadNRTISTPriority;
extern const int32_t g_AOThreadRTWorkerPriority;        // RT:  RealTime
extern const int32_t g_AOThreadRTHighPriority;
extern const int32_t g_AOThreadRTISTPriority;
extern const int32_t g_AOThreadSafetyReportPriority;

/**================================================================================================
** Variables
================================================================================================**/

/**================================================================================================
** Typedefs
================================================================================================**/

#ifndef AO_HANDLE_DEFINED
typedef void *AOHandleType_t;
#define AO_HANDLE_DEFINED
#endif

/**********************************************************************************************//**
@brief
    Defines thread cancellation state
**************************************************************************************************/
typedef enum
{
    AO_THREAD_CANCEL_ENABLE = 0,        /**< Thread is cancellable. Default setting. */
    AO_THREAD_CANCEL_DISABLE,           /**< Thread is not cancellable. Cancellation request is
                                             pending till the state is set to ENABLE */
    AO_THREAD_CANCEL_MAX = 0x7FFFFFFF
} AOThreadCancelState_e;

/**********************************************************************************************//**
@brief
    Macro to push a function into a thread's cancellation
    cleanup stack. It is invoked when the thread is cancelled
    (AOThreadDestroy with bCleanup equal to TRUE), the thread
    exits (AOThreadExit), or AOThreadCleanupPop with nonzero
    argument.
   
@param pfnHandler - cleanup handler declared as void (*pfnHandler)(void *pArg)
    
@param pArg       - pointer to the data passing the the function pfnHandler* *  
**************************************************************************************************/
#define AOThreadCleanupPush(pfnHandler, pArg)   pthread_cleanup_push((pfnHandler), (pArg)) 

/**********************************************************************************************//**
@brief
    Macro to pop a function from the thread's cancellation cleanup stack
    
@param nExecute - An int32_t integer. The popped thread is executed if this value is non-zero.
**************************************************************************************************/
#define AOThreadCleanupPop(nExecute)            pthread_cleanup_pop(nExecute) 

/**********************************************************************************************//**
@brief
    Creates a thread and begins execution

@param nPriority
    Thread priority
 
@param pfnStart
    Start routine at which thread execution starts.
    The return code of the start routine should not be AO_ERROR_SYSTEM_ERROR, i.e., MIN_INT32,
    which is reserved by AOSAL to indicate system error.
 
@param pStartArg
    Data pointer passed to start routine
 
@param nStackSize
    Size of thread stack
 
@param pStrName
    Null terminated Name of the thread
 
@param pHandle
    Pointer to the thread handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadCreate
(
    int32_t         nPriority,
    int32_t         (*pfnStart)(void* pArg),
    void            *pStartArg,
    uint32_t        nStackSize,
    const char      *pStrName,
    AOHandleType_t  *pHandle
);

/**********************************************************************************************//**
@brief
    Releases the resources associated with the target thread.
    
    In a normal scenario, i.e., the bCleanup flag is not set, client should ensure the
    target thread is properly exit before calling this API.
    
    In erroneous scenarios where the target thread needs to be cancelled,
    the bCleanup flag can be set to terminate the target thread.

@param handle
    Thread handle
 
@param bCleanup
    When this flag is set, the target thread is cancelled
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadDestroy
(
    AOHandleType_t  handle,
    boolean         bCleanup
);

/**********************************************************************************************//**
@brief
    Blocks the calling thread until the specified thread terminates.

@param handle
    Thread handle
 
@param pnExitCode
    Pointer to the return code of the joined thread. If not NULL, the value is
    set as one of the following:
    1. the return code from the thread entry function
    2. the exit code set by client via AOThreadExit
    3. AO_ERROR_SYSTEM_ERROR(i.e., MIN_INT32) when system error happens. Client
       can call AOGetSystemError() to retrieve the corresponding AOSAL status
       code.
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadJoin
(
    AOHandleType_t  handle,
    int32_t         *pnExitCode
);

/**********************************************************************************************//**
@brief
    Blocks the calling thread until the specified thread terminates with a time
    limit.

@param handle
    Thread handle
 
@param pnExitCode
    Pointer to the return code of the joined thread. If not NULL, the value is
    set as one of the following:
    1. the return code from the thread entry function
    2. the exit code set by client via AOThreadExit
    3. AO_ERROR_SYSTEM_ERROR(i.e., MIN_INT32) when system error happens. Client
       can call AOGetSystemError() to retrieve the corresponding AOSAL status
       code.
 
@param nTimeOut
    The time in millisecond to wait for the thread to terminate.
    A value of 0 indicates infinite wait time, i.e., the behavior of this API is
    the same as AOThreadJoin.
  
@return
    Error code defined in AOErrorCode_e. AO_ERROR_TIMEDOUT is returned when the
    thread join timeout.
**************************************************************************************************/
AOErrorCode_e AOThreadTimedJoin
(
    AOHandleType_t  handle,
    int32_t         *pnExitCode,
    uint64_t        nTimeOut
);

/**********************************************************************************************//**
@brief
    Exits the calling thread with the given code.

@param handle
    the thread handle
 
@param nExitCode
    the exit code except AO_ERROR_SYSTEM_ERROR(i.e., MIN_INT32) reserved by AOSAL.
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadExit
(
    AOHandleType_t  handle,
    int32_t         nExitCode
);

/**********************************************************************************************//**
@brief
    Detach the thread from the calling thread

@param handle
    Thread handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadDetach
(
    AOHandleType_t   handle
);

/**********************************************************************************************//**
@brief
    Query the priority of the thread.

@param handle
    Thread handle. If NULL, this API queries the priority of the
    calling thread.
 
@param pnPriority
    Thread priority
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadGetPriority
(
    AOHandleType_t  handle,
    int32_t         *pnPriority
);

/**********************************************************************************************//**
@brief
    Sets the priority of the thread.

@param handle
    Thread handle. If NULL, this API sets the priority of the
    calling thread.
 
@param nPriority
    Thread priority
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadSetPriority
(
    AOHandleType_t  handle,
    int32_t         nPriority
);

/**********************************************************************************************//**
@brief
    Sets a cancellation state of the calling thread

@param eState
    Cancellation state to be set

@param pOldState
    Pointer to the old cancellation state

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadSetCancelState
(
    AOThreadCancelState_e  eState,
    AOThreadCancelState_e  *pOldState
);

/**********************************************************************************************//**
@brief
    Create a cancellation point of the calling thread

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadTestCancel(void);

#ifdef __cplusplus
}
#endif

#endif // AOSAL_THREAD_H
