#ifndef AOSAL_SIGNAL_H
#define AOSAL_SIGNAL_H

/**================================================================================================

@file
   aosal_signal.h

@brief
   This file defines functions to send and receive signals typically 
   inter-process objects used for event notification. 

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include "AEEStdDef.h"
#include "aosal_error.h"

#ifdef __cplusplus
extern "C" {
#endif

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/

/**================================================================================================
** Variables
================================================================================================**/

/**================================================================================================
** Typedefs
================================================================================================**/

#ifndef AO_HANDLE_DEFINED
typedef void *AOHandleType_t;
#define AO_HANDLE_DEFINED
#endif

/**********************************************************************************************//**
@brief
	Defines signal attribute used during signal creation
**************************************************************************************************/
typedef enum
{
    AO_SIGNAL_ATTR_RESET_AUTOMATIC = 0, /**< Signal automatically cleared after being handled */
    AO_SIGNAL_ATTR_RESET_MANUAL,        /**< User controls the clearance of the signal after
                                             being set and handled. User calls AOSignalReset
                                             to reset the signal */
    AO_SIGNAL_ATTR_MAX = 0x7FFFFFFF
} AOSignalAttribute_e;

/**********************************************************************************************//**
@brief
    Creates a signal queue object

@param pHandle
    Pointer to the Signal Queue handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOSignalQCreate
(
    AOHandleType_t *pHandle
);

/**********************************************************************************************//**
@brief
    Releases the resources associated with the signal queue

@param handle
    Signal queue handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOSignalQDestroy
(
    AOHandleType_t  handle
);

/**********************************************************************************************//**
@brief
    This function blocks until any of the signals registered to the queue is set
    via AOSignalSet. If a signal handler has been registered when the signal is
    created then the handler is called, else function returns with the user data
    pointer passed in when creating the signal

@param handle
    Signal queue handle
 
@param bCounting  
    Applicable when signal was created with attribute AO_SIGNAL_ATTR_RESET_AUTOMATIC.
    
    If this flag is set to TRUE, setting a signal is counted. AOSignal()
    increments the count. AOSignalQWait() decrements the count and returns to
    the user. It blocks only when the count becomes zero.
    
    If this flag is set to FALSE, this function clears the count of all previous
    signal setting via AOSignalSet() and blocks till a new signal arrives.
 
@param nTimeOut
    The time in millisecond to wait for the signal to be set. A value of 0 or
    0xFFFFFFFFFFFFFFFF disables timeout.
 
@param ppUserArg
    User data pointer of the signal set when signal is created
 
@param pbTimedOut
    True indicates timeout of no signal set during the period of nTimeOut
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOSignalQWait
(
    AOHandleType_t  handle,
    boolean         bCounting,
    uint64_t        nTimeOut,
    void            **ppUserArg,
    boolean         *pbTimedOut
);

/**********************************************************************************************//**
@brief
    Creates a signal handle

    When the associated signal is set the registered call back will be called.  
    Note that the signal implementation does not have a context of its own, so 
    Wait() needs to be called to give context of execution for the handler to be
    called. 
  
    If the optional signal handler is registered then the handler will be called
    with the optional user argument when the signal is set else user argument is
    returned in Wait()/TimerWait() call.

@param hSignalQ
    The signal queue handle
 
@param pvUserArg
    Optional user data pointer to be passed in the call back or returned when
    the signal is set.
 
@param pfnSignalHandler
    Optional signal handler to be called when the signal is set
 
@param eSignalAttributes
    Signal attribute defined in AOSignalAttribute_e
 
@param phSignal
    Pointer to the signal handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOSignalCreate
(
    AOHandleType_t      hSignalQ,
    void                *pvUserArg,
    void                (*pfnSignalHandler)(void* pArg),
    AOSignalAttribute_e eSignalAttributes,
    AOHandleType_t      *phSignal
);

/**********************************************************************************************//**
@brief
    Releases the signal resources

@param handle
    Signal handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOSignalDestroy
(
    AOHandleType_t handle
);

/**********************************************************************************************//**
@brief
    Sets the signal in the associated signal queue

@param handle
    Signal handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOSignalSet
(
    AOHandleType_t  handle
);

/**********************************************************************************************//**
@brief
    Reset the signal state when the signal was created using the attribute
    AO_SIGNAL_ATTR_RESET_MANUAL as defined in AOSignalAttribute.  After the
    signal is raised, AOSAL library does not clear the signal until this API is
    called.

@param handle
    Signal handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOSignalReset
(
    AOHandleType_t  handle
);

#ifdef __cplusplus
}
#endif

#endif // AOSAL_SIGNAL_H
