#ifndef AOSAL_PROFILE_H_
#define AOSAL_PROFILE_H_
/**================================================================================================

@file
   aosal_profile.h

@brief
   This file defines functions that can be used to add event marks to profile log.

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================

                     INCLUDE FILES FOR MODULE

================================================================================================**/
#include "AEEStdDef.h"
#include "aosal_error.h"

#ifdef __cplusplus
extern "C" {
#endif

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/

/**================================================================================================
** Variables
================================================================================================**/

/**================================================================================================
** Typedefs
================================================================================================**/

#ifndef AO_HANDLE_DEFINED
typedef void *AOHandleType_t;
#define AO_HANDLE_DEFINED
#endif

/**********************************************************************************************//**
@brief
	Defines the profile domain
**************************************************************************************************/
typedef enum
{
    AO_PROFILE_DOMAIN_CAMERA = 0,
    AO_PROFILE_DOMAIN_CV,
    AO_PROFILE_DOMAIN_MAX = 0x7FFFFFFF
} AOProfileDomain_e;

/**********************************************************************************************//**
@brief
    Initializes profiling for a client

@param pHandle
    Pointer to the handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOProfileInit
(
    AOHandleType_t *pHandle
);

/**********************************************************************************************//**
@brief
    Deinitializes profiling

@param handle
    Profile handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOProfileDeInit
(
    AOHandleType_t handle
);

/**********************************************************************************************//**
@brief
    Configures profile

@param handle
    Profile handle
 
@param domain
    Profile domain defined in AOProfileDomain_e
 
@param bEnable
    True for enable otherwise disable
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOProfileConfig
(
    AOHandleType_t     handle,
    AOProfileDomain_e  eDomain,
    boolean            bEnable
);

/**********************************************************************************************//**
@brief
    Marks event id in system profiling log

@param handle
    Profile handle
 
@param nEventId
    User event ID to be added into profiling
 
@param nUserData
    User data
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOProfileInsertMarkID
(
    AOHandleType_t handle,
    uint32_t       nEventId,
    uint32_t       nUserData
);

#ifdef __cplusplus
}
#endif

#endif // AOSAL_PROFILE_H_
