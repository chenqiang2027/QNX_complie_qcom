#ifndef AOSAL_TIMER_H
#define AOSAL_TIMER_H
/**================================================================================================

@file
   aosal_timer.h

@brief
   This file defines provides functions to create timers.

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================

                     INCLUDE FILES FOR MODULE

================================================================================================**/
#include "AEEStdDef.h"
#include "aosal_time.h"
#include "aosal_error.h"

#ifdef __cplusplus
extern "C" {
#endif

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/

/**================================================================================================
** Variables
================================================================================================**/

/**================================================================================================
** Typedefs
================================================================================================**/

#ifndef AO_HANDLE_DEFINED
typedef void *AOHandleType_t;
#define AO_HANDLE_DEFINED
#endif

/**********************************************************************************************//**
@brief
    Creates a timer and returns the handle, when the timer
    expires the registered handler is invoked. One timer thread
    is created to receive timer msg from the kernel and make
    user registered timeout callback.

@param bPeriodic 
    True for periodic timer
    False for non-periodic timer
 
@param nTimeOut  - in milliseconds 
    If zero, the timer is created and stay in stopped state. If greater than
    zero (in milliseconds), the timer will be started immediately after
    creation.
 
@param pfnTimerHandler
    Timer callback handler to be invoked on timeout
 
@param pUserArg
    Optional user data pointer to be passed in the callback
 
@param pThreadName
    Thread name of the timer thread. If NULL, the thread name is
    defaulted to be "AOTimerDispatcher"

@param nThreadPrio
    Thread priority of the timer thread. It should be one of the
    thread priorities defined in aosal_thread.h
 
@param pHandle
    Pointer to the timer handle

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOTimerCreate
(
    boolean         bPeriodic,
    int64_t         nTimeOut,
    void            (*pfnTimerHandler)(void* pArg),
    void            *pUserArg,
    const char      *pThreadName,
    int32_t         nThreadPrio,
    AOHandleType_t  *pHandle
);

/**********************************************************************************************//**
@brief
    Releases the resources associated with the timer handle
 
@param handle
    The timer handle

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOTimerDestroy
(
    AOHandleType_t handle
);

/**********************************************************************************************//**
@brief
    Starts a timer for either periodic or non-periodic timer
 
@param handle
    Handle of the timer

@param nTimeOut
    Timeout in milliseconds

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOTimerStart
(
    AOHandleType_t      handle,
    int64_t             nTimeOut
);

/**********************************************************************************************//**
@brief
    Stops a timer
 
@param handle
    Handle of the timer

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOTimerStop
(
    AOHandleType_t     handle
);

/**********************************************************************************************//**
@brief
    Sleeps for specified time in milliseconds
 
@param nSleepTime
    Sleep time in milliseconds

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOTimerSleepMilliSecond
(
    uint32_t nSleepTime
);

/**********************************************************************************************//**
@brief
    Sleeps for specified time in microseconds
 
@param nSleepTime
    Sleep time in microseconds

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOTimerSleepMicroSecond
(
    uint32_t nSleepTime
);

#ifdef __cplusplus
}
#endif

#endif // AOSAL_TIMER_H
