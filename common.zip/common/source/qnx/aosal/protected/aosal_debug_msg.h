#ifndef AOSAL_DEBUG_MSG_H
#define AOSAL_DEBUG_MSG_H

/**================================================================================================

@file
   aosal_debug_msg.h

@brief
   This file contains data types, constants, and methods used to output debug messages

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include <sys/slog2.h>
#include <sys/slogcodes.h>
#include "AEEStdDef.h"
#include "aosal_error.h"


#ifdef __cplusplus
extern "C" {
#endif

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/

/**================================================================================================
** Typedefs
================================================================================================**/

/**********************************************************************************************//**
@brief
    Defines log subsystem id
**************************************************************************************************/
typedef enum
{
    AO_GENERAL = 0,
    AO_CAMERA,
    AO_CV_TASK,
    AO_CV_EVA,
    AO_CV_FASTCV,
    AO_CV_FADAS,
    AO_STATS,
    AO_LOG_SSID_COUNT,
    AO_LOG_SSID_MAX = 0x7FFFFFFF
} AOLogSSIDType_e;

/**********************************************************************************************//**
@brief
    Defines logging verbosity
**************************************************************************************************/
typedef enum
{
    AO_PRIO_LOW = 0,      /**< low verbosity level message */
    AO_PRIO_MEDIUM,       /**< medium verbosity level message */
    AO_PRIO_HIGH,         /**< high verbosity level message */
    AO_PRIO_CRITICAL,     /**< critical message: default logged */
    AO_PRIO_ERROR,        /**< error message: default logged */
    AO_PRIO_FATAL,        /**< fatal message: default logged */
    AO_PRIO_DEBUG,        /**< debug message */
    AO_PRIO_COUNT,
    AO_PRIO_MAX = 0x7FFFFFFF
} AOLogPriorityType_e;

/**================================================================================================
** Variables
================================================================================================**/

/**********************************************************************************************//**
@brief
    slog2 log buffer handle. Used by the AO_MSG Macro only. Client should not use it directly.
**************************************************************************************************/
extern slog2_buffer_t  g_hBuffer;

/**********************************************************************************************//**
@brief
   Log Enablement table. Used by the AO_MSG Macro only. Client should not use it directly. 
**************************************************************************************************/
extern boolean g_bLogTable[AO_LOG_SSID_COUNT][AO_PRIO_COUNT];

/**********************************************************************************************//**
@brief
    String of subsystem id. Used by the AO_MSG Macro only. Client should not use it directly.
**************************************************************************************************/
extern const char *g_pStringSSID[AO_LOG_SSID_COUNT];

/**********************************************************************************************//**
@brief
    String of Log Level. Used by the AO_MSG Macro only. Client should not use it directly.
**************************************************************************************************/
extern const char *g_pStringLvl[AO_PRIO_COUNT];

/**********************************************************************************************//**
@brief
    Map AOSAL verbosity level to Slog2. Used by the AO_MSG Macro only. Client should not use 
   it directly.

@param eLevel
    AOSAL priority level

@return
    Slog2 verbosity level
**************************************************************************************************/
uint32_t AOMapVerbLvlSlog2
(
    AOLogPriorityType_e eLevel
);

/**********************************************************************************************//**
@brief
    Initializes debug msg.
   
    Note: This API should be called when application is launching. Calling this
    function in the middle of use case may potentially impact performance.

@return
    Zero success otherwise failure
**************************************************************************************************/
AOErrorCode_e AODebugMsgInitialize
(
    void
);

/**********************************************************************************************//**
@brief
    Deinitializes debug msg.
   
@return
    Zero success otherwise failure
**************************************************************************************************/
AOErrorCode_e AODebugMsgDeinitialize
(
    void
);


/**********************************************************************************************//**
@brief
    Defines debug message helper macros. Used by the AO_MSG Macro only.
    Client should not use them directly.
**************************************************************************************************/
#define AO_SLOGC_START          (800)
#define AO_SLOG_MSG             (_SLOGC_TEST + AO_SLOGC_START)

#ifdef _WIN32
#define AO_PATH_DELIMITER  '\\'
#define AO_LOG_CONDITION(eSSID, eMask) (TRUE == g_bLogTable[(eSSID)][(eMask)])
#else
#define AO_PATH_DELIMITER  '/'
#define AO_LOG_CONDITION(eSSID, eMask)    \
                ((nullptr != g_hBuffer) && (TRUE == g_bLogTable[(eSSID)][(eMask)]))
#endif


/**********************************************************************************************//**
@brief
    Defines debug message macro.
**************************************************************************************************/
#define AO_MSG(eSSID, eMask, fmt, ...)                                              \
    do {                                                                            \
        const char *pBaseFile = strrchr(__FILE__, AO_PATH_DELIMITER);               \
        pBaseFile = (nullptr == pBaseFile)? pBaseFile: (&pBaseFile[1]);                \
        if(AO_LOG_CONDITION((eSSID), (eMask)))                                      \
        {                                                                           \
            (void)slog2f(g_hBuffer, AO_SLOG_MSG + (eSSID), AOMapVerbLvlSlog2(eMask),\
            "%s:%d [%s:%s]: " fmt, pBaseFile, __LINE__,                             \
            g_pStringSSID[(eSSID)], g_pStringLvl[(eMask)], ## __VA_ARGS__);         \
        }                                                                           \
    } while(0)

#ifdef __cplusplus
}
#endif

#endif // AOSAL_DEBUG_MSG_H
