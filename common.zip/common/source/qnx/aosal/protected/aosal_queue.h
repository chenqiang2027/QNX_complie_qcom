#ifndef AOSAL_QUEUE_H
#define AOSAL_QUEUE_H
/**================================================================================================

@file
   aosal_queue.h

@brief
   This file defines data types and methods for queue implementation

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include "AEEStdDef.h"
#include "aosal_error.h"

#ifdef __cplusplus
extern "C" {
#endif

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/

/**================================================================================================
** Variables
================================================================================================**/

/**================================================================================================
** Typedefs
================================================================================================**/

#ifndef AO_HANDLE_DEFINED
typedef void *AOHandleType_t;
#define AO_HANDLE_DEFINED
#endif

/**********************************************************************************************//**
@brief
    Creates a FIFO queue with optional blocking or non-blocking behavior.

@param nMaxElementSize
    Maximum size of each element in the queue
 
@param nQueueSize
    Total number of elements allowed in the queue
 
@param bBlocking
    If this flag is set to True, dequeueing an empty queue will be blocked until
    one element is enqueued

    If this flag is set to False, dequeueing an empty queue is returned
    immediately with zero data size populated.
 
@param pHandle
    Pointer to the queue handle

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueueCreate
(
    uint64_t        nMaxElementSize,
    uint32_t        nQueueSize,
    boolean         bBlocking,
    AOHandleType_t  *pHandle
);

/**********************************************************************************************//**
@brief
    Destroys the queue.
    
    If the blocking queue was created and the client thread is blocking on
    AOQueuePop(), client should first call AOQueueNotifyExit() which returns
    AO_ERROR_QUEUE_POP_EXIT for the popping thread to exit. Only in error cases,
    client can terminate the pop thread with AOThreadDestroy() with bCleanup flag
    before this API is called.
 
@param handle
    Handle of the queue

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueueDestroy
(
    AOHandleType_t handle
);

/**********************************************************************************************//**
@brief
    This API is used to notify the blocking queue to return AO_ERROR_QUEUE_POP_EXIT
	from AOQueuePop() so that the client popping thread can exit properly
    
    This API is not supported on a non-blocking queue.
    
@param handle
    Handle of the queue

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueueNotifyExit
(
    AOHandleType_t handle
);

/**********************************************************************************************//**
@brief
    Pushes an element to the queue
 
@param handle
    Handle of the queue

@param pData
    Pointer to the data to be enqueued. 

@param nDataSize
    Size of the data to be queued. It shall be no greater than
    the maximum element size passed in the AOQueueCreate API

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueuePush
(
    AOHandleType_t  handle,
    const void      *pData,
    uint64_t         nDataSize
);

/**********************************************************************************************//**
@brief
    Pops an element from a queue.
    
    For a blocking queue, when AOQueueNotifyExit() was called, this API will
    return AO_ERROR_QUEUE_POP_EXIT so that client can exit popping thread properly
 
@param handle
    Handle of the queue

@param pData
    Pointer to the buffer for the dequeued data. The memory holding the data
    shall be no smaller than the maximum element size passed in the
    AOQueueCreate API

@param pnDataSize
    Pointer to the dequeued data size. Zero value is filled if the queue is empty.

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueuePop
(
    AOHandleType_t  handle,
    void            *pData,
    uint64_t        *pnDataSize
);

/**********************************************************************************************//**
@brief
    Peeks an element from the queue. It does not delete the element from the
    queue. Peeking an empty blocking queue returns zero data size without being
    blocked.
 
@param handle
    Handle of the queue

@param pData
    Pointer to the buffer for the dequeued data. The memory holding the data
    shall be no smaller than the maximum element size passed in the
    AOQueueCreate API

@param pnDataSize
    Pointer to the dequeued data size. Zero value is filled if the queue is empty.

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueuePeek
(
    AOHandleType_t  handle,
    void            *pData,
    uint64_t        *pnDataSize
);

/**********************************************************************************************//**
@brief
    Flushes the queue. All elements in the queue are removed.

@param handle
    Handle of the queue

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueueFlush
(
    AOHandleType_t handle
);

/**********************************************************************************************//**
@brief
    Queries the number of elements in the queue.

@param handle
    Handle of the queue

@param pnNumElements
    Pointer to the number of elements in the queue

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueueGetNumElements
(
    AOHandleType_t handle,
    uint32_t       *pnNumElements
);

/**********************************************************************************************//**
@brief
    Queries the number of empty entries in the queue.

@param handle
    Handle of the queue

@param pnNumEmptyEntries
    Pointer to the number of empty entries in the queue

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueueGetNumEmptyEntries
(
    AOHandleType_t handle,
    uint32_t       *pnNumEmptyEntries
);

#ifdef __cplusplus
}
#endif

#endif // AOSAL_QUEUE_H
