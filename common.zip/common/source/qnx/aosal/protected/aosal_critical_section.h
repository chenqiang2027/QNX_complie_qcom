#ifndef AOSAL_CRITICAL_SECTION_H
#define AOSAL_CRITICAL_SECTION_H
/**================================================================================================

@file
   aosal_critical_section.h

@brief
   This file contains data types, constants, and methods used to synchronize access 
   to data in multi-threaded environment

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/

#include "AEEStdDef.h"
#include "aosal_error.h"

#ifdef __cplusplus
extern "C" {
#endif

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/

/**================================================================================================
** Variables
================================================================================================**/

/**================================================================================================
** Typedefs
================================================================================================**/


#ifndef AO_HANDLE_DEFINED
typedef void *AOHandleType_t;
#define AO_HANDLE_DEFINED
#endif

/**********************************************************************************************//**

@brief
    Creates a critical section

@param pHandle
    Pointer to the critical section handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOCriticalSectionCreate
(
    AOHandleType_t  *pHandle
);

/**********************************************************************************************//**
@brief
    Releases the resources associated with the critical section

@param handle
    The critical section handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOCriticalSectionDestroy
(
    AOHandleType_t  handle
);


/**********************************************************************************************//**
@brief
    Enter a critical section, blocks if another thread is inside the critical 
    section until the other thread leaves the critical section.

@param handle
    The critical section handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOCriticalSectionEnter
(
    AOHandleType_t  handle
);

/**********************************************************************************************//**
@brief
    Leave a critical section (releases the lock).

@param handle
    The critical section handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOCriticalSectionLeave
(
    AOHandleType_t  handle
);

#ifdef __cplusplus
}
#endif

#endif // AOSAL_CRITICAL_SECTION_H
