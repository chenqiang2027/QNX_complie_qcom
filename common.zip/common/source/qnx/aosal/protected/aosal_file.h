#ifndef AOSAL_FILE_H
#define AOSAL_FILE_H

/**================================================================================================

@file
   aosal_file.h

@brief
   This file defines functions to support file open/close/read/write operations.

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include "AEEStdDef.h"
#include "aosal_error.h"

#ifdef __cplusplus
extern "C" {
#endif

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/

/**********************************************************************************************//**
@brief
	file permission bits
**************************************************************************************************/
#define   AO_FILE_USER_READ     (1 << 0)
#define   AO_FILE_USER_WRITE    (1 << 1)
#define   AO_FILE_USER_EXEC     (1 << 2)

#define   AO_FILE_GROUP_READ    (1 << 4)
#define   AO_FILE_GROUP_WRITE   (1 << 5)
#define   AO_FILE_GROUP_EXEC    (1 << 6)

#define   AO_FILE_OTHERS_READ   (1 << 8)
#define   AO_FILE_OTHERS_WRITE  (1 << 9)
#define   AO_FILE_OTHERS_EXEC   (1 << 10)

/**================================================================================================
** Variables
================================================================================================**/

/**================================================================================================
** Typedefs
================================================================================================**/

#ifndef AO_FILE_HANDLE_DEFINED
typedef int32_t AOFileHandleType_t;
#define AO_FILE_HANDLE_DEFINED
#endif

/**********************************************************************************************//**
@brief
	Defines the file open mode
**************************************************************************************************/
typedef enum
{
    AO_FILE_CREATE_R = 0,  /**< open for read */
    AO_FILE_CREATE_R_PLUS,  /**< open for read and write */
    AO_FILE_CREATE_W,       /**< truncate or create file for write */
    AO_FILE_CREATE_W_PLUS,  /**< truncate or create for read and write */
    AO_FILE_CREATE_A,       /**< open+seek_to_the_end or create file for write */
    AO_FILE_CREATE_MODE_MAX = 0x7FFFFFFF
} AOFileOpenMode_e;

/**********************************************************************************************//**
@brief
	Defines the file pointer position for seek operation
**************************************************************************************************/
typedef enum
{
	AO_FILE_SEEK_BEGIN = 0,
	AO_FILE_SEEK_CURRENT,
	AO_FILE_SEEK_END,
	AO_FILE_SEEK_MAX = 0x7FFFFFFF
} AOFileSeekPosition_e;

/**********************************************************************************************//**
@brief
    Creates/Opens a file

@param pFilePath
    Name and path of the file to act on
 
@param eMode
    Mode to be used to create a file (AOFileOpenMode_e)
 
@param pHandle
    Pointer to the file handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOFileOpen
(
    const char            *pFilePath,
    AOFileOpenMode_e      eMode,
    AOFileHandleType_t    *pHandle
);

/**********************************************************************************************//**
@brief
    Close the file associated with the file handle

@param handle
    File handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOFileClose
(
    AOFileHandleType_t handle
);

/**********************************************************************************************//**
@brief
    Reads data from a file into the buffer

@param handle
    File handle
 
@param pBuffer
    Pointer to the buffer to which data may be copied
 
@param nSize
    Number of bytes to read, assumes pBuffer is big enough to hold nSize
 
@param pnBytesRead
    Pointer to number of bytes read from file
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOFileRead
(
    AOFileHandleType_t    handle,
    char                  *pBuffer,
    uint64_t              nSize,
    int64_t               *pnBytesRead
);

/**********************************************************************************************//**
@brief
    Reposition the file pointer to the given offset in an open file.

@param handle
    File handle
 
@param nOffset
    Number of bytes to offset from eWhence
 
@param eWhence
    Position from where the nOffset is added
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOFileSeek
(
    AOFileHandleType_t      handle,
    int64_t                 nOffset, 
    AOFileSeekPosition_e    eWhence
);

/**********************************************************************************************//**
@brief
    Writes data from the buffer into the file

@param handle
    File handle
 
@param pBuffer
    Pointer to the buffer that contains the data
 
@param nSize
    Number of bytes to be written
 
@param pnBytesWritten
    Pointer to number of bytes written into pBuffer
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOFileWrite 
(
    AOFileHandleType_t  handle,
    const char          *pBuffer, 
    uint64_t            nSize, 
    int64_t             *pnBytesWritten
);

/**********************************************************************************************//**
@brief
    Retrieves the current file position

@param handle
    File handle

@param pnOffset
    Current position of the File

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOFileGetCurrentPosition
(
    AOFileHandleType_t      handle,
    int64_t                 *pnOffset
);

#ifdef __cplusplus
}
#endif

#endif // AOSAL_FILE_H
