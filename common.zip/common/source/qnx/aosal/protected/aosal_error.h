#ifndef AOSAL_ERROR_H
#define AOSAL_ERROR_H

/**================================================================================================

@file
   aosal_error.h

@brief
   This file has the generic error codes            

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include "AEEStdDef.h"

#ifdef __cplusplus
extern "C" {
#endif

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/

/**********************************************************************************************//**
@brief
    Defnition of AOSAL status code
**************************************************************************************************/
typedef enum
{
    AO_SUCCESS = 0,                    // Success
    AO_ERROR_FAILURE,                  // Generic failure
    AO_ERROR_BAD_PARAMETER,            // Bad Parameter
    AO_ERROR_INVAL,                    // Invalid operation
    AO_ERROR_FILE_IO_PENDING,          // File IO is pending 
    AO_ERROR_FILE_IO,                  // Error in File IO
    AO_ERROR_FILE_OPEN_EXCEEDED,       // Numbers of files opened exceeded the limit 
    AO_ERROR_FILE_PATH_NAME_TOOLONG,   // File path name too long  
    AO_ERROR_FILE_EXISTS,              // File with same name already exists
    AO_ERROR_IS_DIRECTORY,             // It is a directory
    AO_ERROR_BAD_FILE_DESCRIPTOR,      // Bad File descriptor passed
    AO_ERROR_INTR_BY_SIGNAL,           // Interrupted system call  
    AO_ERROR_SEEK_NOT_PERMITTED,       // Seek operation not permitted
    AO_ERROR_FILE_OPENED,              // File or directory already open
    AO_ERROR_FILE_PIPE,                // Error in pipe
    AO_ERROR_FILE_OFFSET,              // Too large Offset
    AO_ERROR_OP_NOT_PERMITTED,         // Operation not permitted
    AO_ERROR_NO_SUCH_FILE,             // File does not exists
    AO_ERROR_NO_PROCESS,               // No such process
    AO_ERROR_NO_MEM,                   // Not enough space
    AO_ERROR_NO_RSRC,                  // Resource unavailable, try again 
    AO_ERROR_BUSY,                     // Device or resource busy
    AO_ERROR_ALREADY_OWNS_MUTEX,       // Deadlock avoided 
    AO_ERROR_TIMEDOUT,                 // Connection timed out
    AO_ERROR_QUEUE_POP_EXIT,           // Exit from popping a blocking queue
    AO_ERROR_NOT_SUPPORTED,            // Not supported
                                       // Do not add new status code below AO_ERROR_SYSTEM_ERROR
    /*-----------------------------------------------------------------------------------------*/
    AO_ERROR_SYSTEM_ERROR = MIN_INT32, // System error
    AO_ERROR_MAX = 0x7FFFFFFF
} AOErrorCode_e;

/**********************************************************************************************//**
@brief
    Get detailed AOSAL error code when AO_ERROR_SYSTEM_ERROR is
    received.

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOGetSystemError
(
    void
);

#ifdef __cplusplus
}
#endif

#endif //AOSAL_ERROR_H


