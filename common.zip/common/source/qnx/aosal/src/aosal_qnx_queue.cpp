/**================================================================================================

@file
   aosal_qnx_queue.cpp

@brief
   This file contains queue implementation

Copyright (c) 2021-2022 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include <pthread.h>
#include "aosal_qnx_utils.h"
#include "aosal_malloc.h"
#include "aosal_debug_msg.h"
#include "aosal_critical_section.h"
#include "aosal_signal.h"
#include "aosal_queue.h"
#include "aosal_error.h"
#include "aosal_timer.h"

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/

#define  AO_MAX_NUM_QUEUE              (512)

/**================================================================================================
** Typedefs
================================================================================================**/

typedef enum
{
    AO_QUEUE_SIGNAL_PUSH = 0,
    AO_QUEUE_SIGNAL_EXIT,
    AO_QUEUE_SIGNAL_COUNT,
    AO_QUEUE_SIGNAL_MAX = 0x7FFFFFFF
} AOQueueSignals_e;

/**********************************************************************************************//**
@brief
   Queue context
**************************************************************************************************/
typedef struct
{
    size_t          nSize;                          /**< size of this structure */
    AOHandleType_t  hCS;                            /**< critical section */
    AOHandleType_t  hSignalQ;                       /**< wait SignalQ for blocking queue */
    AOHandleType_t  hSignals[AO_QUEUE_SIGNAL_COUNT];/**< Signals defined in AOQueueSignals_e */
    boolean         bBlocking;                      /**< flag to indicate blocking queue */
    uint32_t        nElementCnt;                    /**< Current element count in the queue */
    uint32_t        nQueueSize;                     /**< Queue length */
    uint64_t        nMaxElementSize;                /**< maximum size for each element */
    uint32_t        nReadIdx;                       /**< read index [0, nMaxElementSize - 1] */
    uint32_t        nWriteIdx;                      /**< write index [0, nMaxElementSize - 1] */
    uint64_t        nReadPos;                       /**< read position of the DataArray:
                                                        [0, (nMaxElementSize -1) * nQueueSize] */
    uint64_t        nWritePos;                      /**< write position of the DataArray:
                                                        [0, (nMaxElementSize -1) * nQueueSize] */
    uint8_t         *pDataEntry;                    /**< pointer to data memory */
    uint64_t        *pDataSize;                     /**< pointer to data size memory */
} AOQueueCtxt_t;

/**================================================================================================
** Variables
================================================================================================**/

static const void *g_pQueueCtxt[AO_MAX_NUM_QUEUE] = { NULL };


static AOErrorCode_e AOQueueAllocSignals(AOQueueCtxt_t *pCtxt);

/**********************************************************************************************//**
@brief
    Allocates signals for blocking queue.

@param pCtxt
    Pointer to the queue context

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
static AOErrorCode_e AOQueueAllocSignals
(
    AOQueueCtxt_t *pCtxt
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOErrorCode_e eSts = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(pCtxt) || AO_CHK_STRUCT_SIZE(pCtxt->nSize, sizeof(AOQueueCtxt_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        if (TRUE == pCtxt->bBlocking)
        {
            if(AO_SUCCESS != (eSts = AOSignalQCreate(&pCtxt->hSignalQ)))
            {
                eResult = eSts;
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Failed create SignalQ");
            }
            else
            {
                uint32_t i;
                for (i = 0; i < AO_QUEUE_SIGNAL_COUNT; i++)
                {
                    if( AO_SUCCESS != (eSts = AOSignalCreate(pCtxt->hSignalQ,
                                            &pCtxt->hSignals[i],
                                            NULL,
                                            AO_SIGNAL_ATTR_RESET_AUTOMATIC,
                                            &pCtxt->hSignals[i])))
                    {
                        eResult = eSts;
                        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Failed create signal");
                        break;
                    }
                }

                if (AO_QUEUE_SIGNAL_COUNT == i)
                {
                    /* blocking queue */
                    eResult = AO_SUCCESS;
                }
            }
        }
        else
        {
            /* non-blocking queue */
            eResult = AO_SUCCESS;
        }
    }

    return eResult;
}


/**********************************************************************************************//**
@brief
    Creates a FIFO queue with optional blocking or non-blocking behavior.

@param nMaxElementSize
    Maximum size of each element in the queue

@param nQueueSize
    Total number of elements allowed in the queue

@param bBlocking
    If this flag is set to True, dequeueing an empty queue will be blocked until
    one element is enqueued

    If this flag is set to False, dequeueing an empty queue is returned
    immediately with zero data size populated.

@param pHandle
    Pointer to the queue handle

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueueCreate
(
    uint64_t        nMaxElementSize,
    uint32_t        nQueueSize,
    boolean         bBlocking,
    AOHandleType_t  *pHandle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOQueueCtxt_t  *pCtxt = NULL;

    if (AO_CHK_NULL(pHandle) || (0 == nQueueSize) || (0 == nMaxElementSize))
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
               "AOQueueCreate: nQueueSize %d nMaxElementSize %ld", nQueueSize, nMaxElementSize);
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        pCtxt = (AOQueueCtxt_t *)AOMalloc(sizeof(AOQueueCtxt_t));

        if (NULL == pCtxt)
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Failed allocation size %ld", sizeof(AOQueueCtxt_t));
            eResult = AO_ERROR_NO_MEM;
        }
        else if (NULL== AOMemset(pCtxt, 0, sizeof(AOQueueCtxt_t))) 
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMemset failed");
            eResult = AO_ERROR_FAILURE;
        }
        else
        {
            pCtxt->nSize = sizeof(AOQueueCtxt_t);

            if(AO_SUCCESS != AOAddPointerEntry(&g_pQueueCtxt[0], (void *)pCtxt, AO_MAX_NUM_QUEUE))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Reached max number of queues");
                AOFree(pCtxt);
                pCtxt = NULL;
                eResult = AO_ERROR_FAILURE;
            }
            else
            {
                uint64_t nMemSize = nMaxElementSize * nQueueSize;

                pCtxt->pDataEntry = (uint8_t *)AOMalloc(nMemSize);
                pCtxt->pDataSize = (uint64_t *)AOMalloc(nQueueSize * sizeof(pCtxt->nMaxElementSize));

                if (AO_CHK_NULL(pCtxt->pDataEntry) || AO_CHK_NULL(pCtxt->pDataSize))
                {
                    eResult = AO_ERROR_NO_MEM;
                }
                else if((NULL == AOMemset(pCtxt->pDataEntry, 0, nMemSize)) ||
                        (NULL == AOMemset(pCtxt->pDataSize, 0, nQueueSize * sizeof(pCtxt->nMaxElementSize))))
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMemset failed");
                    eResult = AO_ERROR_FAILURE;
                }
                else
                {
                    AOErrorCode_e eSts = AO_ERROR_FAILURE;

                    if (AO_SUCCESS != (eSts = AOCriticalSectionCreate(&pCtxt->hCS)))
                    {
                        eResult = eSts;
                        pCtxt->hCS = NULL;
                        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Failed create CS");
                    }
                    else
                    {
                        pCtxt->bBlocking = bBlocking;

                        eResult = AOQueueAllocSignals(pCtxt);
                    }
                }
            }
        }

        if (AO_SUCCESS == eResult)
        {
            pCtxt->nMaxElementSize = nMaxElementSize;
            pCtxt->nQueueSize = nQueueSize;
            *pHandle = (AOHandleType_t) pCtxt;
        }
        else
        {
            /* error case clean up */
            if (NULL != pCtxt)
            {
                for (uint32_t i = 0; i < AO_QUEUE_SIGNAL_COUNT; i++)
                {
                    if (NULL != pCtxt->hSignals[i])
                    {
                        (void)AOSignalQDestroy(pCtxt->hSignals[i]);
                    }
                }

                if (NULL != pCtxt->hSignalQ)
                {
                    (void)AOSignalQDestroy(pCtxt->hSignalQ);
                }

                if (NULL != pCtxt->pDataSize)
                {
                    AOFree(pCtxt->pDataSize);
                }

                if (NULL != pCtxt->pDataEntry)
                {
                    AOFree(pCtxt->pDataEntry);
                }

                if (NULL != pCtxt->hCS)
                {
                    (void)AOCriticalSectionDestroy(pCtxt->hCS);
                }

                (void) AORemovePointerEntry(&g_pQueueCtxt[0], (void *)pCtxt, AO_MAX_NUM_QUEUE);

                AOFree(pCtxt);
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    This API is used to notify the blocking queue to return AO_ERROR_QUEUE_POP_EXIT
	from AOQueuePop() so that the client popping thread can exit properly
    
    This API is not supported on a non-blocking queue.
    
@param handle
    Handle of the queue

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueueNotifyExit
(
    AOHandleType_t handle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOErrorCode_e eSts = AO_ERROR_FAILURE;
    AOQueueCtxt_t *pCtxt = (AOQueueCtxt_t *) handle;

    if (AO_CHK_NULL(pCtxt) || AO_CHK_STRUCT_SIZE(pCtxt->nSize, sizeof(AOQueueCtxt_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else if (FALSE == pCtxt->bBlocking)
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "this API is not supported on non-blocking queue");
        eResult = AO_ERROR_NOT_SUPPORTED;
    }
    else
    {
        if(AO_SUCCESS != (eSts = AOCriticalSectionEnter(pCtxt->hCS)))
        {
            eResult = eSts;
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionEnter");
        }
        else
        {
            if (AO_SUCCESS != (eSts = AOSignalSet(
                        pCtxt->hSignals[AO_QUEUE_SIGNAL_EXIT])))
            {
                eResult = eSts;
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "set Exit signal failed");
            }
            else
            {
                eResult = AO_SUCCESS;
            }

            if (AO_SUCCESS != (eSts = AOCriticalSectionLeave(pCtxt->hCS)))
            {
                eResult = eSts;
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionLeave failed");
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Destroys the queue.
    
    If the blocking queue was created and the client thread is blocking on
    AOQueuePop(), client should first call AOQueueNotifyExit() which returns
    AO_ERROR_QUEUE_POP_EXIT for the popping thread to exit. Only in error cases,
    client can terminate the pop thread with AOThreadDestroy() with bCleanup flag
    before this API is called.
 
@param handle
    Handle of the queue

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueueDestroy
(
    AOHandleType_t handle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(handle))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        AOQueueCtxt_t *pCtxt = (AOQueueCtxt_t *) handle;

        if(AO_SUCCESS != AORemovePointerEntry(&g_pQueueCtxt[0], handle, AO_MAX_NUM_QUEUE))
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Invalid handle or has been destroyed 0x%p", handle);
        }
        else
        {
            if (pCtxt->nElementCnt > 0)
            {
                AO_MSG(AO_GENERAL, AO_PRIO_HIGH,
                       "Queue is not empty %d. All data are destroyed", pCtxt->nElementCnt);
            }

            if (TRUE == pCtxt->bBlocking)
            {
                for (uint32_t i = 0; i < AO_QUEUE_SIGNAL_COUNT; i++)
                {
                    if (NULL != pCtxt->hSignals[i])
                    {
                        if(AO_SUCCESS != AOSignalDestroy(pCtxt->hSignals[i]))
                        {
                            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOSignalDestroy %p failed",
                                   pCtxt->hSignals[i]);
                        }
                        pCtxt->hSignals[i] = NULL;
                    }
                }

                if (NULL != pCtxt->hSignalQ)
                {
                    if(AO_SUCCESS != AOSignalQDestroy(pCtxt->hSignalQ))
                    {
                        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOSignalQDestroy %p failed",
                               pCtxt->hSignalQ);
                    }
                    pCtxt->hSignalQ = NULL;
                }
            }


            if (NULL != pCtxt->pDataSize)
            {
                AOFree(pCtxt->pDataSize);
                pCtxt->pDataSize = NULL;
            }

            if (NULL != pCtxt->pDataEntry)
            {
                AOFree(pCtxt->pDataEntry);
                pCtxt->pDataEntry = NULL;
            }

            if (NULL != pCtxt->hCS)
            {
                if(AO_SUCCESS != AOCriticalSectionDestroy(pCtxt->hCS))
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionDestroy %p failed",
                           pCtxt->hCS);
                }
                pCtxt->hCS = NULL;
            }

            AOFree(pCtxt);

            eResult = AO_SUCCESS;
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Pushes an element to the queue
 
@param handle
    Handle of the queue

@param pData
    Pointer to the data to be enqueued. 

@param nDataSize
    Size of the data to be queued. It shall be no greater than
    the maximum element size passed in the AOQueueCreate API

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueuePush
(
    AOHandleType_t  handle,
    const void      *pData,
    uint64_t        nDataSize
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOErrorCode_e eSts = AO_ERROR_FAILURE;
    AOQueueCtxt_t *pCtxt = (AOQueueCtxt_t *) handle;

    if (AO_CHK_NULL(pCtxt) || AO_CHK_STRUCT_SIZE(pCtxt->nSize, sizeof(AOQueueCtxt_t)) ||
        AO_CHK_NULL(pData) || (0 == nDataSize) || (nDataSize > pCtxt->nMaxElementSize) )
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOQueuePush: nDataSize %ld", nDataSize);
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        if(AO_SUCCESS != (eSts = AOCriticalSectionEnter(pCtxt->hCS)))
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionEnter");
            eResult = eSts;
        }
        else
        {
            if (pCtxt->nElementCnt >= pCtxt->nQueueSize)
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Queue is full already");
            }
            else
            {
                uint64_t nCopied;

                nCopied = AOMemscpy(&pCtxt->pDataEntry[pCtxt->nWritePos], 
                          pCtxt->nMaxElementSize, pData, nDataSize);

                if (nCopied != nDataSize)
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
                           "Push queue failed copied %ld expect %ld", nCopied, nDataSize);
                    eResult = AO_ERROR_FAILURE;
                }
                else
                {
                    pCtxt->pDataSize[pCtxt->nWriteIdx] = nDataSize;
                    pCtxt->nElementCnt++;

                    pCtxt->nWriteIdx++;
                    pCtxt->nWritePos += pCtxt->nMaxElementSize;

                    if (pCtxt->nWriteIdx == pCtxt->nQueueSize)
                    {
                        pCtxt->nWriteIdx = 0;
                        pCtxt->nWritePos = 0;
                    }

                    if (TRUE == pCtxt->bBlocking)
                    {
                        if (AO_SUCCESS != (eSts = AOSignalSet(
                                        pCtxt->hSignals[AO_QUEUE_SIGNAL_PUSH])))
                        {
                            eResult = eSts;
                            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "set Push signal failed");
                        }
                        else
                        {
                            /* blocking queue */
                            eResult = AO_SUCCESS;
                        }
                    }
                    else
                    {
                        /* non-blocking queue */
                        eResult = AO_SUCCESS;
                    }
                }
            }

            if (AO_SUCCESS != (eSts = AOCriticalSectionLeave(pCtxt->hCS)))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionLeave failed");
                eResult = eSts;
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Pops an element from a queue.
    
    For a blocking queue, when AOQueueNotifyExit() was called, this API will
    return AO_ERROR_QUEUE_POP_EXIT so that client can exit popping thread properly
 
@param handle
    Handle of the queue

@param pData
    Pointer to the buffer for the dequeued data. The memory holding the data
    shall be no smaller than the maximum element size passed in the
    AOQueueCreate API

@param pnDataSize
    Pointer to the dequeued data size. Zero value for an empty queue.

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueuePop
(
    AOHandleType_t  handle,
    void            *pData,
    uint64_t        *pnDataSize
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOErrorCode_e eSts = AO_ERROR_FAILURE;

    AOQueueCtxt_t *pCtxt = (AOQueueCtxt_t *) handle;

    if (AO_CHK_NULL(pCtxt) || AO_CHK_STRUCT_SIZE(pCtxt->nSize, sizeof(AOQueueCtxt_t)) ||
        AO_CHK_NULL(pData) || AO_CHK_NULL(pnDataSize) )
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        eResult = AO_SUCCESS;

        *pnDataSize = 0;

        if (TRUE == pCtxt->bBlocking)
        {
            void        *phSignal = NULL;
            boolean     bWait = TRUE;

            while ((TRUE == bWait) && (AO_SUCCESS == eResult))
            {
                /* using counted signal. Will block only when count is 0 */
                if(AO_SUCCESS != (eSts = AOSignalQWait(pCtxt->hSignalQ,
                                                       TRUE,
                                                       0,
                                                       (void **)&phSignal,
                                                       NULL)))
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOSignalQWait failed");
                    eResult = eSts;
                }
                else
                {
                    if (phSignal == &pCtxt->hSignals[AO_QUEUE_SIGNAL_EXIT])
                    {
                        eResult = AO_ERROR_QUEUE_POP_EXIT;
                        bWait = FALSE;
                    }
                    else if (phSignal == &pCtxt->hSignals[AO_QUEUE_SIGNAL_PUSH])
                    {
                        eResult = AO_SUCCESS;
                        bWait = FALSE;
                    }
                    else
                    {
                        /* SignalQWait returns but without signal set */
                        if(AO_SUCCESS == AOCriticalSectionEnter(pCtxt->hCS))
                        {
                            if (pCtxt->nElementCnt > 0)
                            {
                                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Not supported signals");
                                eResult = AO_ERROR_FAILURE;
                            }
                            else
                            {
                                /* Multi-threads compete the same queue.
                                   Signal was serviced by other threads already */
                                bWait = TRUE;
                            }

                            if (AO_SUCCESS != AOCriticalSectionLeave(pCtxt->hCS)) 
                            {
                                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionLeave failed");
                                eResult = AO_ERROR_FAILURE;
                            }
                        }
                        else
                        {
                            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionEnter failed");
                            eResult = AO_ERROR_FAILURE;
                        }
                    }
                }
            }
        }

        if (AO_SUCCESS == eResult)
        {
            if (AO_SUCCESS != AOCriticalSectionEnter(pCtxt->hCS))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionEnter failed");
                eResult = AO_ERROR_FAILURE;
            }
            else
            {
                if (pCtxt->nElementCnt > 0)
                {
                    uint64_t nCopied;

                    *pnDataSize = pCtxt->pDataSize[pCtxt->nReadIdx];

                    nCopied = AOMemscpy(pData,
                                        *pnDataSize,
                                        &pCtxt->pDataEntry[pCtxt->nReadPos],
                                        *pnDataSize);

                    if (nCopied == *pnDataSize) 
                    {
                        pCtxt->nElementCnt--;

                        pCtxt->nReadIdx++;
                        pCtxt->nReadPos += pCtxt->nMaxElementSize;

                        if (pCtxt->nReadIdx == pCtxt->nQueueSize)
                        {
                            pCtxt->nReadIdx = 0;
                            pCtxt->nReadPos = 0;
                        }
                    }
                    else
                    {
                        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Pop queue failed copied %ld expect %ld",
                                nCopied, *pnDataSize);
                        eResult = AO_ERROR_FAILURE;
                    }
                }
                else
                {
                    /* empty non-blocking queue */
                    *pnDataSize = 0;
                }

                if (AO_SUCCESS != AOCriticalSectionLeave(pCtxt->hCS)) 
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionLeave failed");
                    eResult = AO_ERROR_FAILURE;
                }
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Peeks an element from the queue. It does not delete the element from the
    queue. Peeking an empty blocking queue returns zero data size without being
    blocked.
 
@param handle
    Handle of the queue

@param pData
    Pointer to the buffer for the dequeued data. The memory holding the data
    shall be no smaller than the maximum element size passed in the
    AOQueueCreate API

@param pnDataSize
    Pointer to the dequeued data size. Zero value is filled if the queue is empty.

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueuePeek
(
    AOHandleType_t  handle,
    void            *pData,
    uint64_t        *pnDataSize
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    AOQueueCtxt_t *pCtxt = (AOQueueCtxt_t *) handle;

    if (AO_CHK_NULL(pCtxt) || AO_CHK_STRUCT_SIZE(pCtxt->nSize, sizeof(AOQueueCtxt_t)) ||
        AO_CHK_NULL(pData) || AO_CHK_NULL(pnDataSize) )
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        if (AO_SUCCESS != AOCriticalSectionEnter(pCtxt->hCS))
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionEnter failed");
            eResult = AO_ERROR_FAILURE;
        }
        else
        {
            AOErrorCode_e eSts = AO_ERROR_FAILURE;

            if (pCtxt->nElementCnt > 0)
            {
                uint64_t nCopied;

                *pnDataSize = pCtxt->pDataSize[pCtxt->nReadIdx];

                nCopied = AOMemscpy(pData,
                                    *pnDataSize,
                                    &pCtxt->pDataEntry[pCtxt->nReadPos],
                                    *pnDataSize);

                if (nCopied != *pnDataSize) 
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Peek queue failed copied %ld expect %ld",
                            nCopied, *pnDataSize);
                    eResult = AO_ERROR_FAILURE;
                }
                else
                {
                    eResult = AO_SUCCESS;
                }
            }
            else
            {
                *pnDataSize = 0;
                eResult = AO_SUCCESS;
            }

            if (AO_SUCCESS != (eSts = AOCriticalSectionLeave(pCtxt->hCS)))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionLeave failed");
                eResult = eSts;
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Flushes the queue. All elements in the queue are removed.

@param handle
    Handle of the queue

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueueFlush
(
    AOHandleType_t handle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOErrorCode_e eSts = AO_ERROR_FAILURE;

    AOQueueCtxt_t *pCtxt = (AOQueueCtxt_t *)handle;

    if (AO_CHK_NULL(pCtxt) || AO_CHK_STRUCT_SIZE(pCtxt->nSize, sizeof(AOQueueCtxt_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        if (AO_SUCCESS != (eSts = AOCriticalSectionEnter(pCtxt->hCS)))
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionEnter failed");
            eResult = eSts;
        }
        else
        {
            pCtxt->nReadIdx = 0;
            pCtxt->nReadPos = 0;
            pCtxt->nWriteIdx = 0;
            pCtxt->nWritePos = 0;
            pCtxt->nElementCnt = 0;

            AOErrorCode_e eBlockingQSts = AO_ERROR_FAILURE;

            if (TRUE == pCtxt->bBlocking)
            {
                if (AO_SUCCESS != (eBlockingQSts = AOSignalReset(pCtxt->hSignals[AO_QUEUE_SIGNAL_PUSH]))) 
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOSignalReset failed %d", eBlockingQSts);
                    eBlockingQSts = AO_ERROR_FAILURE;
                }
                else
                {
                    eBlockingQSts = AO_SUCCESS;
                }
            }

            if ((TRUE == pCtxt->bBlocking) && (AO_SUCCESS != eBlockingQSts)) 
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Blocking queue failed");
            }
            else if( NULL == AOMemset(pCtxt->pDataEntry, 0, pCtxt->nQueueSize * pCtxt->nMaxElementSize))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMemset failed");
                eResult = AO_ERROR_SYSTEM_ERROR;
            }
            else if(NULL == AOMemset(pCtxt->pDataSize, 0,
                                     pCtxt->nQueueSize * sizeof(pCtxt->nMaxElementSize)))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMemset failed");
                eResult = AO_ERROR_SYSTEM_ERROR;
            }
            else
            {
                eResult = AO_SUCCESS;
            }

            if (AO_SUCCESS != (eSts = AOCriticalSectionLeave(pCtxt->hCS)))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionLeave failed");
                eResult = eSts;
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Queries the number of elements in the queue.

@param handle
    Handle of the queue

@param pnNumElements
    Pointer to the number of elements in the queue

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueueGetNumElements
(
    AOHandleType_t handle,
    uint32_t       *pnNumElements
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOErrorCode_e eSts = AO_ERROR_FAILURE;

    AOQueueCtxt_t *pCtxt = (AOQueueCtxt_t *)handle;

    if (AO_CHK_NULL(pCtxt) || AO_CHK_STRUCT_SIZE(pCtxt->nSize, sizeof(AOQueueCtxt_t)) ||
        AO_CHK_NULL(pnNumElements))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        if (AO_SUCCESS != (eSts = AOCriticalSectionEnter(pCtxt->hCS)))
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionEnter failed");
            eResult = eSts;
        }
        else
        {
            *pnNumElements = pCtxt->nElementCnt;
            eResult = AO_SUCCESS;
        }

        if (AO_SUCCESS != (eSts = AOCriticalSectionLeave(pCtxt->hCS)))
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionLeave failed");
            eResult = eSts;
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Queries the number of empty entries in the queue.

@param handle
    Handle of the queue

@param pnNumEmptyEntries
    Pointer to the number of empty entries in the queue

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOQueueGetNumEmptyEntries
(
    AOHandleType_t handle,
    uint32_t       *pnNumEmptyEntries
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOErrorCode_e eSts = AO_ERROR_FAILURE;

    AOQueueCtxt_t *pCtxt = (AOQueueCtxt_t *)handle;

    if (AO_CHK_NULL(pCtxt) || AO_CHK_STRUCT_SIZE(pCtxt->nSize, sizeof(AOQueueCtxt_t)) ||
        AO_CHK_NULL(pnNumEmptyEntries))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        if (AO_SUCCESS != (eSts = AOCriticalSectionEnter(pCtxt->hCS)))
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionEnter failed");
            eResult = eSts;
        }
        else
        {
            *pnNumEmptyEntries = pCtxt->nQueueSize - pCtxt->nElementCnt;
            eResult = AO_SUCCESS;
        }

        if (AO_SUCCESS != (eSts = AOCriticalSectionLeave(pCtxt->hCS)))
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOCriticalSectionLeave failed");
            eResult = eSts;
        }
    }

    return eResult;
}