/**================================================================================================

@file
  aosal_qnx_thread.cpp

@brief
   This file implements the thread interface that can be used to create and control threads.

Copyright (c) 2021-2022 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include <pthread.h>
#include <sys/neutrino.h>
#include "aosal_malloc.h"
#include "aosal_thread.h"
#include "aosal_signal.h"
#include "aosal_error.h"
#include "aosal_debug_msg.h"
#include "aosal_qnx_utils.h"

/**================================================================================================
** Constant and Macros
================================================================================================**/

#define AO_THREAD_FLAG_DETACH       (0x1 << 0)
#define AO_MAX_NUM_THREAD           (256)
#define AO_MAX_THREAD_STACK_SIZE    (256*1024)

/**================================================================================================
** Typedefs
================================================================================================**/
typedef struct AOThread
{
    size_t          nSize;                            /**< size of this structure */
    pthread_t       threadHandle;                     /**< thread handle */
    boolean         bValid;                           /**< valid flag */
    uint32_t        nFlags;                           /**< flags: Detach, etc. */
    int32_t         nExitCode;                        /**< exit code */
    int32_t         (*pfnStart)(void* pArg);          /**< user's start routine at which thread
                                                           execution starts */
    void            *pStartArg;                       /**< user's data pointer passed
                                                           to start routine */
    char            pStrName[_NTO_THREAD_NAME_MAX];   /**< Null terminated Name of the thread */
} AOThread_t;

/**================================================================================================
** Variables
================================================================================================**/

#ifdef _WIN32

#include <windows.h>

const int32_t g_AOThreadCallingThreadPriority     = THREAD_PRIORITY_NORMAL;
const int32_t g_AOThreadBackgroundPriority        = THREAD_PRIORITY_LOWEST;
const int32_t g_AOThreadNormalPriority            = THREAD_PRIORITY_BELOW_NORMAL;
const int32_t g_AOThreadDefaultPriority           = THREAD_PRIORITY_NORMAL;
const int32_t g_AOThreadNRTHighPriority           = THREAD_PRIORITY_ABOVE_NORMAL;
const int32_t g_AOThreadNRTISTPriority            = THREAD_PRIORITY_ABOVE_NORMAL;
const int32_t g_AOThreadNRTWorkerPriority         = THREAD_PRIORITY_ABOVE_NORMAL;
const int32_t g_AOThreadRTWorkerPriority          = THREAD_PRIORITY_TIME_CRITICAL;
const int32_t g_AOThreadRTHighPriority            = THREAD_PRIORITY_TIME_CRITICAL;
const int32_t g_AOThreadRTISTPriority             = THREAD_PRIORITY_TIME_CRITICAL;
const int32_t g_AOThreadSafetyReportPriority      = THREAD_PRIORITY_TIME_CRITICAL;

#else

/* Default Thread priority for QNX */
const int32_t g_AOThreadCallingThreadPriority     = -1;
const int32_t g_AOThreadBackgroundPriority        = 8; 
const int32_t g_AOThreadNormalPriority            = 10;
const int32_t g_AOThreadDefaultPriority           = 10;
const int32_t g_AOThreadNRTWorkerPriority         = 10;
const int32_t g_AOThreadNRTHighPriority           = 15;
const int32_t g_AOThreadNRTISTPriority            = 21;
const int32_t g_AOThreadRTWorkerPriority          = 40;
const int32_t g_AOThreadRTHighPriority            = 43;
const int32_t g_AOThreadRTISTPriority             = 45;
const int32_t g_AOThreadSafetyReportPriority      = 55;

#endif

static pthread_mutex_t g_ThreadMutex = PTHREAD_MUTEX_INITIALIZER;

static const void *g_pThreadCtxt[AO_MAX_NUM_THREAD] = { NULL };

static AOErrorCode_e AOThreadCreateInternal
(
    AOThread_t  *pThread,
    int32_t     nPriority,
    uint32_t    nStackSize
);

/**================================================================================================
                        FUNCTION DEFINITIONS
================================================================================================**/

/**********************************************************************************************//**
@brief
    Thread function that wraps the actual function the user request to be run, sets
    the name of the thread, and then executes the users's function, passing in the 
    users's argument.

@param pArgs
    pointer to argument structure containing thread name, user's function, and user's args.

@return
    NULL
**************************************************************************************************/
void* AOThreadSetNameWrapper(void *pArgs)
{
    AOThread_t *pThread = (AOThread_t*) pArgs;

    if ((NULL != pThread) && (pThread->nSize == sizeof(AOThread_t)))
    {
        int nErr;
        if (EOK != (nErr = pthread_setname_np(pthread_self(), pThread->pStrName))) 
        {
            AO_LOG_PTHREAD_ERR(nErr, "pthread_setname_np");

            errno = nErr;
            pThread->nExitCode = AO_ERROR_SYSTEM_ERROR;
        }
        else
        {
            /* pfnStart already verified in AOThreadCreate */
            pThread->nExitCode = pThread->pfnStart(pThread->pStartArg);

            if(EOK != (nErr = pthread_mutex_lock(&g_ThreadMutex)))
            {
                AO_LOG_PTHREAD_ERR(nErr, "pthread_mutex_lock");

                errno = nErr;
                pThread->nExitCode = AO_ERROR_SYSTEM_ERROR;
            }
            else
            {
                /* if Detach was not called. pthread_exit will be called to
                   capture the exit code. Need to unlock the mutex after thread exit */
                pthread_cleanup_push(AOUnlockPthreadMutex, &g_ThreadMutex);

                /* system error occuring at detach cannot be captured as pThread may have been freed */
                if (0 != (pThread->nFlags & AO_THREAD_FLAG_DETACH)) 
                {
                    if(AO_SUCCESS != AORemovePointerEntry(&g_pThreadCtxt[0], pThread, AO_MAX_NUM_THREAD))
                    {
                        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AORemovePointerEntry failed");
                    }

                    AOFree(pThread);
                }
                else
                {
                    pThread->nFlags |= AO_THREAD_FLAG_DETACH;
                    pthread_exit(&pThread->nExitCode);
                }

                pthread_cleanup_pop(0);

                if(EOK != (nErr = pthread_mutex_unlock(&g_ThreadMutex)))
                {
                    AO_LOG_PTHREAD_ERR(nErr, "pthread_mutex_unlock");
                }
            }
        }
    }
    else
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Invalid handle pThread %p or size", pThread);
    }

    return NULL;
}

/**********************************************************************************************//**
@brief
    Creates internal pthread and begins execution

@param pThread
    Pointer to the thread handle
 
@param nPriority
    Thread priority
 
@param nStackSize
    Size of thread stack
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
static AOErrorCode_e AOThreadCreateInternal
(
    AOThread_t  *pThread,
    int32_t     nPriority,
    uint32_t    nStackSize
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(pThread) || AO_CHK_STRUCT_SIZE(pThread->nSize, sizeof(AOThread_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        int nErr = EOK;
        pthread_t hThread;
        pthread_attr_t attrib;

        if (EOK != (nErr = pthread_attr_init(&attrib)))
        {
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_attr_init");
        }
        else if (EOK != (nErr = pthread_attr_setstacksize(&attrib, nStackSize)))
        {
            (void)pthread_attr_destroy(&attrib);
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_attr_setstacksize");
        }
        else if (EOK != (nErr = pthread_attr_setinheritsched(&attrib,
                                                             PTHREAD_EXPLICIT_SCHED)))
        {
            (void)pthread_attr_destroy(&attrib);
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_attr_setinheritsched");
        }
        else if (EOK != (nErr = pthread_attr_setschedpolicy(&attrib, SCHED_RR)))
        {
            (void)pthread_attr_destroy(&attrib);
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_attr_setschedpolicy");
        }
        else
        {
            if ((nPriority <= sched_get_priority_max(SCHED_RR))  &&
                (nPriority >= sched_get_priority_min(SCHED_RR)))
            {
                struct sched_param params;

                params.sched_priority = nPriority;
                if(EOK != (nErr = pthread_attr_setschedparam(&attrib, &params)))
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Priority %d beyond limit", nPriority);
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_attr_setschedparam");
                }
                else
                {
                    if(EOK != (nErr = pthread_create(&hThread,
                                                     &attrib,
                                                     AOThreadSetNameWrapper,
                                                     pThread)))
                    {
                        AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_create");
                    }
                    else
                    {
                        pThread->threadHandle = hThread;
                        pThread->bValid = TRUE;
                        eResult = AO_SUCCESS;
                    }
                }
            }

            if(EOK != (nErr = pthread_attr_destroy(&attrib)))
            {
                AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_attr_destroy");
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Creates a thread and begins execution

@param nPriority
    Thread priority
 
@param pfnStart
    Start routine at which thread execution starts.
    The return code of the start routine should not be AO_ERROR_SYSTEM_ERROR, i.e., MIN_INT32,
    which is reserved by AOSAL to indicate system error.
 
@param pStartArg
    Data pointer passed to start routine
 
@param nStackSize
    Size of thread stack
 
@param pStrName
    Null terminated Name of the thread
 
@param pHandle
    Pointer to the thread handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadCreate
(
    int32_t         nPriority,
    int32_t         (*pfnStart)(void* pArg),
    void            *pStartArg,
    uint32_t        nStackSize,
    const char      *pStrName,
    AOHandleType_t  *pHandle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOErrorCode_e eSts = AO_ERROR_FAILURE;

    AOThread_t *pThread = NULL;
    boolean    bAddedPointerEntry = FALSE;

    if (AO_CHK_NULL(pHandle) || AO_CHK_NULL(pStrName) || AO_CHK_NULL(pfnStart))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else if (AO_MAX_THREAD_STACK_SIZE < nStackSize)
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
               "Beyond max thread stack size 0x%x", AO_MAX_THREAD_STACK_SIZE);
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        *pHandle = NULL;

        pThread = (AOThread_t *)AOMalloc(sizeof(AOThread_t));

        if (NULL == pThread)
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMalloc failed");
            eResult = AO_ERROR_NO_MEM;
        }
        else if (AO_SUCCESS != (eSts = AOAddPointerEntry(&g_pThreadCtxt[0],
                                                         (void *)pThread,
                                                         AO_MAX_NUM_THREAD)) )
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Reached max number of threads");
            eResult = eSts;
        }
        else if (NULL == AOMemset(pThread, 0, sizeof(AOThread_t)))
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMemset failed");
            eResult = AO_ERROR_FAILURE;
        }
        else if (strlen(pStrName) != AOMemscpy(pThread->pStrName,
                                               _NTO_THREAD_NAME_MAX,
                                               pStrName,
                                               strlen(pStrName)))
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMemscpy %s failed", pStrName);
            eResult = AO_ERROR_FAILURE;
        }
        else
        {
            bAddedPointerEntry = TRUE;

            pThread->nSize = sizeof(AOThread_t);
            pThread->pfnStart = pfnStart;
            pThread->pStartArg = pStartArg;

            if(AO_SUCCESS != (eSts = AOThreadCreateInternal(pThread,
                                                            nPriority,
                                                            nStackSize)))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOThreadCreateInternal failed");
                eResult = eSts;
            }
            else
            {
                *pHandle = pThread;
                eResult = AO_SUCCESS;
            }

        }

        if (AO_SUCCESS != eResult)
        {
            if (TRUE == bAddedPointerEntry)
            {
                (void) AORemovePointerEntry(&g_pThreadCtxt[0], (void *)pThread, AO_MAX_NUM_THREAD);
            }

            if (NULL != pThread)
            {
                AOFree(pThread);
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Releases the resources associated with the target thread.
    
    In a normal scenario, i.e., the bCleanup flag is not set, client should ensure the
	target thread is properly exit before calling this API.
    
    In erroneous scenarios where the target thread needs to be cancelled,
    the bCleanup flag can be set to terminate the target thread.

@param handle
    Thread handle
 
@param bCleanup
    When this flag is set, the target thread is cancelled
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadDestroy
(
    AOHandleType_t  handle,
    boolean         bCleanup
)
{
    AOThread_t *pThread = (AOThread_t *)handle;
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(pThread) || (FALSE == pThread->bValid) ||
         AO_CHK_STRUCT_SIZE(pThread->nSize, sizeof(AOThread_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else if (EOK != pthread_equal(pThread->threadHandle, pthread_self()))
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "should not be called in the same context");
        eResult = AO_ERROR_INVAL;
    }
    else
    {
        if (bCleanup)
        {
            int nErr = EOK;

            // we don't care the return value of pthread_cancel. The client might have
            // called AOThreadExit which might cause pthread_cancel to return ESRCH
            (void)pthread_cancel(pThread->threadHandle);

            // we need to call pthread_join always so that zombies can be collected
            // pthread_join may return ESRCH if thread does not exist
            nErr = pthread_join(pThread->threadHandle, NULL);

            if ((EOK == nErr) || (ESRCH == nErr))
            {
                eResult = AO_SUCCESS;

                (void) AORemovePointerEntry(&g_pThreadCtxt[0], pThread, AO_MAX_NUM_THREAD);
                AOFree(pThread);
            }
            else
            {
                AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_join");
            }
        }
        else
        {
            (void) AORemovePointerEntry(&g_pThreadCtxt[0], pThread, AO_MAX_NUM_THREAD);
            AOFree(pThread);

            eResult = AO_SUCCESS;
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Blocks the calling thread until the specified thread terminates.

@param handle
    Thread handle
 
@param pnExitCode
    Pointer to the return code of the joined thread. If not NULL, the value is
    set as one of the following:
    1. the return code from the thread entry function
    2. the exit code set by client via AOThreadExit
    3. AO_ERROR_SYSTEM_ERROR(i.e., MIN_INT32) when system error happens. Client
       can call AOGetSystemError() to retrieve the corresponding AOSAL status
       code.
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadJoin
(
    AOHandleType_t   handle,
    int32_t          *pnExitCode
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOThread_t *pThread = (AOThread_t *) handle;

    if (AO_CHK_NULL(pThread) || AO_CHK_STRUCT_SIZE(pThread->nSize, sizeof(AOThread_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
       void *pExit = NULL;
       int nErr = EOK;

       if(EOK !=( nErr = pthread_join(pThread->threadHandle, &pExit)))
       {
           AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_join");
       }
       else
       {
           if (NULL != pnExitCode)
           {
              if ((NULL != pExit) && (PTHREAD_CANCELED != pExit))
              {
                  *pnExitCode = *(int32_t*)pExit;
              }
              else
              {
                 *pnExitCode = 0;
              }
           }

           eResult = AO_SUCCESS;
       }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Blocks the calling thread until the specified thread terminates with a time
    limit.

@param handle
    Thread handle
 
@param pnExitCode
    Pointer to the return code of the joined thread. If not NULL, the value is
    set as one of the following:
    1. the return code from the thread entry function
    2. the exit code set by client via AOThreadExit
    3. AO_ERROR_SYSTEM_ERROR(i.e., MIN_INT32) when system error happens. Client
       can call AOGetSystemError() to retrieve the corresponding AOSAL status
       code.
 
@param nTimeOut
    The time in millisecond to wait for the thread to terminate.
    A value of 0 indicates infinite wait time, i.e., the behavior of this API is
    the same as AOThreadJoin.
  
@return
    Error code defined in AOErrorCode_e. AO_ERROR_TIMEDOUT is returned when the
    thread join timeout.
**************************************************************************************************/
AOErrorCode_e AOThreadTimedJoin
(
    AOHandleType_t  handle,
    int32_t         *pnExitCode,
    uint64_t        nTimeOut
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOThread_t *pThread = (AOThread_t *) handle;
    struct timespec timeSpec;
    
    if (0U == nTimeOut) 
    {
        eResult = AOThreadJoin(handle, pnExitCode);
    }
    else if (AO_CHK_NULL(pThread) || AO_CHK_STRUCT_SIZE(pThread->nSize, sizeof(AOThread_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else if(-1 == clock_gettime(CLOCK_MONOTONIC, &timeSpec))
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "clock_gettime failed (%s)", strerror(errno));
        eResult = AOMapError(errno);                                                 
    }
    else
    {
        const uint64_t nCurrTimeNSec = timespec2nsec(&timeSpec);

        if ((nTimeOut > (UINT64_MAX/(1000ULL*1000ULL))) ||
            (AO_MSEC_TO_NSEC(nTimeOut) > (UINT64_MAX - nCurrTimeNSec))) 
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "timeout value %lu ms too large currTime %lu ns",
                   nTimeOut, nCurrTimeNSec);
            eResult = AO_ERROR_BAD_PARAMETER;
        }
        else
        {
            void *pExit = NULL;
            int nErr = EOK;

            const uint64_t nAbsTimeNSec = nCurrTimeNSec + AO_MSEC_TO_NSEC(nTimeOut);

            nsec2timespec(&timeSpec, nAbsTimeNSec);

            nErr = pthread_timedjoin_monotonic(pThread->threadHandle, &pExit, &timeSpec);

            if (EOK != nErr)
            {
                /* handles timeout case */
                AO_MAP_PTHREAD_ERR(nErr, eResult, "AOThreadTimedJoin");
            }
            else
            {
                if (NULL != pnExitCode)
                {
                   if ((NULL != pExit) && (PTHREAD_CANCELED != pExit))
                   {
                       *pnExitCode = *(int32_t*)pExit;
                   }
                   else
                   {
                      *pnExitCode = 0;
                   }
                }
                eResult = AO_SUCCESS;
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Exits the calling thread with the given code.

@param handle
    the thread handle
 
@param nExitCode
    the exit code except AO_ERROR_SYSTEM_ERROR(i.e., MIN_INT32) reserved by AOSAL.
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadExit
(
    AOHandleType_t  handle,
    int32_t         nExitCode
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOThread_t *pThread = (AOThread_t *)handle;

    if (AO_CHK_NULL(pThread) || (pThread->nSize != sizeof(AOThread_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else if (AO_ERROR_SYSTEM_ERROR == nExitCode) 
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "MIN_INT32 exit code is reserved");
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        if (0 != pthread_equal(pThread->threadHandle, pthread_self()))
        {
            // called within the same thread context
            pThread->nExitCode = nExitCode;
            pthread_exit((void*)&pThread->nExitCode);
            eResult = AO_SUCCESS;
        }
        else
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Thread handle is not the calling thread");
            eResult = AO_ERROR_INVAL;
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Detach the thread from the calling thread

@param handle
    Thread handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadDetach
(
    AOHandleType_t   handle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    AOThread_t *pThread = (AOThread_t *) handle;

    if (AO_CHK_NULL(pThread) || (FALSE == pThread->bValid) ||
        AO_CHK_STRUCT_SIZE(pThread->nSize, sizeof(AOThread_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        int nErr = EOK;

        if(EOK != (nErr = pthread_detach(pThread->threadHandle)))
        {
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_detach");
        }
        else if (EOK != (nErr = pthread_mutex_lock(&g_ThreadMutex)))
        {
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_lock");
        }
        else
        {
            if (0 != (pThread->nFlags & AO_THREAD_FLAG_DETACH))
            {
                eResult = AORemovePointerEntry(&g_pThreadCtxt[0],
                                               (void*)pThread,
                                               AO_MAX_NUM_THREAD);
                AOFree(pThread);
            }
            else
            {
                eResult = AO_SUCCESS;
                pThread->nFlags |= AO_THREAD_FLAG_DETACH;
            }

            if(EOK != (nErr = pthread_mutex_unlock(&g_ThreadMutex)))
            {
                AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_unlock");
            }
        }
    }

    return eResult;      
}

/**********************************************************************************************//**
@brief
    Query the priority of the thread.

@param handle
    Thread handle. If NULL, this API queries the priority of the
    calling thread.
 
@param pnPriority
    Thread priority
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadGetPriority
(
    AOHandleType_t  handle,
    int32_t         *pnPriority
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOThread_t    *pThread = (AOThread_t*) handle;
    pthread_t     threadHandle;

    if (AO_CHK_NULL(pnPriority))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        boolean   bValidThread = FALSE;

        if (NULL == pThread)
        {
            /*self thread */
            threadHandle = pthread_self();
            bValidThread = TRUE;
        }
        else
        {
            if (AO_CHK_STRUCT_SIZE(pThread->nSize, sizeof(AOThread_t)))
            {
                /* Invalid thread handle */
                eResult = AO_ERROR_BAD_PARAMETER;
            }
            else
            {
                threadHandle = pThread->threadHandle;
                bValidThread = TRUE;
            }
        }

        if (TRUE == bValidThread)
        {
            int nErr = EOK;
            struct sched_param sp = {0};
            int32_t policy = 0;

            if (EOK != (nErr = pthread_getschedparam(threadHandle, &policy, &sp)))
            {
                AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_getschedparam");
            }
            else
            {
                eResult = AO_SUCCESS;
                *pnPriority = sp.sched_curpriority;
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Sets the priority of the thread.

@param handle
    Thread handle. If NULL, this API sets the priority of the
    calling thread.
 
@param nPriority
    Thread priority
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadSetPriority
(
    AOHandleType_t  handle,
    int32_t         nPriority
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOThread_t    *pThread = (AOThread_t*) handle;
    pthread_t     threadHandle;
    boolean       bValidThread = FALSE;

    if (NULL == pThread)
    {
        /*self thread */
        threadHandle = pthread_self();
        bValidThread = TRUE;
    }
    else
    {
        if (AO_CHK_STRUCT_SIZE(pThread->nSize, sizeof(AOThread_t)))
        {
            /* Invalid thread handle */
            eResult = AO_ERROR_BAD_PARAMETER;
        }
        else
        {
            threadHandle = pThread->threadHandle;
            bValidThread = TRUE;
        }
    }

    if (TRUE == bValidThread)
    {
        int nErr = EOK;
        if (EOK != (nErr = pthread_setschedprio(threadHandle, nPriority)))
        {
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_setschedprio");
        }
        else
        {
            eResult = AO_SUCCESS;
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Sets a cancellation state of the calling thread

@param eState
    Cancellation state to be set

@param pOldState
    Pointer to the old cancellation state

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadSetCancelState
(
    AOThreadCancelState_e  eState,
    AOThreadCancelState_e  *pOldState
)
{
    AOErrorCode_e eResult = AO_ERROR_BAD_PARAMETER;

    int nOldState;
    int nErr = EINVAL;

    if ((AO_THREAD_CANCEL_DISABLE != eState) &&
        (AO_THREAD_CANCEL_ENABLE != eState))
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Invalid state %d ", eState);
    }
    else
    {
        if (AO_THREAD_CANCEL_DISABLE == eState)
        {
            nErr = pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, &nOldState);
        }
        else
        {
            nErr = pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, &nOldState);
        }

        if (EOK != nErr)
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "pthread_setcancelstate failed");
        }
        else
        {
            if (NULL == pOldState)
            {
                eResult = AO_SUCCESS;
            }
            else
            {
                if (PTHREAD_CANCEL_DISABLE == nOldState)
                {
                    *pOldState = AO_THREAD_CANCEL_DISABLE;
                    eResult = AO_SUCCESS;
                }
                else if (PTHREAD_CANCEL_ENABLE == nOldState)
                {
                    *pOldState = AO_THREAD_CANCEL_ENABLE;
                    eResult = AO_SUCCESS;
                }
                else
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Invalid cancel state %d ", nOldState);
                    eResult = AO_ERROR_FAILURE;
                }
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Create a cancellation point of the calling thread

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOThreadTestCancel()
{
    pthread_testcancel();
    return AO_SUCCESS;
}