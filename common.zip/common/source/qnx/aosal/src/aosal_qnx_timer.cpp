/**================================================================================================

@file
   aosal_qnx_timer.cpp

@brief
   This file implements functions to create timers.

Copyright (c) 2021-2022 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include <unistd.h>
#include <sys/neutrino.h>
#include <pthread.h>

#include "aosal_timer.h"
#include "aosal_critical_section.h"
#include "aosal_thread.h"
#include "aosal_error.h"
#include "aosal_debug_msg.h"
#include "aosal_signal.h"
#include "aosal_malloc.h"
#include "aosal_qnx_utils.h"

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/
#define AO_CLOCKID                  CLOCK_MONOTONIC

#define AO_TIMER_PULSE_CODE         (10)
#define AO_EXIT_PULSE_CODE          (11)
#define AO_RELEASE_PULSE_CODE       (12)
#define AO_TIMEOUT_VALUE            (2000)
#define AO_TIMER_THREAD_STACK_SIZE  (16*1024)

#define AO_MAX_NUM_TIMER            (128)

/**================================================================================================
** Typedefs
================================================================================================**/

/**********************************************************************************************//**
@brief
    Timer structure associated with user interaction
**************************************************************************************************/
typedef struct
{
    size_t          nSize;                          /**< size of this structure */
    void            (*pfnTimerHandler)(void* pArg); /**< timer callback handler to be
                                                         invoked on timeout */
    void             *pUserArg;                     /**< optional user pointer to be
                                                         passed in the callback*/
    timer_t          timerID;                       /**< timer handle */
    boolean          bPeriodic;                     /**< periodic or non-periodic*/
    AOHandleType_t   hSignalQ;                      /**< signal queue */
    AOHandleType_t   hSignal;                       /**< Signal for synchronization of
                                                         AOTimerDestroy with AOTimerDispatcher
                                                         thread*/
} AOTimer_t;

/**********************************************************************************************//**
@brief
    Timer context structure associated with QNX kenel
    interaction
**************************************************************************************************/
typedef struct
{
    boolean         bCreated;           /**< timer context creation flag */
    int32_t         timerChid;          /**< timer channel id */
    int32_t         timerCoid;          /**< timer connection id */
    AOHandleType_t  hTimerThread;       /**< timer thread handle */
    uint32_t        timerCnt;           /**< timer count */
    pthread_mutex_t mutex;              /**< mutex */
} AOTimerCtxt_t;

/**================================================================================================
** Variables
================================================================================================**/
static AOTimerCtxt_t g_TimerCtxt = { FALSE,                      /* context creation flag */ \
                                     - 1,                        /* timer chid */            \
                                     - 1,                        /* timer coid */            \
                                     NULL,                       /* timer thread handle */   \
                                     0,                          /* timer count */           \
                                     PTHREAD_RMUTEX_INITIALIZER  /* mutex */                 \
                                   };

static const void *g_pTimer[AO_MAX_NUM_TIMER] = { NULL };

/**================================================================================================
                        FUNCTION DECLARATIONS
================================================================================================**/
static AOErrorCode_e AOTimerLongSleep
(
    uint32_t     nSeconds
);

static AOErrorCode_e AOTimerCreateInternal
(
   boolean              bPeriodic,
   void                 (*pfnTimerHandler)(void* pArg),
   void                 *pUserArg,
   AOHandleType_t       *pHandle
);

static int32_t AOTimerDispatcher
(
    void  *pArg
);

static AOErrorCode_e AOTimerInitialize
(
    void
);

static AOErrorCode_e AOTimerDeinitialize
(
    void
);

/**================================================================================================
                        FUNCTION DEFINITIONS
================================================================================================**/

/**********************************************************************************************//**
@brief
    Timer dispatcher handler

@param pArg
    Argument passed to the handler
 
@return
    void
**************************************************************************************************/
static int32_t AOTimerDispatcher
(
    void *pArg
)
{
    int32_t rcvid;
    struct _pulse pulse;
    void (*pfnTimeout)(void* pArg) = NULL;
    void *pUserArg = NULL;
    int nErr;
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if(EOK != (nErr = pthread_setname_np(pthread_self(), (const char*)"AOTimerDispatcher")))
    {
        AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_setname_np");
    }
    else
    {
        for (;;)
        {
            rcvid = MsgReceive(g_TimerCtxt.timerChid, &pulse, sizeof(pulse), NULL);
            if (0 == rcvid)
            {
                if ((AO_TIMER_PULSE_CODE == pulse.code) &&
                     (NULL != pulse.value.sival_ptr))
                {
                    pfnTimeout = NULL;
                    pUserArg = NULL;

                    AOTimer_t *pTimer = (AOTimer_t *) pulse.value.sival_ptr;

                    if(EOK != (nErr = pthread_mutex_lock(&g_TimerCtxt.mutex)))
                    {
                        AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_lock");
                    }
                    else
                    {
                        pfnTimeout = pTimer->pfnTimerHandler;
                        pUserArg = pTimer->pUserArg;
                        eResult = AO_SUCCESS;

                        if(EOK != (nErr = pthread_mutex_unlock(&g_TimerCtxt.mutex)))
                        {
                            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_unlock");
                            
                        }
                    }

                    if (AO_SUCCESS != eResult)
                    {
                        break;
                    }

                    if (NULL != pfnTimeout)
                    {
                        pfnTimeout(pUserArg);
                    }
                }
                else if (AO_EXIT_PULSE_CODE == pulse.code)
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_HIGH, "timer dispatcher exiting");
                    break;
                }
                else
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "pulse code %d not supported", pulse.code);
                }
            }
            else if (rcvid > 0)
            {
                /* other messages */
                if (AO_RELEASE_PULSE_CODE == pulse.code)
                {
                    AOTimer_t *pTimer = (AOTimer_t *) pulse.value.sival_ptr;

                    /* Set signal to unblock AOTimerDestroy */
                    if ((NULL != pTimer) && (NULL != pTimer->hSignal))
                    {
                        if (AO_SUCCESS != AOSignalSet(pTimer->hSignal))
                        {
                            AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
                                   "failed to set signal when received AO_RELEASE_PULSE_CODE");
                        }
                    }

                    if(-1 == MsgReply(rcvid, EOK, NULL, 0))
                    {
                        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "MsgReply failed (%s)", strerror(errno));
                        eResult = AOMapError(errno);                                                 
                    }
                }
            }
            else
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Unexpected rcvid %d", rcvid);
            }
        }
    }

    /* when reaching here, there was failure */
    return -1;
}


/**********************************************************************************************//**
@brief
    Initialize global channel context for timer

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
static AOErrorCode_e AOTimerInitialize
(
    void
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOErrorCode_e eSts = AO_ERROR_FAILURE;
    int nErr;

    if (EOK != (nErr = pthread_mutex_lock(&g_TimerCtxt.mutex)))
    {
        AO_MAP_PTHREAD_ERR(nErr,eResult,"pthread_mutex_lock");
    }
    else
    {
        if(FALSE == g_TimerCtxt.bCreated)
        {
            if (-1 != g_TimerCtxt.timerChid)
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
                       "channel id %d already created", g_TimerCtxt.timerChid);
                eResult = AO_ERROR_FILE_OPENED;
            }
            else if(-1 == (g_TimerCtxt.timerChid = ChannelCreate(0)))
            {
                eResult = AOGetSystemError();
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Create channel failed %s", strerror(errno));
            }
            else if(-1 != g_TimerCtxt.timerCoid)
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
                        "Coid %d already created", g_TimerCtxt.timerCoid);
                eResult = AO_ERROR_FILE_OPENED;
            }
            else if (-1 == (g_TimerCtxt.timerCoid = ConnectAttach(0,
                                                                  0,
                                                                  g_TimerCtxt.timerChid,
                                                                  _NTO_SIDE_CHANNEL,
                                                                  0)))
            {
                eResult = AOGetSystemError();
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
                       "unable to connect channel - %s", strerror(errno));
            }
            else if (AO_SUCCESS != (eSts = AOThreadCreate(g_AOThreadSafetyReportPriority,
                                                          AOTimerDispatcher,
                                                          NULL,
                                                          AO_TIMER_THREAD_STACK_SIZE,
                                                          "AOTimerDispatcher",
                                                          &g_TimerCtxt.hTimerThread)))
            {
                eResult = eSts;
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOThreadCreate failed");
            }
            else
            {
                g_TimerCtxt.bCreated = TRUE;
                eResult = AO_SUCCESS;
            }

            if (AO_SUCCESS != eResult)
            {
                if (-1 != g_TimerCtxt.timerCoid)
                {
                    (void) ConnectDetach(g_TimerCtxt.timerCoid);
                    g_TimerCtxt.timerCoid = -1;
                }

                if (-1 != g_TimerCtxt.timerChid)
                {
                    (void) ChannelDestroy(g_TimerCtxt.timerChid);
                    g_TimerCtxt.timerChid = -1;
                }
            }
        }
        else
        {
            /* already initialized */
            eResult = AO_SUCCESS;
        }

        if (EOK != (nErr = pthread_mutex_unlock(&g_TimerCtxt.mutex)))
        {
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_unlock");
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Deinitialize global channel context for timer

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
static AOErrorCode_e AOTimerDeinitialize
(
    void
)
{

    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    int nErr;

    if (EOK != (nErr = pthread_mutex_lock(&g_TimerCtxt.mutex)))
    {
        AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_lock");
    }
    else
    {
        eResult = AO_SUCCESS;

        if(TRUE == g_TimerCtxt.bCreated)
        {
            /* kill the timer dispatch thread */
            if (-1 == MsgSendPulse(g_TimerCtxt.timerCoid,
                                   g_AOThreadCallingThreadPriority,
                                   AO_EXIT_PULSE_CODE,
                                   0))
            {
               AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
                      "failed to send pulse code %s", strerror(errno));
            }
            else
            {
                if(AO_SUCCESS != AOThreadJoin(g_TimerCtxt.hTimerThread, NULL))
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Join timer dispatch thread failed");
                }

                if (AO_SUCCESS != AOThreadDestroy(g_TimerCtxt.hTimerThread, FALSE))
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Destroy timer dispatch thread failed");
                }
            }

            if (-1 == ConnectDetach(g_TimerCtxt.timerCoid))
            {
               AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
                      "failed to detach from timer channel - %s", strerror(errno));
            }

            g_TimerCtxt.timerCoid = -1;

            if (-1 == ChannelDestroy(g_TimerCtxt.timerChid))
            {
               AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
                      "failed to destroy timer channel - %s", strerror(errno));
            }

            g_TimerCtxt.timerChid = -1;

            g_TimerCtxt.bCreated = FALSE;
        }

        if (EOK != (nErr = pthread_mutex_unlock(&g_TimerCtxt.mutex)))
        {
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_unlock");
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Internal function for a timer creation. 

@param bPeriodic
    True for periodic and FALSE for non-periodic timer
 
@param pfnTimerHandler
    Timer callback handler to be invoked on timeout
 
@param pUserArg
    Optional user data pointer to be passed in the callback
 
@param pHandle
    Pointer to the timer handle

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
static AOErrorCode_e AOTimerCreateInternal
(
    boolean          bPeriodic,
    void             (*pfnTimerHandler)(void* pArg),
    void             *pUserArg,
    AOHandleType_t   *pHandle
)
{
    AOTimer_t *pTimer = NULL;
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOErrorCode_e eSts = AO_ERROR_FAILURE;
    boolean       bAddPointerEntry = FALSE;

    if (AO_CHK_NULL(pHandle) || AO_CHK_NULL(pfnTimerHandler))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        if(AO_SUCCESS != (eSts = AOTimerInitialize()))
        {
            eResult = eSts;
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOTimerInitialize failure");
        }
        else
        {
            pTimer = (AOTimer_t *)AOMalloc(sizeof(AOTimer_t));

            if (NULL == pTimer)
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Timer allocation failure");
                eResult = AO_ERROR_NO_MEM;
            }
            else if (AO_SUCCESS != (eSts = AOAddPointerEntry(&g_pTimer[0],
                                                             (void *)pTimer,
                                                             AO_MAX_NUM_TIMER)))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Reached maximum timer");
                eResult = eSts;
            }
            else if (NULL == AOMemset(pTimer, 0, sizeof(AOTimer_t))) 
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMemset failed");
                eResult = AO_ERROR_FAILURE;
            }
            else
            {
                bAddPointerEntry = TRUE;

                pTimer->nSize = sizeof(AOTimer_t);
                pTimer->pfnTimerHandler = pfnTimerHandler;
                pTimer->pUserArg = pUserArg;
                pTimer->bPeriodic = bPeriodic;

                /* Create SignalQ for synchronization of Timer APIs with TimerDispatcher thread */
                if(AO_SUCCESS != (eSts = AOSignalQCreate(&pTimer->hSignalQ)))
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "failed to create signalQ");
                    pTimer->hSignalQ = NULL;
                }
                else if (AO_SUCCESS != (eSts = AOSignalCreate(pTimer->hSignalQ,
                                                              NULL,
                                                              NULL,
                                                              AO_SIGNAL_ATTR_RESET_AUTOMATIC,
                                                              &pTimer->hSignal)))
                {       
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "failed to create signal");
                    pTimer->hSignal = NULL;
                }
                else
                {
                    int nErr = 0;
                    struct sigevent sev = {0};

                    /* Create the timer */
                    sev.sigev_notify = SIGEV_PULSE;
                    sev.sigev_coid = g_TimerCtxt.timerCoid;
                    sev.sigev_priority = g_AOThreadSafetyReportPriority;
                    sev.sigev_code = AO_TIMER_PULSE_CODE;
                    sev.sigev_value.sival_ptr = (void *) pTimer;

                    nErr = timer_create(AO_CLOCKID, &sev, &pTimer->timerID);
                    if (-1 == nErr)
                    {
                        eResult = AOGetSystemError();
                        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "failed to create timer - %s", strerror(errno));
                    }
                    else
                    {
                        *pHandle = pTimer;
                        g_TimerCtxt.timerCnt++;
                        eResult = AO_SUCCESS;
                    }
                }
            }
        }
    }

    if (AO_SUCCESS != eResult)
    {
        /* clean up resources */
        if (NULL != pTimer)
        {
            if(TRUE == bAddPointerEntry)
            {
                if (NULL != pTimer->hSignal)
                {
                    (void)AOSignalDestroy(pTimer->hSignal);
                    pTimer->hSignal = NULL;
                }

                if (NULL != pTimer->hSignalQ)
                {
                    (void)AOSignalQDestroy(pTimer->hSignalQ);
                    pTimer->hSignalQ = NULL;
                }

                (void)AORemovePointerEntry(&g_pTimer[0], (void *)pTimer, AO_MAX_NUM_TIMER);
            }

            AOFree(pTimer);

            pTimer = NULL;
        }

        if (0 == g_TimerCtxt.timerCnt)
        {
            (void) AOTimerDeinitialize();
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Creates a timer and returns the handle, when the timer expires the registered
    handler is invoked

@param bPeriodic 
    True for periodic timer
    False for non-periodic timer
 
@param nTimeOut  - in milliseconds 
    If zero, the timer is created and stay in stopped state. If greater than
    zero (in milliseconds), the timer will be started immediately after
    creation.
 
@param pfnTimerHandler
    Timer callback handler to be invoked on timeout
 
@param pUserArg
    Optional user data pointer to be passed in the callback
 
@param pThreadName
    Thread name of the timer thread. If NULL, the thread name is
    defaulted to be "AOTimerDispatcher"

@param nThreadPrio
    Thread priority of the timer thread. It should be one of the
    thread priorities defined in aosal_thread.h
 
@param pHandle
    Pointer to the timer handle

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOTimerCreate
(
    boolean         bPeriodic,
    int64_t         nTimeOut,
    void            (*pfnTimerHandler)(void* pArg),
    void            *pUserArg,
    const char      *pThreadName,
    int32_t         nThreadPrio,
    AOHandleType_t  *pHandle
)
{
    (void) pThreadName;
    (void) nThreadPrio;

    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOErrorCode_e eSts = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(pHandle))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        if (AO_SUCCESS != (eSts = AOTimerCreateInternal(bPeriodic,
                                                        pfnTimerHandler,
                                                        pUserArg,
                                                        pHandle)))
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Timer creation failed");
            eResult = eSts;
        }
        else
        {
            if (nTimeOut > 0)
            {
                if(AO_SUCCESS != (eSts = AOTimerStart(*pHandle, nTimeOut)))
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOTimerStart %ld failed", nTimeOut);

                    eResult = eSts;
                    if(AO_SUCCESS != AOTimerDestroy(*pHandle))
                    {
                        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Timer destroy failed");
                    }
                }
                else
                {
                    eResult = AO_SUCCESS;
                }
            }
            else
            {
                /* success if timeout is 0 */
                eResult = AO_SUCCESS;
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Starts a timer for either periodic or non-periodic timer
 
@param handle
    Handle of the timer

@param nTimeOut
    Timeout in milliseconds

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOTimerStart
(
    AOHandleType_t      handle,
    int64_t             nTimeOut
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOTimer_t *pTimer = (AOTimer_t *)handle;

    if (AO_CHK_NULL(pTimer) || AO_CHK_STRUCT_SIZE(pTimer->nSize, sizeof(AOTimer_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else if (nTimeOut < 0 || nTimeOut > 0xFFFFFFFFU )
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "unsupported timeout value %ld", nTimeOut);
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        struct itimerspec its;

        int32_t nsec;

        /* Start the timer */
        its.it_value.tv_sec = nTimeOut / 1000;

        nsec = (nTimeOut - (its.it_value.tv_sec * 1000)) * 1000000;

        its.it_value.tv_nsec = nsec;

        if (TRUE == pTimer->bPeriodic)
        {
            its.it_interval.tv_sec = its.it_value.tv_sec;
            its.it_interval.tv_nsec = its.it_value.tv_nsec;
        }
        else
        {
            its.it_interval.tv_sec = 0;
            its.it_interval.tv_nsec = 0;
        }

        if (-1 == timer_settime(pTimer->timerID, 0, &its, NULL))
        {
            eResult = AOGetSystemError();
        }
        else
        {
            eResult = AO_SUCCESS;
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Stops a timer
 
@param handle
    Handle of the timer

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOTimerStop
(
    AOHandleType_t handle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    struct itimerspec its;

    AOTimer_t *pTimer = (AOTimer_t *) handle;

    if (AO_CHK_NULL(pTimer) || AO_CHK_STRUCT_SIZE(pTimer->nSize, sizeof(AOTimer_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else if (NULL == AOMemset(&its, 0, sizeof(its))) 
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMemset failed");
        eResult = AO_ERROR_FAILURE;
    }
    else
    {
        if (0 == timer_settime(pTimer->timerID, 0, &its, NULL))
        {
            eResult = AO_SUCCESS;
        }
        else
        {
            eResult = AOGetSystemError();
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Releases the resources associated with the timer handle
 
@param handle
    The timer handle

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOTimerDestroy
(
    AOHandleType_t handle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOErrorCode_e eSts = AO_ERROR_FAILURE;

    AOTimer_t *pTimer = (AOTimer_t *) handle;

    if (AO_CHK_NULL(pTimer) || AO_CHK_STRUCT_SIZE(pTimer->nSize, sizeof(AOTimer_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else if (0 == g_TimerCtxt.timerCnt) 
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Timer was not createed. Unexpected");
    }
    else
    {
        struct itimerspec its;

        if(AO_SUCCESS != (eSts = AORemovePointerEntry(&g_pTimer[0],
                                                      (void *)pTimer,
                                                      AO_MAX_NUM_TIMER)))
        {
            eResult = eSts;
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Invalid handle %p or has been released", pTimer);
        }
        else if (NULL == AOMemset(&its, 0, sizeof(its))) 
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMemset failed");
            eResult = AO_ERROR_FAILURE;
        }
        else
        {
            int32_t timeout = 0;
            void *pUserArg = NULL;

            /* stop the timer */
            eResult = AOTimerStop(handle);
            
            /* ensure timer is stopped with timeout */
            while ((AO_SUCCESS == eResult) && (20 > timeout))
            {
                AOErrorCode_e nSts;

                if (-1 == timer_gettime(pTimer->timerID, &its))
                {
                    eResult = AOGetSystemError();
                }
                if ((0 == its.it_value.tv_sec) && (0 == its.it_value.tv_nsec))
                {
                    break;
                }

                timeout++;

                /* stop the timer */
                nSts = AOTimerStop (handle);
                if (AO_SUCCESS != nSts)
                {
                    eResult = nSts;
                }
            }

            if (-1 == timer_delete(pTimer->timerID))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR,"failed to delete timer id = 0x%x - %s",
                       pTimer->timerID, strerror(errno));
            }

            pTimer->pfnTimerHandler = NULL;
            pTimer->pUserArg = NULL;

            if (AO_SUCCESS != AOSignalReset(pTimer->hSignal))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR,"failed to reset signal");
            }

            // release the timer
            struct _pulse pulse;
            pulse.value.sival_ptr = pTimer;
            pulse.code = AO_RELEASE_PULSE_CODE;

            if (-1 == MsgSend(g_TimerCtxt.timerCoid, &pulse, sizeof(pulse), NULL, 0))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
                       "failed to send RELEASE_AO_TIMER_PULSE_CODE %s", strerror(errno));
            }

            boolean bTimedOut = FALSE;
            /* synchronize with AOTimerDispatcher thread. */
            if (AO_SUCCESS != AOSignalQWait(pTimer->hSignalQ,
                                            FALSE,
                                            AO_TIMEOUT_VALUE,
                                            &pUserArg,
                                            &bTimedOut))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOSignalQWait failed");
            }

            /* Free timer signal */
            if (AO_SUCCESS != AOSignalDestroy(pTimer->hSignal))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOSignalDestroy %p failed", pTimer->hSignal);
            }

            /* Free timer signalQ */
            if (AO_SUCCESS != AOSignalQDestroy(pTimer->hSignalQ))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOSignalQDestroy %p failed", pTimer->hSignalQ);
            }

            /* Free timer memory */
            AOFree(pTimer);

            if (EOK == pthread_mutex_lock(&g_TimerCtxt.mutex))
            {
                g_TimerCtxt.timerCnt--;

                if (0 == g_TimerCtxt.timerCnt)
                {
                    eResult = AOTimerDeinitialize();
                }

                if(EOK != pthread_mutex_unlock(&g_TimerCtxt.mutex))
                {
                    eResult = AO_ERROR_FAILURE;
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "pthread_mutex_unlock failed");
                }
            }
            else
            {
                eResult = AO_ERROR_FAILURE;
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "pthread_mutex_lock failed");
            }
        }
     }

    return (eResult);
}

/**********************************************************************************************//**
@brief
    Sleeps for specified time in seconds
 
@param nSeconds
    Sleep time in seconds

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
static AOErrorCode_e AOTimerLongSleep
(
    uint32_t nSeconds
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (nSeconds > 0)
    {
        eResult = AO_SUCCESS;

        // QNX sleep is not accurate if sleep time is more than 60s,
        // break down long sleep into small sleep of 30 seconds
        while (nSeconds > 30)
        {
            if (0 == sleep(30))
            {
                nSeconds -= 30;
                eResult = AO_SUCCESS;
            }
            else
            {
                eResult = AO_ERROR_FAILURE;
                break;
            }
        }

        if (AO_SUCCESS == eResult)
        {
            if (0 != sleep(nSeconds))
            {
                eResult = AO_ERROR_FAILURE;
            }
        }
    }
    else
    {
        eResult = AO_SUCCESS;
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Sleeps for specified time in milliseconds
 
@param nSleepTime
    Sleep time in milliseconds

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOTimerSleepMilliSecond
(
    uint32_t nSleepTime
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOErrorCode_e eSts = AO_SUCCESS;

    // usleep can only sleep up to maximum 1 sec, if the sleep
    // time is more more than that we need to do two sleeps
    int32_t uSleepTime = nSleepTime % 1000;

    if (nSleepTime >= 1000)
    {
        eSts = AOTimerLongSleep(nSleepTime/1000);
    }

    if (AO_SUCCESS == eSts)
    {
        if (uSleepTime > 0)
        {
            if (0 != usleep(uSleepTime * 1000))
            {
                eSts = AO_ERROR_FAILURE;
            }
        }
    }

    if (AO_SUCCESS == eSts)
    {
        eResult = AO_SUCCESS;
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Sleeps for specified time in microseconds
 
@param nSleepTime
    Sleep time in microseconds

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOTimerSleepMicroSecond
(
    uint32_t nSleepTime
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOErrorCode_e eSts = AO_SUCCESS;

    // usleep can only sleep up to maximum 1 sec, if the sleep
    // time is more more than that we need to do two sleeps
    int32_t uSleepTime = nSleepTime % 1000000;

    if (nSleepTime >= 1000000)
    {
        eSts = AOTimerLongSleep(nSleepTime/1000000);
    }

    if (AO_SUCCESS == eSts)
    {
        if (uSleepTime > 0)
        {
            if (0 != usleep(uSleepTime))
            {
                eSts = AO_ERROR_FAILURE;
            }
        }
    }

    if (AO_SUCCESS == eSts)
    {
        eResult = AO_SUCCESS;
    }

    return eResult;
}

