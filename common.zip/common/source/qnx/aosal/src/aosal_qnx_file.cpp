/**================================================================================================

@file
   aosal_qnx_file.cpp

@brief
   This file implements file operation for QNX

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/


/**================================================================================================

                     INCLUDE FILES FOR MODULE

================================================================================================**/
#include <fcntl.h>
#include "aosal_file.h"
#include "aosal_error.h"
#include "aosal_debug_msg.h"
#include "aosal_qnx_utils.h"

/**================================================================================================
                        FUNCTION DECLARATIONS
================================================================================================**/

/**********************************************************************************************//**
@brief
    Creates/Opens a file

@param pFilePath
    Name and path of the file to act on
 
@param eMode
    Mode to be used to create a file (AOFileOpenMode_e)
 
@param pHandle
    Pointer to the file handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOFileOpen
(
    const char          *pFilePath,
    AOFileOpenMode_e    eMode,
    AOFileHandleType_t  *pHandle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(pFilePath) || AO_CHK_NULL(pHandle))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        int32_t fd = -1;
        int32_t nOpenFlag = 0;
        mode_t  mode;

        switch (eMode)
        {
          case AO_FILE_CREATE_R_PLUS:
            nOpenFlag = O_RDWR;
            break;
          case AO_FILE_CREATE_W:
            nOpenFlag = O_CREAT | O_TRUNC | O_WRONLY;
            break;
          case AO_FILE_CREATE_W_PLUS:
            nOpenFlag = O_CREAT | O_TRUNC | O_RDWR;
            break;
          case AO_FILE_CREATE_A:
            nOpenFlag = O_CREAT | O_APPEND | O_WRONLY;
            break;
          case AO_FILE_CREATE_R:
          default:
            nOpenFlag = O_RDONLY;
            break;
        }

        if(0 != (nOpenFlag & O_CREAT))
        {
            mode = S_IRWXU | S_IRGRP;
            fd = open(pFilePath, nOpenFlag, mode);
        }
        else
        {
            fd = open(pFilePath, nOpenFlag);
        }

        if (fd >= 0)
        {
            eResult = AO_SUCCESS;
            *pHandle = fd;
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Close the file associated with the file handle

@param handle
    File handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOFileClose
(
    AOFileHandleType_t handle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (handle >= 0)
    {
        int nErr = 0;
        nErr = close(handle);

        if (0 == nErr)
        {
            eResult = AO_SUCCESS;
        }
    }
    else
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Invalid file handle");
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Reads data from a file into the buffer

@param handle
    File handle
 
@param pBuffer
    Pointer to the buffer to which data may be copied
 
@param nSize
    Number of bytes to read, assumes pBuffer is big enough to hold nSize
 
@param pnBytesRead
    Pointer to number of bytes read from file
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOFileRead
(
  AOFileHandleType_t    handle,
  char                  *pBuffer,
  uint64_t              nSize,
  int64_t               *pnBytesRead
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(pBuffer) || AO_CHK_NULL(pnBytesRead) || (handle < 0))
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "file handle %d", handle);
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        *pnBytesRead = 0;

        int64_t  nBytesRead = read(handle, pBuffer, nSize);
        if (nBytesRead >= 0)
        {
            *pnBytesRead = nBytesRead;
            eResult = AO_SUCCESS;
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Writes data from the buffer into the file

@param handle
    File handle
 
@param pBuffer
    Pointer to the buffer that contains the data
 
@param nSize
    Number of bytes to be written
 
@param pnBytesWritten
    Pointer to number of bytes written into pBuffer
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOFileWrite
(
  AOFileHandleType_t    handle,
  const char            *pBuffer,
  uint64_t              nSize,
  int64_t               *pnBytesWritten
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(pBuffer) || AO_CHK_NULL(pnBytesWritten) || (handle < 0))
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "file handle %d", handle);
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        int64_t  nBytesWritten = write(handle, pBuffer, nSize);
        if (nBytesWritten >= 0)
        {
            *pnBytesWritten = nBytesWritten;
            eResult = AO_SUCCESS;
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Reposition the file pointer to the given offset in an open file.

@param handle
    File handle
 
@param nOffset
    Number of bytes to offset from eWhence
 
@param eWhence
    Position from where the nOffset is added
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOFileSeek
(
    AOFileHandleType_t      handle,
    int64_t                 nOffset, 
    AOFileSeekPosition_e    eWhence
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (handle >= 0)
    {
        boolean bSts = TRUE;
        int efsWhence = SEEK_CUR;

        switch (eWhence)
        {
            case AO_FILE_SEEK_BEGIN:
            {
                efsWhence = SEEK_SET;
                break;
            }

            case AO_FILE_SEEK_END:
            {
                efsWhence = SEEK_END;
                break;
            }

            case AO_FILE_SEEK_CURRENT:
            {
                efsWhence = SEEK_CUR;
                break;
            }

            default:
            {
                bSts = FALSE;
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Invalid seek option");
                break;
            }
        }

        if (bSts)
        {
            if (-1L != lseek64(handle, nOffset, efsWhence))
            {
                eResult = AO_SUCCESS;
            }
            else
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "lseek failed: %s", strerror(errno));
            }
        }
    }
    else
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "invalid file handle %d", handle);
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Retrieves the current file position

@param handle
    File handle

@param pnOffset
    Current position of the File

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOFileGetCurrentPosition
(
    AOFileHandleType_t      handle,
    int64_t                 *pnOffset
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if ((handle >= 0) && (NULL != pnOffset))
    {
        off64_t nOffset = 0;

        nOffset = lseek64(handle, (off64_t)0, SEEK_CUR);

        if (-1L != nOffset)
        {
            *pnOffset = nOffset;
            eResult = AO_SUCCESS;
        }
        else
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "lseek64 failed: %s", strerror(errno));
        }
    }

    return eResult;
}