/**================================================================================================

@file
   aosal_qnx_time.cpp

@brief
   This file defines functions that can be used to obtain system time 

Copyright (c) 2021-2022 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/

#include <sys/syspage.h>
#include <sys/neutrino.h>
#include "aosal_debug_msg.h"
#include "aosal_time.h"
#include "aosal_error.h"
#include "aosal_qnx_utils.h"

#define MICROSEC_PER_SEC      (1000000)
#define MICROSEC_PER_MILLISEC (1000)

/**================================================================================================
                        FUNCTION DEFINITIONS
================================================================================================**/

/**********************************************************************************************//**
@brief
    Returns the system time (as a 64-bit value), the time elapsed since system was started.

@param pTime
    time in millseconds
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOTimeGetTimeMilliSecond
(
    uint64_t *pTime
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    uint64_t nCurrTimeMicroSec = 0;

    if (AO_CHK_NULL(pTime))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else if (AO_SUCCESS != AOTimeGetTimeMicroSecond(&nCurrTimeMicroSec))
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOTimeGetTimeMicroSecond failed");
        eResult = AO_ERROR_FAILURE;
    }
    else
    {
        *pTime = nCurrTimeMicroSec / MICROSEC_PER_MILLISEC;
        eResult = AO_SUCCESS;
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Returns the system time (as a 64-bit value), the time elapsed since system was started.

@param pTime
    time in microseconds
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOTimeGetTimeMicroSecond
(
    uint64_t *pTime
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(pTime))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        uint64_t nCycles = ClockCycles();
        uint64_t nCyclesPerSec = SYSPAGE_ENTRY(qtime)->cycles_per_sec;

        uint64_t nMaxMultiplyNum = MAX_UINT64 / MICROSEC_PER_SEC;

        if(nCycles > nMaxMultiplyNum)
        {
            uint64_t nDiv = nCycles / nMaxMultiplyNum;
            uint64_t nRes = nCycles - nDiv * nMaxMultiplyNum;

            *pTime = (nMaxMultiplyNum * MICROSEC_PER_SEC / nCyclesPerSec) * nDiv
                + nRes * MICROSEC_PER_SEC / nCyclesPerSec;
        }
        else
        {
            *pTime = nCycles * MICROSEC_PER_SEC / nCyclesPerSec;
        }

        eResult = AO_SUCCESS;
    }

    return eResult;
}
