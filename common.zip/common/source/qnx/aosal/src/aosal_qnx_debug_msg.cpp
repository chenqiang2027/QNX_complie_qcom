/**================================================================================================

@file
  aosal_qnx_debug_msg.cpp

@brief
   This file defines methods that can be used to output debug messages

Copyright (c) 2021-2022 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/


/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include <stdlib.h>
#include <ctype.h>
#include <pthread.h>
#include "AEEStdDef.h"
#include "aosal_debug_msg.h"
#include "aosal_file.h"
#include "aosal_error.h"
#include "aosal_malloc.h"
#include "aosal_qnx_utils.h"

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/

#define AO_MAX_STR_BUF_SZ    (256)
#define AO_SLOG2_NUM_PAGES   (32)
#define AO_SLOG2_NUM_BUF     (1)

/**********************************************************************************************//**
@brief
    Defines log mode
**************************************************************************************************/
typedef enum
{
    AO_LOG_MODE_NONE = 0,
    AO_LOG_MODE_SLOG2,
    AO_LOG_MODE_COUNT,
    AO_LOG_MODE_MAX = 0x7FFFFFFF
} AOLogModeType_e;

/**********************************************************************************************//**
@brief
    Log buffer context structure
**************************************************************************************************/
typedef struct
{
    char            configFileDefaultPath[AO_MAX_STR_BUF_SZ];       /**< default cfg file path */
    AOLogModeType_e eLogMode;                                       /**< log mode */
    uint32_t        nSlog2Verbosity;                                /**< slog2 verbosity */
    pthread_mutex_t mutex;                                          /**< mutex */
    int32_t         nRefCnt;                                        /**< ref count for init*/
} AODebugLogCtxt_t;

/**********************************************************************************************//**
@brief
    String of subsystem id
**************************************************************************************************/
const char *g_pStringSSID[AO_LOG_SSID_COUNT] =
{
    "AO_GENERAL",
    "AO_CAMERA",
    "AO_CV_TASK",
    "AO_CV_EVA",
    "AO_CV_FASTCV",
    "AO_CV_FADAS",
    "AO_STATS"
};

/**********************************************************************************************//**
@brief
    String of Log Level
**************************************************************************************************/
const char *g_pStringLvl[AO_PRIO_COUNT] =
{
    "AO_PRIO_LOW",
    "AO_PRIO_MEDIUM",
    "AO_PRIO_HIGH",
    "AO_PRIO_CRITICAL",
    "AO_PRIO_ERROR",
    "AO_PRIO_FATAL",
    "AO_PRIO_DEBUG"
};

/**================================================================================================
** Variables
================================================================================================**/

extern char * __progname;

/**********************************************************************************************//**
@brief
    slog2 log buffer handle
**************************************************************************************************/
slog2_buffer_t  g_hBuffer = nullptr;

/**********************************************************************************************//**
@brief
    Log Enblement table
**************************************************************************************************/
boolean g_bLogTable[AO_LOG_SSID_COUNT][AO_PRIO_COUNT] = { {FALSE} };

#ifdef _WIN32
static AODebugLogCtxt_t  g_logCtxt = {  "",                         /* configFileDefaultPath */ \
                                        AO_LOG_MODE_SLOG2,          /* eLogMode */              \
                                        SLOG2_DEBUG2,               /* nSlog2Verbosity */       \
                                        PTHREAD_RMUTEX_INITIALIZER, /* mutex */                 \
                                        0                           /* ref count */             \
                                     };
#else
static AODebugLogCtxt_t  g_logCtxt = {  "/mnt/etc/",                /* configFileDefaultPath */ \
                                        AO_LOG_MODE_SLOG2,          /* eLogMode */              \
                                        SLOG2_DEBUG2,               /* nSlog2Verbosity */       \
                                        PTHREAD_RMUTEX_INITIALIZER, /* mutex */                 \
                                        0                           /* ref count */             \
                                     };
#endif

/**================================================================================================
                        FUNCTION DECLARATIONS
================================================================================================**/
static AOErrorCode_e AODebugParseConfiguration(void);

/**================================================================================================
                        FUNCTION DEFINITIONS
================================================================================================**/

/**********************************************************************************************//**
@brief
    Map AOSAL verbosity level to Slog2

@param eLevel
    AOSAL priority level

@return
    Slog2 verbosity level
**************************************************************************************************/
uint32_t AOMapVerbLvlSlog2
(
    AOLogPriorityType_e eLevel
)
{
    uint32_t eResult = SLOG2_SHUTDOWN;

    switch(eLevel)
    {
        case AO_PRIO_LOW:
            eResult = SLOG2_DEBUG2;
            break;

        case AO_PRIO_MEDIUM:
            eResult = SLOG2_DEBUG1;
            break;

        case AO_PRIO_HIGH:
            eResult = SLOG2_INFO;
            break;

        case AO_PRIO_CRITICAL:
            eResult = SLOG2_INFO;
            break;

        case AO_PRIO_ERROR:
            eResult = SLOG2_ERROR;
            break;

        case AO_PRIO_FATAL:
            eResult = SLOG2_CRITICAL;
            break;

        case AO_PRIO_DEBUG:
            eResult = SLOG2_DEBUG1;
            break;

        default:
            eResult = SLOG2_SHUTDOWN;
            break;
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Parse log configuration file

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
static AOErrorCode_e AODebugParseConfiguration(void)
{
    AOErrorCode_e eResult = AO_SUCCESS;

    for (uint32_t i = 0; i < AO_LOG_SSID_COUNT; i++)
    {
        char buf[AO_MAX_STR_BUF_SZ];
        if(NULL == AOMemset(buf, 0, sizeof(buf)))
        {
            eResult = AO_ERROR_FAILURE;
        }

        if (AO_SUCCESS != eResult)
        {
            break;
        }
        else if (AO_SUCCESS != AOStrlcpy(buf, g_logCtxt.configFileDefaultPath, AO_MAX_STR_BUF_SZ))
        {
            eResult = AO_ERROR_FAILURE;
            break;
        }
        else if (AO_SUCCESS != AOStrlcat(buf, g_pStringSSID[i] + strlen("AO_"), AO_MAX_STR_BUF_SZ))
        {
            eResult = AO_ERROR_FAILURE;
            break;
        }
        else if (AO_SUCCESS != AOStrlcat(buf, "_", AO_MAX_STR_BUF_SZ))
        {
            eResult = AO_ERROR_FAILURE;
            break;
        }
        else
        {
            for (uint32_t j = 0; j < AO_PRIO_COUNT; j++)
            {
                boolean  bDefaultLog = FALSE;

                if((0 == strcmp(g_pStringLvl[j], "AO_PRIO_CRITICAL")) ||
                   (0 == strcmp(g_pStringLvl[j], "AO_PRIO_ERROR")) ||
                   (0 == strcmp(g_pStringLvl[j], "AO_PRIO_FATAL")))
                {
                    bDefaultLog = TRUE;
                }

                char enableLog[AO_MAX_STR_BUF_SZ];

                if(NULL == AOMemset(enableLog, 0, AO_MAX_STR_BUF_SZ))
                {
                    eResult = AO_ERROR_FAILURE;
                    break;
                }
                else if (AO_SUCCESS != AOStrlcpy(enableLog, buf, AO_MAX_STR_BUF_SZ))
                {
                    eResult = AO_ERROR_FAILURE;
                    break;
                }
                else
                {
                    if (AO_SUCCESS != AOStrlcat(enableLog,
                                                g_pStringLvl[j] + strlen("AO_PRIO_"),
                                                AO_MAX_STR_BUF_SZ))
                    {
                        eResult = AO_ERROR_FAILURE;
                        break;
                    }
                    else
                    {
                        if(EOK != pthread_mutex_lock(&g_logCtxt.mutex))
                        {
                            eResult = AO_ERROR_FAILURE;
                            break;
                        }
                        else
                        {
                            AOFileHandleType_t  hFile = -1;
                            if (AO_SUCCESS == AOFileOpen(enableLog, AO_FILE_CREATE_R, &hFile))
                            {
                                g_bLogTable[i][j] = TRUE;

                                if (AO_SUCCESS != AOFileClose(hFile))
                                {
                                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
                                            "Close log config file failed");
                                    eResult = AO_ERROR_FAILURE;
                                    break;
                                }
                            }
                            else
                            {
                                if (!bDefaultLog)
                                {
                                    g_bLogTable[i][j] = FALSE;
                                }
                            }

                            if(EOK != pthread_mutex_unlock(&g_logCtxt.mutex))
                            {
                                eResult = AO_ERROR_FAILURE;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Initializes debug msg.

    Note: This API should be called when application is launching. Calling this
    function in the middle of use case may potentially impact performance.

@return
    void
**************************************************************************************************/
AOErrorCode_e AODebugMsgInitialize
(
    void
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    int32_t idx;
    int nErr;

    if(EOK != (nErr = pthread_mutex_lock(&g_logCtxt.mutex)))
    {
        printf("pthread_mutex_lock failed %d \n", nErr);
    }
    else
    {
        if (0 == g_logCtxt.nRefCnt)
        {
            char strbuf[AO_MAX_STR_BUF_SZ];
            slog2_buffer_set_config_t  bufferConfig;

            /* register slog2 buffer */
            bufferConfig.num_buffers = AO_SLOG2_NUM_BUF;
            bufferConfig.verbosity_level = g_logCtxt.nSlog2Verbosity;

            if (AO_SUCCESS != AOStrlcpy(strbuf, __progname, AO_MAX_STR_BUF_SZ))
            {
                eResult = AO_ERROR_BAD_PARAMETER;
            }
            else if (AO_SUCCESS != AOStrlcat(strbuf, "_QC", AO_MAX_STR_BUF_SZ))
            {
                eResult = AO_ERROR_BAD_PARAMETER;
            }
            else
            {
                bufferConfig.buffer_config[0].buffer_name = strbuf;
                bufferConfig.buffer_set_name = strbuf;
                bufferConfig.buffer_config[0].num_pages = AO_SLOG2_NUM_PAGES;

                if (0 == slog2_register(&bufferConfig,
                                        &g_hBuffer,
                                        SLOG2_TRY_REUSE_BUFFER_SET))
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_HIGH, "slog2 verbose level = %d, handle = 0x%p",
                        (int32_t)g_logCtxt.nSlog2Verbosity, g_hBuffer);

                    if (-1 == slog2_set_verbosity(g_hBuffer,
                                                  (uint8_t)g_logCtxt.nSlog2Verbosity))
                    {
                        AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
                            "failed to set verbosity level = %d for handle = 0x%p",
                            (int32_t)g_logCtxt.nSlog2Verbosity, g_hBuffer);
                    }
                    else
                    {
                        g_logCtxt.nRefCnt++;
                        /* Enable error and fatal logs by default */
                        for (idx = AO_GENERAL; idx < AO_LOG_SSID_COUNT; idx++)
                        {
                            g_bLogTable[idx][AO_PRIO_CRITICAL] = TRUE;
                            g_bLogTable[idx][AO_PRIO_ERROR] = TRUE;
                            g_bLogTable[idx][AO_PRIO_FATAL] = TRUE;
                        }

                        eResult = AODebugParseConfiguration();
                        if ((AO_SUCCESS != eResult))
                        {
                            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AODebugParseConfiguration failed");
                        }
                    }
                }
            }
        }
        else
        {
            g_logCtxt.nRefCnt++;
            eResult = AO_SUCCESS;
        }

        if (EOK != (nErr = pthread_mutex_unlock(&g_logCtxt.mutex)))
        {
            printf("pthread_mutex_unlock failed %d \n", nErr);
            eResult = AO_ERROR_FAILURE;
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Deinitializes debug msg.

@return
    void
**************************************************************************************************/
AOErrorCode_e AODebugMsgDeinitialize
(
    void
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    int nErr;

    if(EOK != (nErr = pthread_mutex_lock(&g_logCtxt.mutex)))
    {
        printf("pthread_mutex_lock failed %d \n", nErr);
    }
    else
    {
        eResult = AO_SUCCESS;

        g_logCtxt.nRefCnt--;

        if (0 == g_logCtxt.nRefCnt)
        {
            (void)slog2_reset();
        }
        
        if(0 > g_logCtxt.nRefCnt)
        {
            printf("warning: %s already called. Reset the refCnt \n", __FUNCTION__);
            g_logCtxt.nRefCnt = 0;
        }

        if (EOK != (nErr = pthread_mutex_unlock(&g_logCtxt.mutex)))
        {
            printf("pthread_mutex_unlock failed %d \n", nErr);
            eResult = AO_ERROR_FAILURE;
        }
    }

    return eResult;
}

