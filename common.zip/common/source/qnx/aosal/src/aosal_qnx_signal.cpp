/**================================================================================================

@file
  aosal_qnx_signal.cpp

@brief
   This file defines methods to send and receive signals typically objects used for
   multi-thread event notification.

Copyright (c) 2021-2022 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include <pthread.h>
#include "aosal_signal.h"
#include "aosal_critical_section.h"
#include "aosal_debug_msg.h"
#include "aosal_error.h"
#include "aosal_malloc.h"
#include "aosal_qnx_utils.h"

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/

#define AO_MAX_NUMBER_SIGNALS       (32)
#define AO_MAX_NUMBER_SIGNAL_QUEUE  (256)

/**================================================================================================
** Typedefs
================================================================================================**/

typedef struct AOSignalQ AOSignalQ_t;
typedef struct AOSignal AOSignal_t;

/**********************************************************************************************//**
@brief
    Signal structure
**************************************************************************************************/
typedef struct AOSignal
{
    size_t              nSize;                          /**< size of this structure */
    AOSignalAttribute_e eSignalAttributes;              /**< Attributes of the signal */
    boolean             bSignalInUse;                   /**< Signal has been used */
    int32_t             nCount;                         /**< Signal set count */
    void                *pUserArg;                      /**< User data */
    void                (*pfnSignalHandler)(void* pArg);/**< User Signal handler */
    AOSignalQ_t         *pParentSignalQ;                /**< Reference to the parent signalQ with
                                                          *  which the signal is associated
                                                          */
} AOSignal_t;

/**********************************************************************************************//**
@brief
    SignalQ structure
**************************************************************************************************/
typedef struct AOSignalQ
{
    size_t            nSize;                           /**< size of this structure */
    volatile boolean  bWaitReqd;                       /**< flag to indicate whether the internal
                                                         *  pthread wait is required
                                                         */
    pthread_mutex_t   mutex;                           /**< mutex */
    pthread_cond_t    condition;                       /**< conditional variable to be waited */
    boolean           bSignalQInUse;                   /**< SignalQ is in use */
    AOSignal_t        signals[AO_MAX_NUMBER_SIGNALS];  /**< List of signals created in the queue */
} AOSignalQ_t;

/**================================================================================================
** Variables
================================================================================================**/

static const void *g_pSignalQCtxt[AO_MAX_NUMBER_SIGNAL_QUEUE] = { NULL };


/**================================================================================================
                        FUNCTION DECLARATIONS
================================================================================================**/

static AOErrorCode_e AOProcessSignalInternal
(
    AOSignal_t *pSignal,
    boolean     bCounting
);

static AOErrorCode_e AOFindSignalInUse
(
    const AOSignalQ_t     *pSignalQ,
    uint32_t              *pSignalIndex
);

/**================================================================================================
                        FUNCTION DEFINITIONS
================================================================================================**/

/**********************************************************************************************//**
@brief
    Find the raised signal from the signal queue and return the index of the
    raised signal in the queue. If none of the signal was raised,
    AO_MAX_NUMBER_SIGNALS is returned as the index to the signal.

@param pSignalQ
    Pointer to the Signal Queue
 
@param pSignalIndex
    Pointer to the index of the raised signal in the queue
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
static AOErrorCode_e AOFindSignalInUse
(
    const AOSignalQ_t   *pSignalQ,
    uint32_t            *pSignalIndex
)
{
    AOErrorCode_e   eResult = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(pSignalQ) || AO_CHK_NULL(pSignalIndex))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        uint32_t i = 0;
        for (i = 0; i < AO_MAX_NUMBER_SIGNALS; i++)
        {
            if (pSignalQ->signals[i].nCount > 0)
            {
                break;
            }
        }

        *pSignalIndex = i;

        eResult = AO_SUCCESS;
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    This function calls internally pthread_cond_wait or pthread_cond_timedwait 

@param pSignalQ
    Pointer to the Signal Queue
 
@param nTimeoutInMs
    Timeout value in millisecond. Wait forever if the value is 0 or UINT64_MAX 
 
@return
    - AO_SUCCESS if success
    - AO_ERROR_TIMEDOUT if the wait timeout
    - Other error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOSignalQWaitInternal
(
    AOSignalQ_t     *pSignalQ,
    uint64_t        nTimeoutInMs
)
{
    AOErrorCode_e   eResult = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(pSignalQ))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        int nErr = EOK;

        pthread_cleanup_push(AOUnlockPthreadMutex, &pSignalQ->mutex);

        if ((0U == nTimeoutInMs) || (UINT64_MAX == nTimeoutInMs))
        {
            while ((TRUE == pSignalQ->bWaitReqd) && (EOK == nErr))
            {
                nErr = pthread_cond_wait(&pSignalQ->condition, &pSignalQ->mutex);
            }
        }
        else
        {
            struct timespec timeout;

            if (0 == clock_gettime(CLOCK_MONOTONIC, &timeout))
            {
                const uint64_t nCurrTimeNSec = timespec2nsec(&timeout);

                if ((nTimeoutInMs > (UINT64_MAX/(1000ULL*1000ULL))) ||
                    (AO_MSEC_TO_NSEC(nTimeoutInMs) > (UINT64_MAX - nCurrTimeNSec))) 
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "timeout value %lu ms too large currTime %lu ns",
                           nTimeoutInMs, nCurrTimeNSec);
                    nErr = EINVAL;
                }
                else
                {
                    const uint64_t nAbsTimeNSec = nCurrTimeNSec + AO_MSEC_TO_NSEC(nTimeoutInMs);
                    nsec2timespec(&timeout, nAbsTimeNSec);

                    while ((TRUE == pSignalQ->bWaitReqd) && (EOK == nErr))
                    {
                        nErr = pthread_cond_timedwait(&pSignalQ->condition,
                                                      &pSignalQ->mutex,
                                                      &timeout);
                    }
                }
            }
            else
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
                       "clock_gettime error: %s", strerror(errno));
                nErr = errno;
            }
        }

        pthread_cleanup_pop(0);

        switch (nErr)
        {
            case EOK:
            {
                pSignalQ->bWaitReqd = FALSE;

                eResult = AO_SUCCESS;
                break;
            }
            case ETIMEDOUT:
            {
                /* ignore timeout if already in set state */
                eResult = (pSignalQ->bWaitReqd) ? AO_ERROR_TIMEDOUT: AO_SUCCESS;

                pSignalQ->bWaitReqd = FALSE;

                break;
            }
            default:
            {
                eResult = AO_ERROR_FAILURE;
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
                            "AOSignalQWaitInternal error: %s", strerror(errno));
                break;
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Creates a signal queue object

@param pHandle
    Pointer to the Signal Queue handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOSignalQCreate
(
    AOHandleType_t *pHandle
)
{
    AOErrorCode_e   eResult = AO_ERROR_FAILURE; 
    AOErrorCode_e   eSts = AO_ERROR_FAILURE; 
    AOSignalQ_t     *pSignalQ = NULL;

    if (AO_CHK_NULL(pHandle))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        pSignalQ = (AOSignalQ_t *)AOMalloc(sizeof(AOSignalQ_t));

        if (NULL == pSignalQ)
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Allocation failed");
            eResult = AO_ERROR_NO_MEM;
        }
        else
        {
            if (AO_SUCCESS != (eSts = AOAddPointerEntry(&g_pSignalQCtxt[0],
                                                        (void *)pSignalQ,
                                                        AO_MAX_NUMBER_SIGNAL_QUEUE)))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Reached max number of signal Q");
                eResult = eSts;
            }
            else if (NULL == AOMemset(pSignalQ, 0, sizeof(AOSignalQ_t))) 
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMemset failed");
                eResult = AO_ERROR_FAILURE;
            }
            else
            {
                pthread_condattr_t attr;

                pSignalQ->bSignalQInUse = TRUE;
                pSignalQ->nSize = sizeof(AOSignalQ_t);

                int nErr = EOK;
                if (EOK != (nErr = pthread_condattr_init(&attr)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_condattr_init");
                }
                else if (EOK != (nErr = pthread_condattr_setclock(&attr, CLOCK_MONOTONIC)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_condattr_setclock");
                    (void)pthread_condattr_destroy(&attr);
                }
                else if (EOK != (nErr = pthread_mutex_init(&pSignalQ->mutex, NULL)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_init");
                    (void) pthread_condattr_destroy(&attr);
                }
                else if (EOK != (nErr = pthread_cond_init(&pSignalQ->condition, &attr)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_cond_init");
                    (void) pthread_mutex_destroy(&pSignalQ->mutex);
                    (void) pthread_condattr_destroy(&attr);
                }
                else if (EOK != (nErr = pthread_condattr_destroy(&attr)))
                {
                    /* clean up temp attr in success case */
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_condattr_destroy");
                    (void) pthread_mutex_destroy(&pSignalQ->mutex);
                    (void) pthread_cond_destroy(&pSignalQ->condition);
                }
                else
                {
                    /* success */
                   for (uint32_t i = 0; i < AO_MAX_NUMBER_SIGNALS; i++)
                   {
                       pSignalQ->signals[i].pParentSignalQ = pSignalQ;
                   }

                   *pHandle = pSignalQ;
                   eResult = AO_SUCCESS;
                }
            }
        }
    }

    if (AO_SUCCESS != eResult)
    {
        /* clean up */
        if (NULL != pSignalQ)
        {
            (void)AORemovePointerEntry(&g_pSignalQCtxt[0],
                                       (void *)pSignalQ,
                                       AO_MAX_NUMBER_SIGNAL_QUEUE);
            
            AOFree(pSignalQ);
            pSignalQ = NULL;
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Releases the resources associated with the signal queue

@param handle
    Signal queue handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOSignalQDestroy
(
    AOHandleType_t handle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOErrorCode_e eSts = AO_ERROR_FAILURE; 

    if (AO_CHK_NULL(handle))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        AOSignalQ_t *pSignalQ = (AOSignalQ_t *) handle;

        if(AO_SUCCESS != (eSts = AORemovePointerEntry(&g_pSignalQCtxt[0],
                                                      (void *)pSignalQ,
                                                      AO_MAX_NUMBER_SIGNAL_QUEUE)))
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Invalid handle or has been released 0x%p",
                    pSignalQ);
            eResult = eSts;
        }
        else
        {
            int nErr = EOK;

            if(EOK != (nErr = pthread_mutex_lock(&pSignalQ->mutex)))
            {
                AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_lock");
            }
            else
            {
                eResult = AO_SUCCESS;

                // continue cleanup resources below and capture return status if failed
                pSignalQ->bSignalQInUse = FALSE;

                uint32_t nSignalIndex = AO_MAX_NUMBER_SIGNALS;

                // skip error check as it always returns success
                (void) AOFindSignalInUse(pSignalQ, &nSignalIndex);

                if (nSignalIndex < AO_MAX_NUMBER_SIGNALS)
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
                           "AOSignalDestroy should be called before destroying signalQ 0x%p",
                            pSignalQ);
                    eResult = AO_ERROR_INVAL;
                }

                if(EOK != (nErr = pthread_mutex_unlock(&pSignalQ->mutex)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_unlock");
                }

                if (EOK != (nErr = pthread_cond_destroy(&pSignalQ->condition)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_cond_destroy");
                }

                if (EOK != (nErr = pthread_mutex_destroy(&pSignalQ->mutex)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_destroy");
                }

                AOFree(handle);
           }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    This function process the raised signal in the queue

@param pSignal
    pointer to signal in the queue
 
@param bCounting  
    Applicable when signal was created with attribute AO_SIGNAL_ATTR_RESET_AUTOMATIC.
    
    If this flag is set to TRUE, setting a signal is counted. AOSignal()
    increments the count. AOSignalQWait() decrements the count and returns to
    the user. It blocks only when the count becomes zero.
    
    If this flag is set to FALSE, this function clears the count of all previous
    signal setting via AOSignalSet() and blocks till a new signal arrives.
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
static AOErrorCode_e AOProcessSignalInternal
(
    AOSignal_t *pSignal,
    boolean     bCounting
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(pSignal))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        if (AO_SIGNAL_ATTR_RESET_AUTOMATIC == pSignal->eSignalAttributes)
        {
            // automatic mode
            if (bCounting)
            {
                pSignal->nCount--;

                if (pSignal->nCount < 0)
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "invalid signal nCount");
                    eResult = AO_ERROR_FAILURE;
                }
                else
                {
                    eResult = AO_SUCCESS;
                }
            }
            else
            {
                pSignal->nCount = 0;
                eResult = AO_SUCCESS;
            }
        }
        else
        {
            // manual mode
            eResult = AO_SUCCESS;
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    This function blocks until any of the signals registered to the queue is set
    via AOSignalSet. If a signal handler has been registered when the signal is
    created then the handler is called, else function returns with the user data
    pointer passed in when creating the signal

@param handle
    Signal queue handle
 
@param bCounting  
    Applicable when signal was created with attribute AO_SIGNAL_ATTR_RESET_AUTOMATIC.
    
    If this flag is set to TRUE, setting a signal is counted. AOSignal()
    increments the count. AOSignalQWait() decrements the count and returns to
    the user. It blocks only when the count becomes zero.
    
    If this flag is set to FALSE, this function clears the count of all previous
    signal setting via AOSignalSet() and blocks till a new signal arrives.
 
@param nTimeOut
    The time in millisecond to wait for the signal to be set. A value of 0 or
    0xFFFFFFFFFFFFFFFF disables timeout.
 
@param ppUserArg
    User data pointer of the signal set when signal is created
 
@param pbTimedOut
    True indicates timeout of no signal set during the period of nTimeOut
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOSignalQWait
(
    AOHandleType_t  handle,
    boolean         bCounting,
    uint64_t        nTimeOut,
    void            **ppUserArg,
    boolean         *pbTimedOut
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOErrorCode_e eSts = AO_ERROR_FAILURE; 

    AOSignalQ_t *pSignalQ = (AOSignalQ_t *) handle;
    uint32_t nSignalIndex = AO_MAX_NUMBER_SIGNALS;
    void (*pfnSignalHandler)(void* pArg) = NULL;
    void *pUserArg = NULL;
    int nErr = EOK;

    boolean bTimedWait = ((nTimeOut != 0) && (nTimeOut != UINT64_MAX));

    if (AO_CHK_NULL(pSignalQ) || AO_CHK_STRUCT_SIZE(pSignalQ->nSize, sizeof(AOSignalQ_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else if ((TRUE == bTimedWait) && (NULL == pbTimedOut))
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "NULL pbTimedOut nTimeOut %ld", nTimeOut);
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else if(EOK != (nErr = pthread_mutex_lock(&pSignalQ->mutex)))
    {
        AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_lock");
    }
    else
    {
        // initialization
        if (NULL != ppUserArg)
        {
            *ppUserArg = NULL;
        }

        if (TRUE == bTimedWait)
        {
            *pbTimedOut = FALSE;
        }

        (void) AOFindSignalInUse(pSignalQ, &nSignalIndex);

        if (AO_MAX_NUMBER_SIGNALS == nSignalIndex)
        {
            /**<  For the case where multiple threads sharing the same signalQ:
              *   One signal is broadcasted to all threads waiting for the same cond. var.
              *   The signal will be processed by one thread. Other threads will be unblocked with
              *   no signal set. Need to wait again for the next.
              */
            while (AO_MAX_NUMBER_SIGNALS == nSignalIndex)
            {
                // none of the signals have been set, wait
                pSignalQ->bWaitReqd = TRUE;

                eSts = AOSignalQWaitInternal(pSignalQ, nTimeOut);

                if ((TRUE == bTimedWait) && (AO_ERROR_TIMEDOUT == eSts))
                {
                    // timeout case: return success with timeout flag set
                    *pbTimedOut = TRUE;
                    eResult = AO_SUCCESS;
                    break;
                }
                else if (AO_SUCCESS != eSts)
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOSignalQWaitInternal failed %d", eSts);
                    break;
                }
                else
                {
                    // success case without timeout
                    (void)AOFindSignalInUse(pSignalQ, &nSignalIndex);
                }
            }
        }
        else
        {
            eSts = AO_SUCCESS;
        }

        if (AO_SUCCESS == eSts)
        {
            if(AO_SUCCESS != AOProcessSignalInternal(&pSignalQ->signals[nSignalIndex],
                                                  bCounting))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "ProcessSignalInternal %d failed at signalQ %p",
                       nSignalIndex, pSignalQ);
                eResult = AO_ERROR_FAILURE;
            }
            else
            {
                if (NULL != pSignalQ->signals[nSignalIndex].pfnSignalHandler)
                {
                    pfnSignalHandler = pSignalQ->signals[nSignalIndex].pfnSignalHandler;
                    pUserArg = pSignalQ->signals[nSignalIndex].pUserArg;
                }                        

                if ((NULL != pSignalQ->signals[nSignalIndex].pUserArg) &&
                    (NULL != ppUserArg))
                {
                    *ppUserArg = pSignalQ->signals[nSignalIndex].pUserArg;
                }
                eResult = AO_SUCCESS;
            }
        }

        if(EOK != (nErr = pthread_mutex_unlock(&pSignalQ->mutex)))
        {
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_unlock");
        }
        else
        {
            if ((AO_SUCCESS == eSts) && (NULL != pfnSignalHandler))
            {
                pfnSignalHandler(pUserArg);
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Creates a signal handle

    When the associated signal is set the registered call back will be called.  
    Note that the signal implementation does not have a context of its own, so 
    Wait() needs to be called to give context of execution for the handler to be
    called. 
  
    If the optional signal handler is registered then the handler will be called
    with the optional user argument when the signal is set else user argument is
    returned in Wait()/TimerWait() call.

@param hSignalQ
    The signal queue handle
 
@param pvUserArg
    Optional user data pointer to be passed in the call back or returned when
    the signal is set.
 
@param pfnSignalHandler
    Optional signal handler to be called when the signal is set
 
@param eSignalAttributes
    Signal attribute defined in AOSignalAttribute_e
 
@param phSignal
    Pointer to the signal handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOSignalCreate
(
    AOHandleType_t      hSignalQ,
    void                *pvUserArg,
    void                (*pfnSignalHandler)(void* pArg),
    AOSignalAttribute_e eSignalAttributes,
    AOHandleType_t      *phSignal
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOSignalQ_t *pSignalQ = (AOSignalQ_t *) hSignalQ;

    if (AO_CHK_NULL(pSignalQ) || 
        AO_CHK_STRUCT_SIZE(pSignalQ->nSize, sizeof(AOSignalQ_t)) ||
        AO_CHK_NULL(phSignal) || 
        ((AO_SIGNAL_ATTR_RESET_AUTOMATIC != eSignalAttributes) &&
         (AO_SIGNAL_ATTR_RESET_MANUAL != eSignalAttributes)))
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR,
               "AOSignalCreate:eSignalAttributes %d", eSignalAttributes);

        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else if (FALSE == pSignalQ->bSignalQInUse) 
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "pSignalQ not created. Unexpected");
    }
    else
    {
        int nErr = EOK;
        if(EOK != (nErr = pthread_mutex_lock(&pSignalQ->mutex)))
        {
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_lock");
        }
        else
        {
            uint32_t i = 0;
            for (i = 0; i < AO_MAX_NUMBER_SIGNALS; i++)
            {
                if ((FALSE == pSignalQ->signals[i].bSignalInUse) &&
                    (0 == pSignalQ->signals[i].nCount))
                {
                    pSignalQ->signals[i].nSize = sizeof(AOSignal_t);
                    pSignalQ->signals[i].eSignalAttributes = eSignalAttributes;
                    pSignalQ->signals[i].bSignalInUse = TRUE;
                    pSignalQ->signals[i].pUserArg = pvUserArg;
                    pSignalQ->signals[i].pfnSignalHandler = pfnSignalHandler;
                    *phSignal = (AOHandleType_t) &pSignalQ->signals[i];
                    eResult = AO_SUCCESS;
                    break;
                }
            }

            if (AO_MAX_NUMBER_SIGNALS == i) 
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Maximum signal reached");
            }

            if(EOK != (nErr = pthread_mutex_unlock(&pSignalQ->mutex)))
            {
                AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_unlock");
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Releases the signal resources

@param handle
    Signal handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOSignalDestroy
(
    AOHandleType_t handle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE; 

    AOSignal_t *pSignal = (AOSignal_t *) handle;

    if (AO_CHK_NULL(pSignal) || AO_CHK_STRUCT_SIZE(pSignal->nSize, sizeof(AOSignal_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        AOSignalQ_t *pSignalQ = pSignal->pParentSignalQ;

        if (NULL == pSignalQ) 
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "pSignalQ is NULL. Unexpected");
        }
        else
        {
            int nErr = EOK;
            if(EOK != (nErr = pthread_mutex_lock(&pSignalQ->mutex)))
            {
                AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_lock");
            }
            else
            {
                eResult = AO_SUCCESS;

                if (pSignal->bSignalInUse)
                {
                    pSignal->nCount = 0;
                    pSignal->bSignalInUse = FALSE;
                }

                if(EOK != (nErr = pthread_mutex_unlock(&pSignalQ->mutex)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_unlock");
                }
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Sets the signal in the associated signal queue

@param handle
    Signal handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOSignalSet
(
    AOHandleType_t handle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    AOSignal_t *pSignal = (AOSignal_t *) handle;

    if (AO_CHK_NULL(pSignal) || AO_CHK_STRUCT_SIZE(pSignal->nSize, sizeof(AOSignal_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        AOSignalQ_t *pSignalQ = pSignal->pParentSignalQ;

        if (NULL == pSignalQ) 
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "pSignalQ is NULL. Unexpected");
        }
        else if ((FALSE == pSignal->bSignalInUse) ||
                 (FALSE == pSignalQ->bSignalQInUse)) 
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Signal %d SignalQ %d in use unexpected",
                   pSignal->bSignalInUse, pSignalQ->bSignalQInUse);
        }
        else
        {
            int nErr = EOK;
            if(EOK != (nErr = pthread_mutex_lock(&pSignalQ->mutex)))
            {
                AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_lock");
            }
            else
            {
                pSignal->nCount++;

                if (TRUE == pSignalQ->bWaitReqd)
                {
                    pSignalQ->bWaitReqd = FALSE;
                    if(EOK != (nErr = pthread_cond_broadcast(&pSignalQ->condition)))
                    {
                        AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_cond_signal");
                    }
                    else
                    {
                        eResult = AO_SUCCESS;
                    }
                }
                else
                {
                    // Setting a signal that is already set has no effect.
                    eResult = AO_SUCCESS;
                }

                if(EOK != (nErr = pthread_mutex_unlock(&pSignalQ->mutex)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_unlock");
                }
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Reset the signal state when the signal was created using the attribute
    AO_SIGNAL_ATTR_RESET_MANUAL as defined in AOSignalAttribute.  After the
    signal is raised, AOSAL library does not clear the signal until this API is
    called.

@param handle
    Signal handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOSignalReset
(
    AOHandleType_t handle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE; 

    AOSignal_t *pSignal = (AOSignal_t *) handle;

    if (AO_CHK_NULL(pSignal) || AO_CHK_STRUCT_SIZE(pSignal->nSize, sizeof(AOSignal_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        AOSignalQ_t *pSignalQ = pSignal->pParentSignalQ;

        if (NULL == pSignalQ) 
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "pSignalQ is NULL. Unexpected");
        }
        else
        {
            int nErr = EOK;
            if(EOK != (nErr = pthread_mutex_lock(&pSignalQ->mutex)))
            {
                AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_lock");
            }
            else
            {
                pSignal->nCount = 0;
                eResult = AO_SUCCESS;

                if(EOK != (nErr = pthread_mutex_unlock(&pSignalQ->mutex)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_unlock");
                }
            }
        }
    }

    return eResult;
}

