/**================================================================================================

@file
  aosal_qnx_event.cpp

@brief
   This file implements the Event primitives for synchronization.

Copyright (c) 2021-2022 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/


/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include <pthread.h>
#include "aosal_malloc.h"
#include "aosal_event.h"
#include "aosal_error.h"
#include "aosal_debug_msg.h"
#include "aosal_qnx_utils.h"

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/

#define AO_MAX_NUM_EVENT  (256)

/**================================================================================================
** Typedefs
================================================================================================**/
typedef struct
{
    size_t            nSize;            /**< size of this structure */
    boolean           bManualReset;     /**< manual reset mode */
    volatile boolean  bSet;             /**< event raise flag */
    pthread_mutex_t   mutex;            /**< mutex */
    pthread_cond_t    condition;        /**< conditional variable to be waited */
} AOEvent_t;

/**================================================================================================
** Variables
================================================================================================**/

static const void *g_pEventCtxt[AO_MAX_NUM_EVENT] = { NULL };

/**================================================================================================
                        FUNCTION DEFINITIONS
================================================================================================**/

/**********************************************************************************************//**
@brief
    Creates an event

@param phEvent 
    pointer to event handle
 
@return
    Return value 0 is success else failure
**************************************************************************************************/
AOErrorCode_e AOEventCreate
(
    AOHandleType_t *phEvent
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE; 
    pthread_condattr_t attr;

    if (AO_CHK_NULL(phEvent))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        AOEvent_t *pEvent = (AOEvent_t *)AOMalloc(sizeof(*pEvent));

        if (NULL == pEvent)
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMalloc failed");
            eResult = AO_ERROR_NO_MEM;
        }
        else
        {
            if (AO_SUCCESS != AOAddPointerEntry(&g_pEventCtxt[0], (void *)pEvent, AO_MAX_NUM_EVENT))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Reached max number of events");
                AOFree(pEvent);
                eResult = AO_ERROR_INVAL;
            }
            else if(NULL == AOMemset(pEvent, 0, sizeof(*pEvent)))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMemset failed");
                AOFree(pEvent);
                eResult = AO_ERROR_FAILURE;
            }
            else
            {
                int nErr = EOK;
                 
                pEvent->nSize = sizeof(AOEvent_t);

                if (EOK != (nErr = pthread_condattr_init(&attr)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_condattr_init");
                }
                else if (EOK != (nErr = pthread_condattr_setclock(&attr, CLOCK_MONOTONIC)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_condattr_setclock");
                    (void)pthread_condattr_destroy(&attr);
                }
                else if (EOK != (nErr = pthread_mutex_init(&pEvent->mutex, NULL)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_init");
                    (void) pthread_condattr_destroy(&attr);
                }
                else if (EOK != (nErr = pthread_cond_init(&pEvent->condition, &attr)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_cond_init");
                    (void) pthread_mutex_destroy(&pEvent->mutex);
                    (void) pthread_condattr_destroy(&attr);
                }
                else
                {
                    /* success */
                   *phEvent = pEvent;
                   eResult = AO_SUCCESS;

                   if(EOK != (nErr = pthread_condattr_destroy(&attr)))
                   {
                       AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_condattr_destroy");
                   }
                }

                if (AO_SUCCESS != eResult)
                {
                    (void) AORemovePointerEntry(&g_pEventCtxt[0], (void *)pEvent, AO_MAX_NUM_EVENT);
                    AOFree(pEvent);
                }
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Destroys the Event

@param  hEvent
    Event handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOEventDestroy
(
    AOHandleType_t hEvent
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(hEvent))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        if (AO_SUCCESS != AORemovePointerEntry(&g_pEventCtxt[0], (void *)hEvent, AO_MAX_NUM_EVENT))
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Invalid handle or has been released 0x%p", hEvent);
            eResult = AO_ERROR_BAD_PARAMETER;
        }
        else
        {
            int nErr;
            AOEvent_t *pEvent = (AOEvent_t *)(hEvent);

            if (EOK != (nErr = pthread_cond_destroy(&pEvent->condition)))
            {
                AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_cond_destroy");
            }
            else if (EOK != (nErr = pthread_mutex_destroy(&pEvent->mutex)))
            {
                AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_destroy");
            }
            else
            {
                eResult = AO_SUCCESS;
            }

            AOFree(pEvent);
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Set event state

@param hEvent 
    Event handle
 
@return
    Return value 0 is success else failure
**************************************************************************************************/
AOErrorCode_e AOEventSet
(
    AOHandleType_t hEvent
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOEvent_t *pEvent = (AOEvent_t*) hEvent;

    if (AO_CHK_NULL(pEvent) || AO_CHK_STRUCT_SIZE(pEvent->nSize, sizeof(AOEvent_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        int nErr;

        if(EOK != (nErr = pthread_mutex_lock(&pEvent->mutex)))
        {
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_lock");
        }
        else
        {
            if (FALSE == pEvent->bSet)
            {
                pEvent->bSet = TRUE;

                if(EOK != (nErr = pthread_cond_signal(&pEvent->condition)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_cond_signal");
                }
                else
                {
                    eResult = AO_SUCCESS;
                }
            }
            else
            {
                /* Setting an event that is already set has no effect. */
                eResult = AO_SUCCESS;
            }

            if(EOK != (nErr = pthread_mutex_unlock(&pEvent->mutex)))
            {
                AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_unlock");
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Clears the event state

@param  hEvent
    Event handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOEventReset
(
    AOHandleType_t hEvent
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOEvent_t *pEvent = (AOEvent_t*) hEvent;

    if (AO_CHK_NULL(pEvent) || AO_CHK_STRUCT_SIZE(pEvent->nSize, sizeof(AOEvent_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        int nErr;

        if(EOK != (nErr = pthread_mutex_lock(&pEvent->mutex)))
        {
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_lock");
        }
        else
        {
            pEvent->bSet = FALSE;

            if(EOK != (nErr = pthread_mutex_unlock(&pEvent->mutex)))
            {
                AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_unlock");
            }
            else
            {
                eResult = AO_SUCCESS;
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Configures the Event to Manual Reset mode. In Manual Reset mode, the Event Wait
    function does not reset event and does not wait on event since already set.

@param  hEvent
    Event handle
 
@param  bReset
    TRUE or FALSE

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOEventManualReset
(
    AOHandleType_t  hEvent,
    boolean         bReset
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    AOEvent_t *pEvent = (AOEvent_t*) hEvent;

    if (AO_CHK_NULL(pEvent) || AO_CHK_STRUCT_SIZE(pEvent->nSize, sizeof(AOEvent_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        int nErr;

        if(EOK != (nErr = pthread_mutex_lock(&pEvent->mutex)))
        {
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_lock");
        }
        else
        {
            pEvent->bManualReset = bReset;

            if(EOK != (nErr = pthread_mutex_unlock(&pEvent->mutex)))
            {
                AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_unlock");
            }
            else
            {
                eResult = AO_SUCCESS;
            }
        }
    }
    return eResult;
}

/**********************************************************************************************//**
@brief
    Waits on the event with timeout value.

@param  hEvent
    Event handle
 
@param  nTimeoutInMs
    Timeout in milliseconds. A value of 0 or 0xFFFFFFFFFFFFFFFF disables timeout

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOEventWait
(
    AOHandleType_t  hEvent,
    uint64_t        nTimeoutInMs
)
{
    AOErrorCode_e   eResult = AO_ERROR_FAILURE;
    AOEvent_t       *pEvent = (AOEvent_t*) hEvent;

    if (AO_CHK_NULL(pEvent) || AO_CHK_STRUCT_SIZE(pEvent->nSize, sizeof(AOEvent_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        int nErr;

        if(EOK != (nErr = pthread_mutex_lock(&pEvent->mutex)))
        {
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_lock");
        }
        else
        {
            pthread_cleanup_push(AOUnlockPthreadMutex, &pEvent->mutex);

            if ((0U == nTimeoutInMs) || (0xFFFFFFFFFFFFFFFFU == nTimeoutInMs))
            {
                while ((FALSE == pEvent->bSet) && (EOK == nErr))
                {
                    nErr = pthread_cond_wait(&pEvent->condition,&pEvent->mutex);
                }
            }
            else
            {
                struct timespec timeout;
                long nsec;

                if (0 == clock_gettime(CLOCK_MONOTONIC, &timeout))
                {
                    timeout.tv_sec = timeout.tv_sec + (nTimeoutInMs / 1000);
                    nsec = timeout.tv_nsec + (((nTimeoutInMs % 1000) * 1000) * 1000);
                    if (nsec >= (1000 * 1000 * 1000))
                    {
                        nsec -= (1000 * 1000 * 1000);
                        timeout.tv_sec += 1;
                    }
                    timeout.tv_nsec = nsec;

                    while ((FALSE == pEvent->bSet) && (EOK == nErr))
                    {
                        nErr = pthread_cond_timedwait(&pEvent->condition, &pEvent->mutex, &timeout);
                    }
                }
                else
                {
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "clock_gettime error: %s", strerror(errno));
                    nErr = errno;
                }
            }

            pthread_cleanup_pop(0);

            switch (nErr)
            {
                case EOK:
                {
                    eResult = AO_SUCCESS;
                    /* handle auto event */
                    if (FALSE == pEvent->bManualReset)
                    {
                        pEvent->bSet = FALSE; /* auto clear */
                    }
                    break;
                }
                case ETIMEDOUT:
                {
                    /* ignore timeout if already in set state */
                    eResult = (pEvent->bSet) ? AO_SUCCESS : AO_ERROR_TIMEDOUT;

                    /* handle auto event only if no error occured */
                    if ((AO_SUCCESS == eResult) && (FALSE == pEvent->bManualReset))
                    {
                        pEvent->bSet = FALSE; /* auto clear */
                    }
                    break;
                }
                default:
                {
                    eResult = AO_ERROR_FAILURE;
                    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOEventWait error: %s", strerror(errno));
                    break;
                }
            }

            if(EOK != (nErr = pthread_mutex_unlock(&pEvent->mutex)))
            {
                AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_unlock");
            }
        }
    }

    return eResult;
}
