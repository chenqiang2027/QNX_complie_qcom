/**================================================================================================

@file
   aosal_qnx_malloc.cpp

@brief
   This file implements QNX memory utility.

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include "aosal_malloc.h"
#include "aosal_error.h"
#include "aosal_debug_msg.h"
#include "aosal_qnx_utils.h"

/**================================================================================================
                        FUNCTION DEFINITIONS
================================================================================================**/

/**********************************************************************************************//**
@brief
    Allocate memory

@param nSize
    The number of bytes to allocate.
 
@return
    Non-NULL pointer to the memory if success otherwise NULL
**************************************************************************************************/
void* AOMalloc
(
    uint64_t  nSize
)
{
    void *pMem = NULL;

    if (nSize > 0)
    {
        pMem = malloc(nSize);
    }

    return pMem;
}

/**********************************************************************************************//**
@brief
    Free memory

@param ptr
    Pointer to the memory
 
@return
    void
**************************************************************************************************/
void AOFree
(
    void *ptr
)
{
    if (NULL != ptr)
    {
        free(ptr);
    }
    else
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Null ptr at AOFree");
    }
}

/**********************************************************************************************//**
@brief
    Memset memory

@param pDst
    A pointer to the memory to set
 
@param nVal
    The value to be store in each byte
 
@param nLength
    The number of bytes to set
 
@return
    NULL in case of failure, else a pointer to the destination buffer, i.e., pDst
**************************************************************************************************/
void* AOMemset
(
    void        *pDst,
    int32_t     nVal,
    uint64_t    nLength
)
{
    void *ptr = NULL;

    if (NULL != pDst)
    {
        if ((nVal >= -128) && (nVal <= 255))
        {
            errno_t err = memset_s(pDst, nLength, nVal, nLength);
            if (EOK != err)
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "memset_s() ret err %d", err);
            }
            else
            {
                ptr = pDst;
            }
        }
    }
    else
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Null ptr at AOMemset");
    }

    return ptr;
}

/**********************************************************************************************//**
@brief
    Size bounded memory copy

@param pDst
    A pointer to the memory to be filled
 
@param nDstSize
    Destination memory size
 
@param pSrc
    A pointer to the source memory
 
@param nSrcSize
    Number of bytes in the source memory to be copied
 
@return
    Number of bytes copied
**************************************************************************************************/
uint64_t AOMemscpy
(
    void        *pDst,
    uint64_t    nDstSize,
    const void  *pSrc,
    uint64_t    nSrcSize
)
{
    uint64_t  nCopySize = 0;

    if ((NULL != pDst) && (NULL != pSrc)) 
    {
        nCopySize = (nDstSize <= nSrcSize) ? nDstSize : nSrcSize;
        (void)memcpy(pDst, pSrc, nCopySize);
    }
    else
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Null ptr at AOMemscpy");
    }

    return nCopySize;
}

/**********************************************************************************************//**
@brief
    String copy

@param pDst
    A pointer to the destination string buffer
 
@param pSrc
    A pointer to the source memory
 
@param nDstSize
    Destination buffer size
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOStrlcpy
(
    char        *pDst,
    const char  *pSrc,
    uint64_t    nDstSize 
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(pDst) || AO_CHK_NULL(pSrc) || (0 == nDstSize))
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "nDstSize %ld", nDstSize);
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        uint64_t nSrcLen = strlen(pSrc);
        if (MAX_UINT32 > nSrcLen)
        {
            uint64_t nCopiedSize;
            nCopiedSize = AOMemscpy(pDst, nDstSize - 1, pSrc, nSrcLen);

            if (nCopiedSize == nSrcLen)
            {
                pDst[nCopiedSize] = '\0';
                eResult = AO_SUCCESS;
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    String concatenation

@param pDst
    A pointer to the destination string buffer
 
@param pSrc
    A pointer to the source string
 
@param nDstSize
    Destination buffer size
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOStrlcat
(
    char        *pDst,
    const char  *pSrc,
    uint64_t    nDstSize 
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(pDst) || AO_CHK_NULL(pSrc) || (0 == nDstSize))
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "nDstSize %ld", nDstSize);
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        uint64_t nSrcSize;
        uint64_t nOrigDstSize;

        nOrigDstSize = strlen(pDst);
        nSrcSize = strlen(pSrc);

        if ((MAX_UINT32 > nOrigDstSize) && (MAX_UINT32 > nSrcSize))
        {
            if ((nOrigDstSize + nSrcSize) < nDstSize)
            {
                (void)AOMemscpy(&pDst[nOrigDstSize],
                                nDstSize - 1 - nOrigDstSize,
                                (const void*)pSrc,
                                nSrcSize);

                pDst[nOrigDstSize + nSrcSize] = '\0';

                eResult = AO_SUCCESS;
            }
            else
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "nDstSize %ld not enough", nDstSize);
            }
        }
    }

    return eResult;
}

