/**================================================================================================

@file
   aosal_qnx_profile.cpp

@brief
   This file defines functions that can be used for logging events in profile log.

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/


/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include <sys/neutrino.h>
#include <sys/trace.h>
#include "aosal_profile.h"
#include "aosal_malloc.h"
#include "aosal_error.h"
#include "aosal_qnx_utils.h"


/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/

#define PROFILE_TRACE_BASE          (100)
#define PROFILE_MAX_STRING_LEN      (256)

/**********************************************************************************************//**
@brief
    Defines profile context structure 
**************************************************************************************************/
typedef struct
{
    size_t              nSize;      /**< size of this structure */
    boolean             bEnable;    /**< flag for enablement */
    uint32_t            nDomain;    /**< domain name for profiling */
} ProfileCtxt_t;

/**================================================================================================
                        FUNCTION DEFINITIONS
================================================================================================**/

/**********************************************************************************************//**
@brief
    Initializes profiling for a client

@param pHandle
    Pointer to the handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOProfileInit
(
    AOHandleType_t  *pHandle
)
{
    ProfileCtxt_t *pCtxt;
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
   
    if (AO_CHK_NULL(pHandle))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        *pHandle = NULL;

        pCtxt = (ProfileCtxt_t *)AOMalloc(sizeof(ProfileCtxt_t));

        if (NULL == pCtxt)
        {
            eResult = AO_ERROR_NO_MEM;
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMalloc failed");
        }
        else if (NULL == AOMemset(pCtxt, 0, sizeof(ProfileCtxt_t))) 
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMemset failed");
            AOFree(pCtxt);
            eResult = AO_ERROR_FAILURE;
        }
        else
        {
            pCtxt->nSize = sizeof(ProfileCtxt_t);

            *pHandle = (AOHandleType_t)pCtxt;
            eResult = AO_SUCCESS;
        }
    }
    return eResult;
}

/**********************************************************************************************//**
@brief
    Deinitializes profiling

@param handle
    Profile handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOProfileDeInit
(
   AOHandleType_t  handle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    ProfileCtxt_t *pCtxt = (ProfileCtxt_t *)handle;

    if (AO_CHK_NULL(pCtxt) || AO_CHK_STRUCT_SIZE(pCtxt->nSize, sizeof(ProfileCtxt_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        AOFree((void *)handle);
        eResult = AO_SUCCESS;
    }

    return eResult;
}


/**********************************************************************************************//**
@brief
    Configs profile

@param handle
    Profile handle
 
@param domain
    Profile domain defined in AOProfileDomain_e
 
@param bEnable
    True for enable otherwise disable
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOProfileConfig
(
    AOHandleType_t     handle,
    AOProfileDomain_e  eDomain,
    boolean            bEnable
)
{
   AOErrorCode_e eResult = AO_ERROR_FAILURE;
   ProfileCtxt_t *pCtxt = (ProfileCtxt_t *)handle;
   
   if (AO_CHK_NULL(pCtxt) || AO_CHK_STRUCT_SIZE(pCtxt->nSize, sizeof(ProfileCtxt_t)))
   {
       eResult = AO_ERROR_BAD_PARAMETER;
   }
   else
   {
       pCtxt->bEnable = bEnable;
       pCtxt->nDomain = (uint32_t)eDomain + _NTO_TRACE_USERFIRST + PROFILE_TRACE_BASE;
       eResult = AO_SUCCESS;
   }

   return eResult;
}

/**********************************************************************************************//**
@brief
    Marks event id in system profiling log

@param handle
    Profile handle
 
@param nEventId
    User event ID to be added into profiling
 
@param nUserData
    User data
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOProfileInsertMarkID
(
   AOHandleType_t   handle,
   uint32_t         nEventId,
   uint32_t         nUserData
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;
    ProfileCtxt_t *pCtxt = (ProfileCtxt_t *)handle;

    if (AO_CHK_NULL(pCtxt) || AO_CHK_STRUCT_SIZE(pCtxt->nSize, sizeof(ProfileCtxt_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        int nErr = 0;
        if (pCtxt->bEnable)
        {
            nErr = trace_logi(pCtxt->nDomain, nEventId, nUserData);
            if (0 == nErr)
            {
                eResult = AO_SUCCESS;
            }
            else
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "trace_logi failed %s", strerror(errno));
            }
        }
    }

    return (eResult);
}
