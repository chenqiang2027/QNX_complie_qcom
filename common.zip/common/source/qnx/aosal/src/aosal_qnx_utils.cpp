/**================================================================================================

@file
   aosal_qnx_utils.cpp

@brief
   This file contains implementation of utility functions

Copyright (c) 2021-2022 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include "aosal_error.h"
#include "aosal_qnx_utils.h"

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constant and Macros
================================================================================================**/

/**================================================================================================
** Typedefs
================================================================================================**/

/**================================================================================================
** Variables
================================================================================================**/

static pthread_mutex_t   g_PointerMutex = PTHREAD_MUTEX_INITIALIZER;

/**********************************************************************************************//**
@brief
    Unlock pthread mutex at thread exit for clean up. This function was
    registered at pthread_cleanup_push.

@param  pMutex
    pthread mutex handle
 
@return
    void
**************************************************************************************************/
void AOUnlockPthreadMutex
(
    void *pMutex
)
{
    if (NULL != pMutex)
    {
        (void)pthread_mutex_unlock((pthread_mutex_t *)pMutex);
    }
}

/**********************************************************************************************//**
@brief
    Add a pointer into an array of pointers. The purpose is to protect the dynamically
    allocated memory pointers (e.g., context memory) and avoid free an already freed handle.

    Note: the array of pointers is allocated by the caller

@param ppEntryStart
    Pointer to an array of pointers
 
@param pPointerToAdd
    Pointer to be added into the array
 
@param nNumEntries
    Number of entries of the pointer array
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOAddPointerEntry
(
    const void  **ppEntryStart,
    const void  *pPointerToAdd,
    uint32_t    nNumEntries
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(ppEntryStart) || AO_CHK_NULL(pPointerToAdd) || (0 == nNumEntries))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        int nErr;

        if(EOK != (nErr = pthread_mutex_lock(&g_PointerMutex)))
        {
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_lock");
        }
        else
        {
            for (uint32_t i = 0; i < nNumEntries; i++)
            {
                if (NULL == ppEntryStart[i])
                {
                    ppEntryStart[i] = pPointerToAdd;
                    eResult = AO_SUCCESS;
                    break;
                }
            }

            AO_MAP_PTHREAD_ERR_IF_FAILED(pthread_mutex_unlock(&g_PointerMutex),
                                         eResult,
                                         "pthread_mutex_unlock");
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Remove a pointer from an array of pointers. The purpose is to protect the
    dynamically allocated memory pointers (e.g., context memory) and avoid free
    an already freed handle.

    Note: the array of pointers is allocated by the caller

@param ppEntryStart
    Pointer to an array of pointers
 
@param pPointerToRemove
    Pointer to be removed from the array
 
@param nNumEntries
    Number of entries of the pointer array
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AORemovePointerEntry
(
    const void  **ppEntryStart,
    const void  *pPointerToRemove,
    uint32_t    nNumEntries
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if ((AO_CHK_NULL(ppEntryStart) || AO_CHK_NULL(pPointerToRemove)) || (0 == nNumEntries))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        int nErr;

        if(EOK != (nErr = pthread_mutex_lock(&g_PointerMutex)))
        {
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_lock");
        }
        else
        {
            for (uint32_t i = 0; i < nNumEntries; i++)
            {
                if (pPointerToRemove == ppEntryStart[i])
                {
                    ppEntryStart[i] = NULL;
                    eResult = AO_SUCCESS;
                    break;
                }
            }

            AO_MAP_PTHREAD_ERR_IF_FAILED(pthread_mutex_unlock(&g_PointerMutex),
                                         eResult,
                                         "pthread_mutex_unlock");
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Map QNX error codes to AOSAL error codes

@param nErr
    QNX error code

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOMapError
(
    int32_t nErr
)
{
   AOErrorCode_e eResult = AO_SUCCESS;
   switch(nErr)
   {  
       case EOK:
            eResult = AO_SUCCESS;
            break;
       case ENOMEM:
            eResult = AO_ERROR_NO_MEM;
            break;
       case EINVAL:
       case EFAULT:
       case ELOOP:
       case ENOTDIR:
       case ENXIO:
            eResult = AO_ERROR_INVAL;
            break;
       case EAGAIN:
       case ENOSPC:
            eResult = AO_ERROR_NO_RSRC;
            break;
       case EPERM:
       case EACCES:
       case EROFS:
       case EFBIG:
       case ETXTBSY:
            eResult = AO_ERROR_OP_NOT_PERMITTED;
            break;
       case EBUSY:
            eResult = AO_ERROR_BUSY;
            break;
       case EDEADLK:
            eResult = AO_ERROR_ALREADY_OWNS_MUTEX;
            break;
       case ETIMEDOUT:
            eResult = AO_ERROR_TIMEDOUT;
            break;
       case ESRCH:
            eResult = AO_ERROR_NO_PROCESS;
            break;
       case ENOTSUP:
       case ENOSYS:
            eResult = AO_ERROR_NOT_SUPPORTED;
            break;
       case EEXIST:
            eResult = AO_ERROR_FILE_EXISTS;
            break;
       case EISDIR:
            eResult = AO_ERROR_IS_DIRECTORY;
            break;
       case ENAMETOOLONG:
            eResult = AO_ERROR_FILE_PATH_NAME_TOOLONG;
            break;
       case ENODEV:
       case ENOENT:
            eResult = AO_ERROR_NO_SUCH_FILE;
            break;
       case EBADF:
            eResult = AO_ERROR_BAD_FILE_DESCRIPTOR;
            break;
       case EINTR:
            eResult = AO_ERROR_INTR_BY_SIGNAL;  
            break;
       case EIO:
            eResult = AO_ERROR_FILE_IO;
            break;
       case EPIPE:
       case ESPIPE:
            eResult = AO_ERROR_FILE_PIPE; 
            break;
       case EOVERFLOW:
            eResult = AO_ERROR_FILE_OFFSET; 
            break;
        default:          
            eResult = AO_ERROR_FAILURE;
            break;
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Get detailed AOSAL error code when AO_ERROR_SYSTEM_ERROR is
    received.

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOGetSystemError
(
    void
)
{
    return AOMapError(errno);
}

