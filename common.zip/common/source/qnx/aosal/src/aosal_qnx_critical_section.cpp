/**================================================================================================

@file
  aosal_qnx_critical_section.cpp

@brief
   This file implements a utility class that can be used to synchronize access to data in
   multi-thread environment

Copyright (c) 2021-2022 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/


/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#include <pthread.h>
#include "aosal_malloc.h"
#include "aosal_critical_section.h"
#include "aosal_error.h"
#include "aosal_debug_msg.h"
#include "aosal_qnx_utils.h"


/**================================================================================================
** Constant and Macros
================================================================================================**/

#define AO_MAX_NUM_CRIT_SECT  (2048)

/**================================================================================================
** Typedefs
================================================================================================**/

typedef struct
{
    size_t              nSize;      /**< size of the structure */
    pthread_mutex_t     mutex;      /**< mutex */
} AOCriticalSection_t;

/**================================================================================================
** Variables
================================================================================================**/

static const void *g_pCritiSectCtxt[AO_MAX_NUM_CRIT_SECT] = { NULL };

/**================================================================================================

                        FUNCTION DEFINITIONS

================================================================================================**/


/**********************************************************************************************//**

@brief
    Creates a critical section

@param pHandle
    Pointer to the critical section handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOCriticalSectionCreate
(
    AOHandleType_t *pHandle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(pHandle))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        AOCriticalSection_t *pCs;

        pCs = (AOCriticalSection_t *) AOMalloc(sizeof(AOCriticalSection_t));

        if (NULL == pCs)
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMalloc failed");
            eResult = AO_ERROR_NO_MEM;
        }
        else
        {
            if(NULL == AOMemset(pCs, 0, sizeof(AOCriticalSection_t)))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AOMemset failed");
                eResult = AO_ERROR_FAILURE;
            }
            else if (AO_SUCCESS != AOAddPointerEntry(&g_pCritiSectCtxt[0],
                                                (void *)pCs,
                                                AO_MAX_NUM_CRIT_SECT))
            {
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Reached max number of critical section");
                AOFree(pCs);
                eResult = AO_ERROR_FAILURE;
            }
            else
            {
                pCs->nSize = sizeof(AOCriticalSection_t);

                int nErr = EOK;
                pthread_mutexattr_t attr;

                if (EOK != (nErr = pthread_mutexattr_init(&attr)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutexattr_init");
                }
                else if (EOK != (nErr = pthread_mutexattr_setrecursive(&attr,
                                                                       PTHREAD_RECURSIVE_ENABLE)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutexattr_setrecursive");
                    (void)pthread_mutexattr_destroy(&attr);
                }
                else if (EOK != (nErr = pthread_mutex_init(&pCs->mutex, &attr)))
                {
                    AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_init");
                    (void)pthread_mutexattr_destroy(&attr);
                }
                else
                {
                    *pHandle = (AOHandleType_t)pCs;

                    if(EOK != (nErr = pthread_mutexattr_destroy(&attr)))
                    {
                        AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutexattr_destroy");
                    }
                    else
                    {
                        eResult = AO_SUCCESS;
                    }
                }

                if (AO_SUCCESS != eResult)
                {
                    /* clean up during failure */
                    if(AO_SUCCESS != AORemovePointerEntry(&g_pCritiSectCtxt[0],
                                                          (void *)pCs,
                                                          AO_MAX_NUM_CRIT_SECT))
                    {
                        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "AORemovePointerEntry %p failed", pCs);
                    }

                    AOFree(pCs);
                }
            }
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Releases the resources associated with the critical section

@param handle
    The critical section handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOCriticalSectionDestroy
(
    AOHandleType_t handle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    if (AO_CHK_NULL(handle))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        if (AO_SUCCESS != AORemovePointerEntry(&g_pCritiSectCtxt[0],
                                               (void *)handle,
                                               AO_MAX_NUM_CRIT_SECT))
        {
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "Invalid handle or has been released 0x%p", handle);
            eResult = AO_ERROR_BAD_PARAMETER;
        }
        else
        {
            AOCriticalSection_t *pCs = (AOCriticalSection_t *)handle;

            int nErr = EOK;

            if(EOK != (nErr = pthread_mutex_destroy(&pCs->mutex)))
            {
                AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_destroy");
            }
            else
            {
                eResult = AO_SUCCESS;
            }

            AOFree(pCs);
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Enter a critical section, blocks if another thread is inside the critical 
    section until the other thread leaves the critical section.

@param handle
    The critical section handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOCriticalSectionEnter
(
    AOHandleType_t handle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    AOCriticalSection_t *pCs = (AOCriticalSection_t *)handle;

    if (AO_CHK_NULL(pCs) || AO_CHK_STRUCT_SIZE(pCs->nSize, sizeof(AOCriticalSection_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        int nErr = EOK;

        if(EOK != (nErr = pthread_mutex_lock((pthread_mutex_t*) &pCs->mutex)))
        {
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_lock");
        }
        else
        {
            eResult = AO_SUCCESS;
        }
    }

    return eResult;
}

/**********************************************************************************************//**
@brief
    Leave a critical section (releases the lock).

@param handle
    The critical section handle
 
@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOCriticalSectionLeave
(
    AOHandleType_t handle
)
{
    AOErrorCode_e eResult = AO_ERROR_FAILURE;

    AOCriticalSection_t *pCs = (AOCriticalSection_t *)handle;

    if (AO_CHK_NULL(pCs) || AO_CHK_STRUCT_SIZE(pCs->nSize, sizeof(AOCriticalSection_t)))
    {
        eResult = AO_ERROR_BAD_PARAMETER;
    }
    else
    {
        int nErr = EOK;

        if(EOK != (nErr = pthread_mutex_unlock((pthread_mutex_t*) &pCs->mutex)))
        {
            AO_MAP_PTHREAD_ERR(nErr, eResult, "pthread_mutex_unlock");
        }
        else
        {
            eResult = AO_SUCCESS;
        }
    }

    return eResult;
}
