#ifndef AOSAL_QNX_UTILS_H
#define AOSAL_QNX_UTILS_H

/**================================================================================================

@file
   aosal_qnx_utils.h

@brief
   This file includes utility functions used by AOSAL

Copyright (c) 2021-2022 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/
#include <pthread.h>
#include <string.h>
#include "AEEStdDef.h"
#include "aosal_debug_msg.h"
#include "aosal_error.h"

/**================================================================================================
** Constant and Macros
================================================================================================**/

#ifndef EOK
#define EOK 0
#endif

inline boolean AO_CHECK_NULL_INLINE(const void* ptr, const char * pFunc, const char *pCaller)
{
    boolean bRet = FALSE;
    if (NULL == ptr)
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "%s:%s is NULL", pFunc, pCaller);
        bRet = TRUE;
    }
    return bRet;
}

inline boolean AO_CHK_STRUCT_SIZE_INLINE
(
    size_t      nSize,
    size_t      nSizeToMatch,
    const char  *pFunc,
    const char  *pCaller
)
{
    boolean bRet = FALSE;
    if (nSize != nSizeToMatch)
    {
        AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "%s:%s size mismatch %zu expected: %zu",
               pFunc, pCaller, nSize, nSizeToMatch);
        bRet = TRUE;
    }
    return bRet;
}

#define  AO_CHK_NULL(ptr)   AO_CHECK_NULL_INLINE((const void*)(ptr), __FUNCTION__, #ptr)

#define  AO_CHK_STRUCT_SIZE(nSize, nSizeToMatch)  \
         AO_CHK_STRUCT_SIZE_INLINE((nSize), (nSizeToMatch), __FUNCTION__, #nSize)

#define  AO_LOG_PTHREAD_ERR(nErr, str)                                                          \
            AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "%s failed (%s)", (str), strerror(nErr));         \

#define  AO_MAP_PTHREAD_ERR(nErr, eResult, str)                                                 \
            {                                                                                   \
                (eResult) = AOMapError(nErr);                                                   \
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "%s failed (%s)", (str), strerror(nErr));     \
            }

#define  AO_MAP_PTHREAD_ERR_IF_FAILED(nErr, eResult, str)                                       \
            if (EOK != (nErr))                                                                  \
            {                                                                                   \
                (eResult) = AOMapError(nErr);                                                   \
                AO_MSG(AO_GENERAL, AO_PRIO_ERROR, "%s failed (%s)", (str), strerror(nErr));     \
            }

#define  AO_MSEC_TO_NSEC(nMilliSeconds)   ((nMilliSeconds) * 1000ULL * 1000ULL)

#ifdef __cplusplus
extern "C" {
#endif

/**********************************************************************************************//**
@brief
    Unlock pthread mutex at thread exit for clean up. This function was
    registered at pthread_cleanup_push.

@param  pMutex
    pthread mutex handle

@return
    void
**************************************************************************************************/
void AOUnlockPthreadMutex
(
    void *pMutex
);

/**********************************************************************************************//**
@brief
    Add a pointer into an array of pointers. The purpose is to protect the dynamically
    allocated memory pointers (e.g., context memory) and avoid free an already freed handle.

    Note: the array of pointers is allocated by the caller

@param ppEntryStart
    Pointer to an array of pointers

@param pPointerToAdd
    Pointer to be added into the array

@param nNumEntries
    Number of entries of the pointer array

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AOAddPointerEntry
(
    const void  **ppEntryStart,
    const void  *pPointerToAdd,
    uint32_t    nNumEntries
);

/**********************************************************************************************//**
@brief
    Remove a pointer from an array of pointers. The purpose is to protect the
    dynamically allocated memory pointers (e.g., context memory) and avoid free
    an already freed handle.

    Note: the array of pointers is allocated by the caller

@param ppEntryStart
    Pointer to an array of pointers

@param pPointerToRemove
    Pointer to be removed from the array

@param nNumEntries
    Number of entries of the pointer array

@return
    Error code defined in AOErrorCode_e
**************************************************************************************************/
AOErrorCode_e AORemovePointerEntry
(
    const void  **ppEntryStart,
    const void  *pPointerToRemove,
    uint32_t    nNumEntries
);

/**********************************************************************************************//**
@brief
    Map QNX error codes to AOSAL error codes

@param nErr
    QNX error code

@return
    AOSAL error code
**************************************************************************************************/
AOErrorCode_e AOMapError
(
    int32_t     nErr
);

#ifdef __cplusplus
}
#endif

#endif //AOSAL_QNX_UTILS_H


