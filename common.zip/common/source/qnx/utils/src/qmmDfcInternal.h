#ifndef __QMM_DFC_INTERNAL_H__
#define __QMM_DFC_INTERNAL_H__
/*========================================================================

*//** @file qmmDfcInternal.h

@par FILE SERVICES:
      This file contains deferred function call interface.

@par DESCRIPTION:

   User defined function which has generic event handling can be
   queueud into this utility library.

   Typical usage will be event handlers and light duty thread offloading
   It is recommended that applications run a dedicated thread when the
   processing heavy and function arguments have implicit payloads.




@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2010-2014 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/utils/src/qmmDfcInternal.h#1 $

when       who     what, where, why
--------   ---     -------------------------------------------------------
01/15/14   dp      Add missing extern "C" ifdef
11/08/10   zm      Define default QDFC queue size.
03/18/10   dm      Fixed compilation issue.
03/05/10   srk     Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include<qmmList.h>

/*==========================================================================
                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */

#define QDFC_MAX_ARG_LIST  6

#define QDFC_QUEUE_DEPTH_DEFAULT  256

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

/**
 *
 * Following stucture holds the linked list information.
 *
 */
typedef struct
{
   qfc_Arg6FpType          pfFuncPtr; /**<
                                      * Function pointer with matching
                                      * signature for number of arguments.
                                      */
   unsigned int            nNumArgs; /**<
                                    * Pointer to first element of the
                                    * list i.e. Start of the list.
                                    */
   QDFC_ArgType            nArgList[ QDFC_MAX_ARG_LIST ]; /**
                                                         *
                                                         * List of arguments
                                                                * filled upto
                                                         *  nNumArgs. This is
                                                         * used as a data
                                                         * type for queueing
                                                         * functions
                                                                         * deferent into DFC
                                                                         */
} QDFC_QueuePayloadType;


typedef enum
{
  QDFC_DFC_EXEC,
  QDFC_EXIT,

} QDFC_CommandType;


typedef struct
{
  QMM_ListLinkType           sListLink;
  QDFC_CommandType           eCmd;
  union
  {
    QDFC_QueuePayloadType      dfc;
  } payload;

} qdfc_ItemType;


typedef struct
{

  QMM_ListHandleType FreeList;
  QMM_ListHandleType dfcList;
  MM_HANDLE          hCritSect;
  QDFC_BooleanType   bDeIniting;
  MM_HANDLE          hdfcThread;
  MM_HANDLE          hSignal;
  MM_HANDLE          hSignalQ;

} qdfc_ContextType;



#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */

#endif /* __QMM_DFC_INTERNAL_H__ */

