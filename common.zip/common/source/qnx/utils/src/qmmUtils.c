/*========================================================================

*//** @file qmmUtils.c

@par DESCRIPTION:

   Contains mm utilities


@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2012-2017 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/utils/src/qmmUtils.c#1 $

when       who     what, where, why
--------   ---     -------------------------------------------------------
01/17/17   rz      Fix compilation warning with printf format check
02/18/16   hl      add 8096 support
02/11/14   dp      Replace snprintf with std_strlprintf
10/01/13   uc      Added an entry for "MSM8230" in the 'asicInfo' table.
09/23/13   uc      Added AEEstd.h to remove warnings.
07/15/13   uc      Use std typedefs.
06/25/13   am      Add 8064 support.
02/07/13   mg      Change asic name from 8930 to 8x30
01/21/13   am      Search for 8960AB before 8960 for asic detection.
01/02/13   dp      Modified GetAsicType function to print correct error message.
12/13/12   am      Change from 8x30 to 8930
12/13/12   jl      Added qmmUtil_GetAsicType() and made qmmUtil_LoadLib()
                   multi-thread safe
12/03/12   dp      Add meaningful error message.
11/06/12   sk      Added mode for opening library
11/01/12   sk      Created file.

========================================================================= */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
#include <errno.h>
#include <sys/utsname.h>
#include "AEEstd.h" /* std typedefs, ie. byte, uint16, uint32, etc. and memcpy, memset */

#include "qmmUtils.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

static const QMM_AsicInfo asicInfo[] =
{
   {"MSM8960AB", "asic_AF", "asic_8960AB", ASIC_TYPE_8960AB},
   {"MSM8960",   "asic_AF", "asic_8960",   ASIC_TYPE_8960  },
   {"MSM8930",   "asic_AF", "asic_8x30",   ASIC_TYPE_8930  },
   {"MSM8230",   "asic_AF", "asic_8x30",   ASIC_TYPE_8230  },
   {"MSM8974",   "asic_BF", "asic_8974",   ASIC_TYPE_8974  },
   {"APQ8064",   "asic_AF", "asic_8064",   ASIC_TYPE_8064  },
   {"APQ8096",   "asic_BF", "asic_8096",   ASIC_TYPE_8096  },
};

#define QMM_MAX_MACHINE (sizeof(asicInfo) / sizeof(QMM_AsicInfo))


/*==========================================================================

         FUNCTION:      qmmUtil_LoadLib

         DESCRIPTION:
*//**       This function will load asic specific lib

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out]
*//**       @param[in]  inlibName : Name of the lib without asic
*//**       @param[in]  modeVal   : Value of mode for relocation/visibility

**//*     RETURN VALUE:
*//**       @return  : Returns hLib of the opened library or
                               NULL in case of an error

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void* qmmUtil_LoadLib(const char* inlibName, int modeVal)
{
   void* hLib = NULL;
   char libName[64];

   int            nIdx = -1;
   int            nRet;
   int            nErrValue;
   struct utsname sysinfo;

   errno = EOK;
   nRet = uname( &sysinfo );
   nErrValue = errno;

   if ( 0 == nRet )
   {
      for (nIdx = 0; nIdx < QMM_MAX_MACHINE; nIdx++)
      {
         if ( NULL != std_strstr(sysinfo.machine, asicInfo[nIdx].machineName) )
         {
            break;
         }
      }

      // FIXME: uname does not return machine Name there temp hack!!!
      if (QMM_MAX_MACHINE == nIdx)
      {
          nIdx = QMM_MAX_MACHINE-1;
      }
   }
   else
   {
      char* pErrorStr = NULL;

      pErrorStr = strerror( nErrValue );
      QMM_UTILS_MSG("qmmUtil_LoadLib: uname failed with error: %s", pErrorStr);
   }

   if ( ( QMM_MAX_MACHINE == nIdx ) || ( -1 == nIdx ) )
   {
      QMM_UTILS_MSG("qmmUtil_LoadLib: unknown machine name");
   }
   else
   {
      QMM_UTILS_MSG("qmmUtil_LoadLib: machineName:%s familyName:%s asicName:%s",
            asicInfo[nIdx].machineName,
            asicInfo[nIdx].familyName,
            asicInfo[nIdx].asicName);

      /* Trying the asic specific lib first */
      std_strlprintf(libName, sizeof(libName), (char*)"lib%s_%s.so", inlibName, asicInfo[nIdx].asicName);
      QMM_UTILS_MSG("qmmUtil_LoadLib: load %s", libName);
      hLib = dlopen(libName, modeVal);
      if ( NULL == hLib )
      {
         /* Trying the family specific lib */
         std_strlprintf(libName, sizeof(libName), (char*)"lib%s_%s.so", inlibName, asicInfo[nIdx].familyName);
         QMM_UTILS_MSG("qmmUtil_LoadLib: load %s", libName);
         hLib = dlopen(libName, modeVal);
         if ( NULL == hLib )
         {
            /* Trying the family common lib */
            std_strlprintf(libName, sizeof(libName), (char*)"lib%s.so", inlibName);
            QMM_UTILS_MSG("qmmUtil_LoadLib: load %s", libName);
            hLib = dlopen(libName, modeVal);
            if ( NULL == hLib )
            {
               char *dl_error = NULL;

               dl_error = dlerror();
               QMM_UTILS_MSG("qmmUtil_LoadLib: Failed to load %s lib %s !!", libName, dl_error);
            }
            else
            {
               QMM_UTILS_MSG("qmmUtil_LoadLib: Loaded %s mode %d", libName, modeVal);
            }
         }
         else
         {
            QMM_UTILS_MSG("qmmUtil_LoadLib: Loaded %s mode %d", libName, modeVal);
         }
      }
      else
      {
         QMM_UTILS_MSG("qmmUtil_LoadLib: Loaded %s mode %d", libName, modeVal);
      }
   }
   return hLib;
}

/*==========================================================================

         FUNCTION:      qmmUtil_LoadLib_Ex

         DESCRIPTION:
*//**       This function will load lib with a specfic library name without
            searching through platform-specific suffix

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out]
*//**       @param[in]  inlibName : Name of the lib without asic
*//**       @param[in]  modeVal   : Value of mode for relocation/visibility

**//*     RETURN VALUE:
*//**       @return  : Returns hLib of the opened library or
                               NULL in case of an error

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void* qmmUtil_LoadLib_Ex(const char* inlibName, int modeVal)
{
   void* hLib = NULL;
   hLib = dlopen(inlibName, modeVal);

   if ( NULL == hLib )
   {
      QMM_UTILS_MSG("qmmUtil_LoadLib: Loaded %s mode %d failed", inlibName, modeVal);
   }
   else
   {
      QMM_UTILS_MSG("qmmUtil_LoadLib: Loaded %s mode %d", inlibName, modeVal);
   }

   return hLib;
}

/*==========================================================================

         FUNCTION:      qmmUtil_UnloadLib

         DESCRIPTION:
*//**       This function will unload asic specific lib

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out]
*//**       @param[in]  inlibName : Name of the lib without asic

**//*     RETURN VALUE:
*//**       @return  : Returns 0 for success OR 1 for failure

@par     SIDE EFFECTS:
                        None

===========================================================================*/
int qmmUtil_UnloadLib(void* hLib)
{
   int nRet = 0;

   if ( NULL != hLib )
   {
      if ( dlclose(hLib) )
      {
         char *dl_error = NULL;

         dl_error = dlerror();
         QMM_UTILS_MSG("qmmUtil_UnloadLib: dlclose failed %s", dl_error);
         nRet = 1;
      }
   }
   return nRet;
}

/*==========================================================================

         FUNCTION:      qmmUtil_MapLibSym

         DESCRIPTION:
*//**       This function will get the address of a symbl in shared lib

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out]
*//**       @param[in]  hLib : Handle of prev opened lib
*//**       @param[in]  symbName : Name of symbol, for which address is needed

**//*     RETURN VALUE:
*//**       @return  : Returns address of the mapped symbol or
                               NULL in case of an error

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void* qmmUtil_MapLibSym(void* hLib, const char * symbName)
{
   void *hSym = NULL;

   if ( ( NULL == hLib ) || ( NULL == symbName ) )
   {
      QMM_UTILS_MSG("qmmUtil_MapLibSym: NULL hLib/symbName");
   }
   else
   {
      hSym = dlsym(hLib,symbName);
      if ( NULL == hSym )
      {
         char *dl_error = NULL;

         dl_error = dlerror();
         QMM_UTILS_MSG("qmmUtil_MapLibSym: dlsym failed %s", dl_error);
      }
   }
   return hSym;
}

/*==========================================================================

         FUNCTION:      qmmUtil_GetAsicType

         DESCRIPTION:
*//**       This function returns an ASIC type of the target. It loops
            through to find machine name in the table that matches the
            machine name from uname() read from target

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**          None

**//*     RETURN VALUE:
*//**       @return  : ASIC type or -1 if ASIC type is not found

@par     SIDE EFFECTS:
               None

===========================================================================*/
int qmmUtil_GetAsicType( void )
{
   int            nRet;
   int            nIdx;
   struct utsname sysinfo;
   int            nErrValue;
   int            nAsicType = -1;

   errno = EOK;
   nRet = uname( &sysinfo );
   nErrValue = errno;

   if ( 0 == nRet )
   {
      /* Loop through the machine table to find machine name that matches the
       * machine name from uname of the given target */
      for (nIdx = 0; nIdx < QMM_MAX_MACHINE; nIdx++)
      {
         if ( NULL != std_strstr(sysinfo.machine, asicInfo[nIdx].machineName) )
         {
            nAsicType = asicInfo[nIdx].asicType;
            break;
         }
      }

      // FIXME: uname to add machine info
      if (-1 == nAsicType)
      {
         nAsicType = ASIC_TYPE_8096;
      }
   }
   else
   {
      char* pErrorStr = NULL;

      pErrorStr = strerror( nErrValue );
      QMM_UTILS_MSG("qmmUtil_GetAsicType: uname failed with error: %s", pErrorStr);
   }
   return nAsicType;
}
