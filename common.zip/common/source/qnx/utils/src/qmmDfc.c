/*========================================================================

*//** @file qmmDfc.c

@par FILE SERVICES:
      This file contains deferred function call interface.

@par DESCRIPTION:

   User defined function which has generic event handling can be
   queueud into this utility library.

   Typical usage will be event handlers and light duty thread offloading
   It is recommended that applications run a dedicated thread when the
   processing heavy and function arguments have implicit payloads.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2010-2014 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/utils/src/qmmDfc.c#1 $

when       who     what, where, why
--------   ---     -------------------------------------------------------
01/28/14   dp      Use AEEstd lib and NULL out pointers after free.
11/08/10   zm      Set default QDFC queue size.
09/01/10   zm      QDFC uses the MMOSAL defined thread priority.
07/26/10   zm      Fix a Klockwork error.
06/29/10   zm      Change QDFC thread priority to 158.
04/16/10   dm      Fixed list push issue.
04/12/10   dm      Fixed deadlock issue.
04/12/10   dm      Increased stack size to 8 Kb.
03/30/10   dm      Increased stack size.
03/19/10   dm      Increased thread priority.
03/18/10   dm      Fixed compilation issue.
03/05/10   srk     Created file.

========================================================================= */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include <pthread.h>
#include "MMSignal.h"
#include "MMCriticalSection.h"
#include "MMThread.h"
#include "qmmDfcApi.h"
#include "qmmDfcInternal.h"

#include "qmmUtils.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */
#define  QDFC_THREAD_PRIORITY          (MM_Thread_DefaultPriority)
#define  QDFC_THREAD_STACK_SIZE        (8192)

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */
static qdfc_ContextType *hSharedDfc = NULL;
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
static unsigned int qdfcRefCnt = 0;

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
**                 FUNCTION DECLARATIONS
** ----------------------------------------------------------------------- */
static int qdfc_Thread( void * );
static void qdfc_DeallocContext( qdfc_ContextType *pCtx );
void qdfc_CleanupListElems(  QMM_ListHandleType *pList );

/*===========================================================================

                        FUNCTION DEFINITIONS

===========================================================================*/

/*==========================================================================

         FUNCTION:      qdfc_Init

         DESCRIPTION:
*//**       This function will initiazes a DFC instance for application use.
         A handle to a DFC instance is returned on successful created of DFC.


@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out] hDFC     - Pointer to the list object.
*//**       @param[in]  pConfig  - A pointer to DFC configuration
                                   structure.

**//*     RETURN VALUE:
*//**       @return     QDFC Error code

@par     SIDE EFFECTS:
                        None

===========================================================================*/
QDFC_ErrorType qdfc_Init
(
   QDFC_HandleType  *hDFC,
   QDFC_ConfigType  *pConfig
)
{
   qdfc_ContextType  *pDfcContext = NULL;
   qdfc_ItemType     *pFreeItem = ( qdfc_ItemType * ) NULL;
   QDFC_ErrorType    eRetVal = QDFC_ERROR_NONE;
/*-------------------------------------------------------------------------*/

   if ( ( NULL == pConfig ) || ( NULL == hDFC ) )
   {
      return( QDFC_ERROR_BAD_PARM );
   }

   pthread_mutex_lock(&mutex);

   if ( TRUE == pConfig->sharedThread )
   {
      if ( NULL != hSharedDfc )
      {
         /*---------------------------------------------------------------------
           Increment the ref count if we are implementing a singleton
         ---------------------------------------------------------------------*/
         *hDFC = ( QDFC_HandleType ) hSharedDfc;

         qdfcRefCnt++;
         pthread_mutex_unlock(&mutex);
         return( QDFC_ERROR_NONE );
      }
   }

   /*-------------------------------------------------------------------------
     Here after every allocation has to be carefully listed so we free when
     something here are the list so far

     1) Memory for context
     2) Critical Section
     3) Singal
     4) Singal queue
     5) List
     6) List Element allocation
     7) Thread
   -------------------------------------------------------------------------*/
   pDfcContext = ( qdfc_ContextType * ) QMM_UTILS_Malloc(
                                          sizeof( qdfc_ContextType ) );

   if ( NULL == pDfcContext )
   {
      eRetVal = QDFC_ERROR_NORESOURCES;
   }
   else
   {
      QMM_UTILS_MEMSET( pDfcContext, 0, sizeof( qdfc_ContextType ) );
   }

   if ( ( QDFC_ERROR_NONE == eRetVal ) &&
        ( 0 != MM_CriticalSection_Create( &pDfcContext->hCritSect ) ) )
   {
      QMM_UTILS_FreeIf( pDfcContext );
      eRetVal = QDFC_ERROR_NORESOURCES;
   }

   if ( ( QDFC_ERROR_NONE == eRetVal ) &&
        ( 0 != MM_SignalQ_Create ( &pDfcContext->hSignalQ ) ) )
   {
      MM_CriticalSection_Release( pDfcContext->hCritSect );
      QMM_UTILS_FreeIf( pDfcContext );
      eRetVal = QDFC_ERROR_NORESOURCES;
   }

   if ( ( QDFC_ERROR_NONE == eRetVal ) &&
        ( 0 != MM_Signal_Create( pDfcContext->hSignalQ,
                                 ( void * ) NULL,
                                 ( void (*)( void * ) ) NULL,
                                 &pDfcContext->hSignal ) ) )
   {
      MM_CriticalSection_Release( pDfcContext->hCritSect );
      MM_SignalQ_Release( pDfcContext->hSignalQ );
      QMM_UTILS_FreeIf( pDfcContext );
      eRetVal =  QDFC_ERROR_NORESOURCES;
   }

   if ( ( QDFC_ERROR_NONE == eRetVal ) &&
        ( QMM_LIST_ERROR_NONE != qmm_ListInit( &pDfcContext->FreeList ) ) )
   {
      MM_CriticalSection_Release( pDfcContext->hCritSect );
      MM_SignalQ_Release( pDfcContext->hSignalQ );
      MM_Signal_Release( pDfcContext->hSignal );
      QMM_UTILS_FreeIf( pDfcContext );
      eRetVal =  QDFC_ERROR_NORESOURCES;
   }

   if ( ( QDFC_ERROR_NONE == eRetVal )  &&
        ( QMM_LIST_ERROR_NONE != qmm_ListInit( &pDfcContext->dfcList ) ) )
   {
      qmm_ListDeInit( &pDfcContext->FreeList );
      MM_CriticalSection_Release( pDfcContext->hCritSect );
      MM_SignalQ_Release( pDfcContext->hSignalQ );
      MM_Signal_Release( pDfcContext->hSignal );
      QMM_UTILS_FreeIf( pDfcContext );
      eRetVal =  QDFC_ERROR_NORESOURCES;
   }

   if ( QDFC_ERROR_NONE == eRetVal )
   {
      unsigned int nQueDepth = pConfig->nQueDepth;
      unsigned int i;

      /*--------------------------------------------------------------------
        For shared QDFC, if the queue size is lower than the default size,
        use the default size to initialize queue.
        --------------------------------------------------------------------*/
      if ( ( TRUE == pConfig->sharedThread ) &&
           ( pConfig->nQueDepth < QDFC_QUEUE_DEPTH_DEFAULT ) )
      {
         nQueDepth = QDFC_QUEUE_DEPTH_DEFAULT;
      }

      for ( i = 0; i < nQueDepth; i++ )
      {
         /*------------------------------------------------------------------
           Allocate and initialize the entire array into the free list
           ------------------------------------------------------------------*/
         pFreeItem = QMM_UTILS_Malloc( sizeof( qdfc_ItemType ) );

         if ( NULL == pFreeItem )
         {
            MM_SignalQ_Release( pDfcContext->hSignalQ );
            MM_Signal_Release( pDfcContext->hSignal );
            qdfc_CleanupListElems( &pDfcContext->FreeList );
            qmm_ListDeInit( &pDfcContext->FreeList );
            qmm_ListDeInit( &pDfcContext->dfcList );
            MM_CriticalSection_Release( pDfcContext->hCritSect );
            QMM_UTILS_FreeIf( pDfcContext );
            eRetVal = QDFC_ERROR_NORESOURCES;
            break;
         }

         qmm_ListPushFront( &pDfcContext->FreeList,
                            ( QMM_ListLinkType * ) pFreeItem );
      } /* end of for i = 0*/

   } /* end of if ERROR_NONE */

   /*-------------------------------------------------------------------------
     Create a thread and pass the context pointer as argument
     -------------------------------------------------------------------------*/
   if ( QDFC_ERROR_NONE == eRetVal )
   {
      if ( 0 != MM_Thread_CreateEx( QDFC_THREAD_PRIORITY,
                                    0,
                                    qdfc_Thread,
                                    pDfcContext,
                                    QDFC_THREAD_STACK_SIZE,
                                    "qdfc",
                                    &pDfcContext->hdfcThread ) )
      {
         MM_SignalQ_Release( pDfcContext->hSignalQ );
         MM_Signal_Release( pDfcContext->hSignal );
         qdfc_CleanupListElems( &pDfcContext->FreeList );
         qmm_ListDeInit( &pDfcContext->FreeList );
         qmm_ListDeInit( &pDfcContext->dfcList );
         MM_CriticalSection_Release( pDfcContext->hCritSect );
         QMM_UTILS_FreeIf( pDfcContext );
         eRetVal = QDFC_ERROR_NORESOURCES;
      }
   }

   if ( ( QDFC_ERROR_NONE == eRetVal ) &&
        ( TRUE == pConfig->sharedThread ) )
   {
      hSharedDfc = pDfcContext;
      qdfcRefCnt = 1;
   }

   if ( QDFC_ERROR_NONE == eRetVal )
   {
      *hDFC = ( QDFC_HandleType ) pDfcContext;
   }

   pthread_mutex_unlock(&mutex);

   return( eRetVal );

} /* enc of qdfc_Init */


/*==========================================================================

         FUNCTION:      qdfc_EnqueueArg6Function

         DESCRIPTION:
*//**       This function will queue a deferred fucntion call to the DFC
            instace passed as the argument. This function is dedicated to
            queueing multiple argument functions up to 6 arguements. In the
            case of function which requires less than 6 arguments this
            function be used as long as the remainaing aruments are ignored
            when the API is called asynchronously.


@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[in]  hDfc              - handle to a valid DFC.
            @param[in]  pfDeferredFunc    - function pointer of matching
                                            signature in this case function
                                            should be taking one argument
                                            unsigned int
            @param[in]  nArg1             - Argument 1 to be passed when the
                                            deferred function is called. If
                                            this is a pointer use cuation.
                                            Any stack variable will
                                            no maintain its value while dfc
                                            calls it. In general some generic
                                            event code or some preallocate
                                            memory us ownership is
                                            transferred to callee should be
                                            used.

            @param[in]  nArg2             - Argument 2 to be passed when the
                                            deferred function is called. If
                                            this is a pointer use cuation.
                                            Any stack variable will
                                            no maintain its value while dfc
                                            calls it. In general some generic
                                            event code or some preallocate
                                            memory us ownership is
                                            transferred to callee should be
                                            used.
            @param[in]  nArg3             - Argument 3 to be passed when the
                                            deferred function is called. If
                                            this is a pointer use cuation.
                                            Any stack variable will
                                            no maintain its value while dfc
                                            calls it. In general some generic
                                            event code or some preallocate
                                            memory us ownership is
                                            transferred to callee should be
                                            used.
            @param[in]  nArg4             - Argument 4 to be passed when the
                                            deferred function is called. If
                                            this is a pointer use cuation.
                                            Any stack variable will
                                            no maintain its value while dfc
                                            calls it. In general some generic
                                            event code or some preallocate
                                            memory us ownership is
                                            transferred to callee should be
                                            used.

**//*     RETURN VALUE:
*//**       @return    QDFC Error code

@par     SIDE EFFECTS:
                        None

===========================================================================*/
QDFC_ErrorType qdfc_EnqueueArg6Function
(
   QDFC_HandleType   hDfc,
   qfc_Arg6FpType    pfDeferredFunc,
   QDFC_ArgType      nArg1,
   QDFC_ArgType      nArg2,
   QDFC_ArgType      nArg3,
   QDFC_ArgType      nArg4,
   QDFC_ArgType      nArg5,
   QDFC_ArgType      nArg6
)
{
   qdfc_ContextType  *pCtx = ( qdfc_ContextType * ) hDfc;
   qdfc_ItemType     *pListItem = NULL;
   QDFC_ErrorType    eRetVal = QDFC_ERROR_NONE;
/*-------------------------------------------------------------------------*/

   if ( ( NULL == hDfc ) || ( NULL == pfDeferredFunc ) )
   {
      return ( QDFC_ERROR_BAD_PARM  );
   }
   /*-------------------------------------------------------------------------
     Lock the context and then pop get an Item pointer
     -------------------------------------------------------------------------*/
   else if ( 0 != MM_CriticalSection_Enter( pCtx->hCritSect ) )
   {
      eRetVal = QDFC_ERROR_CORRUPTION;
   }

   if ( pCtx->bDeIniting )
   {
      eRetVal = QDFC_ERROR_BAD_PARM;
   }
   else if ( QDFC_ERROR_NONE != (QDFC_ErrorType) qmm_ListPopFront( &pCtx->FreeList,
                                                                   ( QMM_ListLinkType ** ) &pListItem ) )
   {
      eRetVal = QDFC_ERROR_NORESOURCES;
   }
   else if ( NULL == pListItem )
   {
      eRetVal = QDFC_ERROR_NORESOURCES;
   }
   else
   {
      /*---------------------------------------------------------------------
        Populate the command
        -----------------------------------------------------------------------*/
      pListItem->eCmd = QDFC_DFC_EXEC;
      pListItem->payload.dfc.pfFuncPtr = pfDeferredFunc;
      pListItem->payload.dfc.nNumArgs = QDFC_MAX_ARG_LIST;
      pListItem->payload.dfc.nArgList[ 0 ] = nArg1;
      pListItem->payload.dfc.nArgList[ 1 ] = nArg2;
      pListItem->payload.dfc.nArgList[ 2 ] = nArg3;
      pListItem->payload.dfc.nArgList[ 3 ] = nArg4;
      pListItem->payload.dfc.nArgList[ 4 ] = nArg5;
      pListItem->payload.dfc.nArgList[ 5 ] = nArg6;

      /*-----------------------------------------------------------------------
        Push the command into Command queue
        -----------------------------------------------------------------------*/
      if ( QMM_LIST_ERROR_NONE != qmm_ListPushFront( &pCtx->dfcList,
                                                     (QMM_ListLinkType * ) pListItem ) )
      {
         eRetVal = QDFC_ERROR_CORRUPTION;
      }
   }

   /*-------------------------------------------------------------------------
     Unlock the context
     -------------------------------------------------------------------------*/
   if ( 0 != MM_CriticalSection_Leave( pCtx->hCritSect ) )
   {
      eRetVal = QDFC_ERROR_CORRUPTION;
   }

   if ( QDFC_ERROR_NONE == eRetVal )
   {
      /*-----------------------------------------------------------------------
        Set the signal to the thread so it can wake up
        -----------------------------------------------------------------------*/
      if ( 0 != MM_Signal_Set( pCtx->hSignal ) )
      {
         eRetVal = QDFC_ERROR_CORRUPTION;
      }
   }

   return( eRetVal );

} /* end of function qdfc_EnqueueArg6Function */


/*==========================================================================

         FUNCTION:      qmm_DeInit

         DESCRIPTION:
*//**       This function will de-initialize the given dfc instance.

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[in]  hDfc - Handle to DFC queue which is previously
                               initialized.

**//*     RETURN VALUE:
*//**       @return     QDFC Error code

@par     SIDE EFFECTS:
                        None

===========================================================================*/
QDFC_ErrorType qdfc_DeInit
(
   QDFC_HandleType  hDfc
)
{
   qdfc_ContextType  *pCtx = ( qdfc_ContextType * ) hDfc;
   qdfc_ItemType     *pListItem = NULL;
   QDFC_ErrorType    eRetVal = QDFC_ERROR_NONE;
   int               nExitCode;
/*-------------------------------------------------------------------------*/

   if ( NULL == hDfc )
   {
      return ( QDFC_ERROR_BAD_PARM );
   }

   pthread_mutex_lock(&mutex);
   if ( pCtx == hSharedDfc )
   {
      qdfcRefCnt--;
      if ( qdfcRefCnt > 0 )
      {
         pthread_mutex_unlock(&mutex);
         return( eRetVal );
      }
      hSharedDfc = NULL;
   }
   pthread_mutex_unlock(&mutex);

   /*-------------------------------------------------------------------------
     Lock the context and then pop get an Item pointer
     -------------------------------------------------------------------------*/
   if ( 0 != MM_CriticalSection_Enter( pCtx->hCritSect ) )
   {
      eRetVal = QDFC_ERROR_CORRUPTION;
   }
   else if ( pCtx->bDeIniting )
   {
      eRetVal = QDFC_ERROR_BAD_PARM;
      MM_CriticalSection_Leave( pCtx->hCritSect );
      return( eRetVal );
   }

   pCtx->bDeIniting = TRUE;

   if ( ( QDFC_ERROR_NONE == eRetVal ) &&
        ( QDFC_ERROR_NONE != (QDFC_ErrorType) qmm_ListPopFront( &pCtx->FreeList,
                                                                ( QMM_ListLinkType ** ) &pListItem ) ) )
   {
      /*-----------------------------------------------------------------------
        TODO
        Deinit should never fail so we need to tackle this situation better
        -----------------------------------------------------------------------*/
      eRetVal = QDFC_ERROR_NORESOURCES;
   }
   else if ( NULL == pListItem )
   {
      eRetVal = QDFC_ERROR_CORRUPTION;
   }
   else
   {
      /*--------------------------------------------------------------------
        Populate the command
        ----------------------------------------------------------------------*/
      pListItem->eCmd = QDFC_EXIT;
      /*-----------------------------------------------------------------------
        Push the command into Command queue
        -----------------------------------------------------------------------*/
      if ( QMM_LIST_ERROR_NONE != qmm_ListPushFront( &pCtx->dfcList,
                                                     ( QMM_ListLinkType * ) pListItem ) )
      {
         eRetVal = QDFC_ERROR_CORRUPTION;
      }

      /*-----------------------------------------------------------------------
        Unlock the context
        -----------------------------------------------------------------------*/
      if ( 0 != MM_CriticalSection_Leave( pCtx->hCritSect ) )
      {
         eRetVal = QDFC_ERROR_CORRUPTION;
      }
      else
      {
         /*---------------------------------------------------------------------
           Set the signal to the thread so it can wake up
           ---------------------------------------------------------------------*/
         if ( 0 != MM_Signal_Set( pCtx->hSignal ) )
         {
            eRetVal = QDFC_ERROR_CORRUPTION;
         }
      }
   }

   if ( QDFC_ERROR_NONE == eRetVal )
   {
      MM_Thread_Join( pCtx->hdfcThread, &nExitCode );
      qdfc_DeallocContext( pCtx );
   }
   else
   {
      /* Denit failed log error */
   }

   return( eRetVal );

} /* end of function qdfc_DeInit */


/*==========================================================================

         FUNCTION:      qdfc_Thread

         DESCRIPTION:
*//**       This function will .

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[in]  qdfcArg - Handle to DFC queue which is previously
                                     initialized.

**//*     RETURN VALUE:
*//**       @return     Zero

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static int qdfc_Thread( void *qdfcArg )
{
   qdfc_ContextType *pdfcCtx = ( qdfc_ContextType * ) qdfcArg;
   void             *pUnused;
   qdfc_ItemType    *pCmd;
   qfc_Arg6FpType    pFp6;
   QDFC_BooleanType  bRunning = TRUE;
/*-----------------------------------------------------------------------*/

   while ( ( bRunning ) &&
           ( 0 == MM_SignalQ_Wait( pdfcCtx->hSignalQ, &pUnused ) ) )
   {
      if ( 0 != MM_CriticalSection_Enter( pdfcCtx->hCritSect ) )
      {
         break;
      }

      while ( ( bRunning ) &&
              ( QMM_LIST_ERROR_NONE == qmm_ListPopRear( &pdfcCtx->dfcList,
                                                        ( QMM_ListLinkType ** ) &pCmd ) ) &&
              ( NULL != pCmd ) )
      {
         if ( 0 != MM_CriticalSection_Leave( pdfcCtx->hCritSect ) )
         {
            break;
         }

         switch ( pCmd->eCmd )
         {
            case QDFC_DFC_EXEC :
            {
               if ( QDFC_MAX_ARG_LIST == pCmd->payload.dfc.nNumArgs )
               {
                  pFp6 = ( qfc_Arg6FpType ) pCmd->payload.dfc.pfFuncPtr;
                  pFp6( pCmd->payload.dfc.nArgList[0],
                        pCmd->payload.dfc.nArgList[1],
                        pCmd->payload.dfc.nArgList[2],
                        pCmd->payload.dfc.nArgList[3],
                        pCmd->payload.dfc.nArgList[4],
                        pCmd->payload.dfc.nArgList[5]);
               }
            }
            break;

            case QDFC_EXIT :
            {
               bRunning = FALSE;

               /*
               Push the element back in the list
               */
            }
            break;

            default:
            {
               break;
            }


         } /* end of switch */

         if ( 0 != MM_CriticalSection_Enter( pdfcCtx->hCritSect ) )
         {
            break;
         }

         qmm_ListPushFront( &pdfcCtx->FreeList,
                            ( QMM_ListLinkType * ) pCmd );


      } /* end of while */

      if ( 0 != MM_CriticalSection_Leave( pdfcCtx->hCritSect ) )
      {
         break;
      }

   }/* end of while */


   /*-------------------------------------------------------------------------
      Exit the thread when we are donr processing
   -------------------------------------------------------------------------*/
   MM_Thread_Exit( pdfcCtx->hdfcThread, 0 );

   return( 0 );

}/* end of qdfc_Thread */


/*==========================================================================

         FUNCTION:      qdfc_DeallocContext

         DESCRIPTION:
*//**       This function will de-allocate dfc context.

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[in]  pCtx  - Handle to DFC queue which is previously
                                initialized.

**//*     RETURN VALUE:
*//**       @return     None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void qdfc_DeallocContext( qdfc_ContextType *pCtx )
{
   MM_Thread_Release( pCtx->hdfcThread );
   MM_Signal_Release( pCtx->hSignal );
   MM_SignalQ_Release( pCtx->hSignalQ );

   qdfc_CleanupListElems( &pCtx->dfcList );
   qdfc_CleanupListElems( &pCtx->FreeList );

   /* deinitialize the list */
   qmm_ListDeInit( &pCtx->FreeList );
   qmm_ListDeInit( &pCtx->dfcList );

   MM_CriticalSection_Release ( pCtx->hCritSect );

   QMM_UTILS_FreeIf( pCtx );

} /* end of function qdfc_DeallocContext */


void qdfc_CleanupListElems( QMM_ListHandleType *pList )
{
   QMM_ListLinkType *pListItem;

   while ( ( QMM_LIST_ERROR_NONE == qmm_ListPopFront( pList,
                                                      &pListItem ) ) &&
           ( NULL != pListItem ) )
   {
      QMM_UTILS_FreeIf ( pListItem );
   }

} /* end of function qdfc_CleanupListElems */
