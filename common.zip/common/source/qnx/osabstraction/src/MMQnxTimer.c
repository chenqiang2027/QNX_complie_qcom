/*===========================================================================
 M M   T i m e r
 f o r   S i g n a l  Q u e u e  O b j e c t

 *//** @file MMTimer.c
 This file defines provides functions to create waitable timers.

 Copyright (c) 2008 - 2019, 2021 QUALCOMM Technologies Incorporated.
 All Rights Reserved. Qualcomm Proprietary and Confidential.
 *//*========================================================================*/

/*===========================================================================
 Edit History

 $Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/osabstraction/src/MMQnxTimer.c#1 $

 when       who         what, where, why
 --------   ---         -------------------------------------------------------
 08/02/21   xg          Fix mutex deadlock between timer dispatcher and timer release(propagation from gen3)
 04/04/19   jz          Use 64 bit pointer instead of 32 bit variable to store address as it will be truncated if enable ASLR
 01/02/18   rz          Fix MISRA warning
 01/12/17   rz          Fix compilation warnings with format check
 11/18/15   wy          Adjust thread priority
 10/07/14   am          Use free running timer instead of nanospin which depends upon CPU operating frequency.
 07/17/14   rz          Port AF changes: Fix mutex deadlock between timer dispatcher and timer release.
                                         Use calling thread priority when sending exit pulse.
                                         Increment timer counter when channel is created, decrement on failure.
                                         Return error code from functions.  Error handling when memory allocation for MM_Timer fails.
                                         Double the timer thread stack size.
 03/26/14   am          Fix Klockworks warning
 03/22/14   am          Synchronize MM_Timer_Release with MM_Timer_Dispatcher thread.
 06/27/13   am          Fix error handling in MM_Timer_CreateEx()
 06/05/13   am          Fix error handling & clean up in MM_Timer_CreateEx()
 05/27/13   yzgao       Fix resource leak by doing connectDetach/ChannelDestroy in MM_Timer_Release()
 04/03/13   dwp         Insert cleanup of mutexattr
 01/25/13   yzgao       Clean up printf()/fprintf()
 01/10/12   am          Destroy MM_TimerDispatcher thread when no more timer instances.
 10/17/12   sk          Replacing nanospin with clockcycles_nanospin_ns
 04/14/12   che         timer_delete race condition issue. in rare cases, timeout pulse signal can still
                        be delivered to the timer dispatcher event after timer_delete is called.
                        This will lead to a crash since the dispatch will access released memory. Added
                        lock/unlock protectiong; added while loop to settime to 0 to disarm timer before delete.
                        Added RELEASE_PULSE_CDOE to release the timer in the MM_TimerDispatche thread
 07/02/08   gkapalli    Created file.

 ============================================================================*/

/*===========================================================================
 Include Files
 ============================================================================*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <sys/neutrino.h>
#include <errno.h>
#include <semaphore.h>
#include <signal.h>
#include <pthread.h>

#include "MMTimer.h"
#include "MMMalloc.h"
#include "MMCriticalSection.h"
#include "MMThread.h"
#include "MMError.h"
#include "MMDebugMsg.h"
#include "MMSignal.h"
#include "clockcycles_nanospin.h"

/* =======================================================================

 DEFINITIONS AND DECLARATIONS FOR MODULE

 This section contains definitions for constants, macros, types, variables
 and other items needed by this module.

 ========================================================================== */
#define CLOCKID CLOCK_MONOTONIC
#define SIG SIGRTMIN

#define TIMER_PULSE_CODE         (10)
#define EXIT_PULSE_CODE          (11)
#define RELEASE_PULSE_CODE       (12)
#define TIMEOUTVALUE             (2000)
#define TIMER_THREAD_STACK_SIZE  (16*1024)

/* -----------------------------------------------------------------------
 ** Forward declarations
 ** ----------------------------------------------------------------------- */

typedef struct _MM_Timer MM_Timer;
static int timerchid = -1;
static int coid = -1;
static pthread_t timertid = 0;
static unsigned int timercnt = 0;
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

/* -----------------------------------------------------------------------
 ** Type declarations
 ** ----------------------------------------------------------------------- */

struct _MM_Timer
{
   /*
   * timer callback handler to be invoked on timeout
   */
   void (*m_pfnTimerHandler)(void*);
   /*
   * optional user data pointer to be passed in the call  back
   */
   void *m_pvUserArg;
   /*
   * Timer handle
   */
   timer_t timerid;

   /*
   * non-zero indicates if the timer is periodic
   */
   int m_nPeriodic;

   /*
   * Signal Queue
   */
   MM_HANDLE m_SignalQ;

   /*
   * Signal for synchroninzation of MM_Timer_Release
   * with MM_Timer_Dispatcher thread.
   */
   MM_HANDLE m_Signal;

};

/* -----------------------------------------------------------------------
 ** Function declaration
 ** ----------------------------------------------------------------------- */

void MM_Timer_LongSleep( int nSeconds );

/* -----------------------------------------------------------------------
 ** Function definition
 ** ----------------------------------------------------------------------- */

static void *MM_TimerDispatcher(void *arg)
{
   int rcvid;
   struct _pulse pulse;
   void (*pfnTimeout)(void*) = NULL;
   void* pUserArg = NULL;

   pthread_setname_np(0, (char*)"MM_TimerDispatcher");
   for (;;)
   {
      rcvid = MsgReceive(timerchid, &pulse, sizeof(pulse), NULL);
      if ( 0 == rcvid )
      {
         if ( ( TIMER_PULSE_CODE == pulse.code ) &&
              ( NULL != pulse.value.sival_ptr ) )
         {
            pfnTimeout = NULL;
            pUserArg = NULL;

            MM_Timer *pTimer = (MM_Timer *) pulse.value.sival_ptr;
            if ( pTimer && pTimer->m_pfnTimerHandler )
            {
               pfnTimeout = pTimer->m_pfnTimerHandler;
               pUserArg = pTimer->m_pvUserArg;
            }

            if ( pfnTimeout )
            {
               pfnTimeout(pUserArg);
            }
         }
         
         else if ( EXIT_PULSE_CODE == pulse.code )
         {
            MM_MSG_PRIO( MM_STATS_SLOG, MM_PRIO_HIGH, "MM_TimerDispatcher():  timer dispatcher exiting" );
            break;
         }
      } // else other messages ...
      else if (rcvid > 0)
      {
         if ( RELEASE_PULSE_CODE == pulse.code )
         {
            MM_Timer *pTimer = (MM_Timer *) pulse.value.sival_ptr;
            /* Set signal to unblock MM_Timer_Release */
            if ( pTimer && pTimer->m_Signal )
            {
               if ( 0 != MM_Signal_Set( pTimer->m_Signal ) )
               {
                  MM_MSG_PRIO( MM_STATS_SLOG, MM_PRIO_ERROR, "MM_TimerDispatcher() failed to set signal when received RELEASE_PULSE_CODE" );
               }
            }
            MsgReply(rcvid, EOK, NULL, 0);
         }
      }
   }

   return 0;
}

/*
* Starts timer and returns the handle, when the timer expires the registered
* invoked
*
*
* @param[in] nTimeOut - timeout in millseconds
* @param[in] nPeriodic - a non zero value to make the timer periodic
* @param[in] pfnTimerHandler - timer callback handler to be invoked on timeout
* @param[in] pvUserArg - optional user data pointer to be passed in the callback
* @param[out] pHandle - timer callback handler to be invoked on timeout
*
* @return zero value is success else failure
*/
int MM_Timer_Create
(
   int         nTimeOut,
   int         nPeriodic,
   void(*pfnTimerHandler)(void*),
   void*       pvUserArg,
   MM_HANDLE*  pHandle
)
{
   int result = (int)MMOSAL_ERROR_INVAL;

   result = MM_Timer_CreateEx( nPeriodic, pfnTimerHandler, pvUserArg,
                               pHandle );
   if ( (int)MMOSAL_SUCCESS == result )
   {
      result = MM_Timer_Start( *pHandle, nTimeOut );
      if ( (int)MMOSAL_SUCCESS != result )
      {
         (void)MM_Timer_Release( *pHandle );
      }
      else
      {
         result = (int)MMOSAL_SUCCESS;
      }
   }
   return ( result );
}

/*
* Creates a timer and returns the handle
*
* @param[in] nPeriodic - a non zero value to make the timer periodic
* @param[in] pfnTimerHandler - timer callback handler to be invoked on timeout
* @param[in] pvUserArg - optional user data pointer to be passed in the callback
* @param[out] pHandle - timer callback handler to be invoked on timeout
*
* @return zero value is success else failure
*/
int MM_Timer_CreateEx
(
   int         nPeriodic,
   void(*pfnTimerHandler)(void*),
   void*       pvUserArg,
   MM_HANDLE*  pHandle
)
{
   struct sigevent sev;
   MM_Timer *pTimer = 0;
   int nRet = MMOSAL_SUCCESS;

   errno = EOK;

   if ( ( NULL == pHandle ) ||
        ( NULL == pfnTimerHandler ) )
   {
      MM_MSG_PRIO( MM_STATS_SLOG, MM_PRIO_ERROR,"bad input argument");
      return (int)MMOSAL_ERROR_INVAL;
   }

   pthread_mutex_lock(&mutex);
   if ( -1 == timerchid )
   {
      timerchid = ChannelCreate(0);
   }
   if ( -1 == timerchid )
   {
      nRet = MM_GetLastError();
      MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "unable to create channel - %s", strerror( errno ) );
      pthread_mutex_unlock(&mutex);
      return ( nRet );
   }

   if ( -1 == coid )
   {
      coid = ConnectAttach(0, 0, timerchid,_NTO_SIDE_CHANNEL, 0);
      if ( -1 == coid )
      {
         nRet = MM_GetLastError();
         MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "failed to attach to timer channel - %s", strerror( errno ) );
      }
   }

   if ( -1 == coid )
   {
      MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "unable to connect to timer channel - %s", strerror( errno ) );

      if (-1 == ChannelDestroy(timerchid))
      {
         MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "failed to destroy timer channel - %s", strerror( errno ) );
      }
      timerchid = -1;
      pthread_mutex_unlock(&mutex);
      return ( nRet );
   }

   if ( 0 == timertid )
   {
      pthread_attr_t attrib;
      struct sched_param params;

      pthread_attr_init(&attrib);
      pthread_attr_setstacksize(&attrib, TIMER_THREAD_STACK_SIZE );

      params.sched_priority = MM_Thread_HighPriority;
      pthread_attr_setschedparam(&attrib, &params);

      if ( EOK != pthread_create( &timertid, &attrib, MM_TimerDispatcher, NULL ) )
      {
         nRet = MM_GetLastError();

         MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR,"unable to create timer dispatch thread - %s", strerror( errno ));

         if ( -1 == ConnectDetach(coid) )
         {
            MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR,"failed to detach from timer channel - %s", strerror( errno ));
         }

         coid = -1;

         if ( -1 == ChannelDestroy(timerchid) )
         {
            MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR,"failed to destroy timer channel - %s", strerror( errno ));
         }

         timerchid = -1;

         pthread_mutex_unlock(&mutex);
         pthread_attr_destroy(&attrib);
         return ( nRet );
      }
      pthread_attr_destroy(&attrib);
   }

   timercnt++;
   pthread_mutex_unlock(&mutex);

   pTimer = MM_Malloc( sizeof(MM_Timer) );

   if ( pTimer )
   {
      int sts = 0;

      memset(pTimer, 0, sizeof(MM_Timer));
      pTimer->m_pfnTimerHandler = pfnTimerHandler;
      pTimer->m_pvUserArg = pvUserArg;
      pTimer->m_nPeriodic = nPeriodic;

      /* Create SignalQ for syncrhonizaion of Timer APIs with Timer_Dispatcher thread */
      sts = MM_SignalQ_Create(&pTimer->m_SignalQ);
      if ( 0 != sts )
      {
         nRet = MM_GetLastError();
         MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "failed to create signalQ in MM_Timer_CreateEx - %s", strerror( errno ) );
      }
      else
      {
         /* Create Signal for syncrhonizaion of Timer APIs with Timer_Dispatcher thread */
         sts = MM_Signal_Create(pTimer->m_SignalQ, NULL, NULL, &pTimer->m_Signal);
         if ( 0 != sts )
         {
            nRet = MM_GetLastError();
            MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "failed to create signal in MM_Timer_CreateEx - %s", strerror( errno ) );
         }
      }

      if ( 0 == sts )
      {
         /* Create the timer */
         sev.sigev_notify = SIGEV_PULSE;
         sev.sigev_coid = coid;
         sev.sigev_priority = MM_Thread_RealtimePriority;
         sev.sigev_code = TIMER_PULSE_CODE;
         sev.sigev_value.sival_ptr = (void *) pTimer;

         sts = timer_create(CLOCKID, &sev, &pTimer->timerid);
         if ( -1 == sts )
         {
            nRet = MM_GetLastError();
            MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "failed to create timer in MM_Timer_CreateEx - %s", strerror( errno ) );
         }
      }

      if ( 0 != sts )
      {
         MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "failed to create timer - %s", strerror( errno ) );

         pthread_mutex_lock(&mutex);
         /* Error in create timer decrement counter */
         timercnt--;

         if ( 0 == timercnt )
         {
            pthread_mutex_unlock(&mutex);

            /* kill the timer dispatch thread */
            if ( -1 == MsgSendPulse( coid, MM_Thread_CallingThreadPriority, EXIT_PULSE_CODE, 0 ) )
            {
               MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "failed to send pulse code to timerchid - %s", strerror( errno ) );
            }
            else
            {
               pthread_join(timertid, NULL);
               timertid = 0;
            }

            pthread_mutex_lock(&mutex);

            if ( -1 == ConnectDetach(coid) )
            {
               MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "failed to detach from timer channel - %s", strerror( errno ) );
            }

            coid = -1;

            if ( -1 == ChannelDestroy(timerchid) )
            {
               MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "failed to destroy timer channel - %s", strerror( errno ) );
            }

            timerchid = -1;
         }

         if ( pTimer->m_Signal )
         {
            MM_Signal_Release( pTimer->m_Signal );
         }

         if ( pTimer->m_SignalQ )
         {
            MM_SignalQ_Release( pTimer->m_SignalQ );
         }

         pthread_mutex_unlock(&mutex);
         MM_Free(pTimer);

         return ( nRet );
      }

      *pHandle = pTimer;
   }
   else
   {
      nRet = MM_GetLastError();

      // kill the timer dispatch thread
      if ( -1 == MsgSendPulse( coid, MM_Thread_CallingThreadPriority, EXIT_PULSE_CODE, 0 ) )
      {
         MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR,"failed to send pulse code to timerchid - %s", strerror( errno ) );
      }
      else
      {
         pthread_join(timertid, NULL);
         timertid = 0;
      }

      MM_MSG_PRIO( MM_STATS_SLOG, MM_PRIO_ERROR,"memory allocation for MMTimer failed" );

      pthread_mutex_lock( &mutex );

      if ( 0 == timercnt )
      {
         if ( -1  == ConnectDetach( coid ) )
         {
            MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR,"failed to detach from timer channel - %s", strerror( errno ) );
         }

         coid = -1;

         if ( -1 == timerchid )
         {
            if ( -1 == ChannelDestroy( timerchid ) )
            {
               MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR,"failed to destroy timer channel - %s", strerror( errno ) );
            }
            timerchid = -1;
         }
         else
         {
            MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR,"unable to destroy timer channel - %s", strerror( errno ) );
         }
      }

      pthread_mutex_unlock( &mutex );
   }

   return ( nRet );
}

/*
* Starts a timer created using MM_Timer_CreateEx
*
* @param[in] pHandle - handle of timer
* @param[in] nTimeOut - timeout in millseconds
*
* @return zero value is success else failure
*/
int MM_Timer_Start
(
   MM_HANDLE   handle,
   int         nTimeOut
)
{
   int result = (int)MMOSAL_SUCCESS;
   errno = EOK;

   if ( handle )
   {
      struct itimerspec its;
      MM_Timer *pTimer = (MM_Timer *) handle;


      /* Start the timer */
      its.it_value.tv_sec = nTimeOut / 1000;
      its.it_value.tv_nsec = (nTimeOut - (its.it_value.tv_sec * 1000)) * 1000000;

      if ( 0 != pTimer->m_nPeriodic )
      {
         its.it_interval.tv_sec = its.it_value.tv_sec;
         its.it_interval.tv_nsec = its.it_value.tv_nsec;
      }
      else
      {
         its.it_interval.tv_sec = 0;
         its.it_interval.tv_nsec = 0;
      }

      if ( -1 == timer_settime(pTimer->timerid, 0, &its, NULL) )
      {
         result = MM_GetLastError();
      }
   }
   else
   {
      result = (int)MMOSAL_ERROR_INVAL;
   }
   return ( result );
}

/*
* Starts a timer created using MM_Timer_CreateEx
*
* @param[in] pHandle - handle of timer
* @param[in] nTimeOutSec - timeout in seconds
* @param[in] nTimeOutNSec - timeout in nano seconds
*
* @return zero value is success else failure
*/
int MM_Timer_StartEx
(
  MM_HANDLE     handle,
  int           nTimeOutSec,
  int           nTimeOutNSec
)
{
   int result = (int)MMOSAL_SUCCESS;
   errno = EOK;

   if ( handle )
   {
      struct itimerspec its;
      MM_Timer *pTimer = (MM_Timer *) handle;


      /* Start the timer */
      its.it_value.tv_sec = nTimeOutSec;
      its.it_value.tv_nsec = nTimeOutNSec;

      if ( 0 != pTimer->m_nPeriodic )
      {
         its.it_interval.tv_sec = its.it_value.tv_sec;
         its.it_interval.tv_nsec = its.it_value.tv_nsec;
      }
      else
      {
         its.it_interval.tv_sec = 0;
         its.it_interval.tv_nsec = 0;
      }

      if ( -1 == timer_settime(pTimer->timerid, 0, &its, NULL) )
      {
         result = MM_GetLastError();
      }
   }
   else
   {
      result = (int)MMOSAL_ERROR_INVAL;
   }
   return ( result );
}

/*
* Stops a timer started using MM_Timer_Start
*
* @param[in] pHandle - handle of timer
*
* @return zero value is success else failure
*/
int MM_Timer_Stop
(
   MM_HANDLE handle
)
{
   int result = (int)MMOSAL_SUCCESS;
   errno = EOK;

   if (handle)
   {
      struct itimerspec its;
      MM_Timer *pTimer = (MM_Timer *) handle;
      memset(&its, 0,sizeof(its));
      if (-1 == timer_settime(pTimer->timerid, 0, &its, NULL))
      {
         result = MM_GetLastError();
      }
   }
   else
   {
      result = (int)MMOSAL_ERROR_INVAL;
   }

   return ( result );
}

/*
* There are no further refernces to the object mark for deletion
*
* @param[in] handle - reference to the timer handle
*
* @return zero value on success else failure
*/
int MM_Timer_Release
(
   MM_HANDLE handle
)
{
   int nRetVal = (int)MMOSAL_SUCCESS;
   errno = EOK;

   if ( handle )
   {
      MM_Timer *pTimer = (MM_Timer *) handle;
      int timeout = 0;
      struct itimerspec its;
      void *pUserArg = NULL;

      // disarm the timer if needed
      memset(&its, 0, sizeof(its));

      /* stop the timer */
      nRetVal = MM_Timer_Stop ( handle );

      /* ensure timer is stopped with timeout */
      while ( ( 0 == nRetVal ) && ( 20 > timeout ) )
      {
         int nSts;

         if ( -1 == timer_gettime(pTimer->timerid, &its) )
         {
            nRetVal = MM_GetLastError();
         }
         if ( ( 0 == its.it_value.tv_sec ) && ( 0 == its.it_value.tv_nsec ) )
         {
            break;
         }

         timeout++;

         /* stop the timer */
         nSts = MM_Timer_Stop ( handle );
         if ( (int)MMOSAL_SUCCESS != nSts )
         {
            nRetVal = nSts;
         }
      }

      if ( -1 == timer_delete( pTimer->timerid ) )
      {
         nRetVal = MM_GetLastError();
         MM_MSG_PRIO2( MM_STATS_SLOG, MM_PRIO_ERROR,"failed to delete timer id = 0x%x - %s", pTimer->timerid, strerror( errno ) );
      }

      pTimer->m_pfnTimerHandler = NULL;
      pTimer->m_pvUserArg = NULL;

      if ( 0 != MM_Signal_Reset( pTimer->m_Signal ) )
      {
         if ( (int) MMOSAL_SUCCESS == nRetVal )
         {
            nRetVal = MM_GetLastError();
         }
         MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR,"failed to reset signal in MM_Timer_Release - %s", strerror( errno ));
      }

      // release the timer
      struct _pulse pulse;
      pulse.value.sival_ptr = pTimer;
      pulse.code = RELEASE_PULSE_CODE;

      if ( -1 == MsgSend( coid, &pulse, sizeof(pulse), NULL, 0 ) )
      {
         if ( (int) MMOSAL_SUCCESS == nRetVal )
         {
            nRetVal = MM_GetLastError();
         }
         MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR,"failed to send RELEASE_TIMER_PULSE_CODE code to timerchid - %s", strerror( errno ));
      }

      timeout = 0;

      /* synchronize with MM_Timer_Dispatcher thread. */
      if ( 0 != MM_SignalQ_TimedWait( pTimer->m_SignalQ, TIMEOUTVALUE, &pUserArg, &timeout ) )
      {
         if ( (int) MMOSAL_SUCCESS == nRetVal )
         {
            nRetVal = MM_GetLastError();
         }

         MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "failed on MM_WaitEvent in MM_Timer_Release - %s",strerror( errno ));
      }

      /* Free timer signal */
      if ( 0 != MM_Signal_Release( pTimer->m_Signal ) )
      {
         if ( (int) MMOSAL_SUCCESS == nRetVal )
         {
            nRetVal = MM_GetLastError();
         }

         MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "failed on MM_SignalRelease in MM_Timer_Release - %s",strerror( errno ));
      }

      /* Free timer signalQ */
      if ( 0 != MM_SignalQ_Release( pTimer->m_SignalQ ) )
      {
         if ( (int) MMOSAL_SUCCESS == nRetVal )
         {
            nRetVal = MM_GetLastError();
         }

         MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "failed on MM_SignalQRelease in MM_Timer_Release - %s",strerror( errno ));
      }

      pthread_mutex_lock( &mutex );
      timercnt--;
      if ( 0 == timercnt )
      {

         // kill the timer dispatch thread
         if ( -1 == MsgSendPulse(coid, MM_Thread_CallingThreadPriority, EXIT_PULSE_CODE, 0) )
         {
            if ( (int) MMOSAL_SUCCESS == nRetVal )
            {
               nRetVal = MM_GetLastError();
            }

            MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR,"failed to send pulse code to timerchid - %s", strerror( errno ));
         }
         else
         {
            pthread_join(timertid, NULL);
            timertid = 0;
         }

         if ( -1 != coid )
         {
            if ( -1 == ConnectDetach(coid) )
            {
               if ( (int) MMOSAL_SUCCESS == nRetVal )
               {
                  nRetVal = MM_GetLastError();
               }

               MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "failed to detach from timer channel - %s", strerror( errno ) );
            }

            coid = -1;

            if ( -1 != timerchid )
            {
               if ( -1 == ChannelDestroy(timerchid) )
               {
                  if ( (int) MMOSAL_SUCCESS == nRetVal )
                  {
                     nRetVal = MM_GetLastError();
                  }

                  MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "failed to destroy timer channel - %s", strerror( errno ) );
               }
               timerchid = -1;
            }
         }
      }

      pthread_mutex_unlock(&mutex);
   }

   if ( handle )
   {
      /* Free timer memory */
      MM_Free ( (void *)handle );
   }
   return ( nRetVal );
}

/*
* Sleeps for specified time.
*
* @param[in] nSleepTime - Sleep time in millseconds
* A value of ZERO causes the thread to relinquish the remainder of its time
* slice to any other thread of equal priority that is ready to run. If there
* are no other threads of equal priority ready to run, the function returns
* immediately, and the thread continues execution.
* A value of INFINITE indicates that the suspension should not time out.
*
* @return zero value is success else failure
*/
void MM_Timer_LongSleep
(
   int nSeconds
)
{
   // QNX sleep is not accurate if sleep time is more than 60s,
   // break down long sleep into small sleep of 30 seconds
   while ( nSeconds > 30 )
   {
      sleep(30);
      nSeconds -= 30;
   }
   if ( nSeconds )
   {
      sleep(nSeconds);
   }
}

int MM_Timer_Sleep
(
   unsigned long nSleepTime
)
{
   // usleep can only sleep up to maximum 1 sec, if the sleep
   // time is more more than that we need to do two sleeps
   int uSleepTime = nSleepTime % 1000;

   if ( nSleepTime >= 1000 )
   {
      MM_Timer_LongSleep(nSleepTime/1000);
   }

   if ( uSleepTime )
   {
      usleep(uSleepTime*1000);
   }
   return (int)MMOSAL_SUCCESS;
}

int MM_Timer_BusyWait
(
   unsigned long nSleepTime
)
{
   int nRetVal = (int)MMOSAL_FAILURE;

   if ( clockcycles_nanospin_ns(nSleepTime*1000) )
   {
      nRetVal = (int)MMOSAL_SUCCESS;
   }
   return ( nRetVal );
}
