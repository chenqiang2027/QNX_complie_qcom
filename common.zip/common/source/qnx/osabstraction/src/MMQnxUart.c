/*===========================================================================
                          M M    W r a p p e r
                    f o r   M M    U A R T   C o d e s

*//** @file MMQnxUart.c

Copyright (c) 2016-2018 Qualcomm Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*/
/*========================================================================*/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdint.h>
#include <time.h>
#include <unistd.h>
#include <sys/neutrino.h>
#include "MMUart.h"


/* low level macros for accessing memory mapped hardware registers */
#define REG64(addr) ((volatile uint64_t *)((unsigned long)addr))
#define REG32(addr) ((volatile uint32_t *)((unsigned long)addr))
#define REG16(addr) ((volatile uint16_t *)((unsigned long)addr))
#define REG8(addr) ((volatile uint8_t *)((unsigned long)addr))

#define RMWREG64(addr, startbit, width, val) *REG64(addr) = (*REG64(addr) & ~(((1<<(width)) - 1) << (startbit))) | ((val) << (startbit))
#define RMWREG32(addr, startbit, width, val) *REG32(addr) = (*REG32(addr) & ~(((1<<(width)) - 1) << (startbit))) | ((val) << (startbit))
#define RMWREG16(addr, startbit, width, val) *REG16(addr) = (*REG16(addr) & ~(((1<<(width)) - 1) << (startbit))) | ((val) << (startbit))
#define RMWREG8(addr, startbit, width, val) *REG8(addr) = (*REG8(addr) & ~(((1<<(width)) - 1) << (startbit))) | ((val) << (startbit))

#define writel(v, a) (*REG32(a) = (v))
#define readl(a) (*REG32(a))

#define writeb(v, a) (*REG8(a) = (v))
#define readb(a) (*REG8(a))

#define writehw(v, a) (*REG16(a) = (v))
#define readhw(a) (*REG16(a))

// 8096 chip specific for _mm_dputc
#define PERIPH_SS_BASE              0x07400000

#define MSM_SDC1_BASE               (PERIPH_SS_BASE + 0x00064000)
#define MSM_SDC1_SDHCI_BASE         (PERIPH_SS_BASE + 0x00064900)
#define MSM_SDC2_BASE               (PERIPH_SS_BASE + 0x000A4000)
#define MSM_SDC2_SDHCI_BASE         (PERIPH_SS_BASE + 0x000A4900)

#define BLSP1_UART0_BASE            (PERIPH_SS_BASE + 0x0016F000)
#define BLSP1_UART1_BASE            (PERIPH_SS_BASE + 0x00170000)
#define BLSP1_UART2_BASE            (PERIPH_SS_BASE + 0x00171000)
#define BLSP1_UART3_BASE            (PERIPH_SS_BASE + 0x00172000)
#define BLSP1_UART4_BASE            (PERIPH_SS_BASE + 0x00173000)
#define BLSP1_UART5_BASE            (PERIPH_SS_BASE + 0x00174000)

#define BLSP2_UART1_BASE            (PERIPH_SS_BASE + 0x001B0000)

/* UART DM TX FIFO Registers - 4 */
#if PERIPH_BLK_BLSP
#define MSM_BOOT_UART_DM_TF(base, x)         ((base) + 0x100+(4*(x)))
#else
#define MSM_BOOT_UART_DM_TF(base, x)         ((base) + 0x70+(4*(x)))
#endif

/* UART Command Register */
#if PERIPH_BLK_BLSP
#define MSM_BOOT_UART_DM_CR(base)              ((base) + 0xA8)
#else
#define MSM_BOOT_UART_DM_CR(base)              ((base) + 0x10)
#endif

/* Macros for Common Errors */
#define MSM_BOOT_UART_DM_E_SUCCESS           0
#define MSM_BOOT_UART_DM_E_FAILURE           1
#define MSM_BOOT_UART_DM_E_TIMEOUT           2
#define MSM_BOOT_UART_DM_E_INVAL             3
#define MSM_BOOT_UART_DM_E_MALLOC_FAIL       4
#define MSM_BOOT_UART_DM_E_RX_NOT_READY      5

/* UART Interrupt Status Register */
#if PERIPH_BLK_BLSP
#define MSM_BOOT_UART_DM_ISR(base)          ((base) + 0xB4)
#else
#define MSM_BOOT_UART_DM_ISR(base)          ((base) + 0x14)
#endif

/* UART Status Register */
#if PERIPH_BLK_BLSP
#define MSM_BOOT_UART_DM_SR(base)              ((base) + 0x0A4)
#else
#define MSM_BOOT_UART_DM_SR(base)              ((base) + 0x008)
#endif
#define MSM_BOOT_UART_DM_SR_RXRDY            (1 << 0)
#define MSM_BOOT_UART_DM_SR_RXFULL           (1 << 1)
#define MSM_BOOT_UART_DM_SR_TXRDY            (1 << 2)
#define MSM_BOOT_UART_DM_SR_TXEMT            (1 << 3)
#define MSM_BOOT_UART_DM_SR_UART_OVERRUN     (1 << 4)
#define MSM_BOOT_UART_DM_SR_PAR_FRAME_ERR    (1 << 5)
#define MSM_BOOT_UART_DM_RX_BREAK            (1 << 6)
#define MSM_BOOT_UART_DM_HUNT_CHAR           (1 << 7)
#define MSM_BOOT_UART_DM_RX_BRK_START_LAST   (1 << 8)

#define MSM_BOOT_UART_DM_TXLEV               (1 << 0)
#define MSM_BOOT_UART_DM_RXHUNT              (1 << 1)
#define MSM_BOOT_UART_DM_RXBRK_CHNG          (1 << 2)
#define MSM_BOOT_UART_DM_RXSTALE             (1 << 3)
#define MSM_BOOT_UART_DM_RXLEV               (1 << 4)
#define MSM_BOOT_UART_DM_DELTA_CTS           (1 << 5)
#define MSM_BOOT_UART_DM_CURRENT_CTS         (1 << 6)
#define MSM_BOOT_UART_DM_TX_READY            (1 << 7)
#define MSM_BOOT_UART_DM_TX_ERROR            (1 << 8)
#define MSM_BOOT_UART_DM_TX_DONE             (1 << 9)
#define MSM_BOOT_UART_DM_RXBREAK_START       (1 << 10)
#define MSM_BOOT_UART_DM_RXBREAK_END         (1 << 11)
#define MSM_BOOT_UART_DM_PAR_FRAME_ERR_IRQ   (1 << 12)

#define MSM_BOOT_UART_DM_IMR_ENABLED         (MSM_BOOT_UART_DM_TX_READY | \
                                              MSM_BOOT_UART_DM_TXLEV    | \
                                              MSM_BOOT_UART_DM_RXLEV    | \
                                              MSM_BOOT_UART_DM_RXSTALE)

/*UART General Command */
#define MSM_BOOT_UART_DM_CR_GENERAL_CMD(x)   ((x) << 8)

#define MSM_BOOT_UART_DM_GCMD_NULL            MSM_BOOT_UART_DM_CR_GENERAL_CMD(0)
#define MSM_BOOT_UART_DM_GCMD_CR_PROT_EN      MSM_BOOT_UART_DM_CR_GENERAL_CMD(1)
#define MSM_BOOT_UART_DM_GCMD_CR_PROT_DIS     MSM_BOOT_UART_DM_CR_GENERAL_CMD(2)
#define MSM_BOOT_UART_DM_GCMD_RES_TX_RDY_INT  MSM_BOOT_UART_DM_CR_GENERAL_CMD(3)
#define MSM_BOOT_UART_DM_GCMD_SW_FORCE_STALE  MSM_BOOT_UART_DM_CR_GENERAL_CMD(4)
#define MSM_BOOT_UART_DM_GCMD_ENA_STALE_EVT   MSM_BOOT_UART_DM_CR_GENERAL_CMD(5)
#define MSM_BOOT_UART_DM_GCMD_DIS_STALE_EVT   MSM_BOOT_UART_DM_CR_GENERAL_CMD(6)
/* Number of characters for Transmission */
#define MSM_BOOT_UART_DM_NO_CHARS_FOR_TX(base) ((base) + 0x040)


// we assume no other thread is printing out messages at the same time for the initial debug
// if not, we have to think of the work around.
#define enter_critical_section()        ;
#define exit_critical_section()         ;
//
#define udelay(x)       usleep(x)

#define NON_PRINTABLE_ASCII_CHAR      128

#define MAX_BUF_SIZE 1024

/* -----------------------------------------------------------------------
 ** Function declaration
 ** ----------------------------------------------------------------------- */
static unsigned int msm_boot_uart_calculate_num_chars_to_write(char *data_in, uint32_t *num_of_chars);
static uint8_t pack_chars_into_words(uint8_t *buffer, uint8_t cnt, uint32_t *word);
static unsigned int msm_boot_uart_dm_write(uint32_t base, char *data, unsigned int num_of_chars);
static void _mm_dputc(char c);

/* -----------------------------------------------------------------------
 ** Function definition
 ** ----------------------------------------------------------------------- */

static uint8_t pack_chars_into_words(uint8_t *buffer, uint8_t cnt, uint32_t *word)
{
   uint8_t num_chars_writtten = 0;
   int  j;

   *word = 0;
   for(j=0; j < cnt; j++)
   {
      if (buffer[num_chars_writtten] == '\n')
      {
         /* replace '\n' by the NON_PRINTABLE_ASCII_CHAR and print '\r'.
          * While printing the NON_PRINTABLE_ASCII_CHAR, we will print '\n'.
          * Thus successfully replacing '\n' by '\r' '\n'.
          */
         *word |= ('\r' & 0xff) << (j * 8);
         buffer[num_chars_writtten] = NON_PRINTABLE_ASCII_CHAR;
      }
      else
      {
         if (buffer[num_chars_writtten] == NON_PRINTABLE_ASCII_CHAR)
         {
            buffer[num_chars_writtten] = '\n';
         }

         *word |= (buffer[num_chars_writtten] & 0xff) << (j * 8);

         num_chars_writtten++;
      }
   }

   return num_chars_writtten;
}

/*
 * Helper function to keep track of Line Feed char "\n" with
 * Carriage Return "\r\n".
 */
static unsigned int
msm_boot_uart_calculate_num_chars_to_write(char *data_in,
                                uint32_t *num_of_chars)
{
   uint32_t i = 0, j = 0;

   if ((data_in == NULL))
   {
      return MSM_BOOT_UART_DM_E_INVAL;
   }

   for (i = 0, j = 0; i < *num_of_chars; i++, j++)
   {
      if (data_in[i] == '\n')
      {
         j++;
      }
   }

   *num_of_chars = j;

   return MSM_BOOT_UART_DM_E_SUCCESS;
}

/*
 * UART transmit operation
 */
static unsigned int
msm_boot_uart_dm_write(uint32_t base, char *data, unsigned int num_of_chars)
{
   unsigned int tx_word_count = 0;
   unsigned int tx_char_left = 0, tx_char = 0;
   unsigned int tx_word = 0;
   int i = 0;
   char *tx_data = NULL;
   uint8_t num_chars_written;

   if ((data == NULL) || (num_of_chars <= 0))
   {
      return MSM_BOOT_UART_DM_E_INVAL;
   }

   msm_boot_uart_calculate_num_chars_to_write(data, &num_of_chars);

   tx_data = data;

   /* Write to NO_CHARS_FOR_TX register number of characters
    * to be transmitted. However, before writing TX_FIFO must
    * be empty as indicated by TX_READY interrupt in IMR register
    */

   /* Check if transmit FIFO is empty.
    * If not we'll wait for TX_READY interrupt. */
   if (!(readl(MSM_BOOT_UART_DM_SR(base)) & MSM_BOOT_UART_DM_SR_TXEMT))
   {
      while (!(readl(MSM_BOOT_UART_DM_ISR(base)) & MSM_BOOT_UART_DM_TX_READY))
      {
         udelay(1);
         /* Kick watchdog? */
      }
   }

   //We need to make sure the DM_NO_CHARS_FOR_TX&DM_TF are are programmed atmoically.
   enter_critical_section();
   /* We are here. FIFO is ready to be written. */
   /* Write number of characters to be written */
   writel(num_of_chars, MSM_BOOT_UART_DM_NO_CHARS_FOR_TX(base));

   /* Clear TX_READY interrupt */
   writel(MSM_BOOT_UART_DM_GCMD_RES_TX_RDY_INT, MSM_BOOT_UART_DM_CR(base));

   /* We use four-character word FIFO. So we need to divide data into
    * four characters and write in UART_DM_TF register */
   tx_word_count = (num_of_chars % 4) ? ((num_of_chars / 4) + 1) :
       (num_of_chars / 4);
   tx_char_left = num_of_chars;

   for (i = 0; i < (int)tx_word_count; i++)
   {
      tx_char = (tx_char_left < 4) ? tx_char_left : 4;
      num_chars_written = pack_chars_into_words((uint8_t *)tx_data, tx_char, &tx_word);

      /* Wait till TX FIFO has space */
      while (!(readl(MSM_BOOT_UART_DM_SR(base)) & MSM_BOOT_UART_DM_SR_TXRDY))
      {
         udelay(1);
      }

      /* TX FIFO has space. Write the chars */
      writel(tx_word, MSM_BOOT_UART_DM_TF(base, 0));
      tx_char_left = num_of_chars - (i + 1) * 4;
      tx_data = tx_data + num_chars_written;
   }
   exit_critical_section();

   return MSM_BOOT_UART_DM_E_SUCCESS;
}

static void _mm_dputc(char c)
{
   msm_boot_uart_dm_write(BLSP2_UART1_BASE, &c, 1);
}

int _mm_dputs(const char *str)
{
   while(*str != 0)
   {
      _mm_dputc(*str++);
   }

   return 0;
}

int _mm_dprintf(const char *fmt, ...)
{
   char buf[MAX_BUF_SIZE];
   int err=0;

   va_list ap;
   va_start(ap, fmt);
   err = vsnprintf(buf, sizeof(buf), fmt, ap);
   va_end(ap);

   mm_dputs(buf);

   return err;
}
