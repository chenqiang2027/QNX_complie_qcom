/*===========================================================================
                          M M   W r a p p e r
                        f o r   F i l e   S e r v i c e s

*//** @file MMFile.c
  This file implements the interfaces the support file operations like open,
  read, write, and seek.

Copyright (c) 2008 - 2015, 2020 - 2021 QUALCOMM Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*===========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/osabstraction/src/MMQnxFile.c#1 $

when       who         what, where, why
--------   ---         -------------------------------------------------------
04/30/21   yc          Move wchar_t related to test component per QoS requirement
10/23/20   xg          Add parameter mode to MM_File_Create open() API to avoid coredump on sdp7.1
01/21/15   hc          Fixed KW build warnings
07/17/14   rz          Port AF changes: dd function to modify file permission attributes.
05/08/14   rz          Fix Klocwork warning 
04/01/14   rz          Fix Klocwork warning: array buffer overflow 
02/27/12   sk          Fixed KW compiler warnings
07/02/08   gkapalli    Created file.
06/09/12   spandiri    Added MM_File_GetSizeEx to support for 64 bit

============================================================================*/

/*===========================================================================
 Include Files
============================================================================*/


#include "MMFile.h"
#include "MMMalloc.h"
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <fcntl.h>
#include "AEEstd.h"



/* =======================================================================

                DEFINITIONS AND DECLARATIONS FOR MODULE

This section contains definitions for constants, macros, types, variables
and other items needed by this module.

========================================================================== */

/*
 * Creates/Opens a file
 *
 * @param[in] pFilePath - Name and path of the file to act on
 * @param[in] nMode -  mode to be used to create a file (MM_FILE_CREATE_*)
 * @param[out] pHandle - returns a reference to the file handle
 *
 * @return return value 0 is success else failure
 */
int MM_File_Create
(
  const char* pFilePath,
  int   nMode,
  MM_HANDLE *pHandle
)
{
  int nResult = 1;
  if ( pHandle )
  {
    int fd = -1;
    int nOpenFlag;
    mode_t mode;

    switch (nMode)
    {
      case MM_FILE_CREATE_R_PLUS:
        nOpenFlag = O_RDWR;
        break;
      case MM_FILE_CREATE_W:
        nOpenFlag = O_CREAT | O_TRUNC | O_WRONLY;
        break;
      case MM_FILE_CREATE_W_PLUS:
        nOpenFlag = O_CREAT | O_TRUNC | O_RDWR;
        break;
      case MM_FILE_CREATE_A:
        nOpenFlag = O_CREAT | O_APPEND | O_WRONLY;
        break;
      case MM_FILE_CREATE_R:
      default:
        nOpenFlag = O_RDONLY;
        break;
    }

    if( nOpenFlag & O_CREAT )
    {
        mode = S_IRWXU | S_IRGRP;
        fd = open( pFilePath, nOpenFlag, mode);
    }
    else
    {
        fd = open( pFilePath, nOpenFlag);
    }

    if ( fd >= 0 )
    {
       nResult = 0;
       *pHandle = (void *)((size_t)fd);
    }
  }

  return nResult;
}

/*
 * Releases the resources associated with the file handle
 *
 * @param[in] handle - the file handle
 *
 * @return zero value on success else failure
 */
int MM_File_Release
(
  MM_HANDLE handle
)
{
  int nResult = 1;
  if (handle)
  {
    nResult = close( (int)(long)((int*)handle) );
  }
  return nResult;
}

/*
 * Reads data from a file into the buffer
 *
 * @param[in] handle - the file handle
 * @param[in] pBuffer - pointer to the buffer to which data may be copied
 * @param[in] nSize -  sizeof pBuffer
 * @param[out] pBytesRead -  number of bytes read into pBuffer
 *
 * @return return value 0 is success else failure
 */
int MM_File_Read
(
  MM_HANDLE handle,
  char *pBuffer,
  int nSize,
  int *pnBytesRead
)
{
  int nResult = 1;
  if ( handle && pnBytesRead )
  {
    ssize_t nBytesRead = read( (int)(long)((int*)handle), pBuffer, (size_t)nSize);
    if (nBytesRead >= 0)
    {
      *pnBytesRead = (int)nBytesRead;
      nResult = 0;
    }
  }

  return nResult;
}

/*
 * Writes data from the buffer into the file
 *
 * @param[in] handle - the file handle
 * @param[in] pBuffer - pointer to the buffer that contains the data
 * @param[in] nSize -  size of pBuffer that needs to be written
 * @param[out] pBytesWritten -  number of bytes written into the file
 *
 * @return return value 0 is success else failure
 */
int MM_File_Write
(
  MM_HANDLE handle,
  char *pBuffer,
  int nSize,
  int *pnBytesWritten
)
{
  int nResult = 1;
  if ( handle && pnBytesWritten )
  {
    ssize_t nBytesRead = write((int)(long)((int*)handle), pBuffer, (size_t)nSize);
    if (nBytesRead >= 0)
    {
      *pnBytesWritten = (int)nBytesRead;
      nResult = 0;
    }
  }

  return nResult;
}

/*
 * Reposition the file pointer in an open file
 *
 * @param[in] handle - the file handle
 * @param[in] nOffset - offset based on nWhence; may be negative
 * @param[in] nWhence -  flags to be used when acting on a file
 *
 * @return return value 0 is success else failure
 */
int MM_File_Seek
(
  MM_HANDLE handle,
  long nOffset,
  int nWhence
)
{
  int nResult = 1;

  if ( handle )
  {
    int efsWhence;

    switch (nWhence)
    {
      case MM_FILE_SEEK_BEG:
        efsWhence = SEEK_SET;
        break;
      case MM_FILE_SEEK_END:
        efsWhence = SEEK_END;
        break;
      case MM_FILE_SEEK_CUR:
      default:
        efsWhence = SEEK_CUR;
        break;
    }
    if ( lseek((int)(long)((int*)handle), nOffset, efsWhence) != -1 )
    {
      nResult = 0;
    }
  }

  return nResult;
}

/*
 * Reposition the file pointer in an open file. Extended to support
 * 64 bit nOffset
 *
 * @param[in] handle - the file handle
 * @param[in] nOffset - offset based on nWhence; may be negative
 * @param[in] nWhence -  flags to be used when acting on a file
 *
 * @return return value 0 is success else failure
 */
int MM_File_SeekEx
(
  MM_HANDLE handle,
  unsigned long long nOffset,
  int nWhence
)
{
  int nResult = 1;
  if ( handle )
  {
    int efsWhence;

    switch (nWhence)
    {
      case MM_FILE_SEEK_BEG:
        efsWhence = SEEK_SET;
        break;
      case MM_FILE_SEEK_END:
        efsWhence = SEEK_END;
        break;
      case MM_FILE_SEEK_CUR:
      default:
        efsWhence = SEEK_CUR;
        break;
    }
    if(-1 != lseek64((int)(long)((int*)handle), (off64_t)nOffset, efsWhence))
    {
      nResult = 0;
    }
  }
  return nResult;
}

/*
 * Returns the current file size
 *
 * @param[in] handle - the file handle
 * @param[out] dwSize - returns the file size on success
 *
 * @return return value 0 is success else failure
 */
int MM_File_GetSize
(
  MM_HANDLE handle,
  unsigned long *pnSize
)
{
  int nResult = 1;
  if ( handle && pnSize )
  {
    struct stat fsStat;
	memset(&fsStat, 0, sizeof(fsStat));
    if ( fstat((int)(long)((int*)handle), &fsStat) == 0 )
    {
      *pnSize = fsStat.st_size;
      nResult = 0;
    }
  }

  return nResult;
}

/*
 * Returns the current file size. Extended to support 64 bit
 *
 * @param[in] handle - the file handle
 * @param[out] dwSize -> pnSize - returns the file size on success
 *
 * @return return value 0 is success else failure
 */
int MM_File_GetSizeEx
(
  MM_HANDLE handle,
  unsigned long long *pnSize
)
{
  int nResult = 1;
  if ( handle && pnSize )
  {
    struct stat64 fsStat;
    memset(&fsStat, 0, sizeof(fsStat));
    if ( fstat64((int)(long)((int*)handle), &fsStat) == 0 )
    {
      *pnSize = fsStat.st_size;
      nResult = 0;
    }
  }

  return nResult;
}

/*
 * Truncates the file to the length specified
 *
 * @param[in] pFile - reference to the file handle
 * @param[in] nLength - the length to which the file needs to be truncated
 *
 * @return return value 0 is success else failure
 */
int MM_File_Truncate
(
  MM_HANDLE handle,
  long nLength
)
{
  int nResult = 1;
  if ( handle )
  {
    nResult = ftruncate((int)(long)((int*)handle), nLength);
  }
  return nResult;
}

/*
 * Copies an existing file to a new file, fails if there is file by same
 * name at the new location.
 *
 * @param[in] pExistingFile - Pointer to a null-terminated string that
 *                            specifies the name of an existing file
 * @param[in] pNewFilePath - Pointer to a null-terminated string that specifies
 *                           the name of the new file.
 *
 * @return return value 0 is success else failure
 */
int MM_File_Copy
(
  const char* pExistingFile,
  const char *pNewFile
)
{
  int nResult = 1;
  return nResult;
}

/*
 * Moves an existing file to a new file/location, fails if there is file by same
 * name at the new location.
 *
 * @param[in] pExistingFile - Pointer to a null-terminated string that
 *                            specifies the name of an existing file
 * @param[in] pNewFilePath - Pointer to a null-terminated string that specifies
 *                           the name of the new file.
 *
 * @return return value 0 is success else failure
 */
int MM_File_Move
(
  const char* pExistingFile,
  const char *pNewFile
)
{
  return rename(pExistingFile,pNewFile);
}

/*
 * Deletes an existing file.
 *
 * @param[in] pFile - Pointer to a null-terminated string that specifies the
 *                    name of the file file
 *
 * @return return value 0 is success else failure
 */
int MM_File_Delete
(
  const char* pFile
)
{
  return unlink(pFile);
}

/*
 * Gets the free space in the disk pointed by the path
 *
 * @param[in] pPath - Pointer to a null-terminated string that specifies the
 *                    path
 * @param[out] pFreeSpace - updates the value with the avaliable free space
 *
 * @return return value 0 is success else failure
 */
int MM_File_GetFreeSpace
(
  const char* pPath,
  unsigned long long *pFreeSpace
)
{
  int nResult = 1;
  if ( pFreeSpace != NULL && pPath != NULL)
  {
    struct statvfs statvfsData;
    if (statvfs ( pPath, &statvfsData) == 0 )
    {
      *pFreeSpace =  (unsigned long long)statvfsData.f_bsize * statvfsData.f_bavail;
      nResult = 0;
    }
  }
  return nResult;
}

/*
 * Get the current file position
 *
 * @param[in] handle - Reference to the file handle
 * @param[out] filePos - Pointer to the file position
 *
 * @return return value 0 is success else failure
 */

int MM_File_GetCurrentPosition
(
  MM_HANDLE handle,
  unsigned long* filePos
)
{
  int result = 1;
  if ( handle && filePos )
  {
    if( ( *filePos = (int)lseek ((int)(long)((int*)handle),(off64_t)0, SEEK_CUR  ) ) != -1 )
    {
      result = 0;
    }
  }
  return result;
}


/*
 * Get the current file position , Extended support for 64bit offset
 *
 * @param[in] handle - Reference to the file handle
 * @param[out] filePos - Pointer to the file position
 *
 * @return return value 0 is success else failure
 */

int MM_File_GetCurrentPositionEx
(
  MM_HANDLE handle,
  unsigned long long* filePos
)
{
  int result = 1;
  if ( handle && filePos )
  {
    if( ( *filePos = (int)lseek64 ((int)(long)((int*)handle),(off64_t)0, SEEK_CUR  ) ) != -1 )
    {
      result = 0;
    }
  }
  return result;
}


/*
 * Change the file mode
 *
 * @param[in] handle - Reference to the file handle
 * @param[out] mode - file mode bit mask
 *
 * @return return value 0 is success else failure
 */
int MM_File_ChangeMode
(
  MM_HANDLE handle,
  unsigned long  mode
)
{
  int result = 1;

  if ( handle && mode )
  {
     mode_t m = 0;
     
     /* user attributes */
     if ( mode & MM_FILE_USER_READ )
     {
        m |= S_IRUSR;
     }

     if ( mode & MM_FILE_USER_WRITE )
     {
        m |= S_IWUSR;
     }

     if ( mode & MM_FILE_USER_EXEC )
     {
        m |= S_IXUSR;
     }

     /* group attributes */
     if ( mode & MM_FILE_GROUP_READ )
     {
        m |= S_IRGRP;
     }

     if ( mode & MM_FILE_GROUP_WRITE )
     {
        m |= S_IWGRP;
     }

     if ( mode & MM_FILE_GROUP_EXEC )
     {
        m |= S_IXGRP;
     }
     
     /* others attributes */
     if ( mode & MM_FILE_OTHERS_READ )
     {
        m |= S_IROTH;
     }

     if ( mode & MM_FILE_OTHERS_WRITE )
     {
        m |= S_IWOTH;
     }

     if ( mode & MM_FILE_OTHERS_EXEC )
     {
        m |= S_IXOTH;
     }
          
     if ( 0 == fchmod( (int)(long)((int*)handle), m ) )
     {
        result = 0;
     }
  }
  
  return result;
}
