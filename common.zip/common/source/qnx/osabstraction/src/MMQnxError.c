/*===========================================================================
                          M M    W r a p p e r                            
                    f o r   M M    E r r o r   C o d e s                    

*//** @file MMQnxError.c
  This file has the Rex error codes mapped to generic error codes           
  
Copyright (c) 2011 - 2018 Qualcomm Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*/
/*========================================================================*/

#include "MMError.h"
#include "errno.h"

int MM_MapError(int err);

/*
 * Get the last error in QNX calls
 *
 * @return returns the last error in QNX  calls
 */

int MM_MapError(int err)
{
   int nReturn = (int) MMOSAL_SUCCESS;
   /* Map the last error to MMOSAL generic error */  
   switch(err)
   {  
       case EOK:
            nReturn = (int) MMOSAL_SUCCESS;
            break;
       case ENOMEM:
            nReturn = (int) MMOSAL_ERROR_NO_MEM;
            break;
       case EINVAL:
       case EFAULT:
       case ELOOP:
       case ENOTDIR:
       case ENXIO:
            nReturn = (int) MMOSAL_ERROR_INVAL;
            break;
       case EAGAIN:
       case ENOSPC:
            nReturn = (int) MMOSAL_ERROR_NO_RSRC;
            break;
       case EPERM:
       case EACCES:
       case EROFS:
       case EFBIG:
       case ETXTBSY:
            nReturn = (int) MMOSAL_ERROR_OP_NOT_PERMITTED;
            break;
       case EBUSY:
            nReturn = (int) MMOSAL_ERROR_BUSY;
            break;
       case EDEADLK:
            nReturn = (int) MMOSAL_ERROR_ALREADY_OWNS_MUTEX;
            break;
       case ETIMEDOUT:
            nReturn = (int) MMOSAL_ERROR_TIMEDOUT;
            break;
       case ESRCH:
            nReturn = (int) MMOSAL_ERROR_NO_PROCESS;
            break;
       case ENOTSUP:
       case ENOSYS:
            nReturn = (int) MMOSAL_ERROR_VALUE_NOT_SUP;

            break;
       case EEXIST:
            nReturn = (int) MMOSAL_ERROR_FILE_EXISTS;
            break;
       case EISDIR:
            nReturn = (int) MMOSAL_ERROR_IS_DIRECTORY;
            break;
       case EMFILE:
       case ENFILE:
            nReturn = (int) MMOSAL_ERROR_FILE_OPEN_EXCEEDED;
            break;
       case ENAMETOOLONG:
            nReturn = (int) MMOSAL_ERROR_FILE_PATH_NAME_TOOLONG;
            break;
       case ENODEV:
       case ENOENT:
            nReturn = (int) MMOSAL_ERROR_NO_SUCH_FILE;
            break;
       case EBADF:
            nReturn = (int) MMOSAL_ERROR_BAD_FILE_DESCRIPTOR;
            break;
       case EINTR:
            nReturn = (int) MMOSAL_ERROR_INTR_BY_SIGNAL;  
            break;
       case EIO:
            nReturn = (int) MMOSAL_ERROR_FILE_IO;
            break;
       case EPIPE:
       case ESPIPE:
            nReturn = (int) MMOSAL_ERROR_FILE_PIPE; 
            break;
       case EOVERFLOW:
            nReturn = (int) MMOSAL_ERROR_FILE_OFFSET; 
            break;
        default:          
            nReturn = (int) MMOSAL_FAILURE;
            break;
    }
    return nReturn;
}

int MM_GetLastError( void )
{
    return MM_MapError(errno);
}
