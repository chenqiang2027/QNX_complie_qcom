/*===========================================================================

@file MMProfile.h
  This file defines functions that can be used for logging events in profile
  log.

Copyright (c) 2014 QUALCOMM Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*===========================================================================
                             Edit History


============================================================================*/


/*===========================================================================
 Include Files
============================================================================*/
#include "MMProfile.h"
#include "MMMalloc.h"
#include <sys/neutrino.h>
#include <sys/trace.h>

/*===========================================================================
 Type definitions
============================================================================*/
typedef struct ProfileCtxt{
   boolean bEnable;
   MM_Profile_Domain domain;
}ProfileCtxt;

/**
 * Initialize MM profiling for a client
 *
 * @param[in] handle - pointer to client handle
 *
 * @return zero value is success and -1 on failure
 */
int MM_Profile_Init
(
   MM_HANDLE *handle
)
{
   ProfileCtxt *pCtxt;
   int sts = -1;
   *handle = NULL;
   
   pCtxt = (ProfileCtxt *) MM_malloc(sizeof(ProfileCtxt), __FILE__, __LINE__);
   if (pCtxt)
   {
      std_memset(pCtxt, 0, sizeof(ProfileCtxt));
      *handle = (MM_HANDLE)pCtxt;
      sts = 0;
   }
   return sts;
}

/**
 * Deinitialize MM profiling for a client
 *
 * @param[in] handle - client handle
 *
 * @return zero value is success and -1 on failure
 */
int MM_Profile_DeInit
(
   MM_HANDLE handle
)
{
   int sts = -1;

   if (handle)
   {
      MM_free((void *)handle, __FILE__,__LINE__);
      sts = 0;
   }

   return sts;
}


/**
 * configure client for MM profiling
 *
 * @param[in] handle - client handle
 * @param[in] domain - mm profiling domain
 * @param[in] bEnable - TRUE for enable and FALSE for disable
 *
 * @return zero value is success and -1 on failure
 */
int MM_Profile_Config
(
   MM_HANDLE handle,
   MM_Profile_Domain domain,
   boolean bEnable
)
{
   int sts = -1;
   
   if ( handle )
   {
     ProfileCtxt *pCtxt = (ProfileCtxt *)handle;
     
     pCtxt->bEnable = bEnable;
     pCtxt->domain = domain + _NTO_TRACE_USERFIRST + 100;
     sts = 0;
   }

   return sts;
}

/**
 * marks event id in system profiling log
 *
 * @param[in] domain - MM Profile Domain
 * @param[in] user_event_id - event id
 * @param[in] user_data - user data
 *
 * @return zero value is success and -1 on failure
 */
int MM_Profile_Insert_Mark_ID
(
   MM_HANDLE handle,
   unsigned long long event_id,
   unsigned long long user_data
)
{
   int sts = -1;

   if ( handle )
   {
     ProfileCtxt *pCtxt = (ProfileCtxt *)handle;

     sts = 0;

     if ( pCtxt->bEnable )
     {
       sts = trace_logi( pCtxt->domain, event_id, user_data);
     }
   }

   return (sts);
}

/**
 * marks event id in system profiling log
 *
 * @param[in] domain - MM Profile Domain
 * @param[in] str - user supplied string
 *
 * @return zero value is success and -1 on failure
 */
int MM_Profile_Insert_Mark_String
(
   MM_HANDLE handle,
   const char *str
)
{
   int sts = -1;
   
   if ( handle )
   {
     ProfileCtxt *pCtxt = (ProfileCtxt *)handle;
     
     sts = 0;

     if ( pCtxt->bEnable )
     {
        sts = trace_nlogf( pCtxt->domain, 256, str);
     }
   }

   return (sts);
}

/*===========================================================================*/
