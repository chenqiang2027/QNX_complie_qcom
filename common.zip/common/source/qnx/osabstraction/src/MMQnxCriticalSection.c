/*===========================================================================
 M M   W r a p p e r
 f o r   C r i t i c a l  S e c t i o n  O b j e c t

 *//** @file MMCriticalSection.c
 This file implements a utility class that can be used to synchronize access
 to data in multithreaded environment

 Copyright (c) 2008 - 2013 QUALCOMM Technologies Incorporated.
 All Rights Reserved. Qualcomm Proprietary and Confidential.
 *//*========================================================================*/

/*===========================================================================
 Edit History

 $Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/osabstraction/src/MMQnxCriticalSection.c#1 $

 when       who         what, where, why
 --------   ---         -------------------------------------------------------
07/14/14   rz           Port AF changes: Clean up mutexattr only if successfully created.
                                         MM_CriticalSection_Create free up resource on failure.
 04/03/13   dwp         Insert cleanup of mutexattr
 01/25/13   yzgao       Clean up printf()/fprintf()
 02/27/12   sk          Fixed KW compiler warnings
 07/02/08   gkapalli    Created file.

 ============================================================================*/

/*===========================================================================
 Include Files
 ============================================================================*/
#include <stdlib.h> 
#include "pthread.h"
#include "errno.h"
#include <string.h>
#include <stdio.h>
#include "MMCriticalSection.h"
#include "MMMalloc.h"
#include "MMError.h"

#include "MMDebugMsg.h"

int MM_MapError(int err);

/*
 * Initializes the critical section
 *
 * @param[out] pHandle - a reference to the critical section handle
 *
 * @return zero value is success else failure
 */
int MM_CriticalSection_Create(MM_HANDLE *pHandle)
{
    int retValue = 1;

    if (pHandle)
    {
        *pHandle = MM_Malloc(sizeof(pthread_mutex_t));
        if (*pHandle)
        {
            pthread_mutexattr_t attr;
            retValue = pthread_mutexattr_init(&attr);
            if(0 == retValue)
            {
               retValue = pthread_mutexattr_setrecursive(&attr, PTHREAD_RECURSIVE_ENABLE );
               if(0 == retValue)
               {
                  retValue = pthread_mutex_init(*pHandle, &attr);
               }
               pthread_mutexattr_destroy(&attr);
            }
            if(retValue != EOK)
            {
               retValue = MM_MapError(retValue);
               MM_Free ( *pHandle );
               *pHandle = NULL;
            }
        }
    }
    return retValue;
}

/*
 * Releases the resources associated with the cirtical section
 *
 * @param[in] handle - the critical section handle
 *
 * @return zero value on success else failure
 */
int MM_CriticalSection_Release(MM_HANDLE handle)
{
    int retValue = 1;
    if (handle)
    {
        retValue = pthread_mutex_destroy((pthread_mutex_t*) (handle));
        MM_Free(handle);
        if(retValue != EOK)
        {
           retValue = MM_MapError(retValue);
        }
    }

    return retValue;
}

/*
 * Enter a critical section, blocks if another thread is inside the critical 
 * section until the other thread leaves the critical section. 
 *
 * @param[in] handle - the critical section handle
 *
 * @return zero value on success else failure
 */
int MM_CriticalSection_Enter(MM_HANDLE handle)
{
    int retValue = 0;
    if (handle)
    {
        if (EOK != (retValue = pthread_mutex_lock((pthread_mutex_t*) (handle))))
        {
            MM_MSG_PRIO1( MM_GENERAL, MM_PRIO_ERROR, "MM_CriticalSection_Enter error %s", strerror(retValue) );
            retValue = 1;
        }
    }

    return retValue;
}

/*
 * Leave a critical section (releases the lock). 
 *
 * @param[in] handle - the critical section handle
 *
 * @return zero value on success else failure
 */
int MM_CriticalSection_Leave(MM_HANDLE handle)
{
    int retValue = 0;
    if (handle)
    {
        if (EOK != (retValue = pthread_mutex_unlock((pthread_mutex_t*) (handle))))
        {
            MM_MSG_PRIO1( MM_GENERAL, MM_PRIO_ERROR, "MM_CriticalSection_Leave error: %s", strerror(retValue) );
            retValue = 1;
        }
    }

    return retValue;
}

/*
 * Tries to acquire the lock, return with failure immediately if not able to 
 * acquire the lock unlike Enter which blocks until the lock is acquired.  
 *
 * @param[in] handle - the critical section handle
 *
 * @return zero value is success else failure
 */
int MM_CriticalSection_TryEnter(MM_HANDLE handle)
{
    int retValue = 0;
    if (handle)
    {
        if (EOK != (retValue = pthread_mutex_trylock((pthread_mutex_t *) handle)))
        {
            MM_MSG_PRIO1( MM_GENERAL, MM_PRIO_ERROR, "MM_CriticalSection_TryEnter error: %s", strerror(retValue) );
            retValue = 1;
        }
    }
    return retValue;
}

