/*===========================================================================
 M M   W r a p p e r
 f o r   S i g n a l  Q u e u e  O b j e c t

 *//** @file MMSignalQ.cc
 This file defines provides functions to send and receive signals typically
 inter-process objects used for event notification.

 Copyright (c) 2008 - 2018, 2023 QUALCOMM Technologies Incorporated.
 All Rights Reserved. Qualcomm Proprietary and Confidential.
 *//*========================================================================*/

/*===========================================================================
 Edit History

 $Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/osabstraction/src/MMQnxSignal.c#2 $

 when       who         what, where, why
 --------   ---         -------------------------------------------------------
 07/04/23   pp          Check for all the signals in queue instead of first signal in MM_SignalQ_Release
 01/03/18   am          Add semaphore count function to signal.
 01/12/17   rz          Fix compilation warnings with format check
 07/17/14   rz          Port AF changes: Replace perrror with VIDC_MSG_ERROR.
                                         Fix status code return for MM_SignalQ_Release.
 04/01/14   rz          Fix NULL pointer check before dereference
 04/03/13   dwp         Insert cleanup of mutexattr
 01/25/13   yzgao       Clean up printf()/fprintf()
 07/02/08   gkapalli    Created file.

 ============================================================================*/

/*===========================================================================
 Include Files
 ============================================================================*/
#include "MMSignal.h"
#include "MMMalloc.h"
#include "MMCriticalSection.h"
#include "MMEvent.h"
#include <mqueue.h>
#include <stdlib.h>
#include "pthread.h"
#include <stdio.h>
#include <string.h>
#include "errno.h"

#include "MMDebugMsg.h"

/* =======================================================================

 DEFINITIONS AND DECLARATIONS FOR MODULE

 This section contains definitions for constants, macros, types, variables
 and other items needed by this module.

 ========================================================================== */

/* -----------------------------------------------------------------------
 ** Constant / Define Declarations
 ** ----------------------------------------------------------------------- */
#define MM_MAX_NUMBER_SIGNALS 32

/* -----------------------------------------------------------------------
 ** Forward declarations
 ** ----------------------------------------------------------------------- */
typedef struct __MM_SignalQ MM_SignalQ;
typedef struct __MM_Signal MM_Signal;

/* -----------------------------------------------------------------------
 ** Type Declarations
 ** ----------------------------------------------------------------------- */

struct __MM_Signal
{
    /*
     * Attributes of the signal.
     */
    int m_nSignalAttributes;
    /*
     * This signal has been assigned.
     */
    boolean m_bSignalInUse;
    /*
     * Indicates if the signal has been set.
     */
    boolean m_bSignalSet;
    /*
     * User data pointer associated with the event.
     */
    void *m_pvUserArg;
    /*
     * Signal handler associated with the event.
     */
    void (*m_pfnSignalHandler)(void*);
    /*
     * Refernce to the parent signalQ with which the signal is associated.
     */
    MM_SignalQ *m_pParentSignalQ;

};

struct __MM_SignalQ
{
    /*
     * The QNX event handle
     */
    MM_HANDLE m_eventHandle;
    /*
     * This signal has been assigned.
     */
    boolean m_bSignalQInUse;
    /*
     * List of events that have been created in this signal queue
     */
    MM_Signal m_signals[MM_MAX_NUMBER_SIGNALS];
    /*
     * Lock to synchronize the addition and removal of events  m_signals
     */
    MM_HANDLE m_signalsLock;
    /*
     * Signal set count
     */
    int count;
};


/* -----------------------------------------------------------------------
 ** Function Definition
 ** ----------------------------------------------------------------------- */

/*
 * Creates a signal queue object
 *
 * @param[out] return a reference to the Signal Queue handle on success
 *
 * @return zero when successfull else failure
 */
int MM_SignalQ_Create(MM_HANDLE *pHandle)
{
    int nResult = 1; // failure
    MM_SignalQ *pSignalQ = NULL;

    if (pHandle)
    {
        // Create a signal queue handle
        pSignalQ = MM_Malloc( sizeof(MM_SignalQ) );

        if (pSignalQ)
        {
            memset(pSignalQ, 0, sizeof(MM_SignalQ));
            pSignalQ->m_bSignalQInUse = TRUE;
            if (MM_Event_Create((void *) &pSignalQ->m_eventHandle) == 0 &&
                MM_CriticalSection_Create(&pSignalQ->m_signalsLock) == 0)
            {
                int i;
                for (i = 0; i < MM_MAX_NUMBER_SIGNALS; i++)
                {
                    pSignalQ->m_signals[i].m_pParentSignalQ = pSignalQ;
                }
                *pHandle = pSignalQ;
                nResult = 0;
            }
            else
            {
                MM_SignalQ_Release(pSignalQ);
            }
        }
    }

    return nResult;
}

/*
 * Releases the resources associated with the signal queue
 *
 * @param[in] pSignalQ - the signal queue handle
 *
 * @return zero value on success else failure
 */
int MM_SignalQ_Release(MM_HANDLE handle)
{
    int nResult = 1; // failure
    MM_SignalQ *pSignalQ = (MM_SignalQ *) handle;

    if (pSignalQ)
    {
        int i;
        MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
        pSignalQ->m_bSignalQInUse = FALSE;
        // check if all the signals have been closed, if yes go ahead and delete
        // signal queue else wait for the last signal to be closed to delete the
        // signal queue. This is done by calling MM_SignalQ_Release in
        // MM_Signal_Release
        for (i = 0; i < MM_MAX_NUMBER_SIGNALS; i++)
        {
            if (pSignalQ->m_signals[i].m_bSignalInUse)
            {
                break;
            }
        }
        MM_CriticalSection_Leave(pSignalQ->m_signalsLock);
        // all signals have been released, delete the signalQ
        if (i == MM_MAX_NUMBER_SIGNALS)
        {
            MM_Event_Destroy(pSignalQ->m_eventHandle);
            MM_CriticalSection_Release(pSignalQ->m_signalsLock);
            MM_Free( handle );
            handle = NULL;
            nResult = 0;
        }
    }

    return nResult;
}

/*
 * This function blocks until a signal is set on the queue. If a signal handler
 * has been registered when the signal is created then the handler is called,
 * else function returns with the user data pointer passed in when creating
 * the signal
 *
 * @param[in] pSignalQ - reference to the signal queue handle
 * @param[out] ppvUserArg - user data pointer of the signal that is set on
 *                          success
 *
 * @return zero when successfull else failure
 */
int MM_SignalQ_Wait(MM_HANDLE handle, void **ppvUserArg)
{
    MM_SignalQ *pSignalQ = (MM_SignalQ *) handle;
    int signalIndex = MM_MAX_NUMBER_SIGNALS;
    int nResult = 1; //failure
    void (*pfnSignalHandler)(void* ) = NULL;
    void *pUserArg = NULL;

    if (pSignalQ)
    {
        MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
        // check if any of the signals are set, if yes go ahead process the signal
        for ( signalIndex = 0 ; signalIndex < MM_MAX_NUMBER_SIGNALS; signalIndex++)
        {
            if (pSignalQ->m_signals[signalIndex].m_bSignalSet)
            {
                break;
            }
        }
        // none of the signals have been set, wait
        while (signalIndex == MM_MAX_NUMBER_SIGNALS)
        {
            MM_CriticalSection_Leave(pSignalQ->m_signalsLock);
            MM_Event_Wait((void *) pSignalQ->m_eventHandle, 0xFFFFFFFF); // Infinite
            MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
            // check if any of the signals are set, if yes go ahead process
            // the signal
            for ( signalIndex = 0 ; signalIndex < MM_MAX_NUMBER_SIGNALS; signalIndex++)
            {
                if (pSignalQ->m_signals[signalIndex].m_bSignalSet)
                {
                    break;
                }
            }
        }

        if (signalIndex < MM_MAX_NUMBER_SIGNALS)
        {
            // Process the signal
            if (pSignalQ->m_signals[signalIndex].m_nSignalAttributes ==
                MM_SIGNAL_ATTRIBUTE_AUTOMATIC)
            {
                pSignalQ->m_signals[signalIndex].m_bSignalSet = FALSE;
            }
            if (pSignalQ->m_signals[signalIndex].m_pfnSignalHandler)
            {
                pfnSignalHandler = pSignalQ->m_signals[signalIndex].m_pfnSignalHandler;
                pUserArg = pSignalQ->m_signals[signalIndex].m_pvUserArg;
            }
            else if (pSignalQ->m_signals[signalIndex].m_pvUserArg && ppvUserArg)
            {
                *ppvUserArg = pSignalQ->m_signals[signalIndex].m_pvUserArg;
            }
            nResult = 0;
        }
        MM_CriticalSection_Leave(pSignalQ->m_signalsLock);
    }

    if ( pfnSignalHandler )
    {
        pfnSignalHandler(pUserArg);
    }

    return nResult;
}

/*
 * This function blocks until one of the signals specified as input is set on the
 * queue. Note that the signals being specified in "pSignals" MUST be created
 * using the same signalQ that is being waited on "handle". If a signal handler
 * has been registered when the signal is created then the handler is called,
 * else function returns with the user data pointer passed in when creating the
 * signal
 *
 * @param[in] handle - reference to the signal queue handle
 * @param[out] ppvUserArg - user data pointer of the signal that is set on
 *                          success
 * @param[in] pSignals - array of signals to be waited
 * @param[in] nNumSignals - num of signals in the pSignals
 *
 * @return zero when successfull else failure
 */
int MM_SignalQ_WaitEx
(
    MM_HANDLE handle,
    void **ppvUserArg,
    MM_HANDLE *pSigs,
    int numSignals
)
{
    MM_SignalQ *pSignalQ = (MM_SignalQ *) handle;
    int signalIndex = 0;
    MM_Signal **pSignals = (MM_Signal **) pSigs;
    int nResult = 0; //success
    void (*pfnSignalHandler)(void* ) = NULL;
    void *pUserArg = NULL;

    // sanity check for valid signals
    for (signalIndex = 0; signalIndex < numSignals; signalIndex++)
    {
        if (pSignals[signalIndex] == NULL)
        {
            nResult = 1; //failure
            break;
        }
    }

    if (nResult == 0 && pSignalQ)
    {
        nResult = 1; //failure
        MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
        // check if any of the signals are set, if yes go ahead process the signal
        for (signalIndex = 0; signalIndex < numSignals; signalIndex++)
        {
            if (pSignals[signalIndex]->m_bSignalSet)
            {
                break;
            }
        }
        // none of the signals have been set, wait
        while (signalIndex == numSignals)
        {
            MM_CriticalSection_Leave(pSignalQ->m_signalsLock);
            MM_Event_Wait((void *) pSignalQ->m_eventHandle, 0xFFFFFFFF); // Infinite
            MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
            // check if any of the signals are set, if yes go ahead process
            // the signal
            for (signalIndex = 0; signalIndex < numSignals; signalIndex++)
            {
                if (pSignals[signalIndex]->m_bSignalSet)
                {
                    break;
                }
            }
        }
        if (signalIndex < numSignals)
        {
            // Process the signal
            if (pSignals[signalIndex]->m_nSignalAttributes ==
                MM_SIGNAL_ATTRIBUTE_AUTOMATIC)
            {
                pSignals[signalIndex]->m_bSignalSet = FALSE;
            }
            if (pSignals[signalIndex]->m_pfnSignalHandler)
            {
                pfnSignalHandler = pSignalQ->m_signals[signalIndex].m_pfnSignalHandler;
                pUserArg = pSignalQ->m_signals[signalIndex].m_pvUserArg;
            }
            else if (pSignals[signalIndex]->m_pvUserArg && ppvUserArg)
            {
                *ppvUserArg = pSignals[signalIndex]->m_pvUserArg;
            }
            nResult = 0;
        }
        MM_CriticalSection_Leave(pSignalQ->m_signalsLock);
    }

    if ( pfnSignalHandler )
    {
        pfnSignalHandler(pUserArg);
    }

    return nResult;
}

/*
 * This function blocks until an signal is set by count.
 *
 * @param[in] handle - reference to the signal queue handle
 * @return zero when successfull else failure
 */
int MM_SignalQ_WaitEx2
(
    MM_HANDLE handle
)
{
    MM_SignalQ *pSignalQ = (MM_SignalQ *) handle;
    int nResult = 0; //success

    MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
    if (0 == pSignalQ->count)
    {
       MM_CriticalSection_Leave(pSignalQ->m_signalsLock);
       MM_Event_Wait((void *) pSignalQ->m_eventHandle, 0xFFFFFFFF); // Infinite
       MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
    }
    else if (0 > pSignalQ->count)
    {
       nResult = 1; //failure
    }
    if (pSignalQ->count > 0) pSignalQ->count--;
    MM_CriticalSection_Leave(pSignalQ->m_signalsLock);

    return nResult;
}

/*
 * This function blocks until a signal is set on the queue or the specified
 * time has elapsed.
 *
 * If a signal handler has been registered when the signal is created then
 * the handler is called, else function returns with the user data pointer
 * passed in when creating the signal
 *
 * @param[in] handle - the signal queue handle
 * @param[in] nTimeOut - The time in msec to wait for the signal to be set
 * @param[out] ppvUserArg - user data pointer passed in when the signal is
 *                          created
 * @param[out] bTimedOut - 1 indicates a time out no signal set
 *
 * @return zero on sucess else failure
 */
int MM_SignalQ_TimedWait
(
    MM_HANDLE handle,
    int nTimeOut,
    void** ppvUserArg,
    int* pbTimedOut
)
{

    MM_SignalQ *pSignalQ = (MM_SignalQ *) handle;
    int signalIndex = MM_MAX_NUMBER_SIGNALS;
    int nResult = 1; //failure
    void (*pfnSignalHandler)(void* ) = NULL;
    void *pUserArg = NULL;

    if (pSignalQ && pbTimedOut)
    {
        MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
        *pbTimedOut = FALSE;
        // check if any of the signals are set, if yes go ahead process the signal
        for (signalIndex = 0; signalIndex < MM_MAX_NUMBER_SIGNALS; signalIndex++)
        {
            if (pSignalQ->m_signals[signalIndex].m_bSignalSet)
            {
                break;
            }
        }
        // none of the signals have been set, wait
        while (signalIndex == MM_MAX_NUMBER_SIGNALS && *pbTimedOut == FALSE)
        {
            int status;
            MM_CriticalSection_Leave(pSignalQ->m_signalsLock);
            status = MM_Event_Wait(pSignalQ->m_eventHandle, nTimeOut);
            MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
            if (status == MM_EVENT_WAIT_TIMEOUT)
            {
                *pbTimedOut = TRUE;
            }
            else
            {
                // check if any of the signals are set, if yes go ahead process
                // the signal
                for (signalIndex = 0; signalIndex < MM_MAX_NUMBER_SIGNALS; signalIndex++)
                {
                    if (pSignalQ->m_signals[signalIndex].m_bSignalSet)
                    {
                        break;
                    }
                }
            }
        }

        if (*pbTimedOut == TRUE)
        {
            // Timed out
            nResult = 0;
        }
        else if (signalIndex < MM_MAX_NUMBER_SIGNALS)
        {
            // Process the signal
            if (pSignalQ->m_signals[signalIndex].m_nSignalAttributes ==
                MM_SIGNAL_ATTRIBUTE_AUTOMATIC)
            {
                pSignalQ->m_signals[signalIndex].m_bSignalSet = FALSE;
            }
            if (pSignalQ->m_signals[signalIndex].m_pfnSignalHandler)
            {
                pfnSignalHandler = pSignalQ->m_signals[signalIndex].m_pfnSignalHandler;
                pUserArg = pSignalQ->m_signals[signalIndex].m_pvUserArg;
            }
            else if (pSignalQ->m_signals[signalIndex].m_pvUserArg && ppvUserArg )
            {
                *ppvUserArg = pSignalQ->m_signals[signalIndex].m_pvUserArg;
            }
            nResult = 0;
        }
        MM_CriticalSection_Leave(pSignalQ->m_signalsLock);
    }

    if ( pfnSignalHandler )
    {
        pfnSignalHandler(pUserArg);
    }

    return nResult;
}

/*
 * This function blocks until one of the signals specified as input is set on
 * the queue or the specified time has elapsed. Note that the signals being
 * specified in "pSignals" MUST be created using the same signalQ that is being
 * waited on "handle".
 *
 * If a signal handler has been registered when the signal is created then
 * the handler is called, else function returns with the user data pointer
 * passed in when creating the signal.
 *
 * @param[in] handle - the signal queue handle
 * @param[in] nTimeOut - The time in msec to wait for the signal to be set
 * @param[out] ppvUserArg - user data pointer passed in when the signal is
 *                          created
 * @param[out] pbTimedOut - 1 indicates a time out no signal set
 * @param[in] pSignals - array of signals to be waited
 * @param[in] numSignals - num of signals

 *
 * @return zero on sucess else failure
 */
int MM_SignalQ_TimedWaitEx
(
    MM_HANDLE handle,
    int nTimeOut,
    void **ppvUserArg,
    int *pbTimedOut,
    MM_HANDLE *pSigs,
    int nNumSignals
)
{
    MM_SignalQ *pSignalQ = (MM_SignalQ *) handle;
    MM_Signal **pSignals = (MM_Signal **) pSigs;
    int signalIndex = 0;
    int nResult = 0; //success
    void (*pfnSignalHandler)(void* ) = NULL;
    void *pUserArg = NULL;

    // sanity check for valid signals
    for (signalIndex = 0; signalIndex < nNumSignals; signalIndex++)
    {
        if (pSignals[signalIndex] == NULL)
        {
            nResult = 1; //failure
            break;
        }
    }

    if (nResult == 0 && pSignalQ && pbTimedOut)
    {
        nResult = 1; //failure
        MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
        *pbTimedOut = FALSE;
        // check if any of the signals are set, if yes go ahead process the signal
        for (signalIndex = 0; signalIndex < nNumSignals; signalIndex++)
        {
            if (pSignals[signalIndex]->m_bSignalSet)
            {
                break;
            }
        }
        // none of the signals have been set, wait
        while (signalIndex == nNumSignals && *pbTimedOut == FALSE)
        {
            int status;
            MM_CriticalSection_Leave(pSignalQ->m_signalsLock);
            status = MM_Event_Wait(pSignalQ->m_eventHandle, nTimeOut);
            MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
            if (status == MM_EVENT_WAIT_TIMEOUT)
            {
                *pbTimedOut = TRUE;
            }
            else
            {
                // check if any of the signals are set, if yes go ahead process
                // the signal
                for (signalIndex = 0; signalIndex < nNumSignals; signalIndex++)
                {
                    if (pSignals[signalIndex]->m_bSignalSet)
                    {
                        break;
                    }
                }
            }
        }

        if (*pbTimedOut == TRUE)
        {
            // Timed out
            nResult = 0;
        }
        else if (signalIndex < nNumSignals)
        {
            // Process the signal
            if (pSignals[signalIndex]->m_nSignalAttributes ==
                MM_SIGNAL_ATTRIBUTE_AUTOMATIC)
            {
                pSignals[signalIndex]->m_bSignalSet = FALSE;
            }
            if (pSignals[signalIndex]->m_pfnSignalHandler)
            {
                pfnSignalHandler = pSignalQ->m_signals[signalIndex].m_pfnSignalHandler;
                pUserArg = pSignalQ->m_signals[signalIndex].m_pvUserArg;
            }
            else if (pSignals[signalIndex]->m_pvUserArg && ppvUserArg)
            {
                *ppvUserArg = pSignals[signalIndex]->m_pvUserArg;
            }
            nResult = 0;
        }
        MM_CriticalSection_Leave(pSignalQ->m_signalsLock);
    }

    if ( pfnSignalHandler )
    {
        pfnSignalHandler(pUserArg);
    }

    return nResult;
}


/*
 * This function blocks until a signal is set by count or timeout.
 *
 * @param[in] handle - the signal queue handle
 * @param[in] nTimeOut - The time in msec to wait for the signal to be set

 *
 * @return zero on sucess else failure
 */
int MM_SignalQ_TimedWaitEx2
(
    MM_HANDLE handle,
    int nTimeOut,
    int* pbTimedOut
)
{
    MM_SignalQ *pSignalQ = (MM_SignalQ *) handle;
    int nResult = 1; //failure

    if (nResult == 0 && pSignalQ && pbTimedOut)
    {
        MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
        if (0 == pSignalQ->count)
        {
            int status;
            MM_CriticalSection_Leave(pSignalQ->m_signalsLock);
            status = MM_Event_Wait(pSignalQ->m_eventHandle, nTimeOut);
            MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
            if (status == MM_EVENT_WAIT_TIMEOUT)
            {
               *pbTimedOut = TRUE;
               nResult = 0;
            }
            else if (status == 0)
            {
               nResult = 0;
            }
        }
        if (pSignalQ->count > 0) pSignalQ->count--;
        MM_CriticalSection_Leave(pSignalQ->m_signalsLock);
    }

    return nResult;
}

/*
 * Creates a the signal handle
 *
 * When the associated signal is set the registered call back will be called.
 * Note that the signal implementation does not have a context of its own, so
 * Pop() needs to be called to give context of execution for the handler to be
 * called.
 *
 * If the optional signal handler is registered then the handler will be called
 * with the optional user argument when the signal is set else user argument is
 * returned in Pop() call.
 *
 * @param[in] signalQHandle - reference to the signal queue handle
 * @param[in] pfnSignalHandler - optional signal handler to be called when the
 *                               signal is set
 * @param[in] pvUserArg - optional user data pointer to be passed in the call
 *                        back or returned when the signal is set.
 * @param[out] pSignalHandle - returns a reference to the signal handle
 *
 * @return zero value is success else failure
 */
int MM_Signal_Create
(
    MM_HANDLE signalQHandle,
    void *pvUserArg,
    void(*pfnSignalHandler)(void*),
    MM_HANDLE *pSignalHandle
)
{
    return MM_Signal_CreateEx(signalQHandle, pvUserArg, pfnSignalHandler,
            MM_SIGNAL_ATTRIBUTE_AUTOMATIC, pSignalHandle);
}

/*
 * Creates a the signal handle
 *
 * When the associated signal is set the registered call back will be called.
 * Note that the signal implementation does not have a context of its own, so
 * Pop() needs to be called to give context of execution for the handler to be
 * called.
 *
 * If the optional signal handler is registered then the handler will be called
 * with the optional user argument when the signal is set else user argument is
 * returned in Pop() call.
 *
 * @param[in] signalQHandle - reference to the signal queue handle
 * @param[in] pfnSignalHandler - optional signal handler to be called when the
 *                               signal is set
 * @param[in] pvUserArg - optional user data pointer to be passed in the call
 *                        back or returned when the signal is set.
 * @param[in] nSignalAttributes - indicates additional flags that can be specified for
 signal
 * @param[out] pSignalHandle - returns a reference to the signal handle
 *
 * @return zero value is success else failure
 */
int MM_Signal_CreateEx
(
    MM_HANDLE signalQHandle,
    void *pvUserArg,
    void(*pfnSignalHandler)(void*),
    int nSignalAttributes,
    MM_HANDLE *pSignalHandle
)
{
    int nResult = 1; // failure
    MM_SignalQ *pSignalQ = (MM_SignalQ *) signalQHandle;

    if (pSignalQ && pSignalHandle)
    {
        int i;
        MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
        if (pSignalQ->m_bSignalQInUse)
        {
            for (i = 0; i < MM_MAX_NUMBER_SIGNALS; i++)
            {
                if (pSignalQ->m_signals[i].m_bSignalInUse == FALSE &&
                    pSignalQ->m_signals[i].m_bSignalSet == FALSE)
                {
                    pSignalQ->m_signals[i].m_nSignalAttributes = nSignalAttributes;
                    pSignalQ->m_signals[i].m_bSignalInUse = TRUE;
                    pSignalQ->m_signals[i].m_pvUserArg = pvUserArg;
                    pSignalQ->m_signals[i].m_pfnSignalHandler = pfnSignalHandler;
                    *pSignalHandle = (MM_HANDLE) &pSignalQ->m_signals[i];
                    nResult = 0;
                    break;
                }
            }
        }
        MM_CriticalSection_Leave(pSignalQ->m_signalsLock);
    }

    return nResult;
}

/*
 * There are no further refernces to the object mark for deletion
 *
 * @param[in] pSignal - reference to the signal handle
 *
 * @return zero value on success else failure
 */
int MM_Signal_Release(MM_HANDLE handle)
{
    int nResult = 1; // failure
    MM_Signal *pSignal = (MM_Signal *) handle;

    if (pSignal)
    {
        MM_SignalQ *pSignalQ = pSignal->m_pParentSignalQ;
        nResult = 0;
        MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
        if (pSignal->m_bSignalInUse)
        {
            pSignal->m_bSignalInUse = FALSE;
            MM_CriticalSection_Leave(pSignalQ->m_signalsLock);

            // Check if the parent signal queue has been deleted in the earlier
            // call if the signal queue has been deleted and this is the last signal
            // to be released in the signal queue then delete the signal queue
            if (pSignalQ->m_bSignalQInUse == FALSE)
            {
                MM_SignalQ_Release(pSignalQ);
            }
        }
        else
        {
            MM_CriticalSection_Leave(pSignalQ->m_signalsLock);
        }
    }

    return nResult;
}

/*
 * Sets the signal
 *
 * @param[in] pSignal - a reference to the signal handle
 *
 * @return zero when successfull else NULL on failure
 */
int MM_Signal_Set(MM_HANDLE handle)
{
    int nResult = 1; // failure
    MM_Signal *pSignal = (MM_Signal *) handle;

    if (pSignal)
    {
        MM_SignalQ *pSignalQ = pSignal->m_pParentSignalQ;
        MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
        if (pSignal->m_bSignalInUse && pSignalQ->m_bSignalQInUse)
        {
            pSignal->m_bSignalSet = TRUE;
            if (MM_Event_Set(pSignalQ->m_eventHandle) == 0)
            {
                nResult = 0;
                pSignalQ->count++;
            }
        }
        MM_CriticalSection_Leave(pSignalQ->m_signalsLock);
    }

    return nResult;
}

/**
 * Resets the signal state, used for manual signals. For automatic signals
 * the signal is set to reset on exiting a wait to wait with timeout.
 *
 * @param[in] handle - a reference to the signal handle
 *
 * @return zero when successfull else failure
 */
int MM_Signal_Reset(MM_HANDLE handle)
{
    int nResult = 1; // failure
    MM_Signal *pSignal = (MM_Signal *) handle;

    if (pSignal)
    {
        MM_SignalQ *pSignalQ = pSignal->m_pParentSignalQ;
        MM_CriticalSection_Enter(pSignalQ->m_signalsLock);
        pSignal->m_bSignalSet = FALSE;
        pSignalQ->count = 0;
        MM_CriticalSection_Leave(pSignalQ->m_signalsLock);
        nResult = 0;
    }

    return nResult;
}

