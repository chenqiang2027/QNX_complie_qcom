/*===========================================================================
M M   W r a p p e r
f o r   T h r e a d   S e r v i c e s

*//** @file MMThread.cpp
This file implements the thread interface that can be used to create and
control threads.

Copyright (c) 2008 - 2018 QUALCOMM Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*===========================================================================
Edit History

 $Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/osabstraction/src/MMQnxThread.c#1 $

when       who         what, where, why
--------   ---         ------------------------------------------------------- 
04/12/18   jz          Add difinition for MM_Thread_MaxPriority
07/27/18   rz          Fix MM_Thread_Detach memory leak
07/26/16   rz          Add MM_Thread_Detach 
                       Port fix: Return MMOSAL_SUCCESS when thread does not exist 
07/14/16   rz          Workaround to avoid crash
12/01/15   rz          Add pthread_cancel return code check
10/30/15   wy          Add normal and high level to existing thread priority
10/13/15   am          Update thread priorities
07/17/14   rz          Port AF changes: Add calling thread priority.
01/25/13   yzgao       Clean up printf()/fprintf()
07/02/08   gkapalli    Created file.

============================================================================*/

/*===========================================================================
Include Files
============================================================================*/
#include <pthread.h>
#include <errno.h>
#include <string.h>
#include <sys/neutrino.h>
#include <stdio.h>
#include "MMThread.h"
#include "MMMalloc.h"
#include "MMSignal.h"
#include "MMError.h"

#include "MMDebugMsg.h"

int MM_MapError(int err);

/* =======================================================================

DEFINITIONS AND DECLARATIONS FOR MODULE

This section contains definitions for constants, macros, types, variables
and other items needed by this module.pdef

========================================================================== */

/* -----------------------------------------------------------------------
** Defines
** ----------------------------------------------------------------------- */

#define THREAD_FLAG_DETACH       ( 0x1 << 0 )

/* -----------------------------------------------------------------------
** Forward declarations
** ----------------------------------------------------------------------- */
typedef struct __MM_Thread MM_Thread;

/* -----------------------------------------------------------------------
** Type Declarations
** ----------------------------------------------------------------------- */

struct __MM_Thread
{
   pthread_t m_threadHandle;

   MM_HANDLE m_memoryHandle;

   /* flags */
   int m_nFlags;
   /*
   * exit code
   */
   int m_nExitCode;
   /*
   * user's start routine at which thread execution starts
   */
   int(*pfnStart)(void*);
   /*
   * user's data pointer passed to start routine
   */
   void* pvStartArg;
   /*
   * Null terminated Name of the thread
   */
   char pstrName[_NTO_THREAD_NAME_MAX];
};

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* MM Default Thread priority for QNX */

const int MM_Thread_CallingThreadPriority = -1;
const int MM_Thread_BackgroundPriority    = 8;
const int MM_Thread_NormalPriority        = 10;
const int MM_Thread_DefaultPriority       = 10;
const int MM_Thread_HighPriority          = 15;
const int MM_Thread_ComponentPriority     = 24;
const int MM_Thread_RealtimePriority      = 24;
const int MM_Thread_ISTPriority           = 30;
const int MM_Thread_ISRPriority           = 43;
const int MM_Thread_MaxPriority           = 50;

static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

/**
* Thread function that wraps the actual function the user
* request to be run, sets the name of the thread, and then
* executes the users's function, passing in the users's
* argument.
*
* @param[in] pArgs - pointer to argument structure containing
*       thread name, user's function, and user's args.
*
* @return user thread's return code
*/
int MM_Thread_SetNameWrapper(void *pArgs)
{
   int ret = -1;
   struct __MM_Thread *pThread = (struct __MM_Thread*) pArgs;

   if (pThread)
   {
      if (pThread->pfnStart)
      {
         ret = pthread_setname_np(0, pThread->pstrName);
         if (EOK != ret)
         {
            /* Thread name is mainly for profiling, print and continue */
            MM_MSG_PRIO2( MM_STATS_SLOG, MM_PRIO_ERROR, "MM_Thread_SetNameWrapper(): failed to set thread name %s, err: %d", pThread->pstrName, ret );
         }
         ret = pThread->pfnStart(pThread->pvStartArg);

         pthread_mutex_lock(&mutex);

         if ( pThread->m_nFlags & THREAD_FLAG_DETACH ) 
         {
            MM_Free( pThread );
         }
         else
         {
            pThread->m_nFlags |= THREAD_FLAG_DETACH;
         }

         pthread_mutex_unlock(&mutex);
      }
      else
      {
         MM_MSG_PRIO( MM_STATS_SLOG, MM_PRIO_HIGH, "MM_Thread_SetNameWrapper(): invalid start function" );
      }
   }
   else
   {
      MM_MSG_PRIO( MM_STATS_SLOG, MM_PRIO_HIGH, "MM_Thread_SetNameWrapper(): invalid args" );
   }

   return ( ret );
}

/**
* Creates a thread and begins execution
*
* The thread handle needs to be released by calling MM_Thread_Exit
*
* @param[in] nPriority - thread priority
* @param[in] nSuspend -  suspend count a value greater than 0 results in a
suspended thread
* @param[in] pfnStart - start routine at which thread execution starts
* @param[in] pvStartArg - data pointer passed to start routine
* @param[in] dwStackSize - size of thread stack
* @param[in] pstrName - Null terminated Name of the thread
* @param[out] pHandle - returns a reference to the thread handle
*
* @return zero value on success else failure
*/
int MM_Thread_CreateEx2
(
   MM_HANDLE      memoryHandle,
   int            nPriority,
   int            nSuspend,
   int(*pfnStart)(void*),
   void*          pvStartArg,
   unsigned int   nStackSize,
   char*          pstrName,
   MM_HANDLE*     pHandle
)
{
   int retValue = 1; // Failure
   MM_Thread *pThread = 0;

   if (pHandle)
   {
      *pHandle = 0;

      // Create a MM thread handle
      if ( memoryHandle )
      {
         pThread = MM_MallocEx( memoryHandle, sizeof(MM_Thread) );
      }
      else
      {
         pThread = MM_Malloc( sizeof(MM_Thread) );
      }

      if (pThread)
      {
         memset(pThread, 0, sizeof(MM_Thread));
         /* Cache a Memory Handle */
         pThread->m_memoryHandle = memoryHandle;

         pthread_t hThread;
         pthread_attr_t attrib;

         // create thread with priority
         pthread_attr_init(&attrib);

         if (EOK == pthread_attr_setstacksize(&attrib, nStackSize))
         {
            pthread_attr_setinheritsched(&attrib, PTHREAD_EXPLICIT_SCHED );
            pthread_attr_setschedpolicy(&attrib, SCHED_RR);

            if ( nPriority <= sched_get_priority_max( SCHED_RR )  &&
               nPriority >= sched_get_priority_min( SCHED_RR ) )
            {
               struct sched_param params;

               params.sched_priority = nPriority;
               pthread_attr_setschedparam(&attrib, &params);
            }

            pThread->pfnStart = pfnStart;
            pThread->pvStartArg = pvStartArg;
            snprintf(pThread->pstrName, _NTO_THREAD_NAME_MAX, "%s", pstrName);

            if(EOK == pthread_create(&hThread, &attrib, (void*)MM_Thread_SetNameWrapper, pThread))
            {
               if (((pthread_t)((long)NULL)) != hThread)
               {
                  pThread->m_threadHandle = hThread;
                  *pHandle = pThread;
                  retValue = 0;
               }
            }
         }
         pthread_attr_destroy(&attrib);
      }

      if (retValue)
      {
         if (memoryHandle)
         {
            MM_FreeEx( pThread );
         }
         else
         {
            MM_Free( pThread );
         }
      }
   }

   return retValue;
}

int MM_Thread_CreateEx
(
   int            nPriority,
   int            nSuspend,
   int(*pfnStart)(void*),
   void*          pvStartArg,
   unsigned int   nStackSize,
   char*          pstrName,
   MM_HANDLE*     pHandle
)
{
   //(void) pstrName;
   return MM_Thread_CreateEx2(NULL,nPriority, nSuspend, pfnStart,
      pvStartArg, nStackSize, pstrName, pHandle);
}

/*
* Creates a thread and begins execution
*
* @param[in] nPriority - thread priority
* @param[in] nSuspend -  suspend count a value greater than 0 results in a
suspended thread
* @param[in] pfnStart - start routine at which thread execution starts
* @param[in] pvStartArg - data pointer passed to start routine
* @param[in] dwStackSize - size of thread stack
* @param[out] pThread - returns a refereance to the thread handle
*
* @return return zero value on success else failure
*/
int MM_Thread_Create
(
   int            nPriority,
   int            nSuspend,
   int(*pfnStart)(void*),
   void*          pvStartArg,
   unsigned int   nStackSize,
   MM_HANDLE*     pHandle
)
{
   return MM_Thread_CreateEx(nPriority, nSuspend, pfnStart, pvStartArg,
      nStackSize, "MM_Thread_unknown", pHandle);
}

/*
* Releases the resources associated with the thread
*
* @param[in] handle - the thread handle
*
* @return zero value on success else failure
*/
int MM_Thread_Release
(
   MM_HANDLE handle
)
{
   MM_Thread *pThread = handle;
   int retValue = 1; //failure

   if (pThread)
   {
      if (pThread->m_threadHandle)
      {
         if (pThread->m_threadHandle != pthread_self())
         {
            // we don't care the return value of pthread_cancel. The client might have
            // called MM_Thread_Exit which might cause pthread_cancel to return ESRCH
            pthread_cancel(pThread->m_threadHandle);

            // we need to call pthread_join always so that zombies can be collected
            // pthread_join may return ESRCH if thread does not exist
            retValue = pthread_join(pThread->m_threadHandle, NULL);
            if(retValue != EOK)
            {
               retValue = MM_MapError(retValue);

               if ( MMOSAL_ERROR_NO_PROCESS == retValue)
               {
                  MM_MSG_PRIO( MM_STATS_SLOG, MM_PRIO_HIGH, "MM_Thread_Release(): success in no_process" );
                  retValue = MMOSAL_SUCCESS;
               }
            }
         }
         else
         {
            MM_MSG_PRIO( MM_STATS_SLOG, MM_PRIO_ERROR, "MM_Thread_Release(): should not be called in the same context" );
            return retValue;
         }
      }
      MM_Free(pThread);
   }
   else
   {
      MM_MSG_PRIO( MM_STATS_SLOG, MM_PRIO_ERROR, "MM_Thread_Release(): NULL pointer" );
   }
   return ( retValue );
}

/*
* Blocks the calling thread until the specified thread terminates
*
* @param[in] handle - the thread handle
* @param[out] nExitCode - the exit code
*
* @return zero value is success else failure
*/
int MM_Thread_Join
(
   MM_HANDLE   handle,
   int*        pnExitCode
)
{
   int retValue = 1;
   MM_Thread *pThread = handle;

   if ( pThread )
   {
      int *vp = NULL;

      if ( EOK == pthread_join(pThread->m_threadHandle, (void **)&vp) )
      {
         if (pnExitCode)
         {
            if (vp)
            {
               //*pnExitCode = *vp;
               *pnExitCode = 0;   // workaround to avoid crash
            }
            else
            {
               *pnExitCode = 0;
            }
         }
         retValue = 0;
      }
   }

   return ( retValue );
}

/*
* Exits the thread with the given code.
*
* @param[in] handle - the thread handle
* @param[in] nExitCode - the exit code
*
* @return value 0 is success else failure
*/
int MM_Thread_Exit
(
   MM_HANDLE   handle,
   int         nExitCode
)
{
   int retValue = 1;
   MM_Thread *pThread = handle;

   if ( pThread && pThread->m_threadHandle == pthread_self() )
   {
      // called within the same thread context
      pThread->m_nExitCode = nExitCode;
      pthread_exit(&pThread->m_nExitCode);
      retValue = 0;
   }
   return ( retValue );
}

/*
* Detach the thread from the calling thread
*
* @param[in] handle - the thread handle
*
* @return value 0 is success else failure
*/
int MM_Thread_Detach
(
   MM_HANDLE   handle
)
{
   int retValue = 1;
   
   MM_Thread *pThread = handle;

   if ( pThread && pThread->m_threadHandle )
   {
      int rc = 0;
      rc = pthread_detach( pThread->m_threadHandle );
      if( EOK == rc  )
      {
         MM_MSG_PRIO( MM_STATS_SLOG, MM_PRIO_HIGH, "pthread_detach success");
         retValue = 0;
      }
      else if( EINVAL == rc  )
      {
         MM_MSG_PRIO( MM_STATS_SLOG, MM_PRIO_HIGH, "pthread_detach success - already detached");
         retValue = 0;
      }
      else if( ESRCH == rc  )
      {
         MM_MSG_PRIO( MM_STATS_SLOG, MM_PRIO_ERROR, "pthread_detach failed thread not exist");
      }
	  else
      {
         MM_MSG_PRIO1( MM_STATS_SLOG, MM_PRIO_ERROR, "pthread_detach(): failed %d", rc);
      }

      if ( 0 == retValue ) 
      {
         pthread_mutex_lock(&mutex);

         if ( pThread->m_nFlags & THREAD_FLAG_DETACH ) 
         {
            MM_Free( pThread );
         }
         else
         {
            pThread->m_nFlags |= THREAD_FLAG_DETACH;
         }

         pthread_mutex_unlock(&mutex);
      }
   }
      
   return retValue;      
}

/*
* Increments the suspend count on a thread, suspending execution of the
* thread if the previous count was 0.
*
* @param[in] handle - the thread handle
* @param[out] pnSuspCount - the thread's previous suspend count
*
* @return value 0 is success else failure
*/
int MM_Thread_Suspend
(
   MM_HANDLE   handle,
   int*        pnSuspCount
)
{
   return 0;
}

/*
* Decrements the suspend count on a thread, resumes execution of the
* thread if the resulting count was 0.
*
* @param[in] handle - the thread handle
* @param[out] pnSuspCount - the thread's previous suspend count
*
* @return value 0 is success else failure
*/
int MM_Thread_Resume
(
   MM_HANDLE   handle,
   int*        pnSuspCount
)
{
   return 0;
}

/*
* Returns the priority of the current thread.
*
* @param[in] handle - the thread handle
* @param[out] pnPriority - the thread priority
*
* @return value 0 is success else failure
*/
int MM_Thread_GetPriority
(
   MM_HANDLE   handle,
   int*        pnPriority
)
{
   int ret = 1;

   if ( handle )
   {
      MM_Thread* pThread = (MM_Thread*) handle;
      struct sched_param sp;
      int policy;

      if ( EOK == pthread_getschedparam(pThread->m_threadHandle, &policy, &sp) )
      {
         ret = 0;
         *pnPriority = sp.sched_curpriority;
      }
   }
   return ( ret );
}

/*
* Sets the priority of the current thread.
*
* @param[in] handle - the thread handle
* @param[in] nPriority - the thread priority
*
* @return value 0 is success else failure
*/
int MM_Thread_SetPriority
(
   MM_HANDLE   handle,
   int         nPriority
)
{
   int ret = 1;
   MM_Thread* pThread = (MM_Thread*) handle;

   if ( pThread )
   {
      if ( EOK == pthread_setschedprio(pThread->m_threadHandle, nPriority) )
      {
         ret = 0;
      }
   }
   return ( ret );
}

/*
* Gets the thread handle of the calling context
*
* @param[out] pThread - the thread handle on success
*
* @return value 0 is success else failure
*/
int MM_Thread_GetCurrent
(
   MM_HANDLE *pHandle
)
{
   return 1;
}

/*
* Compares two thread handles
*
* @param[in] thread1 - the thread handle on compare
* @param[in] thread2 - the thread handle on compare
*
* @return value 0 is same else the handles are different
*/
int MM_Thread_Compare
(
   MM_HANDLE handle1,
   MM_HANDLE handle2
)
{
   MM_Thread *pThread1 = handle1;
   MM_Thread *pThread2 = handle2;

   if ( pThread1 && pThread2 )
   {
      return ((pThread1->m_threadHandle == pThread2->m_threadHandle) ? 0 : 1);
   }
   return 1;
}
