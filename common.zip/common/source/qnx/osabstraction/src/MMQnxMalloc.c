/*===========================================================================
                          M M   W r a p p e r 
                   f o r   C   M e m o r y   R o u t i n e s

*//** @file  MMMemory.h
   This module defines routines to track and debug memory related usage
 
   Copyright (c) 2008 - 2009 Qualcomm Technologies Incorporated.
   All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/* ==========================================================================
                     INCLUDE FILES FOR MODULE
========================================================================== */
#include <stdlib.h> 
#include <string.h>


#include "MMMalloc.h"
#include "MMDebugMsg.h"
#include "MMCriticalSection.h"

/* =======================================================================

                        DATA DECLARATIONS

========================================================================== */
/* -----------------------------------------------------------------------
** Constant / Define Declarations
** ----------------------------------------------------------------------- */

#define MM_TRUNCATE_FILE_PATH(pFile) \
{ \
  if ( pFile == NULL ) \
    pFile = "NULL"; \
  else \
  { \
    char *pFile2 = strrchr( pFile, '\\'); \
    if (pFile2 != NULL) \
      pFile = pFile2; \
  } \
} \
  
#ifdef __cplusplus
extern "C" {
#endif

// Additional space to store the templatized destuctor function pointer, 
// to call the right destuctor. Note this should be alignment (2^N where 
// N is any positive int). 
const unsigned int MM_MEMORY_SIZEOF_PRIVATE_DATA = 
  sizeof(MM_Memory_DestructPtr);

#ifdef __cplusplus
} 
#endif 

/* -----------------------------------------------------------------------
** Type Declarations
** ----------------------------------------------------------------------- */
#ifdef FEATURE_MM_MEMORY_DEBUG
typedef struct {
  const void   *pointer;
  size_t  bytes;
  const char   *file;
  unsigned int  line;
} MMMallocType;

#define SIZE_OF_MEM_DEBUG_ARRAY 1000

typedef struct {
  /* table to keep a tab on current entires */
  MMMallocType m_mallocTable[SIZE_OF_MEM_DEBUG_ARRAY];
  /* current number of bytes allocated */
  size_t  m_nCurrBytes; 
  /* peek bytes allocated */
  size_t  m_nPeekBytes;
  /* total bytes allocated */
  size_t  m_nTotalBytes;  
  /* Critical section to lock the usage of m_mallocTable */
  MM_HANDLE m_hLock;
} MMMemoryHandle;

static MMMemoryHandle gMMMemoryHandle = {0};

/*
 * Refernce count to the number to init and release calls
 */
static unsigned int numMemDebugLockRefs = 0;

static unsigned int MM_MEMORY_MAGIC_NUMBER = 0xDEADBEEF;

/*
 * Header that is prefixed for debug purposes to indentify 
 * which memory handle the memory belongs
 */
typedef struct {
  /* magic number for validation against corruption */
  unsigned int m_magicNumber;
  /* memory handle to which this block of memory belongs */
  MMMemoryHandle *m_handle;
} MMMemoryHeader;

#else

typedef struct {
  unsigned char m_dummy;
} MMMemoryHandle;

#endif // FEATURE_MM_MEMORY_DEBUG

/* -----------------------------------------------------------------------
** Global Constant Data Declarations
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Global Data Declarations
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Local Object Definitions
** ----------------------------------------------------------------------- */

/* =======================================================================
**                        Class & Function Declarations
** ======================================================================= */

#ifdef FEATURE_MM_MEMORY_DEBUG

/* 
 *  Helper function that adds a mem alloc entry to the MMMallocTable.
 *
 * @param[in] pMemory - pointer to the memory
 * @param[in] size - memory size requested
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 * @param[in] pMemoryHandle - Memory Handle
 */
static void MM_MallocAddEntry
(
  const void *pMemory,
  size_t size,
  const char *file,
  unsigned int line,
  MMMemoryHandle *pMemoryHandle
)
{
  int i;
  /* If memory was allocated, store the information into the mem_pointer_array
   * table.
   */
  if( pMemory != NULL )
  {
    for( i = 0; i < SIZE_OF_MEM_DEBUG_ARRAY; i++ )
    {
      if( pMemoryHandle->m_mallocTable[i].pointer == NULL )
      {
        /* Found an empty spot, so store the data */
        pMemoryHandle->m_mallocTable[i].pointer = pMemory;
        pMemoryHandle->m_mallocTable[i].bytes   = size;
        pMemoryHandle->m_mallocTable[i].file    = file;
        pMemoryHandle->m_mallocTable[i].line    = line;
        break;
      }
    }
    /* Error checking */
    if( i >= SIZE_OF_MEM_DEBUG_ARRAY )
    {
      MM_MSG_SPRINTF_PRIO_3( MM_STATISTICS, MM_PRIO_ERROR,
                             "MM_Memory Unable to store malloc info: [%s:%d] %d bytes",
                             file, line, size );
    }

    /* Increment the number of bytes currently allocated */
    pMemoryHandle->m_nCurrBytes   += size;
    /* Increment the total number of bytes currently allocated */
    pMemoryHandle->m_nTotalBytes   += size;
    /* Keep track of the watermark of bytes allocated */
    if ( pMemoryHandle->m_nPeekBytes < pMemoryHandle->m_nCurrBytes )
    {
      pMemoryHandle->m_nPeekBytes = pMemoryHandle->m_nCurrBytes;
    }
  }
}

/* 
 * Helper function that finds a mem alloc entry in the MMMallocTable given a
 * previously added/allocated memory pointer.
 *
 * @param[in] pMemory - pointer to the memory to match 
 * @param[in] pMemoryHandle - Memory Handle
 *
 * @return Pointer to the MMMallocType element if found else NULL
 */  
static MMMallocType* MM_MallocFindEntry(const void *pMemory, 
                                        MMMemoryHandle *pMemoryHandle)
{
  unsigned int i;

  if( pMemory != NULL )
  {
    /* Search through the table to find the entry corresponding to the pointer */
    for( i = 0; i < SIZE_OF_MEM_DEBUG_ARRAY; i++ )
    {
      if( pMemoryHandle->m_mallocTable[i].pointer == pMemory )
      {
        /* Found the entry.  Return it. */
        return (pMemoryHandle->m_mallocTable + i);
      }
    }
  }
  
  /* Error reporting */
  return NULL;
}

/* 
 * Helper function that removes a mem alloc entry to the qtv_malloc_table given a
 * previously added/allocated memory pointer.  In addition keeps track of total
 * allocated byte counts.
 *
 * @param[in] pEntry - pointer to the MMMallocType to be reset
 * @param[in] pMemoryHandle - Memory Handle
 */
static void MM_MallocDeleteEntry(MMMallocType *pEntry,
                                 MMMemoryHandle *pMemoryHandle)
{
  if( pEntry != NULL )
  {
    /* Decrement the number of bytes allocated by Qtv */
    pMemoryHandle->m_nCurrBytes -= pEntry->bytes;

    /* Clear out the old contents.  Must set 'pointer' field to NULL to let it
     * be reused. */
    memset( pEntry, 0, sizeof(*pEntry) );
  }
}

/*
 * Walk through the array of currently valid allocations.  Report via diag
 * a summary of the items, and information about each one.
 *
 * Outputs one message for the number of allocated items and the total
 * allocated size.  Then outputs N indented messages for each still-allocated
 * item.
 *
 * @param[in] pMemoryHandle - Memory Handle
 */
static void MM_DumpAllocated(MMMemoryHandle *pMemoryHandle)
{
  int index;

  if( pMemoryHandle == &gMMMemoryHandle )
  {
    MM_MSG_PRIO( MM_STATISTICS, MM_PRIO_HIGH, "MM_Memory begin dump (global)" );
  }
  else
  {
    MM_MSG_PRIO1( MM_STATISTICS, MM_PRIO_HIGH, "MM_Memory begin dump (%x)",
                  pMemoryHandle );
  }
  MM_MSG_PRIO2( MM_STATISTICS, MM_PRIO_HIGH,
                "MM_Memory total=%d, peek=%d",
                pMemoryHandle->m_nTotalBytes, pMemoryHandle->m_nPeekBytes );
  
  for( index = 0; index < SIZE_OF_MEM_DEBUG_ARRAY; index++ )
  {
    if(pMemoryHandle->m_mallocTable[index].pointer != NULL)
    {
      MM_MSG_SPRINTF_PRIO_4( MM_STATISTICS, MM_PRIO_HIGH,
                             "MM_Memory Leak detected - [%s:%d] ptr=%x size=%d",
                             pMemoryHandle->m_mallocTable[index].file, 
                             pMemoryHandle->m_mallocTable[index].line,
                             pMemoryHandle->m_mallocTable[index].pointer, 
                             pMemoryHandle->m_mallocTable[index].bytes );
      MM_MallocDeleteEntry(&pMemoryHandle->m_mallocTable[index], 
                            pMemoryHandle);
    }
  }
  MM_MSG_PRIO( MM_STATISTICS, MM_PRIO_HIGH, "MM_Memory end dump" );

  pMemoryHandle->m_nCurrBytes    = 0; 
  pMemoryHandle->m_nPeekBytes     = 0;
  pMemoryHandle->m_nTotalBytes   = 0;
}

#endif // FEATURE_MM_MEMORY_DEBUG

/**
 * This function mallocs the memory of requested size.
 * 
 *  This function should not be called directly, instead, call MM_Malloc().
 * 
 * @param[in] size - memory size requested
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 * 
 * @return void* a pointer to memory
 */
void * MM_malloc(size_t size, const char *file, int line)
{
  #ifdef FEATURE_MM_MEMORY_DEBUG
  MM_TRUNCATE_FILE_PATH(file);
  if (gMMMemoryHandle.m_hLock)
  {
    void *pMemory = NULL;
    pMemory = malloc(size);
    MM_CriticalSection_Enter(gMMMemoryHandle.m_hLock);
    MM_MallocAddEntry(pMemory, size, file, line, &gMMMemoryHandle);
    MM_CriticalSection_Leave(gMMMemoryHandle.m_hLock);
    return pMemory;
  }
  else
  {
    return malloc(size);
  }  
  #else
  (void)file;
  (void)line;
  return malloc(size);
  #endif //FEATURE_MM_MEMORY_DEBUG
}

/*
 * This function reallocs the memory for requested size and
 * returns the new pointer.
 * 
 * This function should not be called directly, instead, call MM_Realloc().
 * 
 * @param[in] pMemory - pointer to old memory
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 * 
 * @return void* a pointer to memory
 */
void * MM_realloc(void *pOldMemory , size_t size, const char *file, int line)
{                                                                          
  #ifdef FEATURE_MM_MEMORY_DEBUG
  MM_TRUNCATE_FILE_PATH(file);
  if (gMMMemoryHandle.m_hLock)
  {
    void *pMemory = NULL;
    MMMallocType *pEntry;
    MM_CriticalSection_Enter(gMMMemoryHandle.m_hLock);
    pEntry = MM_MallocFindEntry( pOldMemory, &gMMMemoryHandle );
    /* Error checking */
    if( pEntry == NULL )
    {
      MM_MSG_SPRINTF_PRIO_4( MM_STATISTICS, MM_PRIO_ERROR,
                             "MM_Memory Unable to find malloc on realloc: "
                             "[%s:%d] ptr=%d, %d bytes",
                             file, line, pOldMemory, size );
    }
    else
    {
      MM_MallocDeleteEntry(pEntry, &gMMMemoryHandle);
      pMemory = realloc(pOldMemory, size);
      MM_MallocAddEntry(pMemory, size, file, line, &gMMMemoryHandle);
    }
    MM_CriticalSection_Leave(gMMMemoryHandle.m_hLock);
    return pMemory;
  }
  else
  {
    return realloc(pOldMemory, size);
  }
  #else
  (void)file;
  (void)line;
  return realloc(pOldMemory, size);
  #endif //FEATURE_MM_MEMORY_DEBUG
}

/**
 * This function frees the memory allocated using MM_malloc or
 * MM_realloc
 * 
 *  This function should not be called directly, instead, call MM_Free().
 * 
 * @param[in] pMemory - pointer to the memory
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 */
void MM_free(void *pMemory, const char *file, int line)
{
  #ifdef FEATURE_MM_MEMORY_DEBUG
  MM_TRUNCATE_FILE_PATH(file);
  if (gMMMemoryHandle.m_hLock)
  {
    MMMallocType *pEntry;
    MM_CriticalSection_Enter(gMMMemoryHandle.m_hLock);
    pEntry = MM_MallocFindEntry( pMemory, &gMMMemoryHandle );
    /* Error checking */
    if( pEntry == NULL )
    {
      MM_MSG_SPRINTF_PRIO_3( MM_STATISTICS, MM_PRIO_ERROR,
                             "MM_Memory Unable to find malloc on free: [%s:%d] ptr=%d",
                             file, line, pMemory );
    }
    else 
    {
      MM_MallocDeleteEntry(pEntry, &gMMMemoryHandle);
      free(pMemory);
    }
    MM_CriticalSection_Leave(gMMMemoryHandle.m_hLock);
  }
  else
  {
    free(pMemory);
  }
  #else
  free(pMemory);
  (void)file;
  (void)line;
  #endif // FEATURE_MM_MEMORY_DEBUG

  return;
}

/* 
 * Allocate memory from the heap.  This function replaces the standard C++ 'new'
 * operator in order to track memory usage.
 *
 * This function should not be called directly, instead, call MM_New()
 *
 * @param[in] pMemory - pointer to the memory
 * @param[in] size  - number of bytes
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 * 
 */
void *MM_new
(
  void* pMemory, 
  size_t size, 
  const char *file, 
  int line
)
{
  #ifdef FEATURE_MM_MEMORY_DEBUG
  MM_TRUNCATE_FILE_PATH(file);
  if( pMemory != NULL )
  {
    if (gMMMemoryHandle.m_hLock)
    {
      MM_CriticalSection_Enter(gMMMemoryHandle.m_hLock);
      MM_MallocAddEntry(pMemory, size, file, line, &gMMMemoryHandle);
      MM_CriticalSection_Leave(gMMMemoryHandle.m_hLock);
    }
  }
  #else
  (void)size;
  (void)file;
  (void)line;
  #endif // FEATURE_MM_MEMORY_DEBUG

  return(pMemory);
}

/* 
 * Free memory back to the heap to be reused later.  This function assumes that
 * the memory has already been deleted.  This function just keeps track of
 * information for debugging memory errors.
 *
 * This function should not be called directly, instead, call MM_Delete()
 *
 * @param[in] pMemory - pointer to the memory
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 * 
 */
void MM_delete
(
  void* pMemory, 
  const char *file, 
  int line
)
{
  #ifdef FEATURE_MM_MEMORY_DEBUG
  MM_TRUNCATE_FILE_PATH(file);
  if (gMMMemoryHandle.m_hLock)
  {
    MMMallocType *pEntry;
    MM_CriticalSection_Enter(gMMMemoryHandle.m_hLock);
    pEntry = MM_MallocFindEntry( pMemory, &gMMMemoryHandle );
    /* Error checking */
    if( pEntry == 0 )
    {
      MM_MSG_SPRINTF_PRIO_3( MM_STATISTICS, MM_PRIO_ERROR,
                             "MM_Memory Unable to find malloc on free: "
                             "[%s:%d] ptr=%d",
                             file, line, pMemory );
    }
    else
    {
      MM_MallocDeleteEntry(pEntry, &gMMMemoryHandle);
    }
    MM_CriticalSection_Leave(gMMMemoryHandle.m_hLock);
  }
  #else
  (void)pMemory;
  (void)file;
  (void)line;
  #endif // FEATURE_MM_MEMORY_DEBUG
}


/*
 * Initialize the information needed to start logging the memory details
 *
 * @return zero when successfull else failure
 */
int MM_Memory_InitializeCheckPoint( void )
{
  #ifdef FEATURE_MM_MEMORY_DEBUG
  if (numMemDebugLockRefs == 0 )
  {
    if ( MM_CriticalSection_Create(&gMMMemoryHandle.m_hLock) == 0 )
    {
      numMemDebugLockRefs = 1;
    }
    else
    {
      return 1;
    }
  }
  else if (gMMMemoryHandle.m_hLock)
  {
    MM_CriticalSection_Enter(gMMMemoryHandle.m_hLock);
    numMemDebugLockRefs++;
    MM_CriticalSection_Leave(gMMMemoryHandle.m_hLock);
  }
  return 0;
  #else
  return 1;
  #endif // FEATURE_MM_MEMORY_DEBUG
}

/*
 * Releases a memory check point and prints leaks if any
 *
 * @return zero when successfull else failure
 */
int MM_Memory_ReleaseCheckPoint( void )
{
  #ifdef FEATURE_MM_MEMORY_DEBUG
  MM_HANDLE memDebugLockCopy = NULL;
  if (gMMMemoryHandle.m_hLock)
  {
    MM_CriticalSection_Enter(gMMMemoryHandle.m_hLock);

    if (numMemDebugLockRefs == 1)
    {
      //Back up memDebugLock, NULL it out and release
      //the copy (note that memDebugLock would not have
      //been added to MMMallocTable when created)
      MM_DumpAllocated(&gMMMemoryHandle);
      numMemDebugLockRefs = 0;
      memDebugLockCopy = gMMMemoryHandle.m_hLock;
      gMMMemoryHandle.m_hLock = NULL;
      MM_CriticalSection_Leave(memDebugLockCopy);
      MM_CriticalSection_Release(memDebugLockCopy);
    }
    else
    {
      --numMemDebugLockRefs;
      MM_CriticalSection_Leave(gMMMemoryHandle.m_hLock);
    }
  }
  return 0;
  #else
  return 1;
  #endif // FEATURE_MM_MEMORY_DEBUG
}

/*
 * Creates a memory pool, the handle returned can used to allocate and free
 * memory from this pool
 *
 * @param[in] nType - the type of the heap/memory that is be used
 * @param[in] pData - any additonal data that is needed to initialize the heap
 *                    the data depends on the type of the pool used (nType)
 *               MM_MEMORY_POOL_TYPE_REGULAR takes NULL pData
 * @param[out] pHandle - handle of the memory pool on success
 *
 * @return zero when successfull else failure
 */
int MM_Memory_Initialize( int nType, void *pData, MM_HANDLE *pHandle )
{
  int nReturn = 1;
  if( nType == MM_MEMORY_POOL_TYPE_DEFAULT && pHandle )
  {
    MMMemoryHandle *pMemoryHandle = MM_Malloc(sizeof(MMMemoryHandle));
    if( pMemoryHandle )
    {
      memset( pMemoryHandle, 0, sizeof(MMMemoryHandle) );
      #ifdef FEATURE_MM_MEMORY_DEBUG
      if ( MM_CriticalSection_Create( &pMemoryHandle->m_hLock ) == 0 )
      {
        *pHandle = pMemoryHandle;
        nReturn = 0;
      }
      else
      {
        MM_Free(pMemoryHandle);
      }
      #else /* FEATURE_MM_MEMORY_DEBUG */
      *pHandle = pMemoryHandle;
      nReturn = 0;
      #endif /* FEATURE_MM_MEMORY_DEBUG */
    }
  }
  return nReturn;
}

/*
 * Releases a memory pool, no further memory allocations and releases can be
 * done on this pool. If the debug feature is enabled the memory statistcs and
 * leaks will be sent to the deugu interface
 *
 * @param[in] handle - handle of the memory pool that needs to be deleted
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 *
 * @return zero when successfull else failure
 */
int MM_Memory_Deinitialize( MM_HANDLE handle )
{
  int nReturn = 1;
  if( handle )
  {
    #ifdef FEATURE_MM_MEMORY_DEBUG
    MM_DumpAllocated(handle);
    MM_CriticalSection_Release(((MMMemoryHandle *)handle)->m_hLock );
    #endif /* FEATURE_MM_MEMORY_DEBUG */
    MM_Free(handle);
    nReturn = 0;
  }
  return nReturn;
}

/**
 * This function mallocs the memory of requested size.
 * 
 *  This function should not be called directly, instead, call MM_Malloc().
 * 
 * @param[in] handle - handle of the memory pool
 * @param[in] size - memory size requested
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 * 
 * @return void* a pointer to memory
 */
void * MM_mallocEx(MM_HANDLE handle, size_t size, const char *file, int line)
{
  #ifdef FEATURE_MM_MEMORY_DEBUG
  void *pMemory = NULL;
  MM_TRUNCATE_FILE_PATH(file);
  if( handle )
  {
     MMMemoryHandle *pHandle = handle;
     MMMemoryHeader *pHeader = malloc(sizeof(MMMemoryHeader) + size);
     if(pHeader)                                 
     {
       /* store the header information */
       pHeader->m_magicNumber = MM_MEMORY_MAGIC_NUMBER;
       pHeader->m_handle = pHandle;
       /* the user is provided with the address following MMMemoryHeader */
       pMemory = ((unsigned  char *)pHeader) + sizeof(MMMemoryHeader);
       MM_CriticalSection_Enter(pHandle->m_hLock);
       MM_MallocAddEntry(pMemory, size, file, line, pHandle);
       MM_CriticalSection_Leave(pHandle->m_hLock);
     }
  }  
  return pMemory;
  #else
  (void)file;
  (void)line;
  return malloc(size);
  #endif //FEATURE_MM_MEMORY_DEBUG
}

/*
 * This function reallocs the memory for requested size and
 * returns the new pointer.
 * 
 * This function should not be called directly, instead, call MM_Realloc().
 * 
 * @param[in] handle - handle of the memory pool
 * @param[in] pMemory - pointer to old memory
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 * 
 * @return void* a pointer to memory
 */
void * MM_reallocEx(MM_HANDLE handle, void *pOldMemory , size_t size, 
                    const char *file, int line)
{                                                                          
  #ifdef FEATURE_MM_MEMORY_DEBUG
  void *pMemory = NULL;
  MM_TRUNCATE_FILE_PATH(file);
  if( handle )
  {
    MMMallocType *pEntry;
    MMMemoryHandle *pHandle = handle;
    MMMemoryHeader *pMemoryHeader = 
      (MMMemoryHeader *)(((unsigned char *)pOldMemory) - sizeof(MMMemoryHeader));
    if( pMemoryHeader == NULL || pMemoryHeader->m_handle != pHandle ||
        pMemoryHeader->m_magicNumber != MM_MEMORY_MAGIC_NUMBER )
    {
      MM_MSG_SPRINTF_PRIO_4( MM_STATISTICS, MM_PRIO_ERROR,
                             "MM_Memory Invalid realloc: [%s:%d] ptr=%x, %d",
                             file, line, pOldMemory, pMemoryHeader );
    }
    else
    {
      MM_CriticalSection_Enter(pHandle->m_hLock);
      pEntry = MM_MallocFindEntry( pOldMemory, pHandle );
      if( pEntry == NULL )
      {
        MM_MSG_SPRINTF_PRIO_4( MM_DEBUG, MM_PRIO_ERROR,
                               "MM_Memory Unable to find malloc on realloc: "
                               "[%s:%d] ptr=%d, %d bytes",
                               file, line, pOldMemory, size );
      }
      else
      {
        MM_MallocDeleteEntry(pEntry, pHandle);
        pMemoryHeader = realloc(pMemoryHeader, sizeof(MMMemoryHeader) + size);
        if( pMemoryHeader )                           
        {                        
          pMemory = pMemoryHeader + sizeof(MMMemoryHeader);
          MM_MallocAddEntry(pMemory, size, file, line, pHandle);
        }   
      }
      MM_CriticalSection_Leave(pHandle->m_hLock);
    }
  }
  else
  {
    MM_MSG_SPRINTF_PRIO_4( MM_STATISTICS, MM_PRIO_ERROR,
                           "MM_Memory NULL handle on realloc: [%s:%d] ptr=%d, %d bytes",
                           file, line, pOldMemory, size );
  }
  return pMemory;
  #else
  (void)file;
  (void)line;
  return realloc(pOldMemory, size);
  #endif //FEATURE_MM_MEMORY_DEBUG
}

/**
 * This function frees the memory allocated using MM_MallocEx or
 * MM_reallocEx
 * 
 *  This function should not be called directly, instead, call
 *  MM_FreeEx().
 * 
 * @param[in] pMemory - pointer to the memory
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 */
void MM_freeEx(void *pMemory, const char *file, int line)
{
  #ifdef FEATURE_MM_MEMORY_DEBUG
  MM_TRUNCATE_FILE_PATH(file);
  if (pMemory)
  {
    MMMemoryHeader *pMemoryHeader = 
      (MMMemoryHeader *)(((unsigned char *)pMemory) - sizeof(MMMemoryHeader));
    if( pMemoryHeader && pMemoryHeader->m_handle && 
        pMemoryHeader->m_magicNumber == MM_MEMORY_MAGIC_NUMBER )
    {
      MMMallocType *pEntry;
      MMMemoryHandle *pMemoryHandle = pMemoryHeader->m_handle;
      MM_CriticalSection_Enter(pMemoryHandle->m_hLock);
      pEntry = MM_MallocFindEntry( pMemory, pMemoryHandle );
      /* Error checking */
      if( pEntry == NULL )
      {
        MM_MSG_SPRINTF_PRIO_3( MM_STATISTICS, MM_PRIO_ERROR,
                               "MM_Memory Unable to find malloc for free: [%s:%d] ptr=%d",
                               file, line, pMemory );
      }
      else 
      {
        MM_MallocDeleteEntry( pEntry, pMemoryHandle );
        free(pMemoryHeader);
      }
      MM_CriticalSection_Leave(pMemoryHandle->m_hLock);
    }
    else
    {
      MM_MSG_SPRINTF_PRIO_4( MM_STATISTICS, MM_PRIO_ERROR,
                             "MM_Memory Invalid/Corrupt free: [%s:%d] ptr=%x, %x",
                             file, line, pMemory, pMemoryHeader );

    }
  }
  else
  {
    MM_MSG_SPRINTF_PRIO_3( MM_STATISTICS, MM_PRIO_ERROR,
                           "MM_Memory NULL handle on free: [%s:%d] ptr=%d",
                           file, line, pMemory );
  }
  #else
  free(pMemory);
  (void)file;
  (void)line;
  #endif // FEATURE_MM_MEMORY_DEBUG

  return;
}

