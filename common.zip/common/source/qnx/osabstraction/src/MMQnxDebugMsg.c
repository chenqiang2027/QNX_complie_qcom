/*===========================================================================
                          M M   W r a p p e r
                    f o r   M M   D e b u g   M s g

*//** @file MMQnxDebugMsg.c
  This file defines methods that can be used to output debug messages

Copyright (c) 2008 - 2018, 2020-2022 QUALCOMM Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*===========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/osabstraction/src/MMQnxDebugMsg.c#1 $

when       who         what, where, why
--------   ---         -------------------------------------------------------
03/15/22   yc          Increase logging buffer pages and refine log pattern for videoCore/hyp_video_be
10/02/22   ag          Add default location for mmlog during boot up
06/09/21   yc          Add dynamic logging support and change the mmlog default path
05/06/21   rz          Fix STATS slog
10/10/20   yc          Fix packed attribute on 'void *' type error
06/10/20   jz          [propagate from 820] Check log level mask before processing log message 
03/25/20   jz          [propagate from 820] Remove redundent mutex lock/unlock
12/10/18   rz          Fix logbuf refcnt increament twice
06/08/18   rz          Load mmlog.cfg from env variable MMLOG_CFG_PATH
06/21/17   rz          Fix slog2 log capture stability issue; Use consolidated slog2/slog macros 
06/24/16   am          Print message catagory in log message for identification of error messages.
05/19/16   am          Use slog instead of Dprintf for logs not intended to be routed to UART.
                       Remove encryption as no longer supported.
05/10/16   am          Enable log configuration from file.
05/10/16   am          Enable Error and Fatal error messages by default.
                       Log log mode setting and severity level to UART for debugging.
05/05/16   am          Enable individual ssid and severity log level.
04/29/16   am          Compile DIAG since support available in the build.
                       Change severity level of few messages to Debug.
                       Remove path from file names in log message.Fix slog2 initialization.
02/24/16   hl          add uart support for the bring up
12/18/15   am          Wait for diag device to be available before loading diag library.
11/17/15   am          Attempt to initialize diag if not already intiailized successfully.
07/29/15   hc          Add SLOG level support for details log level
11/19/14   am          miscellaenous fixes.
11/07/14   hc          Update fix from phone build
10/17/14   am          Execute MM_OutputDebugMessage under mutex. Also check log buffer handle before using slog2f.
10/15/14   rz          Add LogFile change mode and program name at slogf
10/14/14   rz          Add support slog2 for automotive
09/19/14   rz          Temporally disable STATS_SLOG for early video
07/14/14   rz          Port AF changes: Add encryption support for post mortem logs.
                       Add null pointer check in MM_Debug_LogBuffer_destroy.
                       Implement ring buffer for logging.
                       Replace std_strcmp with std_strncmp
07/15/13   uc          Use std typedefs.
06/25/13   am          Removed slog2.
05/02/13   am          All MSG_SSID_STATS_SLOG logs when QXDM routed to slog2 instead of slog.
05/01/13   am          change environment variables to QCMMOSALLOGMODE and QCMMOSALLOGLEVEL.
04/25/13   am          implement log filtering based on severity level enabled.
04/23/13   am          Switch default logging to slog2.
04/18/13   am          Log only error and fatal errors to slog if QXDM is set
                       as logging mode.
03/30/13   am          Dynamically load diag library to avoid build dependency
                       on diag library.
03/15/13   dwp         Insert NULL check on environment variable
02/04/13   am          Add feature to log to slog and slog2.
01/25/13   yzgao       Clean up printf()/fprintf()
02/27/12   sk          Fixed KW compiler warnings
10/21/11   che         cleanup qnpcore releated check
05/12/11   che         rewrite for qnx

============================================================================*/


/*===========================================================================
 Include Files
============================================================================*/
#include <libgen.h>
#include <pthread.h>
#include <dlfcn.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <sys/slog.h>
#include <sys/neutrino.h>
#if (_NTO_VERSION > 650)
#include <sys/slog2.h>
#endif
#include <sys/slogcodes.h>
#include <process.h>
#include <dlfcn.h>

#include "log.h"
#include "event.h"
#include "msg.h"
#include "Diag_LSM.h"

//#include "AEEstd.h" /* std typedefs, ie. byte, uint16, uint32, etc. and memcpy, memset */
#include "MMMalloc.h"
#include "MMTime.h"
#include "MMTimer.h"
#include "MMFile.h"
#include "MMError.h"
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/time.h>
#include <time.h>
#include "MMUart.h"

/* The definition in msg.h are marked undefined
   since there is a definition in MMDebugMsg.h
*/

#undef MSG_LEGACY_LOW
#undef MSG_LEGACY_MED
#undef MSG_LEGACY_HIGH
#undef MSG_LEGACY_ERROR
#undef MSG_LEGACY_FATAL

#include "dll_utils_i.h"
#include "MMDebugMsg.h"


/* -----------------------------------------------------------------------
** Defines
** ----------------------------------------------------------------------- */

#define MM_LOGBUF_MIN_SIZE  (1024)
#define MM_LOGBUF_MAX_SIZE  (2*1024*1024)


#define SLOG_MM_STATS (_SLOGC_TEST + 800)
#define SLOG_MM_MSG   (_SLOGC_TEST + 900)


#define MSG_SSID_CV_TASK    26
#define MSG_SSID_STATS_SLOG 27

#define MAX_SSID sizeof(ssidTable)/sizeof(uint16)

#define MM_MAX_DEBUG_BUFFER  256
#define MM_MAX_STR_BUF_SZ    256
#define MM_SLOG2_NUM_PAGES   32
#define MM_SLOG2_NUM_BUF     1

#define MM_NUM_SEARCH_PATHS 2


/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */
static char mmlog_file_name[MM_MAX_STR_BUF_SZ] = "mmlog.cfg";
static char mmlog_file_default_path[MM_NUM_SEARCH_PATHS][MM_MAX_STR_BUF_SZ] = { "/mnt/etc/", "/ifs/etc/" };

static uint32 logMode = LOG_MODE_SLOG2;
static boolean gDiagInitialized = FALSE;




static int MapVerbLvlSlog(unsigned int mask);

/**
  * Map QXDM log levels to slog2 levels
  *
  */
#if (_NTO_VERSION > 650)

static uint32 MapVerbLvlSlog2(unsigned int mask);

static uint32 MapVerbLvlSlog2(unsigned int mask)
{
   uint32 nRet = SLOG2_SHUTDOWN;

   switch(mask)
   {
   case MM_PRIO_LOW:
      nRet = SLOG2_DEBUG2;
      break;

   case MM_PRIO_MEDIUM:
      nRet = SLOG2_DEBUG1;
      break;

   case MM_PRIO_HIGH:
      nRet = SLOG2_INFO;
      break;

   case MM_PRIO_ERROR:
      nRet = SLOG2_ERROR;
      break;

   case MM_PRIO_FATAL:
      nRet = SLOG2_CRITICAL;
      break;

   case MM_PRIO_DEBUG:
      nRet = SLOG2_DEBUG1;
      break;
   }

   return (nRet);
}

#endif


static int MapVerbLvlSlog(unsigned int mask)
{
   uint32 nRet = _SLOG_SHUTDOWN;

   switch(mask)
   {
   case MM_PRIO_LOW:
      nRet = _SLOG_DEBUG2;
      break;

   case MM_PRIO_MEDIUM:
      nRet = _SLOG_DEBUG1;
      break;

   case MM_PRIO_HIGH:
      nRet = _SLOG_INFO;
      break;

   case MM_PRIO_ERROR:
      nRet = _SLOG_ERROR;
      break;

   case MM_PRIO_FATAL:
      nRet = _SLOG_CRITICAL;
      break;

   case MM_PRIO_DEBUG:
      nRet = _SLOG_DEBUG2;
      break;
   }

   return (nRet);
}


#if (_NTO_VERSION > 650)

static uint32 slog_verbosity_level = SLOG2_DEBUG2;

#define SLOG_PRINT( buf_handle, MSG_ID, mask, xx_fmt, ... )  \
  if( -1 == slog2f( buf_handle, MSG_ID, MapVerbLvlSlog2(mask), xx_fmt, ## __VA_ARGS__) )           \
  {                                                                                \
      slogf( _SLOG_SETCODE(MSG_ID, 2), MapVerbLvlSlog(mask), xx_fmt, ## __VA_ARGS__); \
  }

#else

static uint32 slog_verbosity_level = _SLOG_DEBUG2;

#define SLOG_PRINT( buf_handle, MSG_ID, mask, xx_fmt, ... )  \
  slogf( _SLOG_SETCODE(MSG_ID, 2), MapVerbLvlSlog(mask), xx_fmt, ## __VA_ARGS__)
#endif


/* =======================================================================

                DEFINITIONS AND DECLARATIONS FOR MODULE

This section contains definitions for constants, macros, types, variables
and other items needed by this module.

========================================================================== */

typedef struct {
 char *pBuf;
 int size;
 int idx;
 int recIdx;
 int refCnt;
}LogRingBuf_t;

static uint16 ssidTable[] =
{
    MSG_SSID_APPS_QTV_GENERAL,
    MSG_SSID_APPS_QTV_DEBUG,
    MSG_SSID_APPS_QTV_STATISTICS,
    MSG_SSID_APPS_QTV_UI_TASK,
    MSG_SSID_APPS_QTV_MP4_PLAYER,
    MSG_SSID_APPS_QTV_AUDIO_TASK,
    MSG_SSID_APPS_QTV_VIDEO_TASK,
    MSG_SSID_APPS_QTV_STREAMING,
    MSG_SSID_APPS_QTV_STREAMING,
    MSG_SSID_APPS_QTV_MPEG4_TASK,
    MSG_SSID_APPS_QTV_FILE_OPS,
    MSG_SSID_APPS_QTV_RTP,
    MSG_SSID_APPS_QTV_RTP,
    MSG_SSID_APPS_QTV_RTCP,
    MSG_SSID_APPS_QTV_RTSP,
    MSG_SSID_APPS_QTV_SDP_PARSE,
    MSG_SSID_APPS_QTV_ATOM_PARSE,
    MSG_SSID_APPS_QTV_TEXT_TASK,
    MSG_SSID_APPS_QTV_DEC_DSP_IF,
    MSG_SSID_APPS_QTV_STREAM_RECORDING,
    MSG_SSID_APPS_QTV_CONFIGURATION,
    MSG_SSID_APPS_QTV_BCAST_FLO,
    MSG_SSID_OMX_COMMON,
    MSG_SSID_QSET,
    MSG_SSID_CAMERA,
    MSG_SSID_AUDFMT,
    MSG_SSID_CV_TASK,
    MSG_SSID_STATS_SLOG
};

static char *ssidStr[] =
{
    "QTV_GENERAL",
    "QTV_DEBUG",
    "QTV_STATISTICS",
    "QTV_UI_TASK",
    "QTV_MP4_PLAYER",
    "QTV_AUDIO_TASK",
    "QTV_VIDEO_TASK",
    "QTV_STREAMING",
    "QTV_STREAMING",
    "QTV_MPEG4_TASK",
    "QTV_FILE_OPS",
    "QTV_RTP",
    "QTV_RTP",
    "QTV_RTCP",
    "QTV_RTSP",
    "QTV_SDP_PARSE",
    "QTV_ATOM_PARSE",
    "QTV_TEXT_TASK",
    "QTV_DEC_DSP_IF",
    "QTV_STREAM_RECORDING",
    "QTV_CONFIGURATION",
    "QTV_BCAST_FLO",
    "OMX_COMMON",
    "QSET",
    "CAMERA",
    "AUDFMT",
    "CV_TASK",
    "STATS_SLOG"
};

static char *levelStr[] =
{
    "MM_PRIO_LOW",
    "MM_PRIO_MEDIUM",
    "MM_PRIO_HIGH",
    "MM_PRIO_ERROR",
    "MM_PRIO_FATAL",
    "MM_PRIO_DEBUG"
};

/* simplify the level to one character for videoCore/hyp_video_be to improve log drop
 * create this struct to avoid higher cpu usage for logging
 */
static char *s_levelStr[] =
{
    "L",     //"MM_PRIO_LOW",
    "M",     //"MM_PRIO_MEDIUM",
    "H",     //"MM_PRIO_HIGH",
    "E",     //"MM_PRIO_ERROR",
    "F",     //"MM_PRIO_FATAL",
    "D"     //"MM_PRIO_DEBUG"
};


static boolean mm_debug_log_table[MM_STATS_SLOG+1][MM_PRIO_DEBUG+1];

/* Diag interface functions */
static struct {
   boolean (*pDiag_LSM_Init) (byte* pParam);
   boolean (*pDiag_LSM_DeInit)(void);
   void (*pMsg_sprintf)(const msg_const_type * const_blk,...);
   void * (*pLog_alloc) (log_code_type code, unsigned int length);
   void (*pLog_commit) (void * ptr) ;
   void (*pEvent_report_payload) (event_id_enum_type event_id, uint8 length, void *data);
} DiagFunc;


static void * LoadDiagLibrary ( void );
static void UnloadDiagLibrary (void *handle);
static int MM_Debug_LogBuffer ( int ssid, int logLevel, char *fname, int line, char *logMsg);
static int MM_Debug_Parse_Configuration( void);
static int MM_Debug_Parse_cfg_line(char *buf);
static void MM_String_Conversion(char *buf, boolean bUpper);


/* =======================================================================
**                        Class & Function Definations
** ======================================================================= */

/**
 * Initializes the Diag Interface
 *
 * @return 0 value on success else failure
 */

static pthread_mutex_t mutex = PTHREAD_RMUTEX_INITIALIZER; //support recursive call
static unsigned int gRefCnt = 0;
extern char *__progname;

#if (_NTO_VERSION > 650)
static slog2_buffer_t  buffer_handle;
#else
static void* buffer_handle = NULL;     // dummy buffer handle for slog only
#endif

static void *handle_diag = NULL;

static LogRingBuf_t *logBuf = NULL;


int MM_Debug_Set_LogModeLvl( int mode, int level )
{
   int status = 1;
   pthread_mutex_lock( &mutex );

   if ( ( mode >= LOG_MODE_NONE ) && ( mode <= LOG_MODE_UART ) )
   {
      logMode = (uint32) mode;
      slog_verbosity_level = (uint32) level;
      status = 0;
   }

   pthread_mutex_unlock( &mutex );
   return status;

}

int MM_Debug_LogBuffer_Init(int bufSize)
{
   int status = 0;
   pthread_mutex_lock( &mutex );

   if ( NULL == logBuf )
   {
      logBuf = (LogRingBuf_t *)MM_Malloc(sizeof(LogRingBuf_t));

      if (logBuf)
      {
         std_memset(logBuf, 0, sizeof(LogRingBuf_t));

         logBuf->pBuf = (char *)MM_Malloc(sizeof(char) * bufSize + 256);

         if ( logBuf->pBuf )
         {
           std_memset( logBuf->pBuf, 0, sizeof(char) * bufSize + 256 );
           logBuf->size = bufSize;
           logBuf->idx = 0;
           logBuf->recIdx = 0;
           logBuf->refCnt = 1;
         }
         else
         {
            MM_Free( logBuf );
            logBuf = NULL;
            status = 1;
         }
       }
   }
   else
   {
      logBuf->refCnt++;
   }

   if (logBuf)
   {
      SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_DEBUG, " <%s> %s - status = %d refCnt = %d", __progname, __FUNCTION__, status, logBuf->refCnt);
   }
   else
   {
      SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_DEBUG, " <%s> %s - status = %d", __progname, __FUNCTION__, status);
   }

   pthread_mutex_unlock( &mutex );
   return status;
}

/* destroy ring buffer */
int MM_Debug_LogBuffer_destroy( void )
{
   pthread_mutex_lock(&mutex);

   if ( NULL != logBuf )
   {
      if ( logBuf->refCnt > 0 )
      {
         logBuf->refCnt--;

         if ( logBuf && ( 0 == logBuf->refCnt ) )
         {
            if (logBuf->pBuf)
            {
              MM_Free ( logBuf->pBuf );
            }

            MM_Free ( logBuf );
            logBuf = NULL;
         }
      }
   }
   pthread_mutex_unlock(&mutex);
   return 0;
}

/* enable logs for ring buffer */
int MM_Debug_LogBuffer_Enable ( int ssid, int logLevel, boolean bEnable )
{
   int status = 1;
   pthread_mutex_lock(&mutex);

   if ( ( ssid >= MM_GENERAL ) && ( ssid <= MM_STATS_SLOG ) )
   {
      if ( ( logLevel >= MM_PRIO_LOW ) && ( logLevel <= MM_PRIO_DEBUG ) )
      {
         mm_debug_log_table[ssid][logLevel] = bEnable;
         status = 0;
         //SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s - %s, %s, enable = %d", __progname, __FUNCTION__, ssidStr[ssid], levelStr[logLevel], bEnable);
      }
   }

   pthread_mutex_unlock(&mutex);
   return status;
}

/* log message into ring buffer */
static int MM_Debug_LogBuffer ( int ssid, int logLevel, char *fname, int line, char *logMsg)
{
   int status = 0;

   if ( logBuf && logBuf->pBuf )
   {
    if ( ( ssid >= MM_GENERAL ) && ( ssid <= MM_STATS_SLOG ) )
    {
       if ( ( logLevel >= MM_PRIO_LOW ) && ( logLevel <= MM_PRIO_DEBUG ) )
       {
          if ( TRUE == mm_debug_log_table[ssid][logLevel] )
          {
             int len;
             unsigned long time;

             MM_Time_GetTime( &time );

             len = std_strlen( logMsg );

             if ( len > MM_MAX_STR_BUF_SZ )
             {
                len = MM_MAX_STR_BUF_SZ;
             }

             logBuf->idx = ( ( logBuf->idx + len ) > logBuf->size ) ?  0 : logBuf->idx;

             len = std_strlprintf(&logBuf->pBuf[logBuf->idx], MM_MAX_STR_BUF_SZ, "<%d> %d:%d - %s:%d: %d: %s\n" ,
                logBuf->recIdx++, ssid, logLevel, fname, line, time, logMsg);

             if ( (len > 0 ) && ( len <= MM_MAX_STR_BUF_SZ ) )
             {
                logBuf->idx += len;
             }
          }
       }
    }
   }

   return status;
}

/* dump ring buffer to specified  file  */
int MM_Debug_LogBuffer_Dump(const char *fname)
{
   int status = 1;
   MM_HANDLE  fHandle;

   pthread_mutex_lock(&mutex);

   if ( logBuf )
   {
      if ( logBuf->pBuf && (logBuf->size > 0))
      {
         char fullPathFileName[MM_MAX_STR_BUF_SZ];

         std_strlcpy( (char *)fullPathFileName, (const char *)fname, STD_ARRAY_SIZE(fullPathFileName) );

         if ( 0 == MM_File_Create((const char *)fullPathFileName, MM_FILE_CREATE_W, &fHandle) )
         {
            unsigned long fMode = MM_FILE_USER_READ | MM_FILE_USER_WRITE | MM_FILE_GROUP_READ | MM_FILE_GROUP_WRITE;

            if (0 != MM_File_ChangeMode ( fHandle, fMode ) )
            {
               SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, "<%s> MM_File_ChangeMode failed",__progname);
            }

            int nBytesWritten;
            if ( 0 != MM_File_Write(fHandle, (char *)logBuf->pBuf, (int)logBuf->size, &nBytesWritten) )
            {
                 SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR," <%s> %s - writing failed", __progname, fname);
                 status = 1;
            }
            else if (nBytesWritten != logBuf->size)
            {
                 SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s - insufficient bytes written %d out of %d", __progname, fname, nBytesWritten, logBuf->size);
                 status = 1;
              }
            else
            {
                 status = 0;
                 SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s - dumped successfully", __progname, fname);
            }

            MM_File_Release(fHandle);
         }
         else
         {
            SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> Failed to open file %s for writing", __progname, fname);
         }

      }
   }

   pthread_mutex_unlock(&mutex);
   return status;
}

static void * LoadDiagLibrary ( void )
{
   void *handle = NULL;

   memset(&DiagFunc, 0, sizeof(DiagFunc));

   handle = dlopen("libdiag_lsm.so", RTLD_LOCAL );

   if ( NULL == handle )
   {
      SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s, %d, failed to load diag_lsm.so try loading from /proc/boot/libdiag_lsm.so", __progname, std_basename(__FILE__), __LINE__);

      handle = dlopen("/proc/boot/libdiag_lsm.so", RTLD_LOCAL );
   }
   else
   {
      SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_MEDIUM, " <%s> %s, %d, loading libdiag_lsm.so successful", __progname, std_basename(__FILE__), __LINE__);
   }

   if ( NULL != handle )
   {
      int ret = 0;

      DiagFunc.pDiag_LSM_Init = dlsym(handle,"Diag_LSM_Init");
      if (NULL == DiagFunc.pDiag_LSM_Init){
         SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s, %d, can't find Diag_LSM_Init symbol", __progname, std_basename(__FILE__), __LINE__);
         ret = -1;
      }

      DiagFunc.pDiag_LSM_DeInit = dlsym(handle,"Diag_LSM_DeInit");
      if (NULL == DiagFunc.pDiag_LSM_DeInit){
         SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s, %d, can't find Diag_LSM_DeInit symbol", __progname, std_basename(__FILE__), __LINE__);
         ret = -1;
      }

      DiagFunc.pMsg_sprintf = dlsym(handle,"msg_sprintf");
      if (NULL == DiagFunc.pMsg_sprintf){
         SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s, %d, can't find msg_sprintf symbol", __progname, std_basename(__FILE__), __LINE__);
         ret = -1;
      }

      DiagFunc.pLog_alloc = dlsym(handle,"log_alloc");
      if (NULL == DiagFunc.pLog_alloc){
         SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s, %d, can't find log_alloc symbol", __progname, std_basename(__FILE__), __LINE__);
         ret = -1;
      }

      DiagFunc.pLog_commit = dlsym(handle,"log_commit");
      if (NULL == DiagFunc.pLog_commit){
         SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s, %d, can't find log_commit symbol", __progname, std_basename(__FILE__), __LINE__);
         ret = -1;
      }

      DiagFunc.pEvent_report_payload = dlsym(handle,"event_report_payload");
      if (NULL == DiagFunc.pEvent_report_payload){
         SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s, %d, can't find event_report_payload symbol", __progname, std_basename(__FILE__), __LINE__);
         ret = -1;
      }

      if ( -1 == ret )
      {
         UnloadDiagLibrary (handle);
         handle = NULL;
      }
   }
   else
   {
      char *pMsg = NULL;

      pMsg = dlerror();

      SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s, %d, failed to load diag_lsm.so", __progname, std_basename(__FILE__), __LINE__);

      if (pMsg)
      {
         SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s, %d, dlerror = %s", __progname, std_basename(__FILE__), __LINE__, pMsg);
      }
   }
   return handle;
}

static void UnloadDiagLibrary (void *handle)
{
   if (handle)
   {
      if (0 != dlclose(handle) )
      {
         char *pMsg = NULL;

         pMsg = dlerror();

         SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s, %d, failed to unload diag_lsm.so", __progname, std_basename(__FILE__), __LINE__);

         if (pMsg)
         {
            SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s, %d, dlerror = %s", __progname, std_basename(__FILE__), __LINE__, pMsg);
         }
      }
   }
   memset(&DiagFunc, 0, sizeof(DiagFunc));
}

/* Thread to initialize diag */
void* MM_Debug_DiagInit ( void * arg )
{
    (void) arg;
    SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_MEDIUM, " <%s> wait for /dev/diag",__progname);
    pthread_setname_np(pthread_self () ,  "waitfor_diag" );
    Resource_BlockWait ("/dev/diag");

    SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_MEDIUM, " <%s> /dev/diag available, load diag library",__progname);

    /* load diag library */
    handle_diag = LoadDiagLibrary();

    if ( NULL == handle_diag )
    {
       SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> pid = %d LoadDiagLibrary", __progname, getpid());
    }
    else
    {
       if ( DiagFunc.pDiag_LSM_Init )
       {
          if ( TRUE == DiagFunc.pDiag_LSM_Init ( NULL ) ) {
             gDiagInitialized = TRUE;
          }
       }
    }

    pthread_exit ( NULL ) ;
}

static void MM_String_Conversion(char *buf, boolean bUpper)
{
   int len = strlen(buf);
   int idx;

   len = (len > MM_MAX_STR_BUF_SZ) ? MM_MAX_STR_BUF_SZ : len ;

   for (idx = 0; idx < len; idx++)
   {
      buf[idx] = (bUpper) ? toupper(buf[idx]):tolower(buf[idx]);
   }
}

static int MM_Debug_Parse_cfg_line(char *buf)
{
   int status = MMOSAL_SUCCESS;
   char buf1[MM_MAX_STR_BUF_SZ];
   char buf2[MM_MAX_STR_BUF_SZ];

   if ( NULL == buf )
   {
      return ( ( int ) MMOSAL_FAILURE );
   }

   MM_String_Conversion(buf, FALSE);

   /* skip lines with # and empty lines */
   if (strstr(buf,"#") || buf[0] == '\n')
   {
      return status;
   }

   sscanf( (void *)buf, "%250s", buf1 );

   if ( 0 == std_strncmp( buf1, "logmode", std_strlen("logmode") ) )
   {
      int arg1 = 0;

      sscanf((void *)buf, "%250s %250s %d", buf1, buf2, &arg1);

      if ( 0 == std_strncmp( buf2, "qxdm", std_strlen("qxdm") ) )
      {
         SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_LOW, " <%s> %s - QXDM", __progname, __FUNCTION__);
         MM_Debug_Set_LogModeLvl( LOG_MODE_QXDM, 0 );
      }
      else if ( 0 == std_strncmp( buf2, "slog2", std_strlen("slog2") ) )
      {
         sscanf( (void *)buf, "%250s %250s %d", buf1, buf2, &arg1 );
         SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_LOW," <%s> %s - SLOG2 %d", __progname, __FUNCTION__, arg1);
         MM_Debug_Set_LogModeLvl( LOG_MODE_SLOG2, arg1 );
      }
      else if ( 0 == std_strncmp( buf2, "slog", std_strlen("slog") ) )
      {
         sscanf( (void *)buf, "%250s %250s %d", buf1, buf2, &arg1 );
         SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_LOW," <%s> %s - SLOG %d", __progname, __FUNCTION__, arg1);
         MM_Debug_Set_LogModeLvl( LOG_MODE_SLOG, arg1 );
      }
      else if ( 0 == std_strncmp( buf2, "uart", std_strlen("uart") ) )
      {
         sscanf( (void *)buf, "%250s %250s %d", buf1, buf2, &arg1 );
         SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_LOW," <%s> %s - UART %d", __progname, __FUNCTION__, arg1);
         MM_Debug_Set_LogModeLvl( LOG_MODE_UART, arg1 );
      }
      else
      {
         SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_LOW," <%s> %s - log not handled %s", __progname, __FUNCTION__, buf);
      }
   }
   else if ( 0 == std_strncmp( buf1, "setlog", std_strlen("setlog") ) )
   {
      int arg1 = 0;

      sscanf( (void *)buf, "%255s %255s", buf1, buf2 );

      if ( 0 == std_strncmp( buf2, "bufsize", std_strlen("bufsize") ) )
      {
         sscanf( (void *)buf, "%255s %255s %d", buf1, buf2, &arg1 );

         if ( ( arg1 > MM_LOGBUF_MIN_SIZE ) && ( arg1 < MM_LOGBUF_MAX_SIZE ) )
         {
             /* destroy existing buffer */
             MM_Debug_LogBuffer_destroy();

             if ( 0 != MM_Debug_LogBuffer_Init( arg1 ) )
             {
                SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s - MM_Debug_LogBuffer_Init failed for buffer size = %d", __progname, __FUNCTION__, arg1);
             }
         }
         else
         {
            SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s - MM_Debug_LogBuffer_Init failed for buffer size = %d, (min = %d, max = %d)", __progname,
              __FUNCTION__, arg1, MM_LOGBUF_MIN_SIZE, MM_LOGBUF_MAX_SIZE );
         }
         SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s - RLOG buf size = %d", __progname, __FUNCTION__, arg1);
      }
      else if ( ( 0 == std_strncmp( buf2, "enable", std_strlen("enable") ) ) ||
                    ( 0 == std_strncmp( buf2, "disable", std_strlen("disable") ) ))
      {
         int arg2 = 0;
         char buf3[MM_MAX_STR_BUF_SZ];
         char buf4[MM_MAX_STR_BUF_SZ];
         int ssid,level;
         int enable = ( 0 == std_strncmp( buf2, "enable", std_strlen("enable") ) );

         sscanf( (void *)buf, "%255s %255s %255s %255s", buf1, buf2, buf3, buf4 );

         /* convert ssid string and level string to upper case for comparison*/
         MM_String_Conversion(buf3, TRUE);
         MM_String_Conversion(buf4, TRUE);

         for (ssid= 0 ; ssid < sizeof(ssidStr)/sizeof(ssidStr[0]); ssid++)
         {
            if (0 == std_strncmp(ssidStr[ssid], buf3, std_strlen(ssidStr[ssid])))
            {
               break;
            }
         }

         for (level = 0 ; level < sizeof(levelStr)/sizeof(levelStr[0]); level++)
         {
            if (0 == std_strncmp(levelStr[level], buf4, std_strlen(levelStr[level])))
            {
               break;
            }
         }

         if ( 0 != MM_Debug_LogBuffer_Enable( ssid, level, enable ) )
         {
            SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s - Failed to enable rlog ssid = %d, level = %d", __progname, __FUNCTION__, arg1, arg2);
         }
      }
      else if ( 0 == std_strncmp( buf2, "dump", std_strlen("dump") ) )
      {
         char buf3[MM_MAX_STR_BUF_SZ];

         sscanf( (void *)buf, "%255s %255s %255s", buf1, buf2, buf3 );

         if ( 0 != MM_Debug_LogBuffer_Dump( buf3 ) )
         {
            SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s - Failed to dump rlog %s",__progname, __FUNCTION__,buf3);
         }
      }
   }
   else
   {
      SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> %s - string not handled: %s",__progname, __FUNCTION__,buf);
      status = MMOSAL_ERROR_VALUE_NOT_SUP;
   }
   return status;
}

static int MM_Debug_Parse_Configuration( void)
{
  int status = MMOSAL_SUCCESS;
  char *mmlog_file_path;
  char *buf;
  int ssid, level;
  FILE *fp = NULL;
  bool bCfgFileFound = false;

  buf =(char *) malloc(MM_MAX_STR_BUF_SZ);
  if (buf)
  {
     mmlog_file_path = getenv( "MMLOG_CFG_PATH" );

     if ( NULL != mmlog_file_path )
     {
        SLOG_PRINT(buffer_handle, SLOG_MM_MSG, MM_PRIO_HIGH, "<%s> mmlog environment variable found  %s", __progname, mmlog_file_path);
        std_strlcpy( buf, mmlog_file_path, MM_MAX_STR_BUF_SZ );
        std_strlcat( buf, mmlog_file_name, MM_MAX_STR_BUF_SZ );

        if (access(buf, F_OK ) == 0)
        {
           bCfgFileFound = true;
        }
     }

     //Use default file path if user configured path is not set 
     if (!bCfgFileFound)
     {
         SLOG_PRINT(buffer_handle, SLOG_MM_MSG, MM_PRIO_HIGH, "<%s> mmlog environment variable not found", __progname);
         for (int i = 0; i < MM_NUM_SEARCH_PATHS; i++)
         {
             memset(buf, 0, MM_MAX_STR_BUF_SZ);
             std_strlcpy(buf, mmlog_file_default_path[i], MM_MAX_STR_BUF_SZ);
             std_strlcat(buf, mmlog_file_name, MM_MAX_STR_BUF_SZ);
             SLOG_PRINT(buffer_handle, SLOG_MM_MSG, MM_PRIO_HIGH, "<%s> Checking logging config file path %s", __progname, buf);
             if (access(buf, F_OK) == 0)
             {
                 SLOG_PRINT(buffer_handle, SLOG_MM_MSG, MM_PRIO_HIGH, "<%s> Found logging config file in location %s", __progname, buf);
                 bCfgFileFound = true;
                 break;
             }
         }
     }

     if (bCfgFileFound)
     {
         fp = fopen(buf, "r");
         if (fp)
         {
             /* clear mm_debug_log_table for this time configure */
             for (ssid = 0; ssid < sizeof(ssidStr) / sizeof(ssidStr[0]); ssid++)
             {
                 for (level = 0; level < sizeof(levelStr) / sizeof(levelStr[0]); level++)
                 {
                     mm_debug_log_table[ssid][level] = FALSE;
                 }
             }

             while (NULL != fgets(buf, MM_MAX_STR_BUF_SZ, fp))
             {
                 MM_Debug_Parse_cfg_line(buf);
             }
             fclose(fp);
             SLOG_PRINT(buffer_handle, SLOG_MM_MSG, MM_PRIO_HIGH, "<%s> Completes parsing", __progname);
         }
         else
         {
             SLOG_PRINT(buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, "<%s> fp not valid", __progname);
             status = MMOSAL_ERROR_NO_SUCH_FILE;
         }
     }
     else
     {
         SLOG_PRINT(buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, "<%s> Could not find logging config file", __progname);
     }



     free (buf);
  }
  else
  {
     status = MMOSAL_ERROR_NO_MEM;
     SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR," <%s> %s - not enough memory", __progname, __FUNCTION__);
  }

  return status;
}

int MM_Debug_Initialize( void )
{
    int ret = 0;

    pthread_mutex_lock(&mutex);

    /* ret-initialize ret status code */
    ret = 0;

    if ( 0 == gRefCnt )
    {
#if (_NTO_VERSION > 650)

       char strbuf[MM_MAX_STR_BUF_SZ];
       slog2_buffer_set_config_t  buffer_config;

       /* register slog2 buffer */
       buffer_config.num_buffers = MM_SLOG2_NUM_BUF;
       buffer_config.verbosity_level = slog_verbosity_level;
       std_strlcpy(strbuf, __progname, MM_MAX_STR_BUF_SZ);
       std_strlcat(strbuf,"_QC", MM_MAX_STR_BUF_SZ);
       buffer_config.buffer_config[0].buffer_name = strbuf;
       buffer_config.buffer_set_name = strbuf;
       buffer_config.buffer_config[0].num_pages = MM_SLOG2_NUM_PAGES;
       memset(&buffer_handle, 0, sizeof(slog2_buffer_t));

       if ( strstr(strbuf, "videoCore") || strstr(strbuf, "hyp_video_be") )
       {
          buffer_config.verbosity_level = QCLOG_DEBUG1;
          buffer_config.buffer_config[0].num_pages = 128;
       }

       if ( -1 == slog2_register( &buffer_config, &buffer_handle, SLOG2_TRY_REUSE_BUFFER_SET ) )
       {
         if ( LOG_MODE_SLOG2 == logMode )
         {
            slogf( _SLOG_SETCODE(SLOG_MM_MSG, 2), _SLOG_ERROR, " <%s> %s:%d switch to SLOG ",__progname, std_basename(__FILE__), __LINE__);
            logMode = LOG_MODE_SLOG;
         }
       }
       else
       {
          SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_HIGH, " <%s> : slog2 verbose level = %d, buffer handle = 0x%p",__progname, (int)slog_verbosity_level, buffer_handle);

          if ( -1 == slog2_set_verbosity (buffer_handle, (uint8_t)slog_verbosity_level))
          {
              SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> failed to set verbosity level = %d for buffer handle = 0x%p",__progname, (int)slog_verbosity_level, buffer_handle);
          }
       }
#endif

       ret = MM_Debug_Parse_Configuration();
       if (( MMOSAL_SUCCESS != ret) && (MMOSAL_ERROR_NO_SUCH_FILE != ret))
       {
          SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, "<%s> MM_Debug_Parse_Configuration not successful, ret = %d",__progname, ret);
       }

       if ( LOG_MODE_QXDM == logMode )
       {
          pthread_t hThread;
          pthread_attr_t attrib;

          /* create thread to initialize diag */
          if ( 0 == pthread_attr_init(&attrib) )
          {
             pthread_attr_setdetachstate( &attrib, PTHREAD_CREATE_DETACHED );
             if ( 0 != pthread_create( &hThread, &attrib, &MM_Debug_DiagInit, NULL ) )
             {
                SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, "<%s> failed at create thread MM_Debug_DiagInit",__progname);
                ret = 1;
             }

             if ( 0 != pthread_attr_destroy(&attrib) )
             {
                SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, "<%s> failed to destroy thread attribute",__progname);
             }
          }
          else
          {
             SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, "<%s> failed at initialize diag thread attribute, switch to SLOG2",__progname);
             logMode = LOG_MODE_SLOG2;
          }
       }


    }

    if ( 0 == ret )
    {
      gRefCnt++;
    }

    pthread_mutex_unlock(&mutex);

    return ret;
}

/**
 * De-Initializes the Diag Interface
 *
 * @return 0 value on success else failure
 */
int MM_Debug_Deinitialize( void )
{
    int ret = 0;

    pthread_mutex_lock(&mutex);

    if ( gRefCnt > 0 )
    {
       gRefCnt--;
    }

    if ( 0 == gRefCnt )
    {
       if ( DiagFunc.pDiag_LSM_DeInit )
       {
          if ( gDiagInitialized )
          {
              if ( !DiagFunc.pDiag_LSM_DeInit() )
              {
                 SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR, " <%s> pid = %d Diag_LSM_DeInit failed", __progname, getpid());
                 ret = 1;
              }
              gDiagInitialized = FALSE;
          }
          UnloadDiagLibrary(handle_diag);
        }
    }
    pthread_mutex_unlock(&mutex);
    return ret;
}

/**
 * Reload debug config setting in run time.
 *
 * @return 0 value on success else failure
 */
int MM_Debug_Reload_Config(void)
{
    int ret = 0;

    pthread_mutex_lock(&mutex);

    ret = MM_Debug_Parse_Configuration();

    if (( MMOSAL_SUCCESS != ret) && (MMOSAL_ERROR_NO_SUCH_FILE != ret))
    {
        SLOG_PRINT( buffer_handle, SLOG_MM_MSG, MM_PRIO_ERROR,
            "<%s> MM_Debug_Parse_Configuration not successful, ret = %d",__progname, ret);
    }

    pthread_mutex_unlock(&mutex);

    return ret;
}

/*
 * Spits the message out using the right API based on the platform
 *
 * This function should not be called directly, instead, call one of the
 * defined marcos MM_MSG_XXX()
 *
 * @param[in] file, file name to be prefixed
 * @param[in] line, line number to be prefixed
 * @param[in] format, format string
 * @param[in] format arguments, variable format arguments
 *
 */

void MM_OutputDebugMessage
(
    const char* file,
    unsigned int line,
    unsigned short ssid,
    unsigned int mask,
    const char* format,
    ...
)
{
    msg_const_type msg_blk;
    char buf[MM_MAX_DEBUG_BUFFER];
    va_list arglist;
    int nSize;
    char *fname;

    if (ssid >= MAX_SSID)
    {
      SLOG_PRINT( buffer_handle, SLOG_MM_MSG + ssid, mask, " <%s> pid = %d invalid ssid parameter %d", __progname, getpid(), ssid);
      return;
    }

    if (mask > MM_PRIO_DEBUG)
    {
      SLOG_PRINT( buffer_handle, SLOG_MM_MSG + ssid, mask, " <%s> pid = %d invalid mask parameter %d", __progname, getpid(), mask);
      return;
    }

    /* If certain log level is not enabled, just skip and return */
    if (!mm_debug_log_table[ssid][mask])
    {
      return;
    }

    va_start(arglist, format);
    nSize = vsnprintf(buf, MM_MAX_DEBUG_BUFFER - 1, format, arglist);
    va_end(arglist);

    if ( nSize < 0 )
    {
        return;
    }
    else if ( ( MM_MAX_DEBUG_BUFFER - 1 ) == nSize )
    {
       buf[MM_MAX_DEBUG_BUFFER - 1] = '\0';
    }

    pthread_mutex_lock(&mutex);

    msg_blk.desc.line = line;
    msg_blk.desc.ss_id = ssidTable[ssid];
    msg_blk.desc.ss_mask = ( 1 << mask );
    msg_blk.fmt = "%s";
    msg_blk.fname = std_basename((char *)file);

    fname = std_basename((char *)file);

    /* write to ring buffer */
    MM_Debug_LogBuffer ( ssid, mask, (char *)fname, line, buf);

    if ( LOG_MODE_QXDM == logMode )
    {
       if (msg_blk.desc.ss_id == MSG_SSID_STATS_SLOG)
       {
          if (mm_debug_log_table[ssid][mask])
          {
             SLOG_PRINT( buffer_handle, SLOG_MM_MSG + ssid, mask, "%s:%s:%d:%s %s", ssidStr[ssid], fname, line, levelStr[mask], buf);
          }
       }

       if ( DiagFunc.pMsg_sprintf && gDiagInitialized )
       {
          DiagFunc.pMsg_sprintf(&msg_blk, buf);
       }

       /* log error and fatal messages only to slog2 and slog on failure.*/
       if ( ( MM_PRIO_ERROR == mask ) || ( MM_PRIO_FATAL == mask ) )
       {
             SLOG_PRINT( buffer_handle, SLOG_MM_MSG + ssid, mask, "%s:%s:%d:%s %s", ssidStr[ssid], fname, line, levelStr[mask], buf);
       }
    }
    else if ( LOG_MODE_SLOG2 == logMode || LOG_MODE_SLOG == logMode )
    {
       if ( mm_debug_log_table[ssid][mask] )
       {
          if ( strstr(__progname, "videoCore") || strstr(__progname, "hyp_video_be") )
          {
             /* just make the change available to videoCore/hyp_video_be to prevent any impacts on other components */
             SLOG_PRINT( buffer_handle, SLOG_MM_MSG + ssid, mask, "%s:%d:%s %s", fname, line, s_levelStr[mask], buf);
          }
          else
          {
             SLOG_PRINT( buffer_handle, SLOG_MM_MSG + ssid, mask, "%s:%s:%d:%s %s", ssidStr[ssid], fname, line, levelStr[mask], buf);
          }
       }
    }
    else if ( LOG_MODE_UART == logMode)
    {
        if (mm_debug_log_table[ssid][mask])
        {
            MM_Dprintf("%s:%s:%d:%s %s", ssidStr[ssid], fname, line, levelStr[mask], buf);
        }
    }

    pthread_mutex_unlock(&mutex);
}

void* MM_Log_Alloc (unsigned short code, unsigned int length)
{
   void *pRet = NULL;

    if ( DiagFunc.pLog_alloc && gDiagInitialized )
    {
       pRet = DiagFunc.pLog_alloc(code, length);
    }
    return pRet;
}

void MM_Log_Commit (void * ptr)
{
   if ( DiagFunc.pLog_commit && gDiagInitialized )
   {
      DiagFunc.pLog_commit(ptr);
   }
}

void MM_Event_Report(unsigned int event_id, unsigned char length, void *data)
{
    if ( DiagFunc.pEvent_report_payload && gDiagInitialized )
    {
      DiagFunc.pEvent_report_payload (event_id, length, data);
    }
}
