#ifndef MMUART_H
#define MMUART_H
/*===========================================================================
                          M M    W r a p p e r                            
                    f o r   M M    E r r o r   C o d e s                    

*//** @file MMUart.h
  This file has the generic error codes            
  
Copyright (c) 2016 Qualcomm Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
============================================================================*/

#ifdef __cplusplus
extern "C" {
#endif /* #ifdef __cplusplus */
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/neutrino.h>

// Assume the LK has the UART on and never off
// Otherwise, need code to program the UART

int _mm_dputs(const char *str);
int _mm_dprintf(const char *fmt, ...);

#define mm_dputc(str) do { _mm_dputc(str); } while (0)
#define mm_dputs(str) do { _mm_dputs(str); } while (0)
//#define MM_Dprintf(x...) do {  _mm_dprintf(x); } while (0)
#define MM_Dprintf(x...) do {  printf(x); printf("\n"); } while (0)

#ifdef __cplusplus
}
#endif /* #ifdef __cplusplus */
#endif//MMUART_H


