/*===========================================================================
                          M M   W r a p p e r
                    f o r   M M   N E T W O R K  C O M M U N I C A T I O N

*//** @file MMQnxNetwork.c
  This file defines methods that can be used for network communication.

Copyright (c) 2014 - 2018, 2020 QUALCOMM Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*===========================================================================
                             Edit History


when       who         what, where, why
--------   ---         ------------------------------------------------------- 
10/10/20   yc          Fix inet_addr undefined error on SDP7.1
04/05/18   rz          Fix print fmt check errors
01/02/18   rz          Fix MISRA warning 
09/09/17   rz          Fix Klocwork error 
06/26/17   rz          Add support of UDP communication protocol 
05/19/17   rz          Fix Klocwork error 
01/12/17   rz          Fix compilation warnings with format check
08/15/16   rz          Fix unexpected dlclose socket lib at close 
07/26/16   rz          Add socket based local IPC communication
11/18/15   wy          Adjust thread priority
01/09/15   hc          fixed memory leak in missing dlclose when handling error
31/08/15   hc          removed socket static link dependence
13/11/14   am          created

============================================================================*/


/*===========================================================================
 Include Files
============================================================================*/
#include <libgen.h>
#include <pthread.h>
#include <dlfcn.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <process.h>
#include <dlfcn.h>
#include "MMDebugMsg.h"
#include "AEEstd.h" /* std typedefs, ie. byte, uint16, uint32, etc. and memcpy, memset */
#include "MMMalloc.h"
#include "MMTime.h"
#include "MMFile.h"
#include "MMThread.h"
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>
#include "MMNetwork.h"
#include <net/if.h>
#include <sys/neutrino.h>
#include <sys/un.h>


#define SUN_PATH_MAX  104
#define MAX_STRING_SIZE (256)
#define SOCKET_LIBNAME  "libsocket.so.3"
#define MAX_UDP_PAYLOAD_SIZE  65507

#ifdef __cplusplus
extern "C" {
#endif

/* =======================================================================

                DEFINITIONS AND DECLARATIONS FOR MODULE

This section contains definitions for constants, macros, types, variables
and other items needed by this module.

========================================================================== */

/* =======================================================================
**                        Class & Function Definations
** ======================================================================= */

typedef enum {
   NetConnectTypeServer = 0x1,
   NetConnectTypeClient,
   LocalConnectTypeServer,
   LocalConnectTypeClient,
   NetConnectTypeMax = 0x7fffffff
}NetConnectType;

typedef int (*mmosal_socket_t)(int, int, int);
typedef int (*mmosal_setsockopt_t)(int, int, int, const void *, socklen_t);
typedef int (*mmosal_accept_t)(int, struct sockaddr *, socklen_t *);
typedef int (*mmosal_bind_t)(int, const struct sockaddr *, socklen_t);
typedef int (*mmosal_connect_t)(int, const struct sockaddr *, socklen_t);
typedef int (*mmosal_listen_t)(int, int);
typedef ssize_t (*mmosal_send_t)(int, const void *, size_t, int);
typedef ssize_t (*mmosal_recv_t)(int,  void *, size_t, int);
typedef ssize_t (*mmosal_sendto_t)(int, const void *, size_t, int, const struct sockaddr *, socklen_t);
typedef int (*mmosal_recvfrom_t)(int, void *, size_t, int, struct sockaddr *, socklen_t *);
typedef int (*mmosal_shutdown_t)(int, int);
typedef int (*mmosal_getaddrinfo_t)(const char *, const char *, const struct addrinfo *, struct addrinfo **);
typedef void (*mmosal_freeaddrinfo_t)(struct addrinfo *);
typedef char * (*mmosal_gai_strerror_t)(int);
typedef in_addr_t (*mmosal_inet_addr_t)(const char *);

// Socket interface definition

typedef struct {

   mmosal_socket_t pfSocket;

   mmosal_setsockopt_t pfSetsockopt;

   mmosal_accept_t pfAccept;

   mmosal_bind_t pfBind;

   mmosal_connect_t pfConnect;

   mmosal_listen_t pfListen;

   mmosal_send_t pfSend;

   mmosal_recv_t pfRecv;

   mmosal_sendto_t pfSendto;

   mmosal_recvfrom_t pfRecvfrom;

   mmosal_shutdown_t pfShutdown;

   mmosal_getaddrinfo_t pfGetaddrinfo;

   mmosal_freeaddrinfo_t pfFreeaddrinfo;

   mmosal_gai_strerror_t pfGai_strerror;

   mmosal_inet_addr_t pfInet_addr;

} SocketInterface;

// Network connection context definition

typedef struct {

   void * hdl;
   // socket descriptor
   int sockfd;
   
   // thread handle
   MM_HANDLE thread_handle;
   
   // connection type descriptor
   NetConnectType connectType;
   
   // network transmission protocol
   NetProtocol eProt;

   // ip address
   char ipAddress[MAX_STRING_SIZE];

   // port address
   char portAddress[MAX_STRING_SIZE];
   
   // thread loop terminator
   boolean bContinue;
   
   // local ipc channel id
   int chid;
   
   // local ipc connection id
   int coid;
   
   // remote ipc connection id
   int rcoid;
   
   // remote ipc channel id
   int rchid;
     
   // socket interface
   SocketInterface sock_if;
   
}NetCtxt;

/* -----------------------------------------------------------------------
 ** Function Declarations
 ** ----------------------------------------------------------------------- */
static int SocketInit(NetCtxt *pCtx);
static int MM_Network_Destroy( MM_HANDLE handle );


/* -----------------------------------------------------------------------
 ** Function Definition
 ** ----------------------------------------------------------------------- */
static int SocketInit(NetCtxt *pCtx)
{
   int status = 0;
   
   memset(&pCtx->sock_if, 0, sizeof(SocketInterface));
   
   pCtx->hdl = NULL;
   pCtx->hdl = dlopen(SOCKET_LIBNAME, RTLD_NOW | RTLD_GLOBAL);
   
   if( NULL == pCtx->hdl)
   {
      MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_ERROR, "%s:open socket lib failed %s", __FUNCTION__, dlerror() );
      status = -1;
   }
   

   if (0 == status)
   {
       pCtx->sock_if.pfSocket = (mmosal_socket_t)dlsym(pCtx->hdl, "socket");
       if( NULL == pCtx->sock_if.pfSocket)
       {
          MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:sym link socket failed", __FUNCTION__ );
          status = -1;
       }
   }
   
   if (0 == status)
   {
       pCtx->sock_if.pfSetsockopt = (mmosal_setsockopt_t)dlsym(pCtx->hdl, "setsockopt");
       if( NULL == pCtx->sock_if.pfSetsockopt)
       {
          MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:sym setsockopt failed", __FUNCTION__ );
          status = -1;
       }
   }
   
   if (0 == status)
   {
       pCtx->sock_if.pfAccept = (mmosal_accept_t)dlsym(pCtx->hdl, "accept");
       if( NULL == pCtx->sock_if.pfAccept)
       {
          MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:sym accept failed", __FUNCTION__ );
          status = -1;
       }
   }
   
   if (0 == status)
   {
       pCtx->sock_if.pfBind = (mmosal_bind_t)dlsym(pCtx->hdl, "bind");
       if( NULL == pCtx->sock_if.pfBind)
       {
          MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:sym bind failed", __FUNCTION__ );
          status = -1;
       }
   }
   
   if (0 == status)
   {
       pCtx->sock_if.pfConnect = (mmosal_connect_t)dlsym(pCtx->hdl, "connect");
       if( NULL == pCtx->sock_if.pfConnect)
       {
          MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:sym connect failed", __FUNCTION__ );
          status = -1;
       }
   }
   
   if (0 == status)
   {
       pCtx->sock_if.pfListen = (mmosal_listen_t)dlsym(pCtx->hdl, "listen");
       if( NULL == pCtx->sock_if.pfListen)
       {
          MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:sym listen failed", __FUNCTION__ );
          status = -1;
       }
   }

   if (0 == status)
   {
       pCtx->sock_if.pfSend = (mmosal_send_t)dlsym(pCtx->hdl, "send");
       if( NULL == pCtx->sock_if.pfSend)
       {
          MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:sym send failed", __FUNCTION__ );
          status = -1;
       }
   }
   
   if (0 == status)
   {
       pCtx->sock_if.pfRecv = (mmosal_recv_t)dlsym(pCtx->hdl, "recv");
       if( NULL == pCtx->sock_if.pfRecv)
       {
          MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:sym recv failed", __FUNCTION__ );
          status = -1;
       }
   }
   
   if (0 == status)
   {
       pCtx->sock_if.pfSendto = (mmosal_sendto_t)dlsym(pCtx->hdl, "sendto");
       if( NULL == pCtx->sock_if.pfSendto)
       {
          MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:sym sendto failed", __FUNCTION__ );
          status = -1;
       }
   }

   if (0 == status)
   {
       pCtx->sock_if.pfRecvfrom = (mmosal_recvfrom_t)dlsym(pCtx->hdl, "recvfrom");
       if( NULL == pCtx->sock_if.pfRecvfrom)
       {
          MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:sym recvfrom failed", __FUNCTION__ );
          status = -1;
       }
   }

   if (0 == status)
   {
       pCtx->sock_if.pfShutdown = (mmosal_shutdown_t)dlsym(pCtx->hdl, "shutdown");
       if( NULL == pCtx->sock_if.pfShutdown)
       {
          MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:sym shutdown failed", __FUNCTION__ );
          status = -1;
       }
   }

   if (0 == status)
   {
       pCtx->sock_if.pfGetaddrinfo = (mmosal_getaddrinfo_t)dlsym(pCtx->hdl, "getaddrinfo");
       if( NULL == pCtx->sock_if.pfGetaddrinfo)
       {
          MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:sym getaddrinfo failed", __FUNCTION__ );
          status = -1;
       }
   }
   
   if (0 == status)
   {
       pCtx->sock_if.pfFreeaddrinfo = (mmosal_freeaddrinfo_t)dlsym(pCtx->hdl, "freeaddrinfo");
       if( NULL == pCtx->sock_if.pfFreeaddrinfo)
       {
          MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:sym freeaddrinfo failed", __FUNCTION__ );
          status = -1;
       }
   }

   if (0 == status)
   {
       pCtx->sock_if.pfGai_strerror = (mmosal_gai_strerror_t)dlsym(pCtx->hdl, "gai_strerror");
       if( NULL == pCtx->sock_if.pfGai_strerror)
       {
          MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:sym gai_strerror failed", __FUNCTION__ );
          status = -1;
       }
   }

   if (0 == status)
   {
       pCtx->sock_if.pfInet_addr = (mmosal_inet_addr_t)dlsym(pCtx->hdl, "inet_addr");
       if( NULL == pCtx->sock_if.pfInet_addr)
       {
          MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:sym inet_addr failed", __FUNCTION__ );
          status = -1;
       }
   }

   if (0 == status)
   {   
      MM_MSG_PRIO(MM_GENERAL,MM_PRIO_HIGH, "Successfully open socket lib");
   }
   else
   {
      if (pCtx->hdl) 
      {
         dlclose(pCtx->hdl);
         pCtx->hdl = NULL;
      }
      
      memset(&pCtx->sock_if, 0, sizeof(SocketInterface));

      MM_MSG_PRIO(MM_GENERAL, MM_PRIO_ERROR, "open socket lib Failed");
   }
      
   return status;
}

static int MM_Network_Destroy( MM_HANDLE handle )
{
   int status = 0;

   if ( handle )
   {
      NetCtxt *pCtxt = (NetCtxt *)handle;

      pCtxt->bContinue = FALSE;

      if ( pCtxt->thread_handle )
      {
         MM_Thread_Release( pCtxt->thread_handle );
      }

      if ( pCtxt->sockfd )
      {
         pCtxt->sock_if.pfShutdown(pCtxt->sockfd, SHUT_RDWR);
         close(pCtxt->sockfd);
      }

      if ( pCtxt->coid )
      {
         if ( -1 == ConnectDetach(pCtxt->coid))
         {
             MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:ConnectDetach failed", __FUNCTION__);
             status = -1;
         }
      }

      if ( pCtxt->chid )
      {
          if (-1 == ChannelDestroy( pCtxt->chid))
          {
             MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:ChannelDestroy failed", __FUNCTION__);
             status = -1;
          }
      }

      if ( pCtxt->rcoid )
      {
         if ( -1 == ConnectDetach(pCtxt->rcoid))
         {
             MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:ConnectDetach failed", __FUNCTION__);
             status = -1;
         }
      }

      if ( pCtxt->rchid )
      {
          if (-1 == ChannelDestroy( pCtxt->rchid))
          {
             MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:ChannelDestroy failed", __FUNCTION__);
             status = -1;
          }
      }

   }
   else
   {
      MM_MSG_PRIO(MM_GENERAL, MM_PRIO_ERROR, "MM_Network_Client_Close NULL handle");
      status = -1;
   }

   return status;
}

// asynchronous server thread
static int MM_Network_WorkerThread(void *pInp)
{
   NetCtxt *pCtxt = (NetCtxt *)pInp;

   if ( pCtxt )
   {
       pCtxt->bContinue = TRUE;
       int sockfd = pCtxt->sockfd;
       int chid = pCtxt->chid;
       int rcoid = pCtxt->rcoid;

        do
        {
           int numBytes;
           MMNetworkBuffer Buf;
           struct _msg_info info;
           int rcvid;

           MM_MSG_PRIO1( MM_GENERAL, MM_PRIO_LOW, "%s: block on msg recv", __FUNCTION__  );
           
           // receive empty buffer from client to receive data from network
           rcvid = MsgReceive( chid, &Buf, sizeof(Buf), &info );
           
           if ( rcvid > 0 )
           {
               // send ack for received message
               MsgReply(rcvid, EOK, NULL, 0);
               
               // blocking receive call to read data from socket
               numBytes = pCtxt->sock_if.pfRecv( sockfd, Buf.pBuffer, Buf.nBytes-1, 0 );

               /* pass on received buffer to client */
               if ( numBytes > 0 )
               {
                  int buf[2] = {-1, -1};
                  NetBufferRx rx;

                  rx.nAllocLen = Buf.nBytes;
                  rx.nBytes = numBytes;
                  rx.pBuffer = Buf.pBuffer;
                  rx.handle = (MM_HANDLE)pCtxt;

                  /* send received data to client */
                  if ( MsgSend( rcoid, &rx, sizeof(rx), buf, sizeof(buf) ) == -1)
                  {
                     MM_MSG_PRIO1( MM_GENERAL, MM_PRIO_ERROR, "%s: failed to send msg to client", __FUNCTION__  );
                  }                  
               }
               else
               {
                  MM_MSG_PRIO2( MM_GENERAL, MM_PRIO_LOW, "%s: numBytes = %d", __FUNCTION__ , numBytes );
                  break;
               }
           }
           else
           {
              MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_ERROR, "%s:rcvid = 0x%x failed", __FUNCTION__, rcvid );
           }
           
        } while( pCtxt->bContinue );
        
        MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_LOW, "%s: thread exiting", __FUNCTION__  );
   }
   return 0;
}

int MM_Network_Server_Create( MM_HANDLE *pHandle, const NetServerCfg* pServerCfg, boolean bLocal )
{
   int status = 0;
   *pHandle = 0;

   /* allocate context memory */
   NetCtxt *pServerCtxt = (NetCtxt *)malloc( sizeof(NetCtxt) );

   if ( NULL == pServerCtxt)
   {
      MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:malloc failed", __FUNCTION__ );
      return -1;
   }
   else
   {
      /* clear context memory */
      std_memset(pServerCtxt, 0, sizeof(NetCtxt));

      if ( bLocal )
      {
         /* local server for IPC communication */
         pServerCtxt->connectType = LocalConnectTypeServer;
      }
      else
      {
         /* IP network server */
         pServerCtxt->connectType = NetConnectTypeServer;
         pServerCtxt->eProt = pServerCfg->eProt;
      }


      status = SocketInit( pServerCtxt );

      if (-1 == status)
      {
         MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_ERROR, "%s: failed to load socket lib : %s", __FUNCTION__, strerror(errno) );
      }
   }


   if ( 0 == status ) 
   {
      /* create socket */
      int sockfd = -1;

      if ( LocalConnectTypeServer == pServerCtxt->connectType )
      {
         sockfd = pServerCtxt->sock_if.pfSocket(AF_LOCAL, SOCK_STREAM, 0);
      }
      else
      {
         if ( NET_PROT_TCP == pServerCtxt->eProt ) 
         {
            sockfd = pServerCtxt->sock_if.pfSocket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
            std_strlcpy(pServerCtxt->portAddress, pServerCfg->sPortno, MAX_STRING_SIZE);
         }
         else if ( NET_PROT_UDP == pServerCtxt->eProt ) 
         {
            sockfd = pServerCtxt->sock_if.pfSocket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
            std_strlcpy(pServerCtxt->portAddress, pServerCfg->sPortno, MAX_STRING_SIZE);
         }
         else
         {
            MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "Unsupported network protocol %d", pServerCfg->eProt );
            return -1;
         }

      }

      if ( sockfd  < 0 )
      {
         MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_ERROR, "%s: failed to open socket : %s", __FUNCTION__, strerror(errno) );
         status = -1;
      }
      else
      {
         pServerCtxt->sockfd = sockfd;
         MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_MEDIUM, "created server socket %d", sockfd);
      }
   }

   if ( NetConnectTypeServer == pServerCtxt->connectType )
   {
      int setting = 1;

      /* set socket to reuse address */
      if ( 0 == status )
      {
         if ( (pServerCtxt->sock_if.pfSetsockopt(pServerCtxt->sockfd, SOL_SOCKET, SO_REUSEADDR, (void *)&setting, sizeof(setting))) < 0 )
         {
             MM_MSG_PRIO(MM_GENERAL, MM_PRIO_ERROR, "Server-setsockopt() error for SO_REUSEADDR");
             status = -1;
         }
         else
         {
            MM_MSG_PRIO(MM_GENERAL, MM_PRIO_LOW, "Server-setsockopt() success for SO_REUSEADDR");
         }
      }

      /* set socket to reuse port */
      if (0 == status)
      {   
          if ( (pServerCtxt->sock_if.pfSetsockopt(pServerCtxt->sockfd, SOL_SOCKET, SO_REUSEPORT, (void *)&setting, sizeof(setting))) < 0 )
          {
              MM_MSG_PRIO(MM_GENERAL, MM_PRIO_ERROR, "Server-setsockopt() error for SO_REUSEPORT");
              status = -1;
          }
          else
          {
             MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_LOW, "%s: Server-setsockopt() success for SO_REUSEPORT", __FUNCTION__ );
          }
      }
   }

   /* bind socket to port */
   if (0 == status)
   {   
      if ( LocalConnectTypeServer == pServerCtxt->connectType )
      {
         struct sockaddr_un serverAddress;

         std_memset(&serverAddress, 0, sizeof(serverAddress));     /* Zero out structure */
         serverAddress.sun_family = AF_LOCAL;

         std_strlcpy(serverAddress.sun_path, pServerCfg->pLocalServerPath, SUN_PATH_MAX);

         if( unlink( pServerCfg->pLocalServerPath ) )
         {
            MM_MSG_PRIO3(MM_GENERAL, MM_PRIO_ERROR, "warning: unlink() %s failed error = %d: %s", pServerCfg->pLocalServerPath, errno,strerror(errno));
         }

         /* bind to an address */
         if ( (pServerCtxt->sock_if.pfBind(pServerCtxt->sockfd, (struct sockaddr *)&serverAddress, sizeof(serverAddress))) < 0)
         {
             MM_MSG_PRIO3(MM_GENERAL, MM_PRIO_ERROR, "bind() %s failed error = %d: %s",serverAddress.sun_path, errno,strerror(errno));
             status = -1;
         }

      }
      else if ( NetConnectTypeServer == pServerCtxt->connectType )
      {
         struct sockaddr_in serverAddress;
         int portno;


         serverAddress.sin_family      = AF_INET;             /* Internet address family */
         serverAddress.sin_addr.s_addr = INADDR_ANY;
         portno = (uint16_t)atoi(pServerCtxt->portAddress);
         serverAddress.sin_port        = htons( (uint16_t)portno ); /* local port */

         /* bind to an address */
         if ( (pServerCtxt->sock_if.pfBind(pServerCtxt->sockfd, (struct sockaddr *)&serverAddress, sizeof(serverAddress))) < 0)
         {
             MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "bind() failed %s",strerror(errno));
             status = -1;
         }
         else
         {
            MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_LOW, "%s: Server socket bind() success", __FUNCTION__ );
         }
      }

   } 


   if (0 == status)
   {
      if ( LocalConnectTypeServer == pServerCtxt->connectType ||
           ( NetConnectTypeServer == pServerCtxt->connectType && 
             NET_PROT_TCP == pServerCtxt->eProt ) ) 
      {
         MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_HIGH, "%s:server: listening for connections...", __FUNCTION__ );

          /* listen for connection */
          if ( pServerCtxt->sock_if.pfListen(pServerCtxt->sockfd, SOMAXCONN) )
          {
             MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_ERROR, "listen() failed error = %d: %s", errno,strerror(errno));
             status = -1;
          }
          else
          {
             MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_MEDIUM, "%s: server listen() success", __FUNCTION__ );
          }
      }
   }

   if ( 0 == status ) 
   {
      MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_HIGH, "%s setup sever success", __FUNCTION__ );
      *pHandle = (MM_HANDLE) pServerCtxt;
   }
   else
   {
      MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s Setup sever failed start cleaning up resources ", __FUNCTION__ );

      // clean up server resources
      if ( pServerCtxt->sockfd  ) 
      {
         close( pServerCtxt->sockfd );
         pServerCtxt->sockfd = 0;
      }

      if ( pServerCtxt->hdl )
      {
         dlclose( pServerCtxt->hdl );
         pServerCtxt->hdl = 0;
      }

      if ( pServerCtxt ) 
      {
         free( pServerCtxt );
         pServerCtxt = NULL;
      }
   }

   return status;
}

int MM_Network_Server_Open( MM_HANDLE serverHandle, MM_HANDLE *pHandle, boolean bASync )
{
   int status = 0;
   *pHandle = 0;

   if( NULL == serverHandle )
   {
      MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s: NULL server handle", __FUNCTION__ );
      return -1;
   }

   NetCtxt *pClntCtxt = NULL;
   NetCtxt *pServerCtxt = (NetCtxt *) serverHandle;

   /* allocate context memory */
   pClntCtxt = (NetCtxt *)malloc( sizeof(NetCtxt) );

   if ( NULL == pClntCtxt)
   {
      MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:malloc failed", __FUNCTION__ );
      return -1;
   }
   else
   {
         /* copy from server context for socket interface */
         std_memcpy_s(pClntCtxt, sizeof(NetCtxt), pServerCtxt, sizeof(NetCtxt));
   }

   if ( LocalConnectTypeServer == pClntCtxt->connectType ||
           ( NetConnectTypeServer == pClntCtxt->connectType && 
             NET_PROT_TCP == pClntCtxt->eProt ) ) 
   {
      if (0 == status)
      {
         int fd;
         struct sockaddr *their_addr;
         socklen_t sin_size = sizeof their_addr;

         MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_HIGH, "%s: accept for connections...", __FUNCTION__ );

         /* accept incoming connection */
         fd = pServerCtxt->sock_if.pfAccept( pServerCtxt->sockfd, (struct sockaddr *)&their_addr, &sin_size);

         if ( 0 > fd )
         {
            MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:error accept", __FUNCTION__ );
            status = -1;
         }
         else
         {
            /* get socket descriptor for incoming connection */
            pClntCtxt->sockfd = fd;
            MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_HIGH, "%s: success accept for connections %d ...", __FUNCTION__, pClntCtxt->sockfd );
         }
      }

      // create thread for asynchronous operation of the server.
      if ( bASync  && ( 0 == status ) )
      {
         if ( 0 == status )
         {       
             // create channel for receiving empty buffers from client
              pClntCtxt->chid = ChannelCreate(0);

              if ( -1 == pClntCtxt->chid )
              {
                 MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:ChannelCreate failed", __FUNCTION__ );
                 status = -1;
              }
          }

          if ( 0 == status )
          {
              // connect to channel
              pClntCtxt->coid = ConnectAttach(0, 0, pClntCtxt->chid,_NTO_SIDE_CHANNEL, 0);
              if ( -1 == pClntCtxt->coid )
              {
                  MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:ConnectAttach failed", __FUNCTION__ );
                  status = -1;
              }
          }

          if ( 0 == status )
          {
              // create channel for returning filled buffers to client
              pClntCtxt->rchid = ChannelCreate(0);

              if ( -1 == pClntCtxt->rchid )
              {
                 MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:ChannelCreate failed", __FUNCTION__ );
                 status = -1;
              }
          }

          if ( 0 == status )
          {
              // create connection with remote client
              pClntCtxt->rcoid = ConnectAttach(0, 0, pClntCtxt->rchid,_NTO_SIDE_CHANNEL, 0);
              if ( -1 == pClntCtxt->rcoid )
              {
                  MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:ConnectAttach failed", __FUNCTION__ );
                  status = -1;
              }
          }

          if ( 0 == status )
          {
              // create thread for async operation
              MM_Thread_CreateEx( MM_Thread_HighPriority, 0,  MM_Network_WorkerThread,  (void*)pClntCtxt,
                 16 * 1024,   "NetworkWorkerThread",  &pClntCtxt->thread_handle);
          }
      }
   }

   if ( 0 == status)
   { 
      *pHandle = (MM_HANDLE) pClntCtxt;
   }
   else
   {
      if ( pClntCtxt ) 
      {
         /* clean up on failure */
         if (pClntCtxt->coid)   ConnectDetach(pClntCtxt->coid);
         if (pClntCtxt->chid)   ChannelDestroy(pClntCtxt->chid);          
         if (pClntCtxt->rcoid)  ConnectDetach(pClntCtxt->rcoid);
         if (pClntCtxt->rchid)  ChannelDestroy(pClntCtxt->rchid);

         if ( pClntCtxt->thread_handle )
         {
            int nExitCode;
            MM_Thread_Release( pClntCtxt->thread_handle );
            MM_Thread_Join( pClntCtxt->thread_handle, &nExitCode );
            pClntCtxt->thread_handle = NULL;
         }
         /* clean up resources */
         free( pClntCtxt );
      }
   }

   return status;
}

/* Client queue empty buffer to network server for async operation */
int MM_Network_Server_Queue_Buffer( MM_HANDLE handle, unsigned char *pBuffer, int bufSize )
{
  int status = 0;
  NetCtxt *pCtxt = (NetCtxt *)handle;  
  MMNetworkBuffer buffer;
  int buf[2] = {-1, -1};

  MM_MSG_PRIO4(MM_GENERAL, MM_PRIO_LOW, "%s:handle = 0x%p, pBuffer = 0x%p, size = %d", __FUNCTION__, handle, pBuffer, bufSize);

  buffer.pBuffer = pBuffer;
  buffer.nBytes = bufSize;
  
  /* Send empty buffers to network server */
  if (-1 == MsgSend( pCtxt->coid, &buffer, sizeof(buffer), buf, sizeof(buf) ) )
  {
     MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:MsgSend failed", __FUNCTION__ );
  }
  else
  {
      MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_LOW, "%s:MsgSend successful", __FUNCTION__ );
  }
  
  return status;
}

/* synchronous read from network server */
int MM_Network_Server_Read( MM_HANDLE handle, unsigned char *pBuffer, int bufSize)
{
   int bytesRead = -1;
   NetCtxt *pCtxt = (NetCtxt *)handle;

   if ( handle )
   {
      if ( pCtxt->sockfd )
      {
         // read from server socket
         if ( NET_PROT_TCP == pCtxt->eProt ) 
         {
            bytesRead = pCtxt->sock_if.pfRecv(pCtxt->sockfd, pBuffer, bufSize, 0);
         }
         else if ( NET_PROT_UDP == pCtxt->eProt ) 
         {
            struct sockaddr their_addr;
            socklen_t sin_size = sizeof their_addr;

            bytesRead = pCtxt->sock_if.pfRecvfrom(pCtxt->sockfd, pBuffer, bufSize, 0, &their_addr, &sin_size );
         }
         else
         {
            MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_ERROR, "%s: unsupported network protocl %d", __FUNCTION__, pCtxt->eProt );
         }

         if ( -1 == bytesRead ) 
         {
            MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_ERROR, "%s: socket recv failed %s", __FUNCTION__, strerror(errno) );
         }
      }
   }

   return bytesRead;
}

/* client async read API which blocks on buffer reading from server thread */
int MM_Network_Server_Async_Read( MM_HANDLE handle, NetBufferRx *pNetRx)
{
   NetCtxt *pCtxt = (NetCtxt *)handle;

   if ( handle && pNetRx )
   {
       struct _msg_info info;
       int rcvid;

       /* receive filled buffer from server thread */
       rcvid = MsgReceive( pCtxt->rchid, pNetRx, sizeof(*pNetRx), &info );
           
       if (rcvid > 0)
       {
          MsgReply(rcvid, EOK, NULL, 0);
       }

   }
   
   return 0;  
}


int MM_Network_Client_Open( MM_HANDLE *pHandle, const NetClientCfg* pClientCfg, boolean bLocal )
{
   int status = 0;
   NetCtxt *pCtxt = NULL;
   int sockfd = -1;


   if ( (pHandle == NULL) ||
      ( pClientCfg == NULL ) )
   {
      MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:bad parameter", __FUNCTION__);
      return -1;
   }

   *pHandle = 0;

   MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_HIGH, "%s enter", __FUNCTION__ );

   pCtxt = (NetCtxt *)malloc( sizeof(NetCtxt) );

   if ( NULL == pCtxt)
   {
      MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:malloc failed", __FUNCTION__ );
      return -1;
   }

   std_memset(pCtxt, 0, sizeof(*pCtxt));

   if ( bLocal )
   {
      pCtxt->connectType = LocalConnectTypeClient;
   }
   else
   {
      pCtxt->connectType = NetConnectTypeClient;
      pCtxt->eProt = pClientCfg->eProt;
   }

   status = SocketInit(pCtxt);
   if (-1 == status)
   {
      MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_ERROR, "%s: failed to load socket lib : %s", __FUNCTION__, strerror(errno) );
      free (pCtxt);
      return status;
   }

   struct addrinfo hints, *servinfo =  NULL;
   struct sockaddr_in servAddr;
   int rv;
   int setting = 1;

   if ( LocalConnectTypeClient == pCtxt->connectType )
   {

       /* open socket */
       if ((sockfd = pCtxt->sock_if.pfSocket(AF_LOCAL, SOCK_STREAM, 0)) < 0)
       {
          MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_ERROR, "%s: failed to open socket : %s", __FUNCTION__, strerror(errno) );
          status = -1;
       }

       if ( 0 == status  )
       {
          struct sockaddr_un serverAddress;
          std_memset(&serverAddress, 0, sizeof(serverAddress));     /* Zero out structure */

          serverAddress.sun_family = AF_LOCAL;
          std_strlcpy(serverAddress.sun_path, pClientCfg->pLocalServerPath, SUN_PATH_MAX);

          if ( pCtxt->sock_if.pfConnect ( sockfd, (struct sockaddr *)&serverAddress, sizeof(serverAddress) ) == -1 )
          {
              MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_ERROR, "%s:connect error: %s", __FUNCTION__, strerror(errno) );
              status = -1;
          }
          
       }
   }
   else if ( NetConnectTypeClient == pCtxt->connectType )
   {
      std_strlcpy(pCtxt->portAddress, pClientCfg->remote.sPortno, MAX_STRING_SIZE);
      std_strlcpy(pCtxt->ipAddress, pClientCfg->remote.pRemoteIpAddr, MAX_STRING_SIZE);

      std_memset(&hints, 0, sizeof hints);

      hints.ai_family = AF_INET;

      if ( NET_PROT_TCP == pCtxt->eProt ) 
      {
         hints.ai_socktype = SOCK_STREAM;
      }
      else if ( NET_PROT_UDP == pCtxt->eProt ) 
      {
         hints.ai_socktype = SOCK_DGRAM;
      }

      if ((rv = pCtxt->sock_if.pfGetaddrinfo(pClientCfg->remote.pRemoteIpAddr, pClientCfg->remote.sPortno, &hints, &servinfo)) != 0)
      {
         MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_ERROR, "%s:getaddrinfo: %s", __FUNCTION__, pCtxt->sock_if.pfGai_strerror(rv) );
         status = -1;
      }

      if ( 0 == status )
      {
         /* open socket */

         if ( NET_PROT_TCP == pCtxt->eProt ) 
         {
            sockfd = pCtxt->sock_if.pfSocket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
         }
         else if ( NET_PROT_UDP == pCtxt->eProt ) 
         {
            sockfd = pCtxt->sock_if.pfSocket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
         }

         if ( sockfd  < 0)
         {
            MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_ERROR, "%s: failed to open socket : %s", __FUNCTION__, strerror(errno) );
            status = -1;
         }
         else
         {
            MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_MEDIUM, "%s: open socket successfull: prot = %d", __FUNCTION__, pCtxt->eProt );
         }
      }
      else
      {
         MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_LOW, "%s: open socket successful", __FUNCTION__);
      }

      if ( 0 == status )
      {
          /* reuse address */
          if ( (pCtxt->sock_if.pfSetsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (void *)&setting, sizeof(setting))) < 0 )
          {
              MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s: setsockopt() error for SO_REUSEADDR", __FUNCTION__);
              status = -1;
          }
          else
          {
             MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_LOW, "%s: setsockopt for SO_REUSEADDR successful", __FUNCTION__);
          }
      }

      if ( 0 == status )
      {   
           /* reuse port */
          if ( (pCtxt->sock_if.pfSetsockopt(sockfd, SOL_SOCKET, SO_REUSEPORT, (void *)&setting, sizeof(setting))) < 0 )
          {
              MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s: setsockopt() error for SO_REUSEPORT", __FUNCTION__ );
              status = -1;
          }
          else
          {
             MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_LOW, "%s: setsockopt for SO_REUSEPORT successful", __FUNCTION__);
          }
      }

      if ( 0 == status )
      {   

         if ( LocalConnectTypeServer == pCtxt->connectType ||
                 ( NetConnectTypeClient == pCtxt->connectType && 
                   NET_PROT_TCP == pCtxt->eProt ) ) 
         {

            /* Construct the server address structure */
            std_memset(&servAddr, 0, sizeof(servAddr));     /* Zero out structure */
            servAddr.sin_family      = AF_INET;             /* Internet address family */
            servAddr.sin_addr.s_addr = pCtxt->sock_if.pfInet_addr(pCtxt->ipAddress);   /* Server IP address */
            servAddr.sin_port        = htons( (uint16_t)atoi(pCtxt->portAddress) ); /* Server port */

            if ( pCtxt->sock_if.pfConnect ( sockfd, (struct sockaddr *)&servAddr, sizeof(servAddr) ) == -1 )
            {
                MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_ERROR, "%s:connect error: %s", __FUNCTION__, strerror(errno) );
                status = -1;
            }
            else
            {
               MM_MSG_PRIO3(MM_GENERAL, MM_PRIO_HIGH, "%s:connect server %s port %s successful",
                            __FUNCTION__, pCtxt->ipAddress, pCtxt->portAddress );
            }
         }
       }

       if ( servinfo )
       {
          pCtxt->sock_if.pfFreeaddrinfo( servinfo );
       }
    }
    
    if (0 == status)
    {
        /* return handle on success */
        pCtxt->sockfd = sockfd;
        *pHandle = (MM_HANDLE)pCtxt;
        MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_MEDIUM, "%s:socket fd = 0x%x", __FUNCTION__, sockfd );
    }
    else
    {
        /* close socket on failure */
        if (sockfd >= 0) 
        {
           close(sockfd);
        }
        
        if (pCtxt)
        {
          free (pCtxt);
        }
    }
    
    return status;
}

int MM_Network_Client_Close( MM_HANDLE handle )
{
   int status = 0;

   if ( handle )
   {
      status = MM_Network_Destroy( handle );
   }
   else
   {
      MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:NULL handle ", __FUNCTION__);
      status = -1;
   }

   return status;
}


int MM_Network_Server_Close( MM_HANDLE handle )
{
   int status = 0;

   if ( handle )
   {
      status = MM_Network_Destroy( handle );

      free( handle );
   }
   else
   {
      MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:NULL handle ", __FUNCTION__);
      status = -1;
   }

   return status;
}


int MM_Network_Server_Destroy( MM_HANDLE handle )
{
   int status = 0;

   if ( handle )
   {
      NetCtxt *pCtxt = (NetCtxt *)handle;

      status = MM_Network_Destroy( pCtxt );

      if ( pCtxt->hdl )
      {
         // close socket lib
         if( dlclose( pCtxt->hdl ) )
         {
            MM_MSG_PRIO2(MM_GENERAL, MM_PRIO_ERROR, "%s:dlclose socket lib failed %s", __FUNCTION__, dlerror());
         }
      }

      free(pCtxt);
   }
   else
   {
      MM_MSG_PRIO1(MM_GENERAL, MM_PRIO_ERROR, "%s:NULL handle ", __FUNCTION__);
      status = -1;
   }

   return status;
}


/* client API to send buffer */
int MM_Network_Client_Send( MM_HANDLE handle, char *pBuffer, int nBytes )
{
    int status = 0;
    size_t numBytesSent;
    NetCtxt *pCtxt = (NetCtxt *)handle;

    if ( handle && pBuffer && ( nBytes > 0 ) && pCtxt && pCtxt->sockfd )
    {
       if ( ( NetConnectTypeClient == pCtxt->connectType 
              && NET_PROT_UDP == pCtxt->eProt )  )
       {
          char *pBuf = pBuffer;
          int nBytesLeft = nBytes;
          struct sockaddr_in servAddr;

          /* Construct the server address structure */
          std_memset(&servAddr, 0, sizeof(servAddr));     /* Zero out structure */
          servAddr.sin_family      = AF_INET;             /* Internet address family */
          servAddr.sin_addr.s_addr = pCtxt->sock_if.pfInet_addr(pCtxt->ipAddress);   /* Server IP address */
          servAddr.sin_port        = htons( (uint16_t)atoi(pCtxt->portAddress) ); /* Server port */

          while ( nBytesLeft ) 
          {
             int nBytesToSend = ( nBytesLeft > MAX_UDP_PAYLOAD_SIZE ) ? MAX_UDP_PAYLOAD_SIZE : nBytesLeft;

             numBytesSent =  pCtxt->sock_if.pfSendto ( pCtxt->sockfd, pBuf, nBytesToSend, 0,
                                                   (struct sockaddr *)&servAddr, sizeof(servAddr) );

             if (numBytesSent != nBytesToSend)
             {
                MM_MSG_PRIO4( MM_GENERAL, MM_PRIO_ERROR, "%s:failed to send %d bytes return %zd with %s",
                              __FUNCTION__, nBytesToSend, numBytesSent, strerror(errno) );
                status = -1;
                break;
             }

             if ( MAX_UDP_PAYLOAD_SIZE == nBytesToSend ) 
             {
                pBuf += MAX_UDP_PAYLOAD_SIZE;
             }

             nBytesLeft = ( nBytesLeft > MAX_UDP_PAYLOAD_SIZE ) ? ( nBytesLeft - MAX_UDP_PAYLOAD_SIZE ) : 0;
          }

       }
       else
       {
          numBytesSent = pCtxt->sock_if.pfSend( pCtxt->sockfd, pBuffer, nBytes, 0 );

          if (numBytesSent != nBytes)
          {
             MM_MSG_PRIO3( MM_GENERAL, MM_PRIO_ERROR, "%s:failed to send: return %zd with %s", __FUNCTION__, numBytesSent, strerror(errno) );
             status = -1;
          }
       }
    }
    else
    {
       MM_MSG_PRIO( MM_GENERAL, MM_PRIO_ERROR, "bad parameters");
       status = -1;
    }

    return status;
}

#ifdef __cplusplus
}
#endif
