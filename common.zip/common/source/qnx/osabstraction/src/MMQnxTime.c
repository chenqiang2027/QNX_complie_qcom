/*===========================================================================
                          V i d e o   W r a p p e r 
                    f o r   s y s t e m    t i m e    i n f o  

@file MMRexTime.h
  This file defines functions that can be used to obtain and convert date and
  time 

Copyright (c) 2009 - 2010 Qualcomm Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*===========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/osabstraction/src/MMQnxTime.c#1 $
$DateTime: 2023/02/14 14:42:41 $
$Change: 43697235 $

============================================================================*/


/*===========================================================================
 Include Files
============================================================================*/
#include "MMTime.h"

#include <time.h>

#include <stdio.h>
#include <stdlib.h>
#include <sys/neutrino.h>
#include <sys/select.h>
#include <errno.h>
#include <pthread.h>
#include <mqueue.h>
#include <unistd.h>
#include <assert.h>
#include <pthread.h>
#include <errno.h>
#include <stdlib.h>

/*===========================================================================*/


/*
 * Returns the system time (as a 32-bit value), the time elapsed since system was started.
 *
 * @param[out] pTime - time in millseconds
 *
 * @return zero value is success else failure
 */
int MM_Time_GetTime
(
  unsigned long *pTime
)
{
  struct timespec time;
  unsigned long msec;

  if( clock_gettime( CLOCK_MONOTONIC, &time) == -1 )
  {
    perror( "clock gettime" );
    return EXIT_FAILURE;
  }

  msec = ((unsigned long)time.tv_sec * 1000) + (((unsigned long)time.tv_nsec / 1000) /1000);

  *pTime = msec;

  return 0;
}


/*
 * Returns the system time (as a 64-bit value), the time elapsed since system was started.
 *
 * @param[out] pTime - time in millseconds
 *
 * @return zero value is success else failure
 */
int MM_Time_GetTimeEx
(
  unsigned long long *pTime
)
{
  struct timespec time;
  unsigned long long msec;

  if( clock_gettime( CLOCK_MONOTONIC, &time) == -1 )
  {
    perror( "clock gettime" );
    return EXIT_FAILURE;
  }

  msec = ((unsigned long long)time.tv_sec * 1000) + (((unsigned long long)time.tv_nsec / 1000) /1000);

  *pTime = msec;

  return 0;
}

/*
 * Returns the system time (as a 64-bit value), the time elapsed since system was started.
 *
 * @param[out] pTime - time in microseconds
 *
 * @return zero value is success else failure
 */
int MM_Time_GetTimeMicroSecondEx
(
  unsigned long long *pTime
)
{
  struct timespec time;
  unsigned long long microsec;

  if( clock_gettime( CLOCK_MONOTONIC, &time) == -1 )
  {
    perror( "clock gettime" );
    return EXIT_FAILURE;
  }

  microsec = ((unsigned long long)time.tv_sec * 1000000) + ((unsigned long long)time.tv_nsec / 1000);

  *pTime = microsec;

  return 0;
}

/**
 * @brief
 *  Retrieve the current local date and time.
 * 
 * @param[out] pMMDateTime - local time
 * 
 * @return zero value is success else failure
 */
int MM_Time_GetLocalTime(MM_Time_DateTime *pMMDateTime)
{
  int ret = 1;
  if (pMMDateTime)    
  {  
    struct tm now;
    time_t when = time(NULL);
    localtime_r(&when, &now);
  
    pMMDateTime->m_nYear = now.tm_year;
    pMMDateTime->m_nMonth = now.tm_mon;
    pMMDateTime->m_nDay = now.tm_mday;
    pMMDateTime->m_nDayOfWeek = now.tm_wday;
    pMMDateTime->m_nHour = now.tm_hour;
    pMMDateTime->m_nMinute = now.tm_min;
    pMMDateTime->m_nSecond = now.tm_sec;
    pMMDateTime->m_nMilliseconds = 0;
  
    ret = 0;
  }

  return ret;
}

/**
 * Return the Current Time since Epoch
 *
 * @param[out] pTime - time in millseconds
 *
 * @return zero value is success else failure
 */
int MM_Time_GetCurrentTimeInMilliSecsFromEpoch
(
  unsigned long long *pTime
)
{
  struct timespec time;
  unsigned long long msec;

  if( clock_gettime( CLOCK_REALTIME, &time) == -1 )
  {
    perror( "clock gettime" );
    return EXIT_FAILURE;
  }

  msec = ((unsigned long long)time.tv_sec * 1000) + (((unsigned long long)time.tv_nsec / 1000) /1000);

  *pTime = msec;

  return 0;
}

  
