#ifndef _MM_PROFILE_H_
#define _MM_PROFILE_H_

/*===========================================================================
                          V i d e o   W r a p p e r
                    f o r   p r o f i l e l o g g i n g

@file MMProfile.h
  This file defines functions that can be used to add event marks to profile log.

Copyright (c) 2014 QUALCOMM Technologies, Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*===========================================================================
                             Edit History


============================================================================*/


/*===========================================================================
 Include Files
============================================================================*/
#include <stdlib.h>
#include "AEEstd.h"

#ifdef __cplusplus
extern "C" {
#endif /* #ifdef __cplusplus */

#ifndef MM_HANDLE
#define MM_HANDLE void *
#endif

typedef enum
{
  MM_PROFILE_DOMAIN_VIDEO,
  MM_PROFILE_DOMAIN_AUDIO,
  MM_PROFILE_DOMAIN_CAMERA,
  MM_PROFILE_DOMAIN_DISPLAY,
  MM_PROFILE_DOMAIN_GRAPHICS
} MM_Profile_Domain;

/**
 * Initialize MM profiling for a client
 *
 * @param[in] handle - pointer to client handle
 *
 * @return zero value is success and -1 on failure
 */
int MM_Profile_Init
(
   MM_HANDLE *handle
);

/**
 * Deinitialize MM profiling for a client
 *
 * @param[in] handle - client handle
 *
 * @return zero value is success and -1 on failure
 */
int MM_Profile_DeInit
(
   MM_HANDLE handle
);

/**
 * configure client for MM profiling
 *
 * @param[in] handle - client handle
 * @param[in] domain - mm profiling domain
 * @param[in] bEnable - TRUE for enable and FALSE for disable
 *
 * @return zero value is success and -1 on failure
 */
int MM_Profile_Config
(
   MM_HANDLE handle,
   MM_Profile_Domain domain,
   boolean bEnable
);

/**
 * marks event id in system profiling log
 *
 * @param[in] domain - MM Profile Domain
 * @param[in] user_event_id - event id
 * @param[in] user_data - user data
 *
 * @return zero value is success and -1 on failure
 */
int MM_Profile_Insert_Mark_ID
(
   MM_HANDLE handle,
   unsigned long long event_id,
   unsigned long long user_data
);

/**
 * marks event id in system profiling log
 *
 * @param[in] domain - MM Profile Domain
 * @param[in] str - user supplied string
 *
 * @return zero value is success and -1 on failure
 */
int MM_Profile_Insert_Mark_String
(
   MM_HANDLE handle,
   const char *str
);


#ifdef __cplusplus
}
#endif /* #ifdef __cplusplus */

#endif
