#ifndef _MM_TIME_H_
#define _MM_TIME_H_

/*===========================================================================
                          V i d e o   W r a p p e r
                    f o r   s y s t e m    t i m e    i n f o

@file MMDateTimeUtils.h
  This file defines functions that can be used to obtain and convert date and
  time

Copyright (c) 2009 - 2010 Qualcomm Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*===========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/osabstraction/protected/MMTime.h#1 $
$DateTime: 2023/02/14 14:42:41 $
$Change: 43697235 $

============================================================================*/


/*===========================================================================
 Include Files
============================================================================*/

typedef struct
{
  unsigned int m_nYear;
  unsigned int m_nMonth;
  unsigned int m_nDayOfWeek;
  unsigned int m_nDay;
  unsigned int m_nHour;
  unsigned int m_nMinute;
  unsigned int m_nSecond;
  unsigned int m_nMilliseconds;

} MM_Time_DateTime;

#ifdef __cplusplus
extern "C" {
#endif /* #ifdef __cplusplus */

/**
 * Returns the system time (as a 32-bit value), the time elapsed since system was started.
 *
 * @param[out] pTime - time in millseconds
 *
 * @return zero value is success else failure
 */
int MM_Time_GetTime
(
  unsigned long *pTime
);

/**
 * Returns the system time (as a 64-bit value), the time elapsed since system was started.
 *
 * @param[out] pTime - time in millseconds
 *
 * @return zero value is success else failure
 */
int MM_Time_GetTimeEx
(
  unsigned long long *pTime
);

/**
 * Returns the system time (as a 64-bit value), the time elapsed since system was started.
 *
 * @param[out] pTime - time in microseconds
 *
 * @return zero value is success else failure
 */
int MM_Time_GetTimeMicroSecondEx
(
  unsigned long long *pTime
);

/**
 * @brief
 *  Retrieve the current local date and time.
 *
 * @param[out] pMMDateTime - local time
 *
 * @return zero value is success else failure
 */
int MM_Time_GetLocalTime(MM_Time_DateTime *pMMDateTime);

/**
 *  Returns the current UTC data and time.
 *
 * @param[out] pMMDateTime - UTC time
 *
 * @return zero value is success else failure
 */
int MM_Time_GetUTCTime(MM_Time_DateTime *pMMDateTime);

/**
 * Return the Current Time since Epoch
 *
 * @param[out] pTime - time in millseconds
 *
 *  @return zero value is success else failure
 */
int MM_Time_GetCurrentTimeInMilliSecsFromEpoch(unsigned long long *pTime);

#ifdef __cplusplus
}
#endif /* #ifdef __cplusplus */

#endif
