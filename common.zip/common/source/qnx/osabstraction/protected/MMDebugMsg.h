#ifndef MMDEBUGMSG_H
#define MMDEBUGMSG_H
/*===========================================================================
                          M M    W r a p p e r
                    f o r   M M    D e b u g   M s g

*//** @file MMDebugMsg.h
  This file defines a methods that can be used to output debug messages

Copyright (c) 2008 - 2018, 2020-2021 QUALCOMM Technologies,Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*===========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/osabstraction/protected/MMDebugMsg.h#1 $

when       who         what, where, why
--------   ---         -------------------------------------------------------
06/09/21   yc          Add dynamic logging support
03/26/21   rz          Add MM_CV_TASK ssid
04/30/20   sj          Fix compilation warnings from audio_omx
08/17/18   rz          Enforce print format check
04/05/18   rz          Add print format check
05/20/16   am          Remove encryption enable API.
09/16/14   am          Move some function definitions inside extern "C" block.
07/14/14   rz          Port AF changes: Add encryption support for post mortem logs.
                       Add api for ring buffer logging.
05/12/11   che         rewrite for qnx
05/20/11   che         replacing do{} {....} while(0) with if (pfn_xxx) check to make it robust

============================================================================*/


/*===========================================================================
 Include Files
============================================================================*/
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <libgen.h>
#include "AEEstd.h"

/* =======================================================================

                DEFINITIONS AND DECLARATIONS FOR MODULE

This section contains definitions for constants, macros, types, variables
and other items needed by this module.

========================================================================== */

/* -----------------------------------------------------------------------
** Data Declarations
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Macro Declarations
** ----------------------------------------------------------------------- */

/**
 * Note: These SSIDs in msgcfg.h which is included via msg.h
 */

// MM Message Apps
#define MM_GENERAL           0 // (MSG_SSID_APPS_QTV_GENERAL)
#define MM_DEBUG             1 // (MSG_SSID_APPS_QTV_DEBUG)
#define MM_STATISTICS        2 // (MSG_SSID_APPS_QTV_STATISTICS)
#define MM_UI_TASK           3 // (MSG_SSID_APPS_QTV_UI_TASK)
#define MM_MP4_PLAYER        4 // (MSG_SSID_APPS_QTV_MP4_PLAYER)
#define MM_AUDIO_TASK        5 // (MSG_SSID_APPS_QTV_AUDIO_TASK)
#define MM_VIDEO_TASK        6 // (MSG_SSID_APPS_QTV_VIDEO_TASK)
#define MM_STREAMING         7 // (MSG_SSID_APPS_QTV_STREAMING)
#define MM_HTTP_STREAMING    8 // (MSG_SSID_APPS_QTV_STREAMING)
#define MM_MPEG4_TASK        9 // (MSG_SSID_APPS_QTV_MPEG4_TASK)
#define MM_FILE_OPS         10 // (MSG_SSID_APPS_QTV_FILE_OPS)
#define MM_HTTP_STACK       11 // (MSG_SSID_APPS_QTV_RTP)
#define MM_RTP              12 // (MSG_SSID_APPS_QTV_RTP)
#define MM_RTCP             13 // (MSG_SSID_APPS_QTV_RTCP)
#define MM_RTSP             14 // (MSG_SSID_APPS_QTV_RTSP)
#define MM_SDP_PARSE        15 // (MSG_SSID_APPS_QTV_SDP_PARSE)
#define MM_ATOM_PARSE       16 // (MSG_SSID_APPS_QTV_ATOM_PARSE)
#define MM_TEXT_TASK        17 // (MSG_SSID_APPS_QTV_TEXT_TASK)
#define MM_DEC_DSP_IF       18 // (MSG_SSID_APPS_QTV_DEC_DSP_IF)
#define MM_STREAM_RECORDING 19 // (MSG_SSID_APPS_QTV_STREAM_RECORDING)
#define MM_CONFIGURATION    20 // (MSG_SSID_APPS_QTV_CONFIGURATION)
#define MM_BCAST_FLO        21 // (MSG_SSID_APPS_QTV_BCAST_FLO)
#define MM_OMX_COMMON       22 // (MSG_SSID_APPS_QTV_GENERAL)
#define MM_QSET             23 // (MSG_SSID_QSET)
#define MM_CAMERA           24 // (MSG_SSID_CAMERA)
#define MM_AUDFMT           25 // (MSG_SSID_AUDFMT)
#define MM_CV_TASK          26
#define MM_STATS_SLOG       27

#define MM_PRIO_LOW         0  // MSG_MASK_0
#define MM_PRIO_MEDIUM      1  // MSG_MASK_1
#define MM_PRIO_HIGH        2  // MSG_MASK_2
#define MM_PRIO_ERROR       3  // MSG_MASK_3
#define MM_PRIO_FATAL       4  // MSG_MASK_4
#define MM_PRIO_DEBUG       5  // MSG_MASK_5

#ifdef MSG_LEGACY_LOW
#undef MSG_LEGACY_LOW
#undef MSG_LEGACY_MED
#undef MSG_LEGACY_HIGH
#undef MSG_LEGACY_ERROR
#undef MSG_LEGACY_FATAL
#endif

#define MSG_LEGACY_LOW      0
#define MSG_LEGACY_MED      1
#define MSG_LEGACY_HIGH     2
#define MSG_LEGACY_ERROR    3
#define MSG_LEGACY_FATAL    4

// Log Pkt Codes Apps
#define MM_LOG1X_BASE_C                                   ((uint16) 0x1000)

/* (0x173+MM_LOG1X_BASE_C) is the last reserved log code for Qtv log code space1.
    The following is the allocated second log code space for Qtv (432-480 Qtv reserved logs)
 #define MM_LOGQTV2_RESERVED_CODES_BASE_C                 (0x1B0 + MM_LOG1X_BASE_C)
 #define MM_LOGQTV2_LAST_C                  (48 + MM_LOGQTV2_RESERVED_CODES_BASE_C)
*/

#define MM_LOGQTV_PLAYER_TIMED_TEXT_C                    (0x1B1 + MM_LOG1X_BASE_C)
#define MM_LOGQTV_FRAME_DECODE_C                         (0x1B2 + MM_LOG1X_BASE_C)
#define MM_LOGQTV_FRAME_RENDER_C                         (0x1B3 + MM_LOG1X_BASE_C)
#define MM_LOGQTV_AV_SYNC_C                              (0x1B4 + MM_LOG1X_BASE_C)
#define MM_LOGQTV_PDS2_STATS                             (0x1B6 + MM_LOG1X_BASE_C)
#define MM_LOGQTV_PDS2_GET_REQUEST                       (0x1B7 + MM_LOG1X_BASE_C)
#define MM_LOGQTV_PDS2_GET_RESP_HEADER                   (0x1B8 + MM_LOG1X_BASE_C)
#define MM_LOGQTV_PDS2_GET_RESP_PCKT                     (0x1B9 + MM_LOG1X_BASE_C) //deprecated

#define MM_LOGQTV_CMX_AUDIO_DATA_C                       (0x1BA + MM_LOG1X_BASE_C)
#define MM_LOGQTV_RTSP_OPTIONS_C                         (0x1BB + MM_LOG1X_BASE_C)
#define MM_LOGQTV_RTSP_GET_PARAMETER_C                   (0x1BC + MM_LOG1X_BASE_C)
#define MM_LOGQTV_RTSP_SET_PARAMETER_C                   (0x1BD + MM_LOG1X_BASE_C)
#define MM_LOGARM_VIDEO_DECODE_STATS                     (0x1BF + MM_LOG1X_BASE_C)
#define MM_LOGQTV_CMD_LOGGING_C                          (0x1C1 + MM_LOG1X_BASE_C)

#define MM_LOGQTV_AUDIO_FRAME_PTS_INFO_C                 (0x1C2 + MM_LOG1X_BASE_C)
#define MM_LOGQTV_VIDEO_FRAME_DECODE_INFO_C              (0x1C3 + MM_LOG1X_BASE_C)
#define MM_LOGQTV_RTCP_COMPOUND_RR_C                     (0x1C4 + MM_LOG1X_BASE_C)
#define MM_LOGQTV_FRAME_BUFFER_RELEASE_REASON_C          (0x1C5 + MM_LOG1X_BASE_C)
#define MM_LOGQTV_AUDIO_CHANNEL_SWITCH_FRAME_C           (0x1C6 + MM_LOG1X_BASE_C)

typedef struct
{
    unsigned short len;
    unsigned short code;
    unsigned long long ts;
} mm_log_hdr_type;

// Event codes
typedef enum
{
  MM_EVENT_DROP_ID = 0,

  MM_EVENT_QTV_CLIP_STARTED = 904,              /* 7 byte payload */
  MM_EVENT_QTV_CLIP_ENDED,                      /* 5 byte payload */
  MM_EVENT_QTV_SDP_PARSER_REJECT,               /* No payload */
  MM_EVENT_QTV_CLIP_PAUSE,                      /* 4 byte payload */
  MM_EVENT_QTV_CLIP_REPOSITIONING,              /* 4 byte payload */
  MM_EVENT_QTV_CLIP_ZOOM_IN,                    /* No payload */
  MM_EVENT_QTV_CLIP_ZOOM_OUT,                   /* No payload */
  MM_EVENT_QTV_CLIP_ROTATE,                     /* 4 byte payload */
  MM_EVENT_QTV_CLIP_PAUSE_RESUME,               /* 4 byte payload */
  MM_EVENT_QTV_CLIP_REPOSITION_RESUME,          /* 4 byte payload */
  MM_EVENT_QTV_DSP_INIT,                        /* No payload */
  MM_EVENT_QTV_STREAMING_SERVER_URL,            /* 22 byte payload */
  MM_EVENT_QTV_SERVER_PORTS_USED,               /* 4 byte payload */
  MM_EVENT_QTV_USING_PROXY_SERVER,              /* 6 byte payload */
  MM_EVENT_QTV_STREAMER_STATE_IDLE,             /* No payload */
  MM_EVENT_QTV_STREAMER_STATE_CONNECTING,       /* No payload */
  MM_EVENT_QTV_STREAMER_STATE_CONNECTED,        /* No payload */
  MM_EVENT_QTV_STREAMER_STATE_SETTING_TRACKS,   /* No payload */
  MM_EVENT_QTV_STREAMER_STATE_STREAMING,        /* No payload */
  MM_EVENT_QTV_STREAMER_STATE_PAUSED,           /* No payload */
  MM_EVENT_QTV_STREAMER_STATE_SUSPENDED,        /* No payload */
  MM_EVENT_QTV_STREAMER_STATE_CLOSING,          /* Np payload */
  MM_EVENT_QTV_STREAMER_CONNECTED,              /* No payload */
  MM_EVENT_QTV_STREAMER_INITSTREAM_FAIL,        /* No payload */
  MM_EVENT_QTV_BUFFERING_STARTED,               /* 5 byte payload */
  MM_EVENT_QTV_BUFFERING_ENDED,                 /* 5 byte payload */
  MM_EVENT_QTV_CLIP_FULLSCREEN,                 /* No payload */
  MM_EVENT_QTV_PS_DOWNLOAD_STARTED,             /* 8 byte payload */
  MM_EVENT_QTV_PSEUDO_STREAM_STARTED,           /* No Payload */
  MM_EVENT_QTV_PS_PLAYER_STATE_PSEUDO_PAUSE,    /* No payload */
  MM_EVENT_QTV_PS_PLAYER_STATE_PSEUDO_RESUME,   /* 4 byte payload */
  MM_EVENT_QTV_PARSER_STATE_READY,              /* 14 byte payload */
  MM_EVENT_QTV_FRAGMENT_PLAYBACK_BEGIN,         /* 2 byte payload */
  MM_EVENT_QTV_FRAGMENT_PLAYBACK_COMPLETE,      /* 2 byte payload */
  MM_EVENT_QTV_PARSER_STATE_PSEUDO_PAUSE,       /* No payload */
  MM_EVENT_QTV_PLAYER_STATE_PSEUDO_PAUSE,       /* No payload */
  MM_EVENT_QTV_PARSER_STATE_PSEUDO_RESUME,      /* 4 byte payload */
  MM_EVENT_QTV_PLAYER_STATE_PSEUDO_RESUME,      /* 4 byte payload */
  MM_EVENT_QTV_FRAGMENTED_FILE_DECODE_START,    /* 2 byte payload */
  MM_EVENT_QTV_FRAGMENTED_FILE_END_SUCCESS,     /* 2 byte payload */
  MM_EVENT_QTV_DOWNLOAD_DATA_REPORT,            /* 4 byte payload */
  MM_EVENT_QTV_VDEC_DIAG_DECODE_CALLBACK,       /* 5 byte payload */
  MM_EVENT_QTV_URL_PLAYED_IS_MULTICAST,         /* No payload */
  MM_EVENT_QTV_VDEC_DIAG_STATUS,                /* 4 byte payload */
  MM_EVENT_QTV_STREAMING_URL_OPEN,              /* 4 byte payload */
  MM_EVENT_QTV_STREAMING_URL_OPENING,           /* No payload */
  MM_EVENT_QTV_CLIP_ENDED_VER2,                 /* 13 byte payload */
  MM_EVENT_QTV_SILENCE_INSERTION_STARTED,       /* No payload */
  MM_EVENT_QTV_SILENCE_INSERTION_ENDED,         /* 8 byte payload */
  MM_EVENT_QTV_AUDIO_CHANNEL_SWITCH_FRAME,      /* 8 byte payload */
  MM_EVENT_QTV_FIRST_VIDEO_FRAME_RENDERED,      /* No payload */
  MM_EVENT_QTV_FIRST_VIDEO_I_FRAME_RENDERED,    /* No payload */
  MM_EVENT_QTV_SDP_SELECTED,                    /* No payload */
  MM_EVENT_QTV_DIAG_PLAYER_STATUS,              /* 12 byte payload */
  MM_EVENT_QTV_SILENCE_INSERTION_DURATION,      /* 4 byte payload */
  MM_EVENT_QTV_UNDEFINED_957,
  MM_EVENT_QTV_UNDEFINED_958,
  MM_EVENT_QTV_UNDEFINED_959,
  MM_EVENT_QTV_UNDEFINED_960,
  MM_EVENT_QTV_UNDEFINED_961,
  MM_EVENT_QTV_UNDEFINED_962,
  MM_EVENT_QTV_UNDEFINED_963,
  MM_EVENT_QTV_UNDEFINED_964,
  MM_EVENT_QTV_UNDEFINED_965,
  MM_EVENT_QTV_UNDEFINED_966,
  MM_EVENT_QTV_UNDEFINED_967,

  MM_EVENT_RSVD_START = 0x0800,
  MM_EVENT_RSVD_END   = 0x083F,
  MM_EVENT_LAST_ID    = 0x083F,

  MM_EVENT_MAX_ID     = 0x0FFF
} mm_event_id_enum_type;

/*---------------------------------------------------------------------------
  This macro asserts an expression and produces a DebugBreak if the
  expression is FALSE.
---------------------------------------------------------------------------*/
#ifndef NDEBUG
#define _DEBUG
#endif

#ifdef _DEBUG
#ifdef WIN32
#define MM_ASSERT(exp) ((exp)?1:DebugBreak())
#else /* #ifdef WIN32 */
#define MM_ASSERT(exp) 
#endif /* #ifdef WIN32 */
#else /* #ifdef _DEBUG */
#define MM_ASSERT(exp)
#endif /* #ifdef _DEBUG */

/* =======================================================================
**                        Class & Function Definitions
** ======================================================================= */

#ifdef __cplusplus
extern "C" {
#endif /* #ifdef __cplusplus */


/**
 * Initializes the Diag Interface
 *
 * @return 0 value on success else failure
 */
int MM_Debug_Initialize( void );

/**
 * De-Initializez the Diag Interface
 *
 * @return 0 value on success else failure
 */
int MM_Debug_Deinitialize( void );

/**
  * * Reload debug config setting in run time.
  * *
  * * @return 0 value on success else failure
  * */
int MM_Debug_Reload_Config (void);

void MM_OutputDebugMessage
(
    const char* file,
    unsigned int line,
    unsigned short ssid,
    unsigned int mask,
    const char* format,
    ...
)__attribute__ (( format (printf ,5, 6)));


void* MM_Log_Alloc (unsigned short code, unsigned int length);

void MM_Log_Commit(void* ptr);

void MM_Event_Report(unsigned int event_id, unsigned char length, void *data);

/* set log mode and level */
int MM_Debug_Set_LogModeLvl( int mode, int level );

/* init ring buffer */
int MM_Debug_LogBuffer_Init(int bufSize);

/* destroy ring buffer */
int MM_Debug_LogBuffer_destroy( void );

/* enable logging for specific ssid and log level */
int MM_Debug_LogBuffer_Enable ( int ssid, int logLevel, boolean bEnable );

/* dump ring buffer to specified file */
int MM_Debug_LogBuffer_Dump(const char *fname);

#ifdef __cplusplus
}
#endif /* #ifdef __cplusplus */

/*---------------------------------------------------------------------------
  MM_MSG_PRIO(xx_ss_mask, xx_prio, xx_fmt)
  This is the macro for messages with no parameters with priority.
---------------------------------------------------------------------------*/
#define MM_MSG_PRIO(xx_ss_id, xx_prio_mask, xx_fmt) \
    MM_OutputDebugMessage(__FILE__, __LINE__, xx_ss_id, xx_prio_mask, xx_fmt)

/*---------------------------------------------------------------------------
  MM_MSG1(xx_ss_id, xx_fmt, xx_arg1)
  Macro for messages with 1 parameter and a specific priority
---------------------------------------------------------------------------*/
#define MM_MSG_PRIO1(xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1) \
    MM_OutputDebugMessage(__FILE__, __LINE__, xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1)

/*---------------------------------------------------------------------------
  MM_MSG2(xx_ss_id, xx_fmt, xx_arg1, xx_arg2)
  Macro for messages with 2 parameters and a specific priority.
---------------------------------------------------------------------------*/
#define MM_MSG_PRIO2(xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1, xx_arg2) \
    MM_OutputDebugMessage(__FILE__, __LINE__, xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1, xx_arg2)


/*---------------------------------------------------------------------------
  This is the macro for messages with 3 parameters and a specific priority.
  MM_MSG3(xx_ss_id, xx_fmt, xx_arg1, xx_arg2, xx_arg3)
---------------------------------------------------------------------------*/
#define MM_MSG_PRIO3(xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1, xx_arg2, xx_arg3) \
    MM_OutputDebugMessage(__FILE__, __LINE__, xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1, xx_arg2, xx_arg3)

/*---------------------------------------------------------------------------
  MM_MSG_PRIO4(xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4)
  This is the macro for messages with 4 parameters and a specific priority.
  MM_msg_send_var() uses var arg list supported by the compiler.
---------------------------------------------------------------------------*/
#define MM_MSG_PRIO4(xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4) \
    MM_OutputDebugMessage(__FILE__, __LINE__, xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4)

/*---------------------------------------------------------------------------
  MM_MSG_PRIO5(xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5)
  This is the macro for messages with 5 parameters and a specific priority.
  msg_send_var() uses var arg list supported by the compiler.
---------------------------------------------------------------------------*/
#define MM_MSG_PRIO5( xx_ss_id, xx_prio_mask, xx_fmt, \
    xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5) \
    MM_OutputDebugMessage(__FILE__, __LINE__, xx_ss_id, xx_prio_mask, xx_fmt, \
    		xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5)

/*---------------------------------------------------------------------------
  MM_MSG_PRIO6(xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5, xx_arg6)
  This is the macro for messages with 6 parameters and a specific priority.
  MM_msg_send_var() uses var arg list supported by the compiler.
---------------------------------------------------------------------------*/
#define MM_MSG_PRIO6(xx_ss_id, xx_prio_mask, xx_fmt, \
    xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5, xx_arg6) \
    MM_OutputDebugMessage(__FILE__, __LINE__, xx_ss_id, xx_prio_mask, xx_fmt, \
    		xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5, xx_arg6)

/*---------------------------------------------------------------------------
  MM_MSG_PRIO7(xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5, xx_arg6, xx_arg7)
  This is the macro for messages with 7 parameters and a specific priority.
  MM_msg_send_var() uses var arg list supported by the compiler.
---------------------------------------------------------------------------*/
#define MM_MSG_PRIO7(xx_ss_id, xx_prio_mask, xx_fmt, \
    xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5, xx_arg6, xx_arg7) \
    MM_OutputDebugMessage(__FILE__, __LINE__, xx_ss_id, xx_prio_mask, xx_fmt, \
  		xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5, xx_arg6, xx_arg7)

/*---------------------------------------------------------------------------
  MM_MSG(xx_ss_id, xx_fmt)
  This is the macro for messages with no parameters and defaultpriority.
---------------------------------------------------------------------------*/
#define MM_MSG(xx_ss_id, xx_fmt) \
  MM_MSG_PRIO(xx_ss_id, MM_PRIO_HIGH, xx_fmt)

/*---------------------------------------------------------------------------
  MM_MSG1(xx_ss_id, xx_fmt, xx_arg1)
  Macro for messages with 1 parameter and defaultpriority
---------------------------------------------------------------------------*/
#define MM_MSG1(xx_ss_id, xx_fmt, xx_arg1) \
  MM_MSG_PRIO1(xx_ss_id, MM_PRIO_HIGH, xx_fmt, xx_arg1)

/*---------------------------------------------------------------------------
  MM_MSG2(xx_ss_id, xx_fmt, xx_arg1, xx_arg2)
  Macro for messages with 2 parameters and defaultpriority.
---------------------------------------------------------------------------*/
#define MM_MSG2(xx_ss_id, xx_fmt, xx_arg1, xx_arg2) \
  MM_MSG_PRIO2(xx_ss_id, MM_PRIO_HIGH, xx_fmt, xx_arg1, xx_arg2)

/*---------------------------------------------------------------------------
  MM_MSG3(xx_ss_id, xx_fmt, xx_arg1, xx_arg2, xx_arg3)
  This is the macro for messages with 3 parameters and defaultpriority.
---------------------------------------------------------------------------*/
#define MM_MSG3(xx_ss_id, xx_fmt, xx_arg1, xx_arg2, xx_arg3) \
  MM_MSG_PRIO3(xx_ss_id, MM_PRIO_HIGH, xx_fmt, xx_arg1, xx_arg2, xx_arg3)

/*---------------------------------------------------------------------------
  MM_MSG4(xx_ss_id, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4)
  This is the macro for messages with 4 parameters and defaultpriority. In
  this case the function called needs to have more than 4 parameters so it is
  going to be a slow function call.  So for this case the  MM_msg_send_var() uses
  var arg list supported by the compiler.
---------------------------------------------------------------------------*/
#define MM_MSG4(xx_ss_id, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4) \
  MM_MSG_PRIO4(xx_ss_id, MM_PRIO_HIGH, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4)

/*---------------------------------------------------------------------------
  MM_MSG5(xx_ss_id, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5)
  This is the macro for messages with 5 parameters and defaultpriority.
  msg_send_var() uses var arg list supported by the compiler.
---------------------------------------------------------------------------*/
#define MM_MSG5(xx_ss_id, xx_fmt, \
  xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5) \
  MM_MSG_PRIO5(xx_ss_id, MM_PRIO_HIGH, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5)

/*---------------------------------------------------------------------------
  MM_MSG6(xx_ss_id, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5, xx_arg6)
  This is the macro for messages with 6 parameters and defaultpriority.
  MM_msg_send_var() uses var arg list supported by the compiler.
---------------------------------------------------------------------------*/
#define MM_MSG6(xx_ss_id, xx_fmt, \
  xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5, xx_arg6) \
  MM_MSG_PRIO6(xx_ss_id, MM_PRIO_HIGH, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5, xx_arg6)

/*---------------------------------------------------------------------------
  MM_MSG7(xx_ss_id, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5, xx_arg6, xx_arg7)
  This is the macro for messages with 7 parameters and defaultpriority.
  MM_msg_send_var() uses var arg list supported by the compiler.
---------------------------------------------------------------------------*/
#define MM_MSG7(xx_ss_id, xx_fmt, \
  xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5, xx_arg6, xx_arg7) \
  MM_MSG_PRIO7(xx_ss_id, MM_PRIO_HIGH, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4, xx_arg5, xx_arg6,xx_arg7)

/*---------------------------------------------------------------------------
  MM_MSG_SPRINTF_PRIO_1(xx_ss_id,xx_fmt,xx_arg1)
  This is the macro for messages with 1 string arguments and a specific priority.
---------------------------------------------------------------------------*/
#define MM_MSG_SPRINTF_PRIO_1( xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1) \
    MM_OutputDebugMessage(__FILE__, __LINE__, xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1)

/*---------------------------------------------------------------------------
  MM_MSG_SPRINTF_2(xx_ss_id,xx_fmt,xx_arg1,arg2)
  This is the macro for messages with 1 string arguments, 1 decimal arguments
  and a specific priority.
---------------------------------------------------------------------------*/
#define MM_MSG_SPRINTF_PRIO_2(xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1, xx_arg2) \
    MM_OutputDebugMessage(__FILE__, __LINE__, xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1, xx_arg2)

/*---------------------------------------------------------------------------
  MM_MSG_SPRINTF_3(xx_ss_id,xx_fmt,xx_arg1,arg2,arg3)
  This is the macro for messages with 1 string arguments, 2 decimal arguments
  and a specific priority.
---------------------------------------------------------------------------*/
#define MM_MSG_SPRINTF_PRIO_3(xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1, xx_arg2, xx_arg3) \
    MM_OutputDebugMessage(__FILE__, __LINE__, xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1, xx_arg2, xx_arg3)

/*---------------------------------------------------------------------------
  MM_MSG_SPRINTF_4(xx_ss_id,xx_fmt,xx_arg1,arg2,arg3,arg4)
  This is the macro for messages with 1 string arguments, 3 decimal arguments
  and a specific priority.
---------------------------------------------------------------------------*/
#define MM_MSG_SPRINTF_PRIO_4(xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4) \
    MM_OutputDebugMessage(__FILE__, __LINE__, xx_ss_id, xx_prio_mask, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4)

/*---------------------------------------------------------------------------
  MM_MSG_SPRINTF_1(xx_ss_id,xx_fmt,xx_arg1)
  This is the macro for messages with 1 string argumant and default priority.
---------------------------------------------------------------------------*/
#define MM_MSG_SPRINTF_1(xx_ss_id, xx_fmt, xx_arg1) \
  MM_MSG_SPRINTF_PRIO_1(xx_ss_id, MM_PRIO_HIGH, xx_fmt, xx_arg1)

/*---------------------------------------------------------------------------
  MM_MSG_SPRINTF_2(xx_ss_id,xx_fmt,xx_arg1,arg2)
  This is the macro for messages with 1 string argument, 1 decimal arguments
  and default priority.
---------------------------------------------------------------------------*/
#define MM_MSG_SPRINTF_2(xx_ss_id, xx_fmt, xx_arg1, xx_arg2) \
  MM_MSG_SPRINTF_PRIO_2(xx_ss_id, MM_PRIO_HIGH, xx_fmt, xx_arg1, xx_arg2)

/*---------------------------------------------------------------------------
  MM_MSG_SPRINTF_3(xx_ss_id,xx_fmt,xx_arg1,arg2,arg3)
  This is the macro for messages with 1 string argument, 2 decimal arguments
  and default priority.
---------------------------------------------------------------------------*/
#define MM_MSG_SPRINTF_3(xx_ss_id, xx_fmt, xx_arg1, xx_arg2, xx_arg3) \
  MM_MSG_SPRINTF_PRIO_3(xx_ss_id, MM_PRIO_HIGH, xx_fmt, xx_arg1, xx_arg2, xx_arg3)

/*---------------------------------------------------------------------------
  MM_MSG_SPRINTF_4(xx_ss_id,xx_fmt,xx_arg1,arg2,arg3,arg4)
  This is the macro for messages with 1 string argument, 2 decimal arguments
  and default priority.
---------------------------------------------------------------------------*/
#define MM_MSG_SPRINTF_4(xx_ss_id, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4) \
  MM_MSG_SPRINTF_PRIO_4(xx_ss_id, MM_PRIO_HIGH, xx_fmt, xx_arg1, xx_arg2, xx_arg3, xx_arg4)

#define MM_MSG_PRIO_EX(xx_ss_id, xx_prio_mask, xx_fmt, ...) \
    MM_OutputDebugMessage(__FILE__, __LINE__, xx_ss_id, xx_prio_mask, xx_fmt, ## __VA_ARGS__ )

#ifdef MSG_LOW
#undef MSG_LOW
#undef MSG_MED
#undef MSG_HIGH
#undef MSG_ERROR
#undef MSG_FATAL
#endif

#define MSG_LOW(xx_fmt, a, b, c) \
  MM_MSG_PRIO3(MM_GENERAL, MM_PRIO_LOW, xx_fmt, a, b, c)

#define MSG_MED(xx_fmt, a, b, c) \
  MM_MSG_PRIO3(MM_GENERAL, MM_PRIO_MEDIUM, xx_fmt, a, b, c)

#define MSG_HIGH(xx_fmt, a, b, c) \
  MM_MSG_PRIO3(MM_GENERAL, MM_PRIO_HIGH, xx_fmt, a, b, c)

#define MSG_ERROR(xx_fmt, a, b, c) \
  MM_MSG_PRIO3(MM_GENERAL, MM_PRIO_ERROR, xx_fmt, a, b, c)

#define MSG_FATAL(xx_fmt, a, b, c) \
  MM_MSG_PRIO3(MM_GENERAL, MM_PRIO_FATAL, xx_fmt, a, b, c)

#define LOG_MODE_NONE  0
#define LOG_MODE_SLOG  1
#define LOG_MODE_SLOG2 2
#define LOG_MODE_QXDM  3
#define LOG_MODE_UART  4

#endif//MMDEBUGMSG_H
