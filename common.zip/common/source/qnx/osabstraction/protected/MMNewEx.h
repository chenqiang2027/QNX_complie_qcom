#ifndef MMNEWEX_H
#define MMNEWEX_H
/*===========================================================================
                          M M    W r a p p e r
                   f o r   C + +   M e m o r y   R o u t i n e s

*//** @file  MMMewEx.h
   This module defines routines to track and debug memory related usage

   Copyright (c) 2010 - 2011 Qualcomm Technologies Incorporated.
   All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/* =======================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/osabstraction/protected/MMNewEx.h#1 $
$DateTime: 2023/02/14 14:42:41 $
$Change: 43697235 $

========================================================================== */

/* =======================================================================
**               Includes and Public Data Declarations
** ======================================================================= */
#include "MMMemory.h"
#include "new"

/* =======================================================================
**                          Macro Definitions
** ======================================================================= */

/*
 * This macro allocates the memory from the specified pool and uses the
 * placement 'new' operator to construct an object of the requested type. The
 * memory is tracked and statistics printed if the debug feature is turned on.
 *
 * handle - MM_HANDLE returned from create function
 * type - type of object to construct
 * retptr - returns the pointer of the allocated object
 */
#define MM_NewEx(handle, type, retptr) \
{ \
  unsigned char *newptr = 0; \
  MM_MEMORY_MALLOC_WITH_PRV_DATA(handle, type, 1, newptr) \
  if ( newptr ) \
  { \
    /* call the placement new */ \
    retptr = new(newptr) type; \
    MM_MEMORY_MALLOC_VALIDATE_NEWEX(newptr, retptr) \
  } \
  else \
  { \
    retptr = 0; \
  } \
}

/*
 * This macro allocates the memory from the specified pool and uses the
 * placement 'new' operator to construct an object of the requested type. The
 * memory is tracked and statistics printed if the debug feature is turned on.
 *
 * handle - MM_HANDLE returned from create function
 * type - type of object to allocate and construct
 * args - list of arguments to pass to constructor.  MUST BE SURROUNDED BY
 *        PARENTHESES.
 * objPtr - returns the pointer of the allocated object
 */
#define MM_New_ArgsEx(handle, type, args, retptr)  \
{ \
  unsigned char *newptr = 0; \
  MM_MEMORY_MALLOC_WITH_PRV_DATA(handle, type, 1, newptr) \
  if ( newptr ) \
  { \
    /* call the placement new */ \
    retptr = new(newptr) type args; \
    MM_MEMORY_MALLOC_VALIDATE_NEWEX(newptr, retptr) \
  } \
  else \
  { \
    retptr = 0; \
  } \
}

/* Be careful with placement new on arrays. Excerpt from  C++ Standard
 * ANSI ISO IEC 14882 2003, section 5.3.4.12
 *
 * � new T[5] results in a call of operator new[](sizeof(T)*5+x), and
 * � new(2,f) T[5] results in a call of operator new[](sizeof(T)*5+y,2,f).
 * Here, x and y are non-negative unspecified values representing array
 * allocation overhead; the result of the new-expression will be offset
 * by this amount from the value returned by operator new[]. This overhead
 * may be applied in all array new-expressions, including those referencing
 * the library function operator new[](std::size_t, void*) and other placement
 * allocation functions. The amount of overhead may vary from one invocation
 * of new to another. ]
 *
 * It is clear that you should expect the placement new operator to allocate
 * additional space beyond what the array contents need. "y" is specified only
 * as a non-negative integral value. It will then offset the result of the new
 * function by this amount.
 *
 * since that offset may be different for every invocation of the array, the
 * standard basically means there is no way to allocate the exact amount of
 * size needed. In practice that value is probably constant and you could just
 * add it to the allocation, but his amount may change per platform, and again,
 * per invocation as the standard says.
 */

/*
 * This macro allocates the memory from the specified pool and uses the
 * placement 'new' operator to construct an object of the requested type. The
 * memory is tracked and statistics printed if the debug feature is turned on.
 *
 * handle - MM_HANDLE returned from create function
 * type - type of object to allocate and construct
 * num - number of elements that need to be allocated
 * retptr - returns the pointer of the allocated object
 */
#define MM_New_ArrayEx(handle, type, num, retptr) \
{ \
  retptr = (type **) MM_MallocEx(handle, sizeof(type *) * num); \
  if ( retptr ) { \
    int err = 0; \
    memset( retptr, 0, sizeof(type *) * num ); \
    for ( int i = 0; i <  num; i++ ) { \
      MM_NewEx(handle, type, (retptr[i])); \
      if ( retptr[i] == NULL ) { \
        err = 1; \
        break; \
      } \
    } \
    if ( err == 1 ) { \
      for ( int i = 0; i < num; i++ ) { \
        if ( retptr[i] ) { \
          MM_DeleteEx(retptr[i]); \
          break; \
        } \
      } \
      MM_FreeEx(retptr); \
      retptr = 0; \
    } \
  } \
} \


/*
 * This macro allocates the memory from the specified pool and uses the
 * placement 'new' operator to construct an object of the requested type. The
 * memory is tracked and statistics printed if the debug feature is turned on.
 *
 * handle - MM_HANDLE returned from create function
 * type - type of object to allocate and construct
 * args - list of arguments to pass to constructor.  MUST BE SURROUNDED BY
 *         PARENTHESES.
 * num - number of elements that need to be allocated
 * objPtr - returns the pointer of the allocated object
 */
#define MM_New_Array_ArgsEx(handle, type, args, num, retptr) \
{ \
  retptr = (type **) MM_MallocEx(handle, sizeof(type *) * num); \
  if ( retptr ) { \
    int err = 0; \
    memset( retptr, 0, sizeof(type *) * num ); \
    for ( int i = 0; i < num; i++ ) { \
      MM_New_ArgsEx(handle, type, args, (retptr[i])); \
      if ( retptr[i] == NULL ) { \
        err = 1; \
        break; \
      } \
    } \
    if ( err == 1 ) { \
      for ( int i = 0; i <  num; i++ ) { \
        if ( retptr[i] ) { \
          MM_DeleteEx(retptr[i]); \
          break; \
        } \
      } \
      MM_FreeEx(retptr); \
      retptr = 0; \
    } \
  } \
} \

/*
 * This marco calls the destructor of the object and releases the memory back to
 * pool.
 *
 * handle - MM_HANDLE of the memory pool
 * ptr - the pointer of the obj to be deleted
 */
#define MM_DeleteEx(ptr) \
{ \
  unsigned char *cptr; \
  /* get the offset between the cptr and newptr */ \
  cptr = ((unsigned char *)ptr) - MM_MEMORY_SIZEOF_PRIVATE_DATA; \
  /* call the destructor */ \
  (*(MM_Memory_DestructPtr *)(cptr))(ptr); \
  /* free the memory */ \
  MM_FreeEx(cptr); \
}

/*
 *  This marco calls the destructor of the each object in array and releases the
 *  memory back to pool.
 *
 * handle - MM_HANDLE of the memory pool
 * ptr - the pointer of the obj to be deleted
 * num - number of elements that were allocated
 */
#define MM_Delete_ArrayEx(ptr, num) \
{ \
  for ( int i = 0; i < num; i++ ) { \
      MM_DeleteEx(ptr[i]); \
  } \
  MM_FreeEx(ptr); \
} \

/*
 * Store the private data and get the new pointer can be used for placement new
 *
 * DONOT USE. NOT AN INTERFACE, FOR INTERNAL IMPL ONLY
 *
 * handle - MM_HANDLE returned from create function
 * type - type of object to construct
 * num - number of elements of the 'type' (for arrays)
 * newptr - on success returns the new pointer
 */
#define MM_MEMORY_MALLOC_WITH_PRV_DATA(handle, type, num, newptr) \
{ \
  unsigned char *cptr; \
  /* malloc size of the object + aligment offset for new + */ \
  /* function ptr for destructor + offset */ \
  cptr = (unsigned char *) MM_MallocEx( handle, ( sizeof(type) * num ) + \
                                                MM_MEMORY_SIZEOF_PRIVATE_DATA ); \
  if ( cptr ) \
  { \
    /* store a pointer to "destructor" */ \
    *(MM_Memory_DestructPtr *)cptr = MM_Memory_CallDestructor<type>;  \
    /* get the next aligned memory location for placment new */ \
    newptr = cptr + MM_MEMORY_SIZEOF_PRIVATE_DATA; \
  } \
  else \
  { \
    newptr = 0; \
  } \
}

/*
 * Validates the pointer returned by placement new is the same as what is passed
 * in, if not it is critical error.
 *
 * DONOT USE. NOT AN INTERFACE, FOR INTERNAL IMPL ONLY
 *
 * newptr - the pointer passed into placement new
 * retptr - the pointer returned by placement new
 */
#define MM_MEMORY_MALLOC_VALIDATE_NEWEX(newptr, retptr) \
if ( (void *)retptr !=  (void *)newptr ) \
{ \
  /* not expected, critical */ \
  unsigned char *cptr; \
  /* get the offset between the cptr and newptr */ \
  cptr = ((unsigned char *)newptr) - MM_MEMORY_SIZEOF_PRIVATE_DATA; \
  /* call the destructor */ \
  (*(MM_Memory_DestructPtr *)(cptr))(retptr); \
  /* free the memory */ \
  MM_FreeEx(cptr); \
  retptr = 0; \
} \

/*
 * Validates the pointer returned by placement new is the same as what is passed
 * in, if not it is critical error. Used for arrays.
 *
 * DONOT USE. NOT AN INTERFACE, FOR INTERNAL IMPL ONLY
 *
 * newptr - the pointer passed into placement new
 * retptr - the pointer returned by placement new
 */
#define MM_MEMORY_MALLOC_VALIDATE_NEW_ARRAYEX(newptr, num, retptr) \
if ( (void *)retptr !=  (void *)newptr ) \
{ \
  /* not expected, critical */ \
  unsigned char *cptr; \
  /* get the offset between the cptr and newptr */ \
  cptr = ((unsigned char *)newptr) - MM_MEMORY_SIZEOF_PRIVATE_DATA; \
  /* call the destructor */ \
  for (int i = 0; i < num; i++) \
  { \
    /* call the destructor */ \
    (*(MM_Memory_DestructPtr *)(cptr))(retptr); \
    retptr++; \
  } \
  /* free the memory */ \
  MM_FreeEx(cptr); \
  retptr = 0; \
} \

/* =======================================================================
**                        Class & Function Definations
** ======================================================================= */

#ifdef __cplusplus
/**
 * templatized destructor pointer, calls the destructor.
 * Used for calling the right destructor when using placement new
 *
 * DONOT USE. NOT AN INTERFACE, FOR INTERNAL IMPL ONLY
 *
 * @param[in] objPtr - c++ object pointer
 *
 */

template<class T>
void MM_Memory_CallDestructor(void* objPtr)
{
  ((T*)objPtr)->~T();
}

#endif /* #ifdef __cplusplus */

#endif // MMNEWEX_H
