#ifndef MMERROR_H
#define MMERROR_H
/*===========================================================================
                          M M    W r a p p e r                            
                    f o r   M M    E r r o r   C o d e s                    

*//** @file MMError.h
  This file has the generic error codes            
  
Copyright (c) 2011 - 2012 Qualcomm Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
============================================================================*/




#ifdef __cplusplus
extern "C" {
#endif /* #ifdef __cplusplus */



typedef enum
{
   MMOSAL_SUCCESS = 0,
   MMOSAL_FAILURE,   
   MMOSAL_ERROR_INVAL,
   MMOSAL_FILE_IO_PENDING,                // File IO is pending 
   MMOSAL_ERROR_FILE_IO,                  // Error in File IO
   MMOSAL_ERROR_FILE_OPEN_EXCEEDED,  //5  // Numbers of files opened excedded the limit 
   MMOSAL_ERROR_FILE_PATH_NAME_TOOLONG,   // File path name too long  
   MMOSAL_ERROR_FILE_EXISTS,              // File with same name already exists
   MMOSAL_ERROR_IS_DIRECTORY,             // It is a directory
   MMOSAL_ERROR_BAD_FILE_DESCRIPTOR,      // Bad File descriptor passed
   MMOSAL_ERROR_INTR_BY_SIGNAL, //10      // Interrupted system call  
   MMOSAL_ERROR_SEEK_NOT_PERMITTED,       // Seek operation not permitted
   MMOSAL_ERROR_FILE_OPENED,              // File or directory already open
   MMOSAL_ERROR_FILE_PIPE,                // Error in pipe
   MMOSAL_ERROR_FILE_OFFSET,              // Too large Offset
   MMOSAL_ERROR_OP_NOT_PERMITTED, //15    // Operation not permitted
   MMOSAL_ERROR_NO_SUCH_FILE,             // File does not exists
   MMOSAL_ERROR_NO_PROCESS,               // No such process
   MMOSAL_ERROR_NO_MEM,                   // Not enough spacE
   MMOSAL_ERROR_NO_RSRC,                  // Resource unavailable, try again 
   MMOSAL_ERROR_BUSY,                     // Device or resource busy
   MMOSAL_ERROR_ALREADY_OWNS_MUTEX,       // Deadlock avoided 
   MMOSAL_ERROR_TIMEDOUT,                 // Connection timed out
   MMOSAL_ERROR_VALUE_NOT_SUP,            // Not supported
}mmosal_error_codes;

/*
 * Get the last error in platform calls
 *
 * @return the error code for last platform call
 */

int MM_GetLastError( void );


#ifdef __cplusplus
}
#endif /* #ifdef __cplusplus */
#endif//MMERROR_H


