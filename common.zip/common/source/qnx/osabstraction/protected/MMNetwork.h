#ifndef MMNETWORK_H
#define MMNETWORK_H
/*===========================================================================
                          M M   W r a p p e r
                    f o r   M M   N E T W O R K  C O M M U N I C A T I O N

*//** @file MMNetwork.c
  This file defines methods that can be used for network communication.

Copyright (c)  2015-2017 QUALCOMM Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*===========================================================================
                             Edit History

$Header:

when       who         what, where, why
--------   ---         -------------------------------------------------------
08/24/17   rz          Fixed typo on unused network protocol 
08/16/17   jz          Add unused network protocol for application layer protocol definition
06/26/17   rz          Add support of UDP communication protocol 
07/26/16   rz          Add socket based local IPC communication
13/01/15   hc          Fix build issue for QNX 650 verion
13/11/14   am          created

============================================================================*/


/*===========================================================================
 Include Files
============================================================================*/
#include <libgen.h>
#include <pthread.h>
#include <dlfcn.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <sys/slog.h>
#if (_NTO_VERSION > 650)
#include <sys/slog2.h>
#endif
#include <sys/slogcodes.h>
#include <process.h>
#include "AEEstd.h" /* std typedefs, ie. byte, uint16, uint32, etc. and memcpy, memset */
#include "MMMalloc.h"
#include "MMTime.h"
#include "MMFile.h"
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>
#include "MMDebugMsg.h"

#ifdef __cplusplus
extern "C" {
#endif


/* =======================================================================

                DEFINITIONS AND DECLARATIONS FOR MODULE

This section contains definitions for constants, macros, types, variables
and other items needed by this module.

========================================================================== */

/* =======================================================================
**                        Class & Function Definations
** ======================================================================= */

typedef enum 
{
   NET_PROT_TCP = 0,
   NET_PROT_UDP,
   NET_PROT_UNUSED = 0x3FFFFFFF
} NetProtocol;

typedef struct
{
   unsigned char *pBuffer;
   int nBytes;
   int nAllocLen;
   MM_HANDLE handle;
}  NetBufferRx;

typedef struct
{
   unsigned char *pBuffer;
   int nBytes;
}  MMNetworkBuffer;

typedef struct
{
   char *pLocalServerPath;    // used for IPC
   char *sPortno;             // used for network
   NetProtocol eProt;         // network transmission protocol
} NetServerCfg;

typedef struct
{
   char *pRemoteIpAddr;
   char *sPortno;
} NetClientConnect;

typedef struct 
{
   char *pLocalServerPath;    // used for IPC
   NetClientConnect remote;   // used for network
   NetProtocol eProt;         // network transmission protocol
} NetClientCfg;

int MM_Network_Server_Create( MM_HANDLE *pHandle, const NetServerCfg* pServerCfg, boolean bLocal );
int MM_Network_Server_Destroy( MM_HANDLE handle );

int MM_Network_Server_Open( MM_HANDLE serverHandle, MM_HANDLE *pHandle, boolean bASync );
int MM_Network_Server_Close( MM_HANDLE handle );

int MM_Network_Client_Open( MM_HANDLE *pHandle, const NetClientCfg* pClientCfg, boolean bLocal );
int MM_Network_Client_Close( MM_HANDLE handle );

int MM_Network_Server_Read( MM_HANDLE handle, unsigned char *pBuffer, int bufSize);
int MM_Network_Client_Send( MM_HANDLE handle, char *pBuffer, int nBytes );
int MM_Network_Server_Queue_Buffer( MM_HANDLE handle, unsigned char *pBuffer, int bufSize);
int MM_Network_Server_Async_Read( MM_HANDLE handle, NetBufferRx *pNetRx);

#ifdef __cplusplus
}
#endif

#endif
