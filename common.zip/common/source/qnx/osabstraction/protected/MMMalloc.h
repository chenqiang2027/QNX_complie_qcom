
#ifndef MMMALLOC_H
#define MMMALLOC_H
/*===========================================================================
                          M M    W r a p p e r 
                   f o r   C   M e m o r y   R o u t i n e s

*//** @file  MMMalloc.h
   This module defines routines to track and debug memory related usage
 
   Copyright (c) 2008 - 2009 Qualcomm Technologies Incorporated.
   All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/* =======================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/osabstraction/protected/MMMalloc.h#1 $
$DateTime: 2023/02/14 14:42:41 $
$Change: 43697235 $

when       who         what, where, why
--------   ---         -------------------------------------------------------
01/05/11   che         fix MM_HANDLE multiple definition compiler issue
07/28/09   rmandal     Converted comments to doxygen style.
07/27/09   rmandal     Replaced qtv_ by MM_ in comments
07/27/09   rmandal     Replaced QTVMALLOC_H by MMMALLOC_H

========================================================================== */

/* =======================================================================
**               Includes and Public Data Declarations
** ======================================================================= */
#include "stdlib.h" // for size_t

/* -----------------------------------------------------------------------
** Type Declarations
** ----------------------------------------------------------------------- */
typedef void (*MM_Memory_DestructPtr)(void*); 

#ifndef MM_HANDLE
#define MM_HANDLE void *
#endif

/* -----------------------------------------------------------------------
** Constant / Define Declarations
** ----------------------------------------------------------------------- */
#ifdef __cplusplus
extern "C" {
#endif 

extern const unsigned int MM_MEMORY_SIZEOF_PRIVATE_DATA;

#ifdef __cplusplus
}
#endif 

/* =======================================================================
**                          Macro Definitions
** ======================================================================= */

/**
 * This macro calls MM_malloc in order to allocate memory from the heap and
 * track memory allocations for debugging purposes.  A pointer to the allocated
 * memory is returned.
 *
 * sz - the number of bytes to allocate
 */
#define MM_Malloc(sz)          MM_malloc(sz, __FILE__, __LINE__)

/**
 * This macro calls MM_realloc in order to reallocate memory from the heap and
 * track memory allocations for debugging purposes.  A pointer to the allocated
 * memory is returned.
 *
 * p - original pointer returned by MM_Malloc
 * sz - the number of bytes to allocate
 */
#define MM_Realloc(p, sz)   MM_realloc(p, sz, __FILE__, __LINE__)

/*
 * This macro calls MM_free in order to free memory from the heap and
 * track memory allocations for debugging purposes.
 *
 * p - pointer to memory which will be free'd
 */
#define MM_Free(p)          MM_free(p, __FILE__, __LINE__)

/*
 * This macro calls MM_mallocEx in order to allocate memory from the pool
 * associated with the handle passed and track memory allocations for debugging
 * purposes.
 * A pointer to the allocated memory is returned.
 *
 * handle - MM_HANDLE returned from create function
 * sz - the number of bytes to allocate
 */
#define MM_MallocEx(handle, sz)      MM_mallocEx(handle, sz, __FILE__, __LINE__)

/*
 * This macro calls MM_reallocEx in order to allocate memory from the pool
 * associated with the handle passed and track memory allocations for debugging
 * purposes. A pointer to the allocated memory is returned.
 *
 * handle - MM_HANDLE returned from create function
 * p - original pointer returned by MM_Malloc
 * sz - the number of bytes to allocate
 */
#define MM_ReallocEx(handle, p, sz)   MM_reallocEx(handle, p, sz, __FILE__, __LINE__)

/*
 *  This macro calls MM_free in order to free memory from the pool associated
 *  with the handle passed and track memory allocations for debugging purposes.
 *
 * p - pointer to memory which will be free'd
 */
#define MM_FreeEx(p)          MM_freeEx(p, __FILE__, __LINE__)

/*
 * List of memory pools that are supported,
 *      MM_MEMORY_POOL_TYPE_DEFAULT - regular heap supported by the platfrom
 *      MM_MEMORY_POOL_TYPE_CUSTOM - same as MM_MEMORY_POOL_TYPE_DEFAULT
 */
#define MM_MEMORY_POOL_TYPE_DEFAULT 0
#define MM_MEMORY_POOL_TYPE_CUSTOM  MM_MEMORY_POOL_TYPE_DEFAULT

/* =======================================================================
**                        Class & Function Definations
** ======================================================================= */

#ifdef __cplusplus
extern "C" {
#endif /* #ifdef __cplusplus */

/*
 * Creates a memory pool, the handle returned can used to allocate and free
 * memory from this pool
 *
 * @param[in] nType - the type of the heap/memory that is be used
 * @param[in] pData - any additonal data that is needed to initialize the heap
 *                    the data depends on the type of the pool used (nType)
 *               MM_MEMORY_POOL_TYPE_DEFAULT takes NULL pData
 * @param[out] pHandle - handle of the memory pool on success
 *
 * @return zero when successfull else failure
 */
int MM_Memory_Initialize( int nType, void *pData, MM_HANDLE *pHandle );

/*
 * Releases a memory pool, no further memory allocations and releases can be
 * done on this pool. If the debug feature is enabled the memory statistics and
 * leaks will be sent to the deugu interface
 *
 * @param[in] handle - handle of the memory pool that needs to be deleted
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 *
 * @return zero when successfull else failure
 */
int MM_Memory_Deinitialize( MM_HANDLE handle );

/*
 * Initialize the information needed to start logging the memory statistic
 *
 * @return zero when successfull else failure
 */
int MM_Memory_InitializeCheckPoint( void );

/*
 * Releases a memory check point and prints the statistics
 *
 * @return zero when successfull else failure
 */
int MM_Memory_ReleaseCheckPoint( void );

/**
 * This function allocates the memory of requested size.
 * 
 * DONOT USE. NOT AN INTERFACE, FOR INTERNAL IMPL ONLY
 * This function should not be called directly, instead, call
 * MM_Malloc().
 *
 * @param[in] size - memory size requested
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 * 
 * @return void* a pointer to memory
 */
 void * MM_malloc(size_t size, const char *file, int line);

/**
 * This function reallocates the memory for requested size and
 * returns the new pointer.
 * 
 * DONOT USE. NOT AN INTERFACE, FOR INTERNAL IMPL ONLY
 * This function should not be called directly, instead, call
 * MM_Realloc().
 *
 * @param[in] pMemory - pointer to old memory
 * @param[in] size - new memory size requested
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 * 
 * @return void* a pointer to memory
 */
 void * MM_realloc(void *pMemory , size_t size, const char *file, 
                   int line);

/**
 * This function frees the memory allocated using MM_malloc or
 * MM_free
 * 
 * DONOT USE. NOT AN INTERFACE, FOR INTERNAL IMPL ONLY
 * This function should not be called directly, instead, call
 * MM_Free().
 * 
 * @param[in] pMemory - pointer to the memory
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 */
 void MM_free(void *pMemory, const char *file, int line);

/**
 * This function mallocs the memory of requested size.
 * 
 * DONOT USE. NOT AN INTERFACE, FOR INTERNAL IMPL ONLY
 * This function should not be called directly, instead, 
 * call MM_Malloc().
 * 
 * @param[in] handle - handle of the memory pool
 * @param[in] size - memory size requested
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 * 
 * @return void* a pointer to memory
 */
void * MM_mallocEx(MM_HANDLE handle, size_t size, const char *file, int line);

/**
 * This function reallocs the memory for requested size and
 * returns the new pointer.
 * 
 * DONOT USE. NOT AN INTERFACE, FOR INTERNAL IMPL ONLY
 * This function should not be called directly, instead, call MM_Realloc().
 * 
 * @param[in] handle - handle of the memory pool
 * @param[in] pMemory - pointer to old memory
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 * 
 * @return void* a pointer to memory
 */
void * MM_reallocEx(MM_HANDLE handle, void *pOldMemory , size_t size, 
                    const char *file, int line);

/**
 * This function frees the memory allocated using MM_MallocEx or
 * MM_reallocEx
 * 
 * DONOT USE. NOT AN INTERFACE, FOR INTERNAL IMPL ONLY
 * This function should not be called directly, instead, call
 * MM_FreeEx().
 * 
 * @param[in] pMemory - pointer to the memory
 * @param[in] file - the file name for debugging
 * @param[in] line - line number for debugging
 */
void MM_freeEx(void *pMemory, const char *file, int line);

#ifdef __cplusplus
}
#endif /* #ifdef __cplusplus */

#endif // MMMALLOC_H
