/**================================================================================================

@file
   apdf.cpp

@brief
   This file implements plane definition query of image buffer formats.

Copyright (c) 2021-2022 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================

                     INCLUDE FILES FOR MODULE

================================================================================================**/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "apdf.h"
#include "wfdext2.h"
#include "AEEStdDef.h"
#include "aosal_debug_msg.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/**********************************************************************************************//**
@brief
    Defines Maximum supported width height, and stride
**************************************************************************************************/
#define PD_MAX_WIDTH_PIXELS  (8192)
#define PD_MAX_HEIGHT_PIXELS (4320)
#define PD_MAX_STRIDE  (8192)

/**********************************************************************************************//**
@brief
    Defines maximum number of planes
**************************************************************************************************/
#define PD_MAX_NUM_PLANES   (4)

/**********************************************************************************************//**
@brief
    Macros to downscale a number with an integer scale factor
**************************************************************************************************/
#define PD_DOWNSCALE(num, divisor) ( (0 != (divisor)) ? (((num) + ((divisor)-1))/(divisor)) :(num))

/**********************************************************************************************//**
@brief
    Macros to calculate number of tiles for UBWC format
**************************************************************************************************/
#define PD_NUMTILES(num_pix, tile_dim) \
            ((0 != (tile_dim)) ? (( (num_pix) + ((tile_dim) - 1)) / (tile_dim)) : (num_pix))

/**********************************************************************************************//**
@brief
    Macros to adjust a number to return the next aligned number
**************************************************************************************************/
#define PD_ALIGN( val, align) ( (0 != (align)) ? (((((val)+(align))-1)/(align))*(align)) : (val))

/**********************************************************************************************//**
@brief
    Macros to define kilo bytes
**************************************************************************************************/
#define PD_KILO( val )          (1024*(val))

/**********************************************************************************************//**
@brief
    Macros to log messages
**************************************************************************************************/

#define PD_MSG_ERROR( xx_fmt, ...) \
    AO_MSG(AO_GENERAL, AO_PRIO_ERROR, # xx_fmt, ## __VA_ARGS__)
#define PD_MSG_DEBUG( xx_fmt, ... )   AO_MSG(AO_GENERAL, AO_PRIO_LOW, # xx_fmt, ## __VA_ARGS__)

/**********************************************************************************************//**
@brief
    Macros to define PD HW usage flags
**************************************************************************************************/
#define PD_HW_USAGE_FLAGS   (WFD_USAGE_OPENGL_ES2 |    \
                                WFD_USAGE_CAPTURE |    \
                                WFD_USAGE_VIDEO   |    \
                                WFD_USAGE_DISPLAY |    \
                                WFD_USAGE_NATIVE )

/**********************************************************************************************//**
@brief
    Macros to define PD SW usage flags
**************************************************************************************************/
#define PD_SW_USAGE_FLAGS   (WFD_USAGE_READ | WFD_USAGE_WRITE)

/**********************************************************************************************//**
@brief
    Macros to define PD COMPRESSION usage flag
**************************************************************************************************/
#define PD_USAGE_COMPRESSION_FLAG  WFD_USAGE_COMPRESSION


/**================================================================================================
** Variables
================================================================================================**/
static uint32_t g_nPDAsicIdx = 0;

/**================================================================================================
** Typedefs
================================================================================================**/


/**********************************************************************************************//**
@brief
    Defines table entry of alignment info structure for one plane
**************************************************************************************************/
typedef struct
{
   /* stride multiple in bytes for this plane
    * For UBWC format, this is the width of macro tile in bytes
    */
   uint32_t  nStrideMultiple;

   /* extra stride padding in bytes after applying stride multiple */
   uint32_t  nStridePadding;

   /* numerator of bit-per-pixel including all pixel padding */
   uint32_t  nBppNumerator;

   /* numerator of bit-per-pixel includes all pixel padding */
   uint32_t  nBppDenominator;

   /* height multiple in scanlines for this plane */
   uint32_t  nHeightMultiple;

   /* Tile width in pixels used for UBWC metadata planes.
    * Zero for UBWC image data planes or linear format
    */
   uint32_t  nTileWidth;

   /* Tile height in pixels used for UBWC metadata planes.
    * Zero for UBWC image data planes or linear format
    */
   uint32_t nTileHeight;

   /* Pixel division factor from the frame width for this plane, e.g., 2 for
    * chroma plane of YV12/YU12
    */
   uint32_t nWidthDivisor;

   /* Height division factor from the frame height for this plane,
    * e.g., 2 for the chroma plane of NV12
    */
   uint32_t nHeightDivisor;

   /* buffer address alignment for this plane in number of bytes */
   uint32_t  nBufAddrAlignment;

   /* buffer size alignment for this plane in number of bytes */
   uint32_t  nBufSizeAlignment;

   /* Extradata padding bytes at the end of the plane. Non-zero padding size
   ** allowed only at the last plane of the buffer
   */
   uint32_t  nPaddingSize;

} PDPlaneInfoType_t;

/**********************************************************************************************//**
@brief
    Defines table entry structure for one color format
**************************************************************************************************/
typedef struct
{
   /* The usage flag */
   uint32_t              nUsage;

   /* color format */
   PDColorFormat_e      eColorformat;

   /* number of planes for this color format */
   uint32_t             nNumPlanes;

   /* data structure including planedef information */
   PDPlaneInfoType_t    sPlanedefInfo[PD_MAX_NUM_PLANES];

} PDTableEntryType_t;

/**********************************************************************************************//**
@brief
    Defines table entry structure for one asic type
**************************************************************************************************/
/* This data type defines planedef tables */
typedef struct
{
   /* Number of table entries */
   uint32_t           nNumEntries;

   /* each entry: one color format */
   PDTableEntryType_t *pEntries;
} PDTableType_t;


/**********************************************************************************************//**
@brief
 *  Defines Asic type.  Used as array index of sAsicTable
**************************************************************************************************/
typedef enum
{
    PD_ASIC_TYPE_8540 = 0x0,
    PD_ASIC_TYPE_MAX  = 0x80000000U
} PDAsicType_e;


/**********************************************************************************************//**
@brief
    Defines platform info
**************************************************************************************************/
typedef struct
{
    const char         *pMachineName;   /* chipset asic number*/
    const char         *pAsicName;      /* chipset name */
    PDAsicType_e        eAsicType;      /* enum of asic type */
    PDTableType_t      *pPDTable;       /* pointer to the static asic table */
} PDAsicInfoType_t;


/**********************************************************************************************//**
@brief
    Static SA8540 APDF table
**************************************************************************************************/
static PDTableEntryType_t   sPDTableEntry_8540[] =
{
    {
        PD_HW_USAGE_FLAGS,     // usage flag
        PD_FORMAT_UYVY,        // color format
        1,                     // number of planes
        {
            //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz    bufSz
            //multi  padding  nor den  muti  wd   ht   div  div  align    align    padding
            {128,    0,      16,  1,  32,   0,   0,   1,   1,   128,     4096,     0}, // UYVY
            {0,      0,      0,   0,  0,    0,   0,   0,   0,   0,          0,     0}, // N/A
            {0,      0,      0,   0,  0,    0,   0,   0,   0,   0,          0,     0}, // N/A
            {0,      0,      0,   0,  0,    0,   0,   0,   0,   0,          0,     0}  // N/A
       },
    },

    {
        PD_HW_USAGE_FLAGS,         // usage flag
        PD_FORMAT_EXT_UYVY_10LSB,  // color format
        1,                         // number of planes
        {
          //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz    bufSz
          //multi  padding  nor den  muti  wd   ht   div  div  align    align    padding
            {128,    0,    32,  1,  32,   0,   0,   1,   1,   128,     4096,     0}, // UYVY10LSB
            {0,      0,    0,   0,  0,    0,   0,   0,   0,   0,          0,     0}, // N/A
            {0,      0,    0,   0,  0,    0,   0,   0,   0,   0,          0,     0}, // N/A
            {0,      0,    0,   0,  0,    0,   0,   0,   0,   0,          0,     0}  // N/A
        },
    },

    {
        PD_HW_USAGE_FLAGS,         // usage flag
        PD_FORMAT_EXT_UYVY_RAW10,  // color format
        1,                         // number of planes
        {
           //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz    bufSz
           //multi  padding  nor den  muti  wd   ht   div  div  align    align    padding
            {128,    0,      20,  1,  32,   0,   0,   1,   1,   128,     4096,     0}, // UYVYRAW10
            {0,      0,      0,   0,  0,    0,   0,   0,   0,   0,          0,     0}, // N/A
            {0,      0,      0,   0,  0,    0,   0,   0,   0,   0,          0,     0}, // N/A
            {0,      0,      0,   0,  0,    0,   0,   0,   0,   0,          0,     0}  // N/A
        },
    },

    {
        PD_HW_USAGE_FLAGS,   // usage flag
        PD_FORMAT_NV12,      // color format
        2,                // number of planes
        {
         //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz  bufSz
         //multi  padding  nor den  muti  wd   ht   div  div  align    align  padding
            {128,   0,      8,  1,  32,  0,   0,   1,   1,   128,     0,     0},     // Y
            {128,   0,      8,  1,  32,  0,   0,   1,   2,   128,     4096,  4096},  // UV
            {0,     0,      0,  0,    0,  0,   0,   0,   0,   0,       0,     0},     // N/A
            {0,     0,      0,  0,    0,  0,   0,   0,   0,   0,       0,     0}      // N/A
        },
    },

    {
        PD_HW_USAGE_FLAGS,   // usage flag
        PD_FORMAT_EXT_GRAY8, // color format
        1,                   // number of planes
        {
         //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz  bufSz
         //multi  padding  nor den  muti  wd   ht   div  div  align    align  padding
            {128,   0,      8,  1,  32,   0,   0,   1,   1,   128,     0,     0},     // Y
            {0,     0,      0,  0,    0,  0,   0,   0,   0,   0,       0,     0},     // N/A
            {0,     0,      0,  0,    0,  0,   0,   0,   0,   0,       0,     0},     // N/A
            {0,     0,      0,  0,    0,  0,   0,   0,   0,   0,       0,     0}      // N/A
        },
    },

    {
        PD_HW_USAGE_FLAGS | PD_USAGE_COMPRESSION_FLAG,  // usage flag with UBWC
        PD_FORMAT_NV12,       // color format
        4,                    // number of planes
        {
            //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz  bufSz
            //multi  padding  nor den  muti  wd   ht   div  div  align    align  padding
            { 64,      0,      8,  1,  16,   32,  8,    1,   1,   4096,    4096,   0}, // Y meta
            {128,      0,      8,  1,  32,    0,  0,    1,   1,   4096,    4096,   0}, // Y
            { 64,      0,      8,  1,  16,   16,  8,    2,   2,   4096,    4096,   0}, // UV meta
            {128,      0,      8,  1,  32,    0,  0,    1,   2,   4096,    4096,   0}  // UV
        },
    },

    {
        PD_HW_USAGE_FLAGS | PD_USAGE_COMPRESSION_FLAG,  // usage flag with UBWC
        PD_FORMAT_EXT_GRAY8,  // color format
        2,                    // number of planes
        {
            //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz  bufSz
            //multi  padding  nor den  muti  wd   ht   div  div  align    align  padding
            { 64,      0,      8,  1,  16,   32,  8,    1,   1,   4096,    4096,   0}, // Y meta
            {128,      0,      8,  1,  32,    0,  0,    1,   1,   4096,    4096,   0}, // Y
            {0,        0,      0,  0,   0,    0,  0,    0,   0,      0,       0,   0}, // N/A
            {0,        0,      0,  0,   0,    0,  0,    0,   0,      0,       0,   0}  // N/A
        },
    },

    {
        PD_HW_USAGE_FLAGS | PD_USAGE_COMPRESSION_FLAG,  // usage flag with UBWC
        PD_FORMAT_EXT_UBWC_NV124R,                  // color format
        4,                                          // number of planes
        {
           //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz  bufSz
           //multi  padding  nor den  muti  wd   ht   div  div  align    align  padding
            { 64,   0,       8,   1,  16,   64,  4,    1,   1,   4096,   4096,   0},   // Y meta
            {256,   0,       8,   1,  16,    0,  0,    1,   1,   4096,   4096,   0},   // Y
            { 64,   0,       8,   1,  16,   32,  4,    2,   2,   4096,   4096,   0},   // UV meta
            {256,   0,       8,   1,  16,    0,  0,    1,   2,   4096,   4096,   0}    // UV
        },
    },

    {
        PD_HW_USAGE_FLAGS,     // usage flag
        PD_FORMAT_RGBA8888,    // color format
        1,                     // number of planes
        {
            //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz    bufSz
            //multi  padding  nor den  muti  wd   ht   div  div  align    align    padding
            {256,    0,       32,  1,  32,   0,   0,   1,   1,   128,     4096,     8192}, // RGBA
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,          0,     0},    // N/A
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,          0,     0},    // N/A
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,          0,     0}     // N/A
       },
    },

    {
        PD_HW_USAGE_FLAGS,      // usage flag
        PD_FORMAT_P010,         // color format
        2,                      // number of planes
        {
            //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz    bufSz
            //multi  padding  nor den  muti  wd   ht   div  div  align    align    padding
            {256,    0,       16,  1,  32,   0,   0,   1,   1,   256,        0,     0},     // Y
            {256,    0,       16,  1,  16,   0,   0,   1,   2,   256,     4096,     4096},  // UV
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,          0,     0},     // N/A
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,          0,     0}      // N/A
       },
    },

    {
        PD_HW_USAGE_FLAGS | PD_USAGE_COMPRESSION_FLAG,      // usage flag
        PD_FORMAT_P010,                                     // color format
        4,                                                  // number of planes
        {
            //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz    bufSz
            //multi  padding  nor den  muti  wd   ht   div  div  align    align    padding
            {64,     0,       8,   1,  16,   32,   4,   1,   1,   4096,    4096,     0},    // Y meta
            {256,    0,       16,  1,  16,   0,    0,   1,   1,   4096,    4096,     0},    // Y
            {64,     0,       8,   1,  16,   16,   4,   2,   2,   4096,    4096,     0},    // UV meta
            {256,    0,       16,  1,  16,   0,    0,   1,   2,   4096,    4096,     4096}  // UV
       },
    },

    {
        PD_HW_USAGE_FLAGS,      // usage flag
        PD_FORMAT_TP10,         // color format
        2,                      // number of planes
        {
            //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz    bufSz
            //multi  padding  nor den  muti  wd   ht   div  div  align    align    padding
            {128,    0,       32,  3,  32,   0,   0,   1,   1,   128,        0,     0},     // Y
            {128,    0,       32,  3,  32,   0,   0,   1,   2,   128,     4096,     4096},  // UV
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,          0,     0},     // N/A
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,          0,     0}      // N/A
       },
    },

    {
        PD_HW_USAGE_FLAGS | PD_USAGE_COMPRESSION_FLAG,      // usage flag
        PD_FORMAT_TP10,                                     // color format
        4,                                                  // number of planes
        {
            //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz    bufSz
            //multi  padding  nor den  muti  wd   ht   div  div  align    align    padding
            {64,     0,       8,   1,  16,   48,   4,   1,   1,   4096,    4096,     0},    // Y meta
            {256,    0,       32,  3,  16,   0,    0,   1,   1,   4096,    4096,     0},    // Y
            {64,     0,       8,   1,  16,   24,   4,   2,   2,   4096,    4096,     0},    // UV meta
            {256,    0,       32,  3,  16,   0,    0,   1,   2,   4096,    4096,     4096}  // UV
       },
    },

    {
        PD_HW_USAGE_FLAGS,      // usage flag
        PD_FORMAT_RGB888,       // color format
        1,                      // number of planes
        {
            //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz    bufSz
            //multi  padding  nor den  muti  wd   ht   div  div  align    align    padding
            {768,    768,     24,  1,  32,   0,   0,   1,   1,   0,         0,     0},    // RGB
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,         0,     0},    // N/A
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,         0,     0},    // N/A
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,         0,     0}     // N/A
       },
    },

    {
        PD_HW_USAGE_FLAGS,      // usage flag
        PD_FORMAT_EXT_P01210,   // color format
        2,                      // number of planes
        {
            //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz    bufSz
            //multi  padding  nor den  muti  wd   ht   div  div  align    align    padding
            {256,    0,       16,  1,  32,   0,   0,   1,   1,   256,        0,     0},     // Y
            {256,    0,       16,  1,  16,   0,   0,   1,   2,   256,     4096,     0},     // UV
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,          0,     0},     // N/A
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,          0,     0}      // N/A
       },
    },

    {
        PD_HW_USAGE_FLAGS,      // usage flag
        PD_FORMAT_EXT_P01208,   // color format
        2,                      // number of planes
        {
            //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz    bufSz
            //multi  padding  nor den  muti  wd   ht   div  div  align    align    padding
            {256,    0,       16,  1,  32,   0,   0,   1,   1,   256,        0,     0},     // Y
            {128,    0,       8,   1,  16,   0,   0,   1,   2,   128,     4096,     0},     // UV
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,          0,     0},     // N/A
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,          0,     0}      // N/A
       },
    },
    
    {
        PD_HW_USAGE_FLAGS,      // usage flag
        PD_FORMAT_RGB888,       // color format
        1,                      // number of planes
        {
            //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz    bufSz
            //multi  padding  nor den  muti  wd   ht   div  div  align    align    padding
            {768,    768,     24,  1,  32,   0,   0,   1,   1,   0,         0,     0},    // RGB
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,         0,     0},    // N/A
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,         0,     0},    // N/A
            {0,      0,       0,   0,  0,    0,   0,   0,   0,   0,         0,     0}     // N/A
       },
    },

    {
        PD_HW_USAGE_FLAGS,      // usage flag
        PD_FORMAT_EXT_RGB888_PLANAR,       // color format
        3,                      // number of planes
        {
            //stride stride   bpp bpp  ht   tile tile  wd   ht   bufAddr  bufSz    bufSz
            //multi  padding  nor den  muti  wd   ht   div  div  align    align    padding
            {64,      0,       8,  1,  1,    0,   0,   1,   1,   4096,    4096,     0},    // RGB
            {64,      0,       8,  1,  1,    0,   0,   1,   1,   4096,    4096,     0},    // N/A
            {64,      0,       8,  1,  1,    0,   0,   1,   1,   4096,    4096,     0},    // N/A
            {0,       0,       0,  0,  0,    0,   0,   0,   0,      0,       0,     0}     // N/A
       },
    },
};




/**********************************************************************************************//**
@brief
    Static SA8540 APDF table
**************************************************************************************************/
static PDTableType_t sPDInfoTable_8540 =
                {  sizeof(sPDTableEntry_8540)/sizeof(PDTableEntryType_t),
                   sPDTableEntry_8540  };

/**********************************************************************************************//**
@brief
    Static Asisc info table
**************************************************************************************************/
static PDAsicInfoType_t sAsicTable[] =
{
   {"SA8540", "Makena",  PD_ASIC_TYPE_8540,   &sPDInfoTable_8540}
};


/*===========================================================================

                        FUNCTION DECLARATIONS

===========================================================================*/


/*===========================================================================

                        FUNCTION DEFINITIONS

===========================================================================*/

/*==========================================================================

       FUNCTION:     PDDetectAsic

       DESCRIPTION:
*//**                This function detects asic platform info.

@par   DEPENDENCIES:
                     None
@par   SYNCHRONOUS:
                     Yes
*//*
       PARAMETERS:
*//**
         @param[in]  None

*//*
*//**  RETURN VALUE:
         @return  index to asic info table on success or -1 otherwise

@par   SIDE EFFECTS:
===========================================================================*/
static PDStatus_e PDDetectAsic()
{
    PDStatus_e  eStatus = PD_ERR_MAX;

    static boolean g_bPDInit = FALSE;

    if (FALSE == g_bPDInit)
    {
        if (AO_SUCCESS != AODebugMsgInitialize())
        {
            eStatus = PD_ERR_FAILURE;
        }
        else
        {
            /* run-time detection can be added in the future once
               platform detection is ASIL-B */
            g_nPDAsicIdx = PD_ASIC_TYPE_8540;

            g_bPDInit = TRUE;

            eStatus = PD_OK;
        }
    }
    else
    {
        /* already initialized. return success.*/
        eStatus = PD_OK;
    }

   return eStatus;
}

/**********************************************************************************************//**
@brief
    Query the number of planes given the color format and usage

@param [in] eColorFormat
    APDF color format defined in PDColorFormat_e

@param [in] nUsage
    Usage bits defined in wfdExt2.h

@param [out] pNumPlanes
    Pointer to number of planes

@param [in] nFlags
    Flags reserved for future features

@return
    status code defined in PDStatus_e
**************************************************************************************************/
PDStatus_e PDQueryNumPlanes
(
	PDColorFormat_e 	eColorFormat,
	uint32_t			nUsage,
	uint32_t			*pNumPlanes,
	uint32_t			nFlags
)
{
    PDStatus_e           eStatus = PD_ERR_MAX;
/*----------------------------------------------------------------*/

    if (PD_OK != PDDetectAsic())
    {
        eStatus = PD_ERR_FAILURE;
    }
    else if (NULL == pNumPlanes)
    {
        PD_MSG_ERROR("NULL pNumPlanes");
        eStatus = PD_ERR_BAD_PARAM;
    }
    else
    {
        PDTableType_t        *pTbl;
        boolean              bFound = FALSE;
        uint32_t             nPlanes = 0;
        boolean              bCompressed = FALSE;
        uint32_t             i = 0;

        pTbl =  sAsicTable[g_nPDAsicIdx].pPDTable;

        PD_MSG_DEBUG("query_num_nPlanes: color format 0x%x, usage 0x%x", eColorFormat, nUsage);

        bCompressed = (0 != (nUsage & PD_USAGE_COMPRESSION_FLAG)) ? TRUE : FALSE;

        /* if the usage contains HW flags, ignore the SW usage flags */
        nUsage = (0 != ( nUsage & PD_HW_USAGE_FLAGS ))?  ( PD_HW_USAGE_FLAGS ) : (PD_SW_USAGE_FLAGS);

        if ( (TRUE == bCompressed) ||
             (PD_FORMAT_EXT_UBWC_NV124R == eColorFormat))
        {
            /* This format does not have linear version. Enforce compression flag */
            nUsage |= WFD_USAGE_COMPRESSION;
        }

        for (i = 0; i < pTbl->nNumEntries; i++ )
        {
           if ((eColorFormat == pTbl->pEntries[i].eColorformat) &&
               (nUsage == pTbl->pEntries[i].nUsage))
           {
              nPlanes = pTbl->pEntries[i].nNumPlanes;
              bFound = TRUE;
              PD_MSG_DEBUG("number of planes %d", *pNumPlanes);

              break;
           }
        }

        if ( !bFound )
        {
            PD_MSG_ERROR("Unsupported color format 0x%x, usage 0x%x", eColorFormat, nUsage);
            eStatus = PD_ERR_UNSUPPORTED;
        }
        else
        {
            *pNumPlanes = nPlanes;
            eStatus = PD_OK;
        }
    }

    return eStatus;
}

/**********************************************************************************************//**
@brief
    Query the plane definition of the uncompressed buffer given the input color
    format, usage, frame resolution and plane index.

@param [in] eColorFormat
    Planedef color formats

@param [in] nUsage
    Usage bits defined in wfdExt2.h

@param [in] pFrameRes
    Pointer to frame resolution (width / height in pixels)

@param [in/out] pPlaneDef
    Pointer to plane definition including an input of plane index and output
    plane definition

@param [in] nFlags
    Flags reserved for future features

@return
    status code defined in PDStatus_e
**************************************************************************************************/
PDStatus_e PDQueryPlaneDef
(
	PDColorFormat_e         eColorFormat,
	uint32_t		        nUsage,
    const	FrameRes_t		*pFrameRes,
	PlaneDef_t		        *pPlaneDef,
	uint32_t		        nFlags
)
{
    PDPlaneInfoType_t    *pCurrPlane;
    PDStatus_e           eStatus = PD_ERR_MAX;
    PDTableType_t        *pTbl;
    boolean              bFound = FALSE;
    boolean              bCompressed = FALSE;
    uint32_t             i = 0;


    if ((NULL == pFrameRes) || (NULL == pPlaneDef))
    {
       PD_MSG_ERROR("NULL pointer pFrameRes or pPlanedef");
       eStatus = PD_ERR_BAD_PARAM;
    }
    else if ((0 == pFrameRes->nWidthInPixels) || (0 == pFrameRes->nHeightInPixels) ||
             (PD_MAX_WIDTH_PIXELS < pFrameRes->nWidthInPixels) ||
             (PD_MAX_HEIGHT_PIXELS < pFrameRes->nHeightInPixels))
    {
        PD_MSG_ERROR("width %d or height %d out of range",
                     pFrameRes->nWidthInPixels, pFrameRes->nHeightInPixels);
        eStatus = PD_ERR_BAD_PARAM;
    }
    else if ((0 == pPlaneDef->nPlaneIndex) ||
              (PD_MAX_NUM_PLANES < pPlaneDef->nPlaneIndex))
    {
        PD_MSG_ERROR("plane index %d wrong, should be from 1 to %d",
                     pPlaneDef->nPlaneIndex, PD_MAX_NUM_PLANES);
        eStatus = PD_ERR_BAD_PARAM;
    }
    else if(PD_OK != PDDetectAsic())
    {
        PD_MSG_ERROR("PDDetectAsic failed");
        eStatus = PD_ERR_FAILURE;
    }
    else
    {
        pTbl = sAsicTable[g_nPDAsicIdx].pPDTable;

        PD_MSG_DEBUG("query_plane_def: color format 0x%x, usage 0x%x", eColorFormat, nUsage);

        bCompressed = (0 != ( nUsage & WFD_USAGE_COMPRESSION )) ? TRUE : FALSE;

        /* if the usage contains HW flags, ignore the SW usage flags */
        nUsage = (0 != ( nUsage & PD_HW_USAGE_FLAGS ))? ( PD_HW_USAGE_FLAGS ) : (PD_SW_USAGE_FLAGS) ;

        if ((TRUE == bCompressed) || (PD_FORMAT_EXT_UBWC_NV124R == eColorFormat))
        {
           nUsage |= WFD_USAGE_COMPRESSION;
        }

        for ( i = 0; i < pTbl->nNumEntries; i++ )
        {
            if ((eColorFormat == pTbl->pEntries[i].eColorformat) &&
                (nUsage == pTbl->pEntries[i].nUsage))
            {
                bFound = TRUE;
                break;
           }
        }

        if (FALSE == bFound )
        {
            PD_MSG_ERROR("Unsupported color format 0x%x, usage 0x%x", eColorFormat, nUsage);
            eStatus = PD_ERR_UNSUPPORTED;
        }
        else
        {
            if (pPlaneDef->nPlaneIndex > pTbl->pEntries[i].nNumPlanes)
            {
                PD_MSG_ERROR("Plane index %d larger than the maximum %d",
                              pPlaneDef->nPlaneIndex, pTbl->pEntries[i].nNumPlanes);

                eStatus = PD_ERR_BAD_PARAM;
            }
            else
            {
                /* plane index start from 1 */
                pCurrPlane = &pTbl->pEntries[i].sPlanedefInfo[pPlaneDef->nPlaneIndex - 1];

                /* Horizontal */
                uint32_t    nWidthInPixels = 0;
                uint32_t    nNumTileHorizontal = 0;
                uint32_t    nWidthInBytes = 0;
                uint32_t    nNumBitsPerByte = 8;

                nWidthInPixels = PD_DOWNSCALE(pFrameRes->nWidthInPixels,
                                                pCurrPlane->nWidthDivisor);
                /* stride */
                pPlaneDef->nStrideMultiples = pCurrPlane->nStrideMultiple;

                /* for linear format, numTile = numPixel */
                nNumTileHorizontal = PD_NUMTILES(nWidthInPixels, pCurrPlane->nTileWidth);

                nWidthInBytes = PD_ALIGN((nNumTileHorizontal * pCurrPlane->nBppNumerator)
                                        / pCurrPlane->nBppDenominator, nNumBitsPerByte) / 8;

                pPlaneDef->nMinStride = PD_ALIGN(nWidthInBytes, pCurrPlane->nStrideMultiple);

                pPlaneDef->nActualStride = pPlaneDef->nMinStride;

                pPlaneDef->nMaxstride = PD_MAX_STRIDE;

                /* Vertical */
                uint32_t    nHeightInScanlines;
                uint32_t    nNumTileVertical;
                nHeightInScanlines = PD_DOWNSCALE(pFrameRes->nHeightInPixels,
                                               pCurrPlane->nHeightDivisor);

                pPlaneDef->nHeightMultiples = pCurrPlane->nHeightMultiple;

                /* for linear format, numTile = numScanlines */
                nNumTileVertical = PD_NUMTILES(nHeightInScanlines, pCurrPlane->nTileHeight);
                pPlaneDef->nMinPlaneBufHeight = PD_ALIGN(nNumTileVertical,
                                                         pCurrPlane->nHeightMultiple);
                pPlaneDef->nActualPlaneBufHeight = pPlaneDef->nMinPlaneBufHeight;

                /* buffer start address alignment */
                pPlaneDef->nBufAddrAlignment = pCurrPlane->nBufAddrAlignment;

                /* buffer size alignment */
                pPlaneDef->nActualBufSizeAlignment = pCurrPlane->nBufSizeAlignment;

                /* buffer size calculation:*/
                pPlaneDef->nPlaneBufSize =
                    PD_ALIGN(pPlaneDef->nActualStride * pPlaneDef->nActualPlaneBufHeight,
                             pPlaneDef->nActualBufSizeAlignment);

                /* padding size */
                pPlaneDef->nPlanePaddingSize = pCurrPlane->nPaddingSize;

                PD_MSG_DEBUG("Plandef: frame width %d height %d",
                               pFrameRes->nWidthInPixels,
                               pFrameRes->nHeightInPixels);

                PD_MSG_DEBUG("plane %d: plane_stride %d plane_height %d",
                             pPlaneDef->nPlaneIndex,
                             pPlaneDef->nActualStride,
                             pPlaneDef->nActualPlaneBufHeight);

                PD_MSG_DEBUG("\t plane_bufferSize %d plane_padding_size %d",
                             pPlaneDef->nPlaneBufSize,
                             pPlaneDef->nPlanePaddingSize);

                eStatus = PD_OK;
            }
        }
    }

    return eStatus;

}

