#ifndef APDF_H
#define APDF_H

/**================================================================================================

@file
   apdf.h

@brief
   This file defines data types and functions to query plane definition of image
   buffer formats.

Copyright (c) 2022-2023 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

================================================================================================**/

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/

#include <wfd.h>
#include <wfdext2.h>
#include "AEEStdDef.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**================================================================================================
** Constant and Macros
================================================================================================**/

/**================================================================================================
** Variables
================================================================================================**/

/**================================================================================================
** Typedefs
================================================================================================**/

/**********************************************************************************************//**
@brief
    Defines plane index for NV12
**************************************************************************************************/
typedef enum
{
   PD_Y_PLANE_INDEX_NV12 = 1,  /**< Luma plane ID */
   PD_UV_PLANE_INDEX_NV12 = 2   /**< Chroma plane ID */
} PD_NV12_PLANE_INDEX_TYPE;

/**********************************************************************************************//**
@brief
    Defines plane index for RGB color formats e.g., RGB565/RGB888/RGBA8888
**************************************************************************************************/
typedef enum
{
   PD_PAYLOAD_PLANE_INDEX_RGB  = 1,
} PD_RGB_PLANE_INDEX_TYPE;

/**********************************************************************************************//**
@brief
    Defines plane index for NV12_UBWC
**************************************************************************************************/
typedef enum
{
   PD_Y_META_PLANE_INDEX_NV12_UBWC     = 1,
   PD_Y_PAYLOAD_PLANE_INDEX_NV12_UBWC  = 2,
   PD_UV_META_PLANE_INDEX_NV12_UBWC    = 3,
   PD_UV_PAYLOAD_PLANE_INDEX_NV12_UBWC = 4
} PD_NV12_UBWC_PLANE_INDEX_TYPE;

/**********************************************************************************************//**
@brief
    Defines plane index for TP10_UBWC
**************************************************************************************************/
typedef enum
{
   PD_Y_META_PLANE_INDEX_TP10_UBWC     = 1,
   PD_Y_PAYLOAD_PLANE_INDEX_TP10_UBWC  = 2,
   PD_UV_META_PLANE_INDEX_TP10_UBWC    = 3,
   PD_UV_PAYLOAD_PLANE_INDEX_TP10_UBWC = 4
} PD_TP10_UBWC_PLANE_INDEX_TYPE;

/**********************************************************************************************//**
@brief
    Defines plane index for P010_UBWC
**************************************************************************************************/
typedef enum
{
   PD_Y_META_PLANE_INDEX_P010_UBWC     = 1,
   PD_Y_PAYLOAD_PLANE_INDEX_P010_UBWC  = 2,
   PD_UV_META_PLANE_INDEX_P010_UBWC    = 3,
   PD_UV_PAYLOAD_PLANE_INDEX_P010_UBWC = 4
} PD_P010_UBWC_PLANE_INDEX_TYPE;

/**********************************************************************************************//**
@brief
    Defines plane index for RGB_UBWC color formats
**************************************************************************************************/
typedef enum
{
   PD_META_PLANE_INDEX_RGB_UBWC    = 1,
   PD_PAYLOAD_PLANE_INDEX_RGB_UBWC = 2
} PD_RGB_UBWC_PLANE_INDEX_TYPE;

/**********************************************************************************************//**
@brief
    Defines planedef status code
**************************************************************************************************/
typedef enum
{
    PD_OK,                      /* Success */
    PD_ERR_FAILURE,             /* General failure */
    PD_ERR_UNSUPPORTED,         /* Unsupported color formats */
    PD_ERR_BAD_PARAM,           /* Bad parameters */
    PD_ERR_MAX = 0x7FFFFFFF
} PDStatus_e;

/**********************************************************************************************//**
@brief
    Defines planedef color formats
**************************************************************************************************/
typedef enum PDColorFormat : uint32_t
{
    PD_FORMAT_NV12 =  WFD_FORMAT_NV12,
    PD_FORMAT_UYVY =  WFD_FORMAT_UYVY,
    PD_FORMAT_RGBA8888 = WFD_FORMAT_RGBA8888,
    PD_FORMAT_P010 = WFD_FORMAT_P010,
    PD_FORMAT_TP10 = WFD_FORMAT_NV12_QC_TP10,
    PD_FORMAT_RGB888 = WFD_FORMAT_RGB888,
    /* PD color format extension: start from 1000 as in WFD */

   /* Grayscale 8 bit */
   PD_FORMAT_EXT_GRAY8 = (1000),

    /* UYVY_RAW10:  MIPI RAW10 YUV422 format with each sample 10 bits
     *  | byte1 | | byte2 |  | byte3 | | byte4 | |-----     byte5     -------|
     *   U[9:2]     Y[9:2]     V[9:2]    Y[9:2]   U[1:0] Y[1:0] V[1:0] Y[1:0] ....
     */
    PD_FORMAT_EXT_UYVY_RAW10,

    /* UYVY_10LSB:  MIPI YUV422 10bit in 16-bits container with LSB alignment
     *  |<-- byte 1-2  -->| |<-- byte 3-4  -->| |<-- byte 5-6  -->| |<-- byte 7-8  -->|
     *   pad[15:10] U[9:0]   pad[15:10] Y[9:0]   pad[15:10] V[9:0]   pad[15:10] Y[9:0]
     */
    PD_FORMAT_EXT_UYVY_10LSB,

    /* P01208: 12bit Y and 10bit UV in 16-bits container with MSB alignment
     *        |<-- byte 1-2  -->| |<-- byte 3-4  -->|  |<-- byte 4-5  -->| |<-- byte 5-6  -->|
	 *  Plane 1: Y[15:4] pad[3:0]  Y[15:4] pad[3:0]   Y[15:4] pad[3:0]   Y[15:4] pad[3:0]
     *  Plane 2: U[15:6] pad[5:0]  V[15:6] pad[5:0]   U[15:6] pad[5:0]   V[15:6] pad[5:0]
     */
    PD_FORMAT_EXT_P01210,
    
    /* P01208: 12bit Y in 16-bits container for Plane 1 and 8-bits container for 
     *          Plane 2 with MSB alignment
     *           |<-- byte 1-2  -->| |<-- byte 3-4  -->|  |<-- byte 4-5  -->| |<-- byte 5-6  -->|
     *  Plane 1: Y[15:4] pad[3:0]  Y[15:4] pad[3:0]   Y[15:4] pad[3:0]   Y[15:4] Y[3:0]
     *           |<-- byte 1 -->| |<-- byte 2 -->|  |<-- byte 3 -->| |<-- byte 4 -->|
     *  Plane 2:      U[7:0]           V[7:0]            U[7:0]           V[7:0]
     */
    PD_FORMAT_EXT_P01208,

    /* RGB888_PLANAR: 8bit in 8-bits container
     *         |<-- byte 1 -->|  |<-- byte 2 -->|  |<-- byte 3  -->|
     *  Plane 1     R[7:0]            R[7:0]            R[7:0]
     *  Plane 2     G[7:0]            G[7:0]            G[7:0]
     *  Plane 3     B[7:0]            B[7:0]            B[7:0]
     */
    PD_FORMAT_EXT_RGB888_PLANAR,
    
    /* PD extension of color format with variations using unused platform bits in WFD */
    /* WFD:  0-15 bits   colorformat
            16-19 bits:  QC extension
            20-31 bits:  platform bits (unused) */

    /* UBWC_NV124R. WFD_USAGE_COMPRESSION shall always be used together with this format. */
    
    PD_FORMAT_EXT_UBWC_NV124R = ((1 << 20) | WFD_FORMAT_NV12),

    PD_FORMAT_MAX = 0x7FFFFFFF
} PDColorFormat_e;

/**********************************************************************************************//**
@brief
    Defines plane definition structure
**************************************************************************************************/
typedef struct
{
   /**< [in] Plane index to which property applies. Starts from 1. */
   uint32_t            nPlaneIndex;

   /**< Minimum allowed stride in bytes for the plane */
   uint32_t            nMinStride;

   /**< Maximum allowed stride in bytes for the plane */
   uint32_t            nMaxstride;

   /**< Stride multiple in byes allowed in horizontal direction. */
   uint32_t            nStrideMultiples;

   /**< Actual stride for the plane in bytes. This would be used while calculating
        buffer requirement */
   uint32_t            nActualStride;

   /**< Minimum allowed plane height in scanlines */
   uint32_t            nMinPlaneBufHeight;

   /**< Height multiple in scanlines allowed in vertical direction. */
   uint32_t            nHeightMultiples;

   /**< Actual plane height in scanlines for the plane. This would be used while calculating
        buffer requirement */
   uint32_t            nActualPlaneBufHeight;

   /**< Buffer size alignment requirement in bytes for this plane. */
   uint32_t            nBufSizeAlignment;

   /**< Actual buffer size alignment in bytes for this plane. */
   uint32_t            nActualBufSizeAlignment;

   /**< Buffer address alignment requirement in bytes for this plane. */
   uint32_t            nBufAddrAlignment;

   /**< Minimum buffer size in bytes required for this plane. This does not include
        padding size. It is calculated as
        Align(nActualPlaneBufStride * nActualPlaneBufHeight, nActuaBufSizeAlignment) */
   uint32_t            nPlaneBufSize;

   /**< Padding size (used as extra data) at the end of the plane.
        The total buffer size for this plane is
        plane_buf_size + plane_padding_size */
   uint32_t            nPlanePaddingSize;

} PlaneDef_t;

/**********************************************************************************************//**
@brief
    Defines frame resolution structure
**************************************************************************************************/
typedef struct
{
   /**< frame width in number of pixels */
   uint32_t            nWidthInPixels;

   /**< frame height in number of pixels */
   uint32_t            nHeightInPixels;
} FrameRes_t;

/**********************************************************************************************//**
@brief
    Query the number of planes given the color format and usage

@param [in] eColorFormat
    APDF color format defined in PDColorFormat_e

@param [in] nUsage
    Usage bits defined in wfdExt2.h

@param [out] pNumPlanes
    Pointer to number of planes

@param [in] nFlags
    Flags reserved for future features

@return
    status code defined in PDStatus_e
**************************************************************************************************/
PDStatus_e PDQueryNumPlanes
(
    PDColorFormat_e     eColorFormat,
    uint32_t            nUsage,
    uint32_t            *pNumPlanes,
    uint32_t            nFlags
);

/**********************************************************************************************//**
@brief
    Query the plane definition of the uncompressed buffer given the input color
    format, usage, frame resolution and plane index.

@param [in] eColorFormat
    Planedef color formats

@param [in] nUsage
    Usage bits defined in wfdExt2.h

@param [in] pFrameRes
    Pointer to frame resolution (width / height in pixels)

@param [in/out] pPlaneDef
    Pointer to plane definition including an input of plane index and output
    plane definition

@param [in] nFlags
    Flags reserved for future features

@return
    status code defined in PDStatus_e
**************************************************************************************************/
PDStatus_e PDQueryPlaneDef
(
    PDColorFormat_e     eColorFormat,
    uint32_t            nUsage,
    const   FrameRes_t  *pFrameRes,
    PlaneDef_t          *pPlaneDef,
    uint32_t            nFlags
);

#ifdef __cplusplus
}

#endif

#endif /* APDF_H */
