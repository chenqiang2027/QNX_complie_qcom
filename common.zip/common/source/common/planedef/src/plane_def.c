/*========================================================================

*//** @file plane_def.c

@par FILE SERVICES:
      This file defines the data types to get plane definition of
      uncompressed buffer formats.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2013-2022 QUALCOMM Technologies, Incorporated. All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/planedef/src/plane_def.c#1 $

when       who     what, where, why
--------   ---     -------------------------------------------------------
11/30/22   sh      Update alignment for RGB888 on 8560
09/14/22   jz      Update alignment for RGB888 on 8540
07/06/22   sh      Increase padding size to match interlace calculated size for NV12_UBWC
07/04/22   sh      Add 8255 planedef info
10/20/21   mm      Change NV12's alignment to 128x32 for 8540
08/17/21   xg      Change TP10 marco due to QNX screen header change
03/17/21   sw      Fix static analysis tool reported issues
05/26/21   yc      Correct compatible type judegment
05/18/21   yc      Update NV12 height_multiple in planedef for Makena
03/26/21   rz      Add support of NV124R-UBWC color format
10/10/20   yc      Add 8540 planedef info
02/21/20   sm      Update h/w access flag to include opengl ES3  
01/02/20   sm      Update stride alignment for UYVY on 8155  
12/06/19   sm      Invoke detect asic only once to reduce underlying fdt API call  
11/05/19   md      Add support for 10 bit formats
10/08/19   hl      Support Ghs Integrity
09/26/19   rz      Remove unused header; Fix csim build
08/27/19   jz      use fdt instead of dal api to query chip info
07/29/19   sm      Update for Hana/Talos and chip detection
04/11/19   jz      Add PLANEDEF_SW_USAGE_FLAGS for UYVY and YVYU
09/04/18   rz      Fix planedef macro when alignment is not power of 2  
08/24/18   rz      Add WFD_FORMAT_YUY2
06/20/18   rz      Move WFD_USAGE_NATIVE from SW usage to HW usage category 
06/12/18   rz      Use wfdext2.h instead of wfdext.h 
04/05/18   rz      Fix print fmt check errors
01/02/18   rz      Fix MISRA warning 
11/21/17   rz      Consolidate entries for the same format and different usage flags
11/17/17   rz      Add Venus workaround for NV12_UBWC 
11/15/17   rz      Add RGB888 for SW usage 
10/11/17   rz      Update video encoder NV12 extra data requirement
10/05/17   rz      Update Video usage NV12 UBWC UV meta plane scale factor
09/29/17   rz      Support SW usage and HW DISPLAY formats: NV12/RGBA8888/RGBX8888 
09/13/17   rz      Add 8096 RGBA4444 and RGBA5551
08/31/17   rz      Fix 8996 UBWC use case query failure 
07/28/17   rz      Update 8996 Capture buffer alignment; 
                   Select the entry of largest buffer size given the same color format 
05/25/17   rz      Add 8996 UYVY/YVYU
04/11/17   rz      Add 8996 RGB565 UBWC
03/31/17   rz      Add 8996 RGB565
03/30/17   am      Fix 8096 tables with highest flag table first for same color format.
                   Added RGBX8888 and RGBX8888 UBWC planedef tables.
03/08/17   rz      Fix compilation
02/17/17   am      Update 8096 tables and add UBWC_RGBA888 table.
01/17/17   rz      Fix compilation warning with printf format check
05/27/16   am      Add 8096 plane definitions for NV12, UBWC_NV12 and
                   RGB565/RGBA8888 formats.
06/10/14   am      Height multiple for UYVU should be non-zero.
04/16/14   rz      Avoid redundent uname calls for unsupported chipset
04/09/14   rz      Optimization on saving detected asic
03/19/14   rz      Add UYVU for APQ8064 
02/11/13   rz      Turn off debug msg flag
02/04/13   rz      Use debug library to silence error log
10/31/13   rz      Add/remove logging
10/16/13   rz      Add extra data for decoder 
09/06/13   rz      Reorder encoder/decoder table entries for UI camcorder
09/05/13   uc      Fixed Klocwork warnings.
08/08/13   rz      Remove obselete APIs
08/02/13   rz      Use align instead of ceil function
07/11/13   rz      Ceil the stride calculation
07/10/13   rz      Support RGB565/RGBA8888 in 8960Pro/8930
06/27/13   rz      Add encoder input crop extra data
05/14/13   rz      Fix usage flag check
05/14/13   rz      Support usage flag via new APIs
04/25/13   rz      Use bit mask to get QC color format
04/03/13   dwp     modify detect_asic() to return only valid index values or error
03/12/13   rz      Added get_omx_plane_def API
03/04/13   rz      Removed buffer size alignment for the last plane
02/27/13   rz      Added height_multiple
01/31/13   rz      Created file.
========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "plane_def.h"
#include "wfd.h"
#include "wfdext2.h"
#include "AEEStdDef.h"
#include "AEEstd.h"
#include "MMDebugMsg.h"
#include "QOMX_IVCommonExtensions.h"

#if defined(__INTEGRITY)
#include "fdt_stub.h"
#elif !defined(WIN32)
#include "libfdt_env.h"
#include <fdt.h>
#include <libfdt.h>
#include <fdt_utils.h>
#endif

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */
#define  PLANEDEF_ASIC_UNINITIALIZED    ( -3 )
#define  PLANEDEF_ASIC_DETECTION_FAILED ( -2 )
#define  PLANEDEF_ASIC_UNSUPPORTED      ( -1 )

/* Returns the next aligned location */
#define PLANEDEF_NUMBLOCKS(num_pix, block_dim) ((block_dim) ? (( (num_pix) + ((block_dim) - 1)) / (block_dim)) : (num_pix))
#define PLANEDEF_ALIGN( val, align ) ( (0 != (align)) ? (((val)+(align)-1)/(align)*(align)) : (val))
#define PLANEDEF_KILO( val )          (1024*(val))
#define PLANEDEF_MAX_NUM_PLANES       (4)
#define PLANEDEF_SCALE(num_pix, scale_factor) ( (scale_factor) ? ( ((num_pix) + (scale_factor-1))/(scale_factor)) : (num_pix) )

#define PLANEDEF_MSG_HIGH( xx_fmt, ...) \
    MM_MSG_PRIO_EX(MM_VIDEO_TASK, MM_PRIO_HIGH, xx_fmt, ## __VA_ARGS__)
#define PLANEDEF_MSG_ERROR( xx_fmt, ...) \
    MM_MSG_PRIO_EX(MM_VIDEO_TASK, MM_PRIO_ERROR, xx_fmt, ## __VA_ARGS__)
#define PLANEDEF_MSG_DEBUG( xx_fmt, ... )   \
       { if( g_planedef_debug )    \
          { MM_MSG_PRIO_EX(MM_VIDEO_TASK, MM_PRIO_HIGH, xx_fmt, ## __VA_ARGS__); } \
       }

#define INTERLACE_MAX_WIDTH 1920
#define INTERLACE_MAX_HEIGHT 1920
#define INTERLACE_MAX_MB_PER_FRAME ((1920*1088)/256)

typedef enum
{
   ASIC_TYPE_8960AB = 0x0,
   ASIC_TYPE_8930,
   ASIC_TYPE_8064,
   ASIC_TYPE_8974,
   ASIC_TYPE_8096,
   ASIC_TYPE_6150,
   ASIC_TYPE_8150,
   ASIC_TYPE_8540,
   ASIC_TYPE_8255
} planedef_asic_type;

/**
 * This is to check whether HW or SW usage flag is used 
 */
#define PLANEDEF_HW_USAGE_FLAGS  ( WFD_USAGE_OPENGL_ES2 | \
                                   WFD_USAGE_OPENGL_ES3 | \
                                   WFD_USAGE_CAPTURE |    \
                                   WFD_USAGE_VIDEO |      \
                                   WFD_USAGE_DISPLAY |    \
                                   WFD_USAGE_NATIVE )

#define PLANEDEF_SW_USAGE_FLAGS  ( WFD_USAGE_READ |    \
                                   WFD_USAGE_WRITE )

/**
 * This is to check whether the color format is nv12
 */
#define PLANEDEF_IS_NV12(color_format)   ( WFD_FORMAT_NV12 == (color_format & 0xFFFF) )

#define PLANEDEF_FIRST_PLANE   (1)

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

static boolean g_planedef_debug    = FALSE;
static boolean g_logInit = FALSE;
static int     g_planedef_asic_idx = PLANEDEF_ASIC_UNINITIALIZED;



/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/* This data type defines plane alignment and padding requirement */
typedef struct
{
   /* stride multiple for this plane in number of bytes */
   unsigned long  stride_multiple;

   /* extra stride padding after applying stride multiple in number of bytes */
   unsigned long  stride_padding;

   /* bits per pixel */
   unsigned long  bits_per_pixel;

   /* height multiple for this plane in number of scan lines */
   unsigned long  height_multiple;

   /* block width in pixels */
   unsigned long  block_width;

   /* block height in pixels */
   unsigned long block_height;

   /* scale factor for plane width */
   unsigned long width_scale;

   /* scale factor for plane height */
   unsigned long height_scale;

   /* buffer alignment for this plane in number of bytes */
   unsigned long  buf_alignment;

   /* extra padding size at the end of the plane in number of bytes */
   unsigned long  padding_size;

} planedef_info_type;


/* This data type defines overall alignment requirement for
** uncompressed buffer format
*/
typedef struct
{
   /* The usage flag defined in wfdext.h
   */
   unsigned long       usage;

   /* color format defined in wfdext.h:
   ** Expectation of the color format:
   **     0-15 bits:   Native QNX format defined in wfdext.h
   **     16-19 bits:  QCOM format defined in wfdext.h
   **     20-31 bits:  platform bits defined in wfdext.h
   */
   unsigned long        color_format;

   /* number of planes required for this color format */
   unsigned long        num_planes;

   /* data structure including planedef information */
   planedef_info_type   planedef_info[PLANEDEF_MAX_NUM_PLANES];

} planedef_tbl_entry_type;


/* This data type defines planedef tables */
typedef struct
{
   /* Number of table entries */
   unsigned long   num_entries;

   /* each entry: one color format */
   planedef_tbl_entry_type* entries;

} planedef_tbl_type;


/* This data type defines platform information */
typedef struct
{
    char* machine_name;
    char* family_name;
    char* asic_name;
    planedef_asic_type asic_type;
    planedef_tbl_type* planedef_tbl;
} planedef_asic_info;

/* 8960Pro planedef table for supported color formats */
static planedef_tbl_entry_type   planedef_info_tbl_8960AB[] =
{
   {
      PLANEDEF_HW_USAGE_FLAGS,       // usage flag
      WFD_FORMAT_RGB565,          // color format
      1,                              // number of planes
      {
         {128, 0,  16, 32, 0, 0, 1, 1, 0,  0},  // Plane 1 alignment
         {0,   0,  0,  0,  0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,  0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,  0, 0, 0, 0, 0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,       // usage flag
      WFD_FORMAT_RGBA8888,        // color format
      1,                              // number of planes
      {
         {128, 0,  32, 32,  0, 0, 1, 1, 0,  0},  // Plane 1 alignment
         {0,   0,  0,   0,  0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,   0,  0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,   0,  0, 0, 0, 0, 0,  0}   // N/A
      },
   }
};

/* 8930 planedef table for supported color formats */
static planedef_tbl_entry_type   planedef_info_tbl_8930[] =
{
   {
      PLANEDEF_HW_USAGE_FLAGS,       // usage flag
      WFD_FORMAT_RGB565,          // color format
      1,                              // number of planes
      {
         {128, 128, 16, 32,  0, 0, 1, 1, 0, 0},  // Plane 1 alignment
         {0,     0,  0,  0,  0, 0, 0, 0, 0, 0},  // N/A
         {0,     0,  0,  0,  0, 0, 0, 0, 0, 0},  // N/A
         {0,     0,  0,  0,  0, 0, 0, 0, 0, 0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,       // usage flag
      WFD_FORMAT_RGBA8888,        // color format
      1,                              // number of planes
      {
         {128, 128, 32, 32, 0,  0, 1, 1, 0,  0},  // Plane 1 alignment
         {0,     0,  0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,     0,  0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,     0,  0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   }
};

/* 8064 planedef table for supported color formats */
static planedef_tbl_entry_type   planedef_info_tbl_8064[] =
{
   {  PLANEDEF_HW_USAGE_FLAGS,     // usage flag
      WFD_FORMAT_UYVY,       // color format
      1,                         // number of planes
      {
         {32*2, 0,  16, 32,  0, 0, 1, 1, 0,  0},     // Plane 1 alignment
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0}          // N/A
      },
   }

};

/* 8974 planedef table for supported color formats */
static planedef_tbl_entry_type   planedef_info_tbl_8974[] =
{
   {  PLANEDEF_HW_USAGE_FLAGS,     // usage flag
      WFD_FORMAT_NV12,       // color format
      2,                         // number of planes
      {
         {128, 0, 8,  32, 0, 0, 1, 1, 128, 0},      // Plane 1 alignment
         {128, 0, 8,  16, 0, 0, 1, 2, 128, 128 + 256 + 2048}, // plane 2 alignment
                                                    // Padding: 128 - Venus YUV requirement
                                                    //          72  - Encoder input crop extra data
         {0,   0,  0,  0,  0, 0, 0, 0, 0,  0},      // N/A
         {0,   0,  0,  0,  0, 0, 0, 0, 0,  0}       // N/A
      },
   },
};

/* 8096 planedef table for supported color formats */
static planedef_tbl_entry_type   planedef_info_tbl_8096[] =
{
   {  PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_UYVY,       // color format
      1,                         // number of planes
      {
         {128,  0,  16, 32,  0, 0, 1, 1, 0,  0},     // Plane 1 alignment
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0}          // N/A
      },
   },

   {  PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_YVYU,       // color format
      1,                         // number of planes
      {
         {128,  0,  16, 32,  0, 0, 1, 1, 0,  0},     // Plane 1 alignment
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0}          // N/A
      },
   },

   {  PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_NV12,       // color format
      2,                         // number of planes
      {
         {128, 0, 8,  32, 0, 0, 1, 1, 128,   0},  // Plane 1 alignment
         {128, 0, 8,  32, 0, 0, 1, 2, 128,  4096},  // plane 2 alignment: 
                                                    // padding: extra data
         {0,   0, 0,   0, 0, 0, 0, 0,   0,   0},  // N/A
         {0,   0, 0,   0, 0, 0, 0, 0,   0,   0}   // N/A
      },
   },

   {  PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_YUY2,       // color format
      1,                         // number of planes
      {
         {128,  0,  16, 32,  0, 0, 1, 1, 0,  0},     // Plane 1 alignment
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0}          // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_RGB565,                        // color format
      1,                                            // number of planes
      {
         {128, 0,  16, 32,  0, 0, 1, 1, 0,  0},   // Plane 1 alignment
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },
   
   {
      PLANEDEF_HW_USAGE_FLAGS,       // usage flag
      WFD_FORMAT_RGBA8888,        // color format
      1,                              // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,       // usage flag
      WFD_FORMAT_RGBX8888,        // color format
      1,                              // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,        // usage flag
      WFD_FORMAT_RGB888,          // color format
      1,                              // number of planes
      {
         {192, 0,  24, 32,  0, 0, 1, 1, 0,  0},   // Plane 1 alignment
         {  0, 0,  0,  0, 0, 0, 0, 0, 0, 0}, // N/A
         {  0, 0,  0,  0, 0, 0, 0, 0, 0, 0}, // N/A
         {  0, 0,  0,  0, 0, 0, 0, 0, 0, 0}  // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,  // usage flag
      WFD_FORMAT_RGBA4444,     // color format
      1,                         // number of planes
      {
         {128, 0, 16, 32, 0, 0, 1, 1, 0, 0}, // Plane 1 alignment
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
     PLANEDEF_HW_USAGE_FLAGS,  // usage flag
     WFD_FORMAT_RGBA5551,     // color format
     1,                         // number of planes
     {
        {128, 0, 16, 32, 0, 0, 1, 1, 0, 0}, // Plane 1 alignment
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
     }, 
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag with UBWC
      WFD_FORMAT_NV12,       // color format
      4,                         // number of planes
      {
         { 64, 0, 8,  16, 32, 8, 1, 1, 4096,      0},      // plane 1 alignment Y metadata
         {128, 0, 8,  32,  0, 0, 1, 1, 4096,      0},      // Plane 2 alignment Y
         { 64, 0, 8,  16, 16, 8, 2, 2, 4096,      0},      // plane 3 alignment UV metadata
         {128, 0, 8,  32,  0, 0, 1, 2, 4096,      4096}    // plane 4 alignment UV
                                                           // Padding: extra data
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION, // usage flag
      WFD_FORMAT_RGB565,                                // color format
      2,                                                    // number of planes
      {
         { 64, 0,  8, 16, 16, 4, 1, 1, 4096, 0}, // Plane 1 alignment metadata
         {256, 0, 16, 16,  0, 0, 1, 1, 4096, 0}, // Plane 2 alignment
         {  0, 0,  0,  0,  0, 0, 0, 0, 0, 0}, // N/A
         {  0, 0,  0,  0,  0, 0, 0, 0, 0, 0}  // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag
      WFD_FORMAT_RGBA8888,        // color format
      2,                              // number of planes
      {
         {64,   0,  8, 16, 16, 4, 1, 1, 4096,  0},     // Plane 1 alignment metadata
         {256,  0, 32, 16,  0, 0, 1, 1, 4096,  0},  // Plane 2 alignment Padding: 8K for extradata
         {0,    0,  0,  0,  0, 0, 0, 0,    0,  0},  // N/A
         {0,    0,  0,  0,  0, 0, 0, 0,    0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag
      WFD_FORMAT_RGBX8888,        // color format
      2,                              // number of planes
      {
         {64,  0,   8, 16,  0, 0, 1, 1, 4096,  0},     // Plane 1 alignment metadata
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 2 alignment Padding: 8K for extradata
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
      },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_NV12,       // color format
     2,                         // number of planes
     {
        {2, 0, 8,  2, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {2, 0, 8,  1, 0, 0, 1, 2, 0, 0},            // plane 2 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_YUY2,       // color format
     1,                         // number of planes
     {
        {1, 0, 16, 1, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_UYVY,       // color format
     1,                         // number of planes
     {
        {1, 0, 16, 1, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_YVYU,       // color format
     1,                         // number of planes
     {
        {1, 0, 16, 1, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,             // SW usage flag for native color formats
     WFD_FORMAT_RGBA8888,        // color format
     1,                              // number of planes
     {
        {1,   0,  32, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment 
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,             // SW usage flag for native color formats
     WFD_FORMAT_RGBX8888,        // color format
     1,                              // number of planes
     {
        {1,   0,  32, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment 
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,             // SW usage flag for native color formats
     WFD_FORMAT_RGB565,        // color format
     1,                              // number of planes
     {
        {1,   0,  16, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment 
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,             // SW usage flag for native color formats
     WFD_FORMAT_RGB888,        // color format
     1,                              // number of planes
     {
        {1,   0,  24, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment 
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
     },
   },
};

/* Hana/Talos planedef table for supported color formats */
static planedef_tbl_entry_type   planedef_info_tbl_8150[] =
{
   {  PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_UYVY,       // color format
      1,                         // number of planes
      {
         {16,   0,  16, 32,  0, 0, 1, 1, 0,  0},     // Plane 1 alignment
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0}          // N/A
      },
   },

   {  PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_YVYU,       // color format
      1,                         // number of planes
      {
         {128,  0,  16, 32,  0, 0, 1, 1, 0,  0},     // Plane 1 alignment
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0}          // N/A
      },
   },

   {  PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_NV12,       // color format
      2,                         // number of planes
      {
         {128, 0, 8,  32, 0, 0, 1, 1, 128,   0},  // Plane 1 alignment
         {128, 0, 8,  32, 0, 0, 1, 2, 128,  4096},  // plane 2 alignment: 
                                                    // padding: extra data
         {0,   0, 0,   0, 0, 0, 0, 0,   0,   0},  // N/A
         {0,   0, 0,   0, 0, 0, 0, 0,   0,   0}   // N/A
      },
   },

   {  PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_YUY2,       // color format
      1,                         // number of planes
      {
         {128,  0,  16, 32,  0, 0, 1, 1, 0,  0},     // Plane 1 alignment
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0}          // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_RGB565,                        // color format
      1,                                            // number of planes
      {
         {128, 0,  16, 32,  0, 0, 1, 1, 0,  0},   // Plane 1 alignment
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },
   
   {
      PLANEDEF_HW_USAGE_FLAGS,       // usage flag
      WFD_FORMAT_RGBA8888,        // color format
      1,                              // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,       // usage flag
      WFD_FORMAT_RGBX8888,        // color format
      1,                              // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,        // usage flag
      WFD_FORMAT_RGB888,          // color format
      1,                              // number of planes
      {
         {192, 0,  24, 32,  0, 0, 1, 1, 0,  0},   // Plane 1 alignment
         {  0, 0,  0,  0, 0, 0, 0, 0, 0, 0}, // N/A
         {  0, 0,  0,  0, 0, 0, 0, 0, 0, 0}, // N/A
         {  0, 0,  0,  0, 0, 0, 0, 0, 0, 0}  // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,  // usage flag
      WFD_FORMAT_RGBA4444,     // color format
      1,                         // number of planes
      {
         {128, 0, 16, 32, 0, 0, 1, 1, 0, 0}, // Plane 1 alignment
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
     PLANEDEF_HW_USAGE_FLAGS,  // usage flag
     WFD_FORMAT_RGBA5551,     // color format
     1,                         // number of planes
     {
        {128, 0, 16, 32, 0, 0, 1, 1, 0, 0}, // Plane 1 alignment
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
     }, 
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_RGBX1010102,                        // color format
      1,                                            // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_RGBA1010102,                        // color format
      1,                                            // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_BGRX1010102,                        // color format
      1,                                            // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_BGRA1010102,                        // color format
      1,                                            // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_P010,       // color format
      2,                         // number of planes
      {
         {256, 0, 16,  32, 0, 0, 1, 1, 0,   0},  // Plane 1 alignment
         {256, 0, 16,  16, 0, 0, 1, 2, 0,  4096},  // plane 2 alignment: padding: extra data
         {0,   0, 0,   0, 0,  0, 0, 0, 0,   0},  // N/A
         {0,   0, 0,   0, 0,  0, 0, 0, 0,   0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag with UBWC
      WFD_FORMAT_NV12,       // color format
      4,                         // number of planes
      {
         { 64, 0, 8,  16, 32, 8, 1, 1, 4096,      0},      // plane 1 alignment Y metadata
         {128, 0, 8,  32,  0, 0, 1, 1, 4096,      0},      // Plane 2 alignment Y
         { 64, 0, 8,  16, 16, 8, 2, 2, 4096,      0},      // plane 3 alignment UV metadata
         {128, 0, 8,  32,  0, 0, 1, 2, 4096,      4096}    // plane 4 alignment UV
                                                           // Padding: extra data
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION, // usage flag
      WFD_FORMAT_RGB565,                                // color format
      2,                                                    // number of planes
      {
         { 64, 0,  8, 16, 16, 4, 1, 1, 4096, 0}, // Plane 1 alignment metadata
         {256, 0, 16, 16,  0, 0, 1, 1, 4096, 0}, // Plane 2 alignment
         {  0, 0,  0,  0,  0, 0, 0, 0, 0, 0}, // N/A
         {  0, 0,  0,  0,  0, 0, 0, 0, 0, 0}  // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag
      WFD_FORMAT_RGBA8888,        // color format
      2,                              // number of planes
      {
         {64,   0,  8, 16, 16, 4, 1, 1, 4096,  0},     // Plane 1 alignment metadata
         {256,  0, 32, 16,  0, 0, 1, 1, 4096,  0},  // Plane 2 alignment Padding: 8K for extradata
         {0,    0,  0,  0,  0, 0, 0, 0,    0,  0},  // N/A
         {0,    0,  0,  0,  0, 0, 0, 0,    0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag
      WFD_FORMAT_RGBX8888,        // color format
      2,                              // number of planes
      {
         {64,  0,   8, 16,  0, 0, 1, 1, 4096,  0},     // Plane 1 alignment metadata
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 2 alignment Padding: 8K for extradata
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag
      WFD_FORMAT_RGBA1010102,        // color format
      2,                              // number of planes
      {
         {64,   0,  8, 16, 16, 4, 1, 1, 4096,  0},  // Plane 1 alignment metadata
         {256,  0, 32, 16,  0, 0, 1, 1, 4096,  0},  // Plane 2 alignment Padding: 8K for extradata
         {0,    0,  0,  0,  0, 0, 0, 0,    0,  0},  // N/A
         {0,    0,  0,  0,  0, 0, 0, 0,    0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag with UBWC
      WFD_FORMAT_P010,       // color format
      4,                         // number of planes
      {
         {64,  0, 8,  16, 32, 4, 1, 1, 4096,  0},      // plane 1 alignment Y metadata
         {256, 0, 8,  16, 0,  0, 1, 1, 4096,  0},      // Plane 2 alignment Y
         {64,  0, 8,  16, 16, 4, 2, 2, 4096,  0},      // plane 3 alignment UV metadata
         {256, 0, 8,  16, 0,  0, 1, 2, 4096,  4096}    // plane 4 alignment UV
                                                           // Padding: extra data
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag with UBWC
      WFD_FORMAT_NV12_QC_TP10,       // color format
      4,                         // number of planes
      {
         { 64, 0, 8, 16, 48, 4, 1, 1, 4096, 0 },      // plane 1 alignment Y metadata
         { 256, 0, 8, 16, 0, 0, 1, 1, 4096, 0 },      // Plane 2 alignment Y
         { 64, 0, 8, 16, 24, 4, 2, 2, 4096, 0 },      // plane 3 alignment UV metadata
         { 256, 0, 8, 16, 0, 0, 1, 2, 4096, 4096 }    // plane 4 alignment UV
         // Padding: extra data
      },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_NV12,       // color format
     2,                         // number of planes
     {
        {2, 0, 8,  2, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {2, 0, 8,  1, 0, 0, 1, 2, 0, 0},            // plane 2 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_YUY2,       // color format
     1,                         // number of planes
     {
        {1, 0, 16, 1, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_UYVY,       // color format
     1,                         // number of planes
     {
        {1, 0, 16, 1, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_YVYU,       // color format
     1,                         // number of planes
     {
        {1, 0, 16, 1, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,             // SW usage flag for native color formats
     WFD_FORMAT_RGBA8888,        // color format
     1,                              // number of planes
     {
        {1,   0,  32, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment 
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,             // SW usage flag for native color formats
     WFD_FORMAT_RGBX8888,        // color format
     1,                              // number of planes
     {
        {1,   0,  32, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment 
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,             // SW usage flag for native color formats
     WFD_FORMAT_RGB565,        // color format
     1,                              // number of planes
     {
        {1,   0,  16, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment 
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,             // SW usage flag for native color formats
     WFD_FORMAT_RGB888,        // color format
     1,                              // number of planes
     {
        {1,   0,  24, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment 
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
     },
   },
   {
      PLANEDEF_SW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_RGBX1010102,                        // color format
      1,                                            // number of planes
      {
        {1,   0,  32, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },
   {
      PLANEDEF_SW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_RGBA1010102,                        // color format
      1,                                            // number of planes
      {
        {1,   0,  32, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },
   {
      PLANEDEF_SW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_BGRX1010102,                        // color format
      1,                                            // number of planes
      {
         {1,   0,  32,  1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },
   {
      PLANEDEF_SW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_BGRA1010102,                        // color format
      1,                                            // number of planes
      {
         {1,   0,  32,  1,  0, 0, 1, 1, 0,  0},  // Plane 1 alignment
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },
   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_P010,       // color format
     2,                         // number of planes
     {
        {2, 0, 16,  1, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {2, 0, 16,  1, 0, 0, 1, 2, 0, 0},            // plane 2 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },
};

/* Makena planedef table for supported color formats */
static planedef_tbl_entry_type   planedef_info_tbl_8540[] =
{
   {  PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_UYVY,       // color format
      1,                         // number of planes
      {
         {16,   0,  16, 32,  0, 0, 1, 1, 0,  0},     // Plane 1 alignment
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0}          // N/A
      },
   },

   {  PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_YVYU,       // color format
      1,                         // number of planes
      {
         {128,  0,  16, 32,  0, 0, 1, 1, 0,  0},     // Plane 1 alignment
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0}          // N/A
      },
   },

   {  PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_NV12,       // color format
      2,                         // number of planes
      {
         {128, 0, 8,  32, 0, 0, 1, 1, 128,   0},  // Plane 1 alignment
         {128, 0, 8,  32, 0, 0, 1, 2, 128,  4096},  // plane 2 alignment: 
                                                    // padding: extra data
         {0,   0, 0,   0, 0, 0, 0, 0,   0,   0},  // N/A
         {0,   0, 0,   0, 0, 0, 0, 0,   0,   0}   // N/A
      },
   },

   {  PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_YUY2,       // color format
      1,                         // number of planes
      {
         {128,  0,  16, 32,  0, 0, 1, 1, 0,  0},     // Plane 1 alignment
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0}          // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_RGB565,                        // color format
      1,                                            // number of planes
      {
         {128, 0,  16, 32,  0, 0, 1, 1, 0,  0},   // Plane 1 alignment
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,       // usage flag
      WFD_FORMAT_RGBA8888,        // color format
      1,                              // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,       // usage flag
      WFD_FORMAT_RGBX8888,        // color format
      1,                              // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,        // usage flag
      WFD_FORMAT_RGB888,          // color format
      1,                              // number of planes
      {
         {768, 768,  24, 32,  0, 0, 1, 1, 0,  0},   // Plane 1 alignment
         {  0, 0,  0,  0, 0, 0, 0, 0, 0, 0}, // N/A
         {  0, 0,  0,  0, 0, 0, 0, 0, 0, 0}, // N/A
         {  0, 0,  0,  0, 0, 0, 0, 0, 0, 0}  // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,  // usage flag
      WFD_FORMAT_RGBA4444,     // color format
      1,                         // number of planes
      {
         {128, 0, 16, 32, 0, 0, 1, 1, 0, 0}, // Plane 1 alignment
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
     PLANEDEF_HW_USAGE_FLAGS,  // usage flag
     WFD_FORMAT_RGBA5551,     // color format
     1,                         // number of planes
     {
        {128, 0, 16, 32, 0, 0, 1, 1, 0, 0}, // Plane 1 alignment
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
     },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_RGBX1010102,                        // color format
      1,                                            // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_RGBA1010102,                        // color format
      1,                                            // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_BGRX1010102,                        // color format
      1,                                            // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_BGRA1010102,                        // color format
      1,                                            // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_P010,       // color format
      2,                         // number of planes
      {
         {256, 0, 16,  32, 0, 0, 1, 1, 0,   0},  // Plane 1 alignment
         {256, 0, 16,  16, 0, 0, 1, 2, 0,  4096},  // plane 2 alignment: padding: extra data
         {0,   0, 0,   0, 0,  0, 0, 0, 0,   0},  // N/A
         {0,   0, 0,   0, 0,  0, 0, 0, 0,   0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag with UBWC
      WFD_FORMAT_NV12,       // color format
      4,                         // number of planes
      {
         { 64, 0, 8,  16, 32, 8, 1, 1, 4096,      0},      // plane 1 alignment Y metadata
         {128, 0, 8,  32,  0, 0, 1, 1, 4096,      0},      // Plane 2 alignment Y
         { 64, 0, 8,  16, 16, 8, 2, 2, 4096,      0},      // plane 3 alignment UV metadata
         {128, 0, 8,  32,  0, 0, 1, 2, 4096,      4096}    // plane 4 alignment UV
                                                           // Padding: extra data
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag with UBWC
      PLANEDEF_FORMAT_EXT_UBWC_NV124R,       // color format
      4,                         // number of planes
      {
         { 64, 0, 8,  16, 64, 4, 1, 1, 4096,      0},      // plane 1 alignment Y metadata
         {256, 0, 8,  16,  0, 0, 1, 1, 4096,      0},      // Plane 2 alignment Y
         { 64, 0, 8,  16, 32, 4, 2, 2, 4096,      0},      // plane 3 alignment UV metadata
         {256, 0, 8,  16,  0, 0, 1, 2, 4096,      0}       // plane 4 alignment UV
                                                           // Padding: extra data
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION, // usage flag
      WFD_FORMAT_RGB565,                                // color format
      2,                                                    // number of planes
      {
         { 64, 0,  8, 16, 16, 4, 1, 1, 4096, 0}, // Plane 1 alignment metadata
         {256, 0, 16, 16,  0, 0, 1, 1, 4096, 0}, // Plane 2 alignment
         {  0, 0,  0,  0,  0, 0, 0, 0, 0, 0}, // N/A
         {  0, 0,  0,  0,  0, 0, 0, 0, 0, 0}  // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag
      WFD_FORMAT_RGBA8888,        // color format
      2,                              // number of planes
      {
         {64,   0,  8, 16, 16, 4, 1, 1, 4096,  0},     // Plane 1 alignment metadata
         {256,  0, 32, 16,  0, 0, 1, 1, 4096,  0},  // Plane 2 alignment Padding: 8K for extradata
         {0,    0,  0,  0,  0, 0, 0, 0,    0,  0},  // N/A
         {0,    0,  0,  0,  0, 0, 0, 0,    0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag
      WFD_FORMAT_RGBX8888,        // color format
      2,                              // number of planes
      {
         {64,  0,   8, 16,  0, 0, 1, 1, 4096,  0},     // Plane 1 alignment metadata
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 2 alignment Padding: 8K for extradata
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag
      WFD_FORMAT_RGBA1010102,        // color format
      2,                              // number of planes
      {
         {64,   0,  8, 16, 16, 4, 1, 1, 4096,  0},  // Plane 1 alignment metadata
         {256,  0, 32, 16,  0, 0, 1, 1, 4096,  0},  // Plane 2 alignment Padding: 8K for extradata
         {0,    0,  0,  0,  0, 0, 0, 0,    0,  0},  // N/A
         {0,    0,  0,  0,  0, 0, 0, 0,    0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag with UBWC
      WFD_FORMAT_P010,       // color format
      4,                         // number of planes
      {
         {64,  0, 8,  16, 32, 4, 1, 1, 4096,  0},      // plane 1 alignment Y metadata
         {256, 0, 8,  16, 0,  0, 1, 1, 4096,  0},      // Plane 2 alignment Y
         {64,  0, 8,  16, 16, 4, 2, 2, 4096,  0},      // plane 3 alignment UV metadata
         {256, 0, 8,  16, 0,  0, 1, 2, 4096,  4096}    // plane 4 alignment UV
                                                           // Padding: extra data
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag with UBWC
      WFD_FORMAT_NV12_QC_TP10,       // color format
      4,                         // number of planes
      {
         { 64, 0, 8, 16, 48, 4, 1, 1, 4096, 0 },      // plane 1 alignment Y metadata
         { 256, 0, 8, 16, 0, 0, 1, 1, 4096, 0 },      // Plane 2 alignment Y
         { 64, 0, 8, 16, 24, 4, 2, 2, 4096, 0 },      // plane 3 alignment UV metadata
         { 256, 0, 8, 16, 0, 0, 1, 2, 4096, 4096 }    // plane 4 alignment UV
         // Padding: extra data
      },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_NV12,       // color format
     2,                         // number of planes
     {
        {2, 0, 8,  2, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {2, 0, 8,  1, 0, 0, 1, 2, 0, 0},            // plane 2 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_YUY2,       // color format
     1,                         // number of planes
     {
        {1, 0, 16, 1, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_UYVY,       // color format
     1,                         // number of planes
     {
        {1, 0, 16, 1, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_YVYU,       // color format
     1,                         // number of planes
     {
        {1, 0, 16, 1, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,             // SW usage flag for native color formats
     WFD_FORMAT_RGBA8888,        // color format
     1,                              // number of planes
     {
        {1,   0,  32, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,             // SW usage flag for native color formats
     WFD_FORMAT_RGBX8888,        // color format
     1,                              // number of planes
     {
        {1,   0,  32, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,             // SW usage flag for native color formats
     WFD_FORMAT_RGB565,        // color format
     1,                              // number of planes
     {
        {1,   0,  16, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,             // SW usage flag for native color formats
     WFD_FORMAT_RGB888,        // color format
     1,                              // number of planes
     {
        {1,   0,  24, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
     },
   },
   {
      PLANEDEF_SW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_RGBX1010102,                        // color format
      1,                                            // number of planes
      {
        {1,   0,  32, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },
   {
      PLANEDEF_SW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_RGBA1010102,                        // color format
      1,                                            // number of planes
      {
        {1,   0,  32, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },
   {
      PLANEDEF_SW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_BGRX1010102,                        // color format
      1,                                            // number of planes
      {
         {1,   0,  32,  1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },
   {
      PLANEDEF_SW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_BGRA1010102,                        // color format
      1,                                            // number of planes
      {
         {1,   0,  32,  1,  0, 0, 1, 1, 0,  0},  // Plane 1 alignment
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },
   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_P010,       // color format
     2,                         // number of planes
     {
        {2, 0, 16,  1, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {2, 0, 16,  1, 0, 0, 1, 2, 0, 0},            // plane 2 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },
};

/* Lemans planedef table for supported color formats */
static planedef_tbl_entry_type   planedef_info_tbl_8255[] =
{
   {  PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_UYVY,       // color format
      1,                         // number of planes
      {
         {16,   0,  16, 32,  0, 0, 1, 1, 0,  0},     // Plane 1 alignment
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0}          // N/A
      },
   },

   {  PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_YVYU,       // color format
      1,                         // number of planes
      {
         {128,  0,  16, 32,  0, 0, 1, 1, 0,  0},     // Plane 1 alignment
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0}          // N/A
      },
   },

   {  PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_NV12,       // color format
      2,                         // number of planes
      {
         {128, 0, 8,  32, 0, 0, 1, 1, 128,   0},  // Plane 1 alignment
         {128, 0, 8,  32, 0, 0, 1, 2, 128,  4096},  // plane 2 alignment: 
                                                    // padding: extra data
         {0,   0, 0,   0, 0, 0, 0, 0,   0,   0},  // N/A
         {0,   0, 0,   0, 0, 0, 0, 0,   0,   0}   // N/A
      },
   },

   {  PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_YUY2,       // color format
      1,                         // number of planes
      {
         {128,  0,  16, 32,  0, 0, 1, 1, 0,  0},     // Plane 1 alignment
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0},         // N/A
         {0,    0,   0,  0,  0, 0, 0, 0, 0,  0}          // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_RGB565,                        // color format
      1,                                            // number of planes
      {
         {128, 0,  16, 32,  0, 0, 1, 1, 0,  0},   // Plane 1 alignment
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,       // usage flag
      WFD_FORMAT_RGBA8888,        // color format
      1,                              // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,       // usage flag
      WFD_FORMAT_RGBX8888,        // color format
      1,                              // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,        // usage flag
      WFD_FORMAT_RGB888,          // color format
      1,                              // number of planes
      {
         {768, 768,  24, 32,  0, 0, 1, 1, 0,  0},   // Plane 1 alignment
         {  0, 0,  0,  0, 0, 0, 0, 0, 0, 0}, // N/A
         {  0, 0,  0,  0, 0, 0, 0, 0, 0, 0}, // N/A
         {  0, 0,  0,  0, 0, 0, 0, 0, 0, 0}  // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,  // usage flag
      WFD_FORMAT_RGBA4444,     // color format
      1,                         // number of planes
      {
         {128, 0, 16, 32, 0, 0, 1, 1, 0, 0}, // Plane 1 alignment
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
     PLANEDEF_HW_USAGE_FLAGS,  // usage flag
     WFD_FORMAT_RGBA5551,     // color format
     1,                         // number of planes
     {
        {128, 0, 16, 32, 0, 0, 1, 1, 0, 0}, // Plane 1 alignment
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
     },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_RGBX1010102,                        // color format
      1,                                            // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_RGBA1010102,                        // color format
      1,                                            // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_BGRX1010102,                        // color format
      1,                                            // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_BGRA1010102,                        // color format
      1,                                            // number of planes
      {
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 1 alignment Padding: 8K for extradata
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS,   // usage flag
      WFD_FORMAT_P010,       // color format
      2,                         // number of planes
      {
         {256, 0, 16,  32, 0, 0, 1, 1, 0,   0},  // Plane 1 alignment
         {256, 0, 16,  16, 0, 0, 1, 2, 0,  4096},  // plane 2 alignment: padding: extra data
         {0,   0, 0,   0, 0,  0, 0, 0, 0,   0},  // N/A
         {0,   0, 0,   0, 0,  0, 0, 0, 0,   0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag with UBWC
      WFD_FORMAT_NV12,       // color format
      4,                         // number of planes
      {
         { 64, 0, 8,  16, 32, 8, 1, 1, 4096,      0},      // plane 1 alignment Y metadata
         {128, 0, 8,  32,  0, 0, 1, 1, 4096,      0},      // Plane 2 alignment Y
         { 64, 0, 8,  16, 16, 8, 2, 2, 4096,      0},      // plane 3 alignment UV metadata
         {128, 0, 8,  32,  0, 0, 1, 2, 4096,      4096}    // plane 4 alignment UV
                                                           // Padding: extra data
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag with UBWC
      PLANEDEF_FORMAT_EXT_UBWC_NV124R,       // color format
      4,                         // number of planes
      {
         { 64, 0, 8,  16, 64, 4, 1, 1, 4096,      0},      // plane 1 alignment Y metadata
         {256, 0, 8,  16,  0, 0, 1, 1, 4096,      0},      // Plane 2 alignment Y
         { 64, 0, 8,  16, 32, 4, 2, 2, 4096,      0},      // plane 3 alignment UV metadata
         {256, 0, 8,  16,  0, 0, 1, 2, 4096,      0}       // plane 4 alignment UV
                                                           // Padding: extra data
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION, // usage flag
      WFD_FORMAT_RGB565,                                // color format
      2,                                                    // number of planes
      {
         { 64, 0,  8, 16, 16, 4, 1, 1, 4096, 0}, // Plane 1 alignment metadata
         {256, 0, 16, 16,  0, 0, 1, 1, 4096, 0}, // Plane 2 alignment
         {  0, 0,  0,  0,  0, 0, 0, 0, 0, 0}, // N/A
         {  0, 0,  0,  0,  0, 0, 0, 0, 0, 0}  // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag
      WFD_FORMAT_RGBA8888,        // color format
      2,                              // number of planes
      {
         {64,   0,  8, 16, 16, 4, 1, 1, 4096,  0},     // Plane 1 alignment metadata
         {256,  0, 32, 16,  0, 0, 1, 1, 4096,  0},  // Plane 2 alignment Padding: 8K for extradata
         {0,    0,  0,  0,  0, 0, 0, 0,    0,  0},  // N/A
         {0,    0,  0,  0,  0, 0, 0, 0,    0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag
      WFD_FORMAT_RGBX8888,        // color format
      2,                              // number of planes
      {
         {64,  0,   8, 16,  0, 0, 1, 1, 4096,  0},     // Plane 1 alignment metadata
         {256, 0,  32, 32,  0, 0, 1, 1, 4096,  8192},  // Plane 2 alignment Padding: 8K for extradata
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
         {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag
      WFD_FORMAT_RGBA1010102,        // color format
      2,                              // number of planes
      {
         {64,   0,  8, 16, 16, 4, 1, 1, 4096,  0},  // Plane 1 alignment metadata
         {256,  0, 32, 16,  0, 0, 1, 1, 4096,  0},  // Plane 2 alignment Padding: 8K for extradata
         {0,    0,  0,  0,  0, 0, 0, 0,    0,  0},  // N/A
         {0,    0,  0,  0,  0, 0, 0, 0,    0,  0}   // N/A
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag with UBWC
      WFD_FORMAT_P010,       // color format
      4,                         // number of planes
      {
         {64,  0, 8,  16, 32, 4, 1, 1, 4096,  0},      // plane 1 alignment Y metadata
         {256, 0, 8,  16, 0,  0, 1, 1, 4096,  0},      // Plane 2 alignment Y
         {64,  0, 8,  16, 16, 4, 2, 2, 4096,  0},      // plane 3 alignment UV metadata
         {256, 0, 8,  16, 0,  0, 1, 2, 4096,  4096}    // plane 4 alignment UV
                                                           // Padding: extra data
      },
   },

   {
      PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION,  // usage flag with UBWC
      WFD_FORMAT_NV12_QC_TP10,       // color format
      4,                         // number of planes
      {
         { 64, 0, 8, 16, 48, 4, 1, 1, 4096, 0 },      // plane 1 alignment Y metadata
         { 256, 0, 8, 16, 0, 0, 1, 1, 4096, 0 },      // Plane 2 alignment Y
         { 64, 0, 8, 16, 24, 4, 2, 2, 4096, 0 },      // plane 3 alignment UV metadata
         { 256, 0, 8, 16, 0, 0, 1, 2, 4096, 4096 }    // plane 4 alignment UV
         // Padding: extra data
      },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_NV12,       // color format
     2,                         // number of planes
     {
        {2, 0, 8,  2, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {2, 0, 8,  1, 0, 0, 1, 2, 0, 0},            // plane 2 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_YUY2,       // color format
     1,                         // number of planes
     {
        {1, 0, 16, 1, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_UYVY,       // color format
     1,                         // number of planes
     {
        {1, 0, 16, 1, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_YVYU,       // color format
     1,                         // number of planes
     {
        {1, 0, 16, 1, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,             // SW usage flag for native color formats
     WFD_FORMAT_RGBA8888,        // color format
     1,                              // number of planes
     {
        {1,   0,  32, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,             // SW usage flag for native color formats
     WFD_FORMAT_RGBX8888,        // color format
     1,                              // number of planes
     {
        {1,   0,  32, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,             // SW usage flag for native color formats
     WFD_FORMAT_RGB565,        // color format
     1,                              // number of planes
     {
        {1,   0,  16, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
     },
   },

   {
     PLANEDEF_SW_USAGE_FLAGS,             // SW usage flag for native color formats
     WFD_FORMAT_RGB888,        // color format
     1,                              // number of planes
     {
        {1,   0,  24, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0},  // N/A
        {0,   0,  0,  0,   0, 0, 0, 0, 0,  0}   // N/A
     },
   },
   {
      PLANEDEF_SW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_RGBX1010102,                        // color format
      1,                                            // number of planes
      {
        {1,   0,  32, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },
   {
      PLANEDEF_SW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_RGBA1010102,                        // color format
      1,                                            // number of planes
      {
        {1,   0,  32, 1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
        {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },
   {
      PLANEDEF_SW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_BGRX1010102,                        // color format
      1,                                            // number of planes
      {
         {1,   0,  32,  1,   0, 0, 1, 1, 0,  0},  // Plane 1 alignment
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },
   {
      PLANEDEF_SW_USAGE_FLAGS,                      // usage flag
      WFD_FORMAT_BGRA1010102,                        // color format
      1,                                            // number of planes
      {
         {1,   0,  32,  1,  0, 0, 1, 1, 0,  0},  // Plane 1 alignment
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0},   // N/A
         {0,   0,   0,  0,  0, 0, 0, 0, 0,  0}    // N/A
      },
   },
   {
     PLANEDEF_SW_USAGE_FLAGS,        // SW usage flag for native color formats
     WFD_FORMAT_P010,       // color format
     2,                         // number of planes
     {
        {2, 0, 16,  1, 0, 0, 1, 1, 0, 0},            // Plane 1 alignment
        {2, 0, 16,  1, 0, 0, 1, 2, 0, 0},            // plane 2 alignment
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0},            // N/A
        {0, 0, 0,  0, 0, 0, 0, 0, 0, 0}             // N/A
     },
   },
};

/* planedef table for 8960Pro */
static planedef_tbl_type planedef_tbl_8960AB =
         {  sizeof(planedef_info_tbl_8960AB)/sizeof(planedef_tbl_entry_type),
            planedef_info_tbl_8960AB  };

/* planedef table for 8930 */
static planedef_tbl_type planedef_tbl_8930 =
         {  sizeof(planedef_info_tbl_8930)/sizeof(planedef_tbl_entry_type),
            planedef_info_tbl_8930  };

/* planedef table for 8064 */
static planedef_tbl_type planedef_tbl_8064 =
         {  sizeof(planedef_info_tbl_8064)/sizeof(planedef_tbl_entry_type),
            planedef_info_tbl_8064  };

/* planedef table for 8974 */
static planedef_tbl_type planedef_tbl_8974 =
         {  sizeof(planedef_info_tbl_8974)/sizeof(planedef_tbl_entry_type),
            planedef_info_tbl_8974  };

static planedef_tbl_type planedef_tbl_8096 =
         {  sizeof(planedef_info_tbl_8096)/sizeof(planedef_tbl_entry_type),
            planedef_info_tbl_8096  };

/* planedef table for 6150. currently shares with 8150 */
static planedef_tbl_type planedef_tbl_6150 =
         {  sizeof(planedef_info_tbl_8150)/sizeof(planedef_tbl_entry_type),
            planedef_info_tbl_8150  };

/* planedef table for 8150 */
static planedef_tbl_type planedef_tbl_8150 =
         {  sizeof(planedef_info_tbl_8150)/sizeof(planedef_tbl_entry_type),
            planedef_info_tbl_8150  };

/* planedef table for 8540 */
static planedef_tbl_type planedef_tbl_8540 =
         {  sizeof(planedef_info_tbl_8540)/sizeof(planedef_tbl_entry_type),
            planedef_info_tbl_8540  };

/* planedef table for 8255 */
static planedef_tbl_type planedef_tbl_8255 =
         {  sizeof(planedef_info_tbl_8255)/sizeof(planedef_tbl_entry_type),
            planedef_info_tbl_8255  };

/* asic information supported by planedef*/
static planedef_asic_info asic_info[] =
{
   {"MSM8960AB", "asic_AF",  "asic_8960AB", ASIC_TYPE_8960AB, &planedef_tbl_8960AB},
   {"MSM8930",   "asic_AF",  "asic_8930",   ASIC_TYPE_8930,   &planedef_tbl_8930},
   {"APQ8064",   "asic_AF",  "asic_8064",   ASIC_TYPE_8064,   &planedef_tbl_8064},
   {"MSM8974",   "asic_BF",  "asic_8974",   ASIC_TYPE_8974,   &planedef_tbl_8974},
   {"APQ8096",   "asic_BF",  "asic_8096",   ASIC_TYPE_8096,   &planedef_tbl_8096},
   {"SA6150",    "asic_hoya","asic_6150",   ASIC_TYPE_6150,   &planedef_tbl_6150},
   {"SA8150",    "asic_hoya","asic_8150",   ASIC_TYPE_8150,   &planedef_tbl_8150},
   {"SA8540",    "asic_makena","asic_8540",   ASIC_TYPE_8540, &planedef_tbl_8540},
   {"SA8255",    "asic_lemans","asic_8255",   ASIC_TYPE_8255, &planedef_tbl_8255}
};

#define PLANEDEF_MAX_MACHINE (sizeof(asic_info) / sizeof(planedef_asic_info))

/*===========================================================================

                        FUNCTION DECLARATIONS

===========================================================================*/

static int detect_asic(void);


/*===========================================================================

                        FUNCTION DEFINITIONS

===========================================================================*/

/*==========================================================================

       FUNCTION:     detect_asic

       DESCRIPTION:
*//**                This function detects asic platform info.

@par   DEPENDENCIES:
                     None
@par   SYNCHRONOUS:
                     Yes
*//*
       PARAMETERS:
*//**
         @param[in]  None

*//*
*//**  RETURN VALUE:
         @return  index to asic info table on success or -1 otherwise

@par   SIDE EFFECTS:
===========================================================================*/
static int detect_asic()
{
   g_planedef_asic_idx = ASIC_TYPE_8540;
#ifndef WIN32
   const void* fdt = NULL;

   fdt = fdt_get_root();

   if (fdt)
   {
      if (0 == fdt_node_check_compatible(fdt, 0, "qcom,msm8155"))
      {
         g_planedef_asic_idx = ASIC_TYPE_8150;
      }
      else if (0 == fdt_node_check_compatible(fdt, 0, "qcom,msm6155"))
      {
         g_planedef_asic_idx = ASIC_TYPE_6150;
      }
      else if (0 == fdt_node_check_compatible(fdt, 0, "qcom,sa8540"))
      {
         g_planedef_asic_idx = ASIC_TYPE_8540;
      }
      else if (0 == fdt_node_check_compatible(fdt, 0, "qcom,sa8255"))
      {
         g_planedef_asic_idx = ASIC_TYPE_8255;
      }
      else
      {
         PLANEDEF_MSG_HIGH("chip info not found, default %d is used",
               g_planedef_asic_idx);
      }
   }
#endif

   if (FALSE == g_logInit)
   {
      MM_Debug_Initialize();
      g_logInit = TRUE;
   }

   return g_planedef_asic_idx;

} /* end of detect_asic */

/*==========================================================================

       FUNCTION:     query_num_planes

       DESCRIPTION:
*//**                This function returns the number of planes given the
                     color format.

                     The unsigned long type of color format is the
                     format defined in WFD header file, i.e., wfdExt.h,
                     with the upper 16 bits the proprietary formats and
                     the lower 16 bits the WFD native color format.

@par   DEPENDENCIES:
                     None
@par   SYNCHRONOUS:
                     Yes
*//*
       PARAMETERS:
*//**
         @param[in]  color_format - color format defined in wfdExt.h.
         @param[in]  usage   - the usage flag defined in wfdExt.h
         @param[out] num_planes   - ptr to number of planes
         @param[in]  flag - reserved for future special feautre


*//*
*//**  RETURN VALUE:
         @return  PLANEDEF_ERR_NONE on Success or error code otherwise
@par   SIDE EFFECTS:
===========================================================================*/
planedef_status_type query_num_planes
(
   unsigned long        color_format,
   unsigned long        usage,
   unsigned long*       num_planes,
   unsigned long        flag
)
{
   planedef_status_type status = PLANEDEF_ERR_NONE;
   planedef_tbl_type    tbl;
   unsigned long        i = 0;
   int                  asic_idx = g_planedef_asic_idx;
   unsigned long        bFound = FALSE;
   unsigned long        planes = 0;
   boolean              is_compressed = FALSE;
/*----------------------------------------------------------------*/

   /* ASIC detection */
   if ( asic_idx == PLANEDEF_ASIC_UNINITIALIZED )
   {
      asic_idx = detect_asic();
   }

   if( 0 <= asic_idx )
   {
      tbl =  *(asic_info[asic_idx].planedef_tbl) ;
   }
   else
   {
      PLANEDEF_MSG_DEBUG("Asic detection failed with return %d", asic_idx);
      return PLANEDEF_ERR_FAILED;
   }

   PLANEDEF_MSG_DEBUG("query_num_planes: color format 0x%lx, usage 0x%lx", color_format, usage);

   is_compressed = ( usage & WFD_USAGE_COMPRESSION ) ? TRUE : FALSE;

   /* if the usage contains HW flags, ignore the SW usage flags */
   usage = ( usage & PLANEDEF_HW_USAGE_FLAGS ) ?  ( PLANEDEF_HW_USAGE_FLAGS ) : PLANEDEF_SW_USAGE_FLAGS ;

   if ( is_compressed ||
        PLANEDEF_FORMAT_EXT_UBWC_NV124R == color_format ) 
   {
      usage |= WFD_USAGE_COMPRESSION;
   }

   for ( i = 0; i < tbl.num_entries; i++ )
   {
      if ( color_format == tbl.entries[i].color_format &&
           usage == tbl.entries[i].usage )
      {
         planes = tbl.entries[i].num_planes;
         bFound = TRUE;
         PLANEDEF_MSG_DEBUG("number of planes %ld", *num_planes);

         break;
      }
   }

   if ( !bFound )
   {
      PLANEDEF_MSG_DEBUG("Unsupported color format 0x%lx, usage 0x%lx", color_format, usage);
      return (PLANEDEF_ERR_UNSUPPORTED);
   }
   else
   {
      *num_planes = planes;
   }

   return status;
} /* end of query_num_planes */

/*==========================================================================

       FUNCTION:     calculate_ubwc_plane_bufsize

       DESCRIPTION:
*//**                This function is used to calculate plane size for NV12_UBWC

@par   DEPENDENCIES:
                     None
@par   SYNCHRONOUS:
                     Yes
*//*
       PARAMETERS:
*//**
         @param[in]     width_in_pixels - width passed by client.
         @param[in]     height_in_pixels - height passed by client.
         @param[in]     curr_plane - ptr to the current plane
         @param[in]     is_interlace - used to differentiate height needed for interlace/progressive calculation

*//*
*//**  RETURN VALUE:
         @return  returns the total buffer size
@par   SIDE EFFECTS:
===========================================================================*/
unsigned long calculate_ubwc_plane_bufsize( unsigned long width_in_pixels, unsigned long height_in_pixels, planedef_info_type*  curr_plane, boolean is_interlace )
{
   unsigned long plane_bufsize = 0;
   unsigned long min_stride = 0;
   unsigned long actual_stride = 0;
   unsigned long min_plane_buf_height = 0;
   unsigned long actual_plane_buf_height = 0;

   width_in_pixels = PLANEDEF_SCALE( width_in_pixels, curr_plane->width_scale );

   if ( TRUE == is_interlace )
   {
      height_in_pixels = PLANEDEF_SCALE( ( height_in_pixels + 1 ) >> 1, curr_plane->height_scale );
   }
   else
   {
      height_in_pixels = PLANEDEF_SCALE( height_in_pixels, curr_plane->height_scale );
   }

   min_stride = PLANEDEF_NUMBLOCKS( width_in_pixels, curr_plane->block_width );
   actual_stride = PLANEDEF_ALIGN( PLANEDEF_ALIGN( min_stride * curr_plane->bits_per_pixel, 8 ) / 8, curr_plane->stride_multiple );
   actual_stride += curr_plane->stride_padding;

   min_plane_buf_height = PLANEDEF_NUMBLOCKS( height_in_pixels, curr_plane->block_height );
   actual_plane_buf_height = PLANEDEF_ALIGN( min_plane_buf_height, curr_plane->height_multiple );

   plane_bufsize = PLANEDEF_ALIGN( actual_stride * actual_plane_buf_height, curr_plane->buf_alignment );

   return plane_bufsize;
}

/*==========================================================================

       FUNCTION:     query_plane_def

       DESCRIPTION:
*//**                This function returns geometrical buffer format layout
                     (plane definition) given input color format, usage flag,
                     resolution, and plane index.

                     The unsigned long type of color format is the
                     format defined in WFD header file, i.e., wfdExt.h,
                     with the upper 16 bits the proprietary formats and
                     the lower 16 bits the WFD native color format.

@par   DEPENDENCIES:
                     None
@par   SYNCHRONOUS:
                     Yes
*//*
       PARAMETERS:
*//**
         @param[in]     color_format - color format defined in wfdExt.h.
         @param[in]     usage   - the usage flag defined in wfdExt.h
         @param[in]     frame_res - ptr to frame resolution
         @param[in]     flag - reserved for future special feautre
         @param[in/out] plane_def - ptr to plane definition

*//*
*//**  RETURN VALUE:
         @return  PLANEDEF_ERR_NONE on Success or error code otherwise
@par   SIDE EFFECTS:
===========================================================================*/
planedef_status_type query_plane_def
(
   unsigned long        color_format,
   unsigned long        usage,
   frame_res_type*      frame_res,
   plane_def_type*      plane_def,
   unsigned long        flag
)
{
   planedef_status_type status = PLANEDEF_ERR_NONE;
   planedef_tbl_type    tbl;
   unsigned long        i = 0;
   int                  asic_idx = g_planedef_asic_idx;
   planedef_info_type*  curr_plane;
   unsigned long        bFound = FALSE;
   unsigned long        width_in_pixels;
   unsigned long        height_in_pixels;
   boolean              is_compressed = FALSE;
/*----------------------------------------------------------------*/

   if ( !frame_res | !plane_def )
   {
      PLANEDEF_MSG_ERROR("query_plane_def NULL pointer");
      return (PLANEDEF_ERR_FAILED);
   }

   if ( !plane_def->plane_index || plane_def->plane_index > PLANEDEF_MAX_NUM_PLANES )
   {
      PLANEDEF_MSG_ERROR("plane index %ld wrong, should be from 1 to %d",
                   plane_def->plane_index, PLANEDEF_MAX_NUM_PLANES);
      return (PLANEDEF_ERR_FAILED);
   }

   if ( !frame_res->width_in_pixels || !frame_res->height_in_pixels )
   {
      PLANEDEF_MSG_ERROR("Zero width or height ");
      return (PLANEDEF_ERR_FAILED);
   }

   /* ASIC detection */
   if ( asic_idx == PLANEDEF_ASIC_UNINITIALIZED )
   {
      asic_idx = detect_asic();
   } 
   
   if( 0 <= asic_idx)
   {
      tbl =  *(asic_info[asic_idx].planedef_tbl) ;
   }
   else
   {
      PLANEDEF_MSG_DEBUG("Asic detection failed with return %d", asic_idx);
      return PLANEDEF_ERR_FAILED;
   }

   PLANEDEF_MSG_DEBUG("query_plane_def: color format 0x%lx, usage 0x%lx", color_format, usage);

   is_compressed = ( usage & WFD_USAGE_COMPRESSION ) ? TRUE : FALSE;

   /* if the usage contains HW flags, ignore the SW usage flags */
   usage = ( usage & PLANEDEF_HW_USAGE_FLAGS ) ?  ( PLANEDEF_HW_USAGE_FLAGS ) : PLANEDEF_SW_USAGE_FLAGS ;

   if ( is_compressed ) 
   {
      usage |= WFD_USAGE_COMPRESSION;
   }
   
   for ( i = 0; i < tbl.num_entries; i++ )
   {
      if ( color_format == tbl.entries[i].color_format &&
           usage == tbl.entries[i].usage )
      {
         if ( plane_def->plane_index > tbl.entries[i].num_planes )
         {
            PLANEDEF_MSG_ERROR("Plane index %ld larger than supported %ld",
                         plane_def->plane_index, tbl.entries[i].num_planes);
            return PLANEDEF_ERR_PLANE_INDEX;
         }

         /* plane index start from 1 */
         curr_plane = & tbl.entries[i].planedef_info[plane_def->plane_index - 1];

         /* plane width and height */
         width_in_pixels = PLANEDEF_SCALE(frame_res->width_in_pixels, curr_plane->width_scale);
         height_in_pixels = PLANEDEF_SCALE(frame_res->height_in_pixels, curr_plane->height_scale);

          /* stride */
          plane_def->stride_multiples = curr_plane->stride_multiple;
          plane_def->min_stride = PLANEDEF_NUMBLOCKS(width_in_pixels, curr_plane->block_width);
          plane_def->min_stride = PLANEDEF_ALIGN(
                                    PLANEDEF_ALIGN(plane_def->min_stride * curr_plane->bits_per_pixel, 8) / 8,
                                    plane_def->stride_multiples );


         /* Handle exception: stride  */
         if ( (ASIC_TYPE_8974 == asic_info[asic_idx].asic_type ) &&
              ( color_format == WFD_FORMAT_NV12 ) &&
              ( usage == PLANEDEF_HW_USAGE_FLAGS ) )
         {
            if( plane_def->min_stride % PLANEDEF_KILO(2) == 0)
            {
               plane_def->min_stride += plane_def->stride_multiples;
            }
         }

         if ((color_format == WFD_FORMAT_NV12_QC_TP10) &&
             (usage == (PLANEDEF_HW_USAGE_FLAGS  | WFD_USAGE_COMPRESSION) ) &&
            (plane_def->plane_index == PLANEDEF_Y_PAYLOAD_PLANE_INDEX_TP10_UBWC ||
            plane_def->plane_index == PLANEDEF_UV_PAYLOAD_PLANE_INDEX_TP10_UBWC ) )
         {
            plane_def->min_stride = PLANEDEF_ALIGN(
               PLANEDEF_ALIGN(width_in_pixels, 192) * 4 / 3,  plane_def->stride_multiples);
         }

        if ((color_format == WFD_FORMAT_P010) &&
            (usage == (PLANEDEF_HW_USAGE_FLAGS  | WFD_USAGE_COMPRESSION) ) &&
            (plane_def->plane_index == PLANEDEF_Y_PAYLOAD_PLANE_INDEX_P010_UBWC ||
            plane_def->plane_index == PLANEDEF_UV_PAYLOAD_PLANE_INDEX_P010_UBWC ) )
         {
            plane_def->min_stride = PLANEDEF_ALIGN((width_in_pixels * 2), plane_def->stride_multiples);
         }

         plane_def->min_stride += curr_plane->stride_padding;

         plane_def->actual_stride = plane_def->min_stride;

         /* just a big number with compatible stride multiple */
         plane_def->max_stride = PLANEDEF_ALIGN(0xFFFF, plane_def->stride_multiples);

         /* buffer start address alignment */
         plane_def->buf_alignment = curr_plane->buf_alignment;
         plane_def->actual_buf_alignment = plane_def->buf_alignment;

         /* height */
         plane_def->height_multiples = curr_plane->height_multiple;
         plane_def->min_plane_buf_height = PLANEDEF_NUMBLOCKS(height_in_pixels, curr_plane->block_height);
         plane_def->min_plane_buf_height = PLANEDEF_ALIGN(plane_def->min_plane_buf_height, curr_plane->height_multiple);
         plane_def->actual_plane_buf_height = plane_def->min_plane_buf_height;

         /* Handle exception : buffer height */
         if ( ( ASIC_TYPE_8096 == asic_info[asic_idx].asic_type ) &&
              ( color_format == WFD_FORMAT_NV12 ) &&  
              ( usage == ( PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION )) &&
              ( PLANEDEF_UV_PAYLOAD_PLANE_INDEX_NV12_UBWC == plane_def->plane_index ) )
         {
            /* Venus FW workaound for HW bug of over prefetching chroma about 48 lines */
            plane_def->actual_plane_buf_height += 48;
         }

         /* buffer size calculation:*/
         plane_def->plane_buf_size =
               PLANEDEF_ALIGN( plane_def->actual_stride * plane_def->actual_plane_buf_height,
                               plane_def->buf_alignment );
         /* padding size */
         plane_def->plane_padding_size = curr_plane->padding_size;

         // For the interlace case, the buffer size is slightly greater than the non interlaced one.
         // Below calculation is done to figure out the difference between the interlaced & non interlaced case &
         // append the additional size to the padding field for the last plane.
         if ( ( ASIC_TYPE_8255 == asic_info[asic_idx].asic_type ) &&
              ( color_format == WFD_FORMAT_NV12 ) &&  
              ( usage == ( PLANEDEF_HW_USAGE_FLAGS | WFD_USAGE_COMPRESSION ) ) &&
              ( INTERLACE_MAX_WIDTH >= frame_res->width_in_pixels ) &&
              ( INTERLACE_MAX_HEIGHT >= frame_res->height_in_pixels ) &&
              ( INTERLACE_MAX_MB_PER_FRAME >= (frame_res->width_in_pixels * frame_res->height_in_pixels ) / 256 ) )
         {
            if ( plane_def->plane_index == 4 )
            {
               unsigned long interlace_bufsize = 0, interlace_y_meta_bufsize = 0, interlace_y_bufsize = 0, interlace_uv_meta_bufsize = 0, interlace_uv_bufsize = 0;
               unsigned long planedef_bufsize = 0, planedef_y_meta_bufsize = 0, planedef_y_bufsize = 0, planedef_uv_meta_bufsize = 0, planedef_uv_bufsize = 0;

               interlace_y_meta_bufsize = calculate_ubwc_plane_bufsize( frame_res->width_in_pixels, frame_res->height_in_pixels, & tbl.entries[i].planedef_info[0], TRUE );
               interlace_y_bufsize = calculate_ubwc_plane_bufsize( frame_res->width_in_pixels, frame_res->height_in_pixels, & tbl.entries[i].planedef_info[1], TRUE );
               interlace_uv_meta_bufsize = calculate_ubwc_plane_bufsize( frame_res->width_in_pixels, frame_res->height_in_pixels, & tbl.entries[i].planedef_info[2], TRUE );
               interlace_uv_bufsize = calculate_ubwc_plane_bufsize( frame_res->width_in_pixels, frame_res->height_in_pixels, & tbl.entries[i].planedef_info[3], TRUE );
               interlace_bufsize = 2 * ( interlace_y_meta_bufsize + interlace_y_bufsize + interlace_uv_meta_bufsize + interlace_uv_bufsize );

               planedef_y_meta_bufsize = calculate_ubwc_plane_bufsize( frame_res->width_in_pixels, frame_res->height_in_pixels, & tbl.entries[i].planedef_info[0], FALSE );
               planedef_y_bufsize = calculate_ubwc_plane_bufsize( frame_res->width_in_pixels, frame_res->height_in_pixels, & tbl.entries[i].planedef_info[1], FALSE);
               planedef_uv_meta_bufsize = calculate_ubwc_plane_bufsize( frame_res->width_in_pixels, frame_res->height_in_pixels, & tbl.entries[i].planedef_info[2], FALSE );
               planedef_uv_bufsize = calculate_ubwc_plane_bufsize( frame_res->width_in_pixels, frame_res->height_in_pixels, & tbl.entries[i].planedef_info[3], FALSE );
               planedef_bufsize = planedef_y_meta_bufsize + planedef_y_bufsize + planedef_uv_meta_bufsize + planedef_uv_bufsize;

               if ( ( interlace_bufsize <= planedef_bufsize ) ||
                    ( curr_plane->padding_size >= ( interlace_bufsize - planedef_bufsize ) ) )
               {
                  plane_def->plane_padding_size = curr_plane->padding_size;
               }
               else
               {
                  plane_def->plane_padding_size = interlace_bufsize - planedef_bufsize;
               }
            }
         }

         PLANEDEF_MSG_HIGH("Found planedef entry %ld for color format %ld", i, color_format);
         PLANEDEF_MSG_HIGH("Plandef: frame width %ld height %ld",
                        frame_res->width_in_pixels,
                        frame_res->height_in_pixels);

         PLANEDEF_MSG_HIGH("plane %ld:  plane_stride %ld plane_height %ld",
                        plane_def->plane_index,
                        plane_def->actual_stride,
                        plane_def->actual_plane_buf_height );

         PLANEDEF_MSG_HIGH("plane_bufferSize %ld plane_padding_size %ld, plane_buf_align %ld",
                        plane_def->plane_buf_size,
                        plane_def->plane_padding_size,
                        plane_def->actual_buf_alignment );

         bFound = TRUE;

         break;
      }
   }

   if ( !bFound )
   {
      PLANEDEF_MSG_DEBUG("Unsupported color format 0x%lx, usage 0x%lx", color_format, usage);
      return (PLANEDEF_ERR_UNSUPPORTED);
   }

   return status;

}  /* end of query_plane_def */


/*==========================================================================

       FUNCTION:     query_omx_plane_def

       DESCRIPTION:
*//**                This function returns omx uncompressed buffer plane
                     layout according to omx plane definition extension

                     The unsigned long type of color format is the
                     format defined in WFD header file, i.e., wfdExt.h,
                     with the upper 16 bits the proprietary formats and
                     the lower 16 bits the WFD native color format.


@par   DEPENDENCIES:
                     None
@par   SYNCHRONOUS:
                     Yes
*//*
       PARAMETERS:
*//**
         @param[in]     color_format - color format defined in wfdExt.h.
         @param[in]     usage   - the usage flag defined in wfdExt.h
         @param[in]     frame_res - ptr to frame resolution
         @param[in]     flag - reserved for future special feautre
         @param[in/out] plane_def - ptr to the omx planedef and size

*//*
*//**  RETURN VALUE:
         @return  PLANEDEF_ERR_NONE on Success or error code otherwise
@par   SIDE EFFECTS:
===========================================================================*/
planedef_status_type query_omx_plane_def
(
   unsigned long                 color_format,
   unsigned long                 usage,
   frame_res_type*               frame_res,
   omx_plane_def_type*           plane_def,
   unsigned long                 flag
)
{
   planedef_status_type status = PLANEDEF_ERR_NONE;
   plane_def_type       qc_plane_def;
   QOMX_PLANEDEFINITIONTYPE*  omx_plane_def;
/*----------------------------------------------------------------*/


   if ( !plane_def || !plane_def->omx_plane_def)
   {
      PLANEDEF_MSG_ERROR("omx_plane_def Null pointer!");
      return PLANEDEF_ERR_FAILED;
   }

   if ( plane_def->size != sizeof(QOMX_PLANEDEFINITIONTYPE) )
   {
      PLANEDEF_MSG_ERROR("size of planedef structure not equal to omx structure!");
      return PLANEDEF_ERR_FAILED;
   }

   omx_plane_def = (QOMX_PLANEDEFINITIONTYPE* ) plane_def->omx_plane_def;

   memset(&qc_plane_def, 0, sizeof(qc_plane_def));

   if ( PLANEDEF_IS_NV12(color_format) )
   {
      /*
       **  For packed buffer format such as YUV420PackedSemiPlanar (NV12),
       **  the first plane contains buffer size for all planes according
       **  to OMX extension
       */
      if ( PLANEDEF_FIRST_PLANE == omx_plane_def->nPlaneIndex )
      {
         unsigned long        num_plane;
         unsigned long        i;

         /* query number of planes */
         status = query_num_planes(color_format, usage, &num_plane, flag);

         if ( PLANEDEF_ERR_NONE != status )
         {
            PLANEDEF_MSG_DEBUG("query_num_plane failed with status %d", status);
            return status;
         }

         /* for NV12, the buffer size in the first plane contains buffer size for all planes */
         omx_plane_def->nBufferSize = 0;
         for (i = 0; i < num_plane; i++ )
         {
            qc_plane_def.plane_index = i+1;
            status = query_plane_def(color_format, usage, frame_res, &qc_plane_def, flag );

            if ( PLANEDEF_ERR_NONE != status )
            {
               PLANEDEF_MSG_DEBUG("query_plane_def failed with status %d", status );
               return status;
            }

            if ( PLANEDEF_FIRST_PLANE == qc_plane_def.plane_index )
            {
               omx_plane_def->nActualBufferAlignment = qc_plane_def.actual_buf_alignment;
               omx_plane_def->nActualPlaneBufferHeight = qc_plane_def.actual_plane_buf_height;
               omx_plane_def->nActualStride = qc_plane_def.actual_stride;
               omx_plane_def->nBufferAlignment = qc_plane_def.buf_alignment;
               omx_plane_def->nMaxStride = qc_plane_def.max_stride;
               omx_plane_def->nMinPlaneBufferHeight = qc_plane_def.min_plane_buf_height;
               omx_plane_def->nMinStride = qc_plane_def.min_stride;
               omx_plane_def->nStrideMultiples = qc_plane_def.stride_multiples;
            }

            omx_plane_def->nBufferSize += qc_plane_def.plane_buf_size + qc_plane_def.plane_padding_size;
         }
      }
      else
      {
         /* not the first plane */
         qc_plane_def.plane_index = omx_plane_def->nPlaneIndex;
         status = query_plane_def(color_format, usage, frame_res, &qc_plane_def, flag);

         if ( PLANEDEF_ERR_NONE != status )
         {
            PLANEDEF_MSG_DEBUG("query_plane_def failed with status %d", status );
            return status;
         }

         omx_plane_def->nActualBufferAlignment = qc_plane_def.actual_buf_alignment;
         omx_plane_def->nActualPlaneBufferHeight = qc_plane_def.actual_plane_buf_height;
         omx_plane_def->nActualStride = qc_plane_def.actual_stride;
         omx_plane_def->nBufferAlignment = qc_plane_def.buf_alignment;
         omx_plane_def->nMaxStride = qc_plane_def.max_stride;
         omx_plane_def->nMinPlaneBufferHeight = qc_plane_def.min_plane_buf_height;
         omx_plane_def->nMinStride = qc_plane_def.min_stride;
         omx_plane_def->nStrideMultiples = qc_plane_def.stride_multiples;

         /* all planes has zero buffer size expect the first plane */
         omx_plane_def->nBufferSize = 0;
      }
   }
   else
   {
      /* for non-packed color format */
      qc_plane_def.plane_index = omx_plane_def->nPlaneIndex;
      status = query_plane_def(color_format, usage, frame_res, &qc_plane_def, flag);

      if ( PLANEDEF_ERR_NONE != status )
      {
         PLANEDEF_MSG_DEBUG("query_plane_def failed with status %d", status );
         return status;
      }

      omx_plane_def->nActualBufferAlignment = qc_plane_def.actual_buf_alignment;
      omx_plane_def->nActualPlaneBufferHeight = qc_plane_def.actual_plane_buf_height;
      omx_plane_def->nActualStride = qc_plane_def.actual_stride;
      omx_plane_def->nBufferAlignment = qc_plane_def.buf_alignment;
      omx_plane_def->nMaxStride = qc_plane_def.max_stride;
      omx_plane_def->nMinPlaneBufferHeight = qc_plane_def.min_plane_buf_height;
      omx_plane_def->nMinStride = qc_plane_def.min_stride;
      omx_plane_def->nStrideMultiples = qc_plane_def.stride_multiples;
      omx_plane_def->nBufferSize = qc_plane_def.plane_buf_size + qc_plane_def.plane_padding_size;

   }


   PLANEDEF_MSG_HIGH(" query_omx_plane_def: color_format %ld width %ld height %ld plane idx %d stride %d aligned buffer height %d buffer size %d",
                        color_format,
                        frame_res->width_in_pixels,
                        frame_res->height_in_pixels,
                        omx_plane_def->nPlaneIndex,
                        omx_plane_def->nActualStride,
                        omx_plane_def->nActualPlaneBufferHeight,
                        omx_plane_def->nBufferSize );

   return status;

} /* end of query_omx_plane_def */

