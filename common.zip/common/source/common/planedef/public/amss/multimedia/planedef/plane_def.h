#ifndef _PLANE_DEF_H_
#define _PLANE_DEF_H_
/*========================================================================

*//** @file plane_def.h

@par FILE SERVICES:
      This file defines the data types to get plane definition of 
      uncompressed buffer formats.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2013, 2017, 2019, 2021 QUALCOMM Technologies, Incorporated.
    All Rights Reserved. QUALCOMM Proprietary. Export of this technology or
    software is regulated by the U.S. Government, Diversion contrary to
    U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: 

when       who     what, where, why
--------   ---     ------------------------------------------------------- 
03/26/21   rz      Add support of NV124R-UBWC color format
11/05/19   md      Add support for 10 bit color formats
11/01/17   jz      Add support for NV12 UBWC color format
10/06/17   rz      Add NV12/NV12_UBWC Y plane index define 
08/08/13   rz      Remove obselete APIs 
05/14/13   rz      Support usage flag via new APIs
03/12/13   rz      Added get_omx_plane_def API 
02/27/13   rz      Added height_multiple
01/28/13   rz      Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */

#ifdef __cplusplus
extern "C" 
{
#endif

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* planedef format extension
   WFD:  0-15 bits   colorformat
        16-19 bits:  QC extension
        20-31 bits:  platform bits (unused) */
#define PLANEDEF_FORMAT_EXT_UBWC_NV124R     ((1 << 20) | WFD_FORMAT_NV12)

#define PLANEDEF_ID_UNUSED 0x3FFFFFFF
#define COLOR_PLANE_MAX 2

/** Plane ID defines for NV12 color format */
typedef enum
{
   PLANEDEF_Y_PLANE_INDEX_NV12 = 1,  /**< Luma plane ID */
   PLANEDEF_UV_PLANE_INDEX_NV12 = 2   /**< Chroma plane ID */
} PLANEDEF_NV12_PLANE_INDEX_TYPE;

/** Plane ID defines for RGB565/RGBA8888 color format */
typedef enum
{
   PLANEDEF_PAYLOAD_PLANE_INDEX_RGB  = 1,
} PLANEDEF_RGB_PLANE_INDEX_TYPE;

/** Plane ID defines for NV12 UBWC color format */
typedef enum
{
   PLANEDEF_Y_META_PLANE_INDEX_NV12_UBWC     = 1,
   PLANEDEF_Y_PAYLOAD_PLANE_INDEX_NV12_UBWC  = 2,
   PLANEDEF_UV_META_PLANE_INDEX_NV12_UBWC    = 3,
   PLANEDEF_UV_PAYLOAD_PLANE_INDEX_NV12_UBWC = 4
} PLANEDEF_NV12_UBWC_PLANE_INDEX_TYPE;

/** Plane ID defines for TP10_UBWC color format */
typedef enum
{
   PLANEDEF_Y_META_PLANE_INDEX_TP10_UBWC     = 1,
   PLANEDEF_Y_PAYLOAD_PLANE_INDEX_TP10_UBWC  = 2,
   PLANEDEF_UV_META_PLANE_INDEX_TP10_UBWC    = 3,
   PLANEDEF_UV_PAYLOAD_PLANE_INDEX_TP10_UBWC = 4
} PLANEDEF_TP10_UBWC_PLANE_INDEX_TYPE;

/** Plane ID defines for P010_UBWC color format */
typedef enum
{
   PLANEDEF_Y_META_PLANE_INDEX_P010_UBWC     = 1,
   PLANEDEF_Y_PAYLOAD_PLANE_INDEX_P010_UBWC  = 2,
   PLANEDEF_UV_META_PLANE_INDEX_P010_UBWC    = 3,
   PLANEDEF_UV_PAYLOAD_PLANE_INDEX_P010_UBWC = 4
} PLANEDEF_P010_UBWC_PLANE_INDEX_TYPE;

/** Plane ID defines for RGB565/RGBA888 UBWC color format */
typedef enum
{
   PLANEDEF_META_PLANE_INDEX_RGB_UBWC    = 1,
   PLANEDEF_PAYLOAD_PLANE_INDEX_RGB_UBWC = 2
} PLANEDEF_RGB_UBWC_PLANE_INDEX_TYPE;

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

typedef enum
{
   PLANEDEF_ERR_NONE                 = 0x0,

   /** general failure */
   PLANEDEF_ERR_FAILED               = 0x1,

   /** unsupported color format */
   PLANEDEF_ERR_UNSUPPORTED          = 0x2,

   /** incorrect plane index for this color format */
   PLANEDEF_ERR_PLANE_INDEX          = 0x3,

   PLANEDEF_ERR_UNUSED               = 0x7FFFFFFF
} planedef_status_type;


typedef struct _plane_def_type
{
   /**< [in] Plane index to which property applies. Counting starts from 1. 
        An index more than allowed for the selected buffer format will be
        returned with PLANEDEF_ERR_PLANE_INDEX */
   unsigned long            plane_index;            

   /**< Minimum allowed stride for the plane */
   unsigned long            min_stride;          

   /**< Maximum allowed stride for the plane */
   unsigned long            max_stride;             

   /**< Stride multiple allowed in horizontal direction. */
   unsigned long            stride_multiples;

   /**< Actual stride for the plane. This would be used while calculating 
        buffer requirement */
   unsigned long            actual_stride;          

   /**< Minimum plane height supported */
   unsigned long            min_plane_buf_height;  

   /**< Height multiple allowed in vertical direction. */
   unsigned long            height_multiples;

   /**< Actual plane height for the plane. This should adhere to restrictions 
        put by min_plane_buf_height. This would be used while calculating
        buffer requirement */
   unsigned long            actual_plane_buf_height;

   /**< Buffer alignment requirement for this plane. */
   unsigned long            buf_alignment;    

   /**< Actual buffer alignment requirement for this plane. */
   unsigned long            actual_buf_alignment;    

   /**< Minimum buffer size required for this plane. This does not include
        padding size. It is calculated as 
        Align(actual_plane_buf_stride * actual_plane_buf_height, actual_buf_alignment) */
   unsigned long            plane_buf_size;

   /**< Padding size (used as extra data) at the end of the plane. 
        The total buffer size for this plane is 
        plane_buf_size + plane_padding_size */
   unsigned long            plane_padding_size;

} plane_def_type;

/**
 * This type defines frame resolution type.
 */
typedef struct _frame_res_type
{
   /**< frame width in number of pixels */
   unsigned long            width_in_pixels;  

   /**< frame height in number of pixels */
   unsigned long            height_in_pixels;
} frame_res_type;

/** This type defines structure type for omx planedef usage
 */
typedef struct _omx_plane_def_type
{
   /**<  This should be a pointer to OMX structure
         defined as QOMX_PLANEDEFINITIONTYPE
         in QOMX_IVCommonExtensions.h  */
   void*          omx_plane_def;

   /**<  This is the size of the structure pointer of 
         omx_plane_def. It is expected to be
         size = sizeof(QOMX_PLANEDEFINITIONTYPE)  */
   unsigned long  size;
} omx_plane_def_type;

/* -----------------------------------------------------------------------
** Function Declarations
** ----------------------------------------------------------------------- */

/*==========================================================================

       FUNCTION:     query_num_planes

       DESCRIPTION:
*//**                This function returns the number of planes given the
                     color format.

                     The unsigned long type of color format is the 
                     format defined in WFD header file, i.e., wfdExt.h,
                     with the upper 16 bits the proprietary formats and 
                     the lower 16 bits the WFD native color format.

@par   DEPENDENCIES:
                     None
@par   SYNCHRONOUS:
                     Yes
*//*
       PARAMETERS:
*//**
         @param[in]  color_format - color format defined in wfdExt.h.
         @param[in]  usage   - the usage flag defined in wfdExt.h
         @param[out] num_planes   - ptr to number of planes
         @param[in]  flag - reserved for future special feautre


*//*
*//**  RETURN VALUE:
         @return  PLANEDEF_ERR_NONE on Success or error code otherwise
@par   SIDE EFFECTS:
===========================================================================*/
planedef_status_type query_num_planes
(
   unsigned long        color_format,
   unsigned long        usage,
   unsigned long*       num_planes,
   unsigned long        flag
);

/*==========================================================================

       FUNCTION:     query_plane_def

       DESCRIPTION:
*//**                This function returns geometrical buffer format layout
                     (plane definition) given input color format, usage flag,
                     resolution, and plane index.

                     The unsigned long type of color format is the 
                     format defined in WFD header file, i.e., wfdExt.h,
                     with the upper 16 bits the proprietary formats and 
                     the lower 16 bits the WFD native color format.

@par   DEPENDENCIES:
                     None
@par   SYNCHRONOUS:
                     Yes
*//*
       PARAMETERS:
*//**
         @param[in]     color_format - color format defined in wfdExt.h.
         @param[in]     usage   - the usage flag defined in wfdExt.h
         @param[in]     frame_res - ptr to frame resolution
         @param[in]     flag - reserved for future special feautre
         @param[in/out] plane_def - ptr to plane definition

*//*
*//**  RETURN VALUE:
         @return  PLANEDEF_ERR_NONE on Success or error code otherwise
@par   SIDE EFFECTS:
===========================================================================*/
planedef_status_type query_plane_def
(
   unsigned long        color_format,
   unsigned long        usage,
   frame_res_type*      frame_res,
   plane_def_type*      plane_def,
   unsigned long        flag
);

/*==========================================================================

       FUNCTION:     query_omx_plane_def

       DESCRIPTION:
*//**                This function returns omx uncompressed buffer plane 
                     layout according to omx plane definition extension 

                     The unsigned long type of color format is the 
                     format defined in WFD header file, i.e., wfdExt.h,
                     with the upper 16 bits the proprietary formats and 
                     the lower 16 bits the WFD native color format.


@par   DEPENDENCIES:
                     None
@par   SYNCHRONOUS:
                     Yes
*//*
       PARAMETERS:
*//**
         @param[in]     color_format - color format defined in wfdExt.h.
         @param[in]     usage   - the usage flag defined in wfdExt.h
         @param[in]     frame_res - ptr to frame resolution
         @param[in]     flag - reserved for future special feautre
         @param[in/out] plane_def - ptr to the omx planedef and size

*//*
*//**  RETURN VALUE:
         @return  PLANEDEF_ERR_NONE on Success or error code otherwise
@par   SIDE EFFECTS:
===========================================================================*/
planedef_status_type query_omx_plane_def
(
   unsigned long                 color_format,
   unsigned long                 usage,
   frame_res_type*               frame_res,
   omx_plane_def_type*           plane_def,
   unsigned long                 flag
);

#ifdef __cplusplus
}

#endif

#endif /* _PLANE_DEF_H_ */
