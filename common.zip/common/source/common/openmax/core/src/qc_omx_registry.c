/*============================================================================
                             O p e n  M A X   C o r e

*//** @file omx_core.c
  This module contains the implementation of the os independent part of the
  OpenMAX core.

  It uses an externed virtual table omxcore to access the os dependent core.
  Each os target will have to implement the omxcore table in its own version of
  the qc_omx_core.c file

  Copyright (c) 2006-2019 QUALCOMM Technologies Incorporated.
  All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*============================================================================
                              Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/core/src/qc_omx_registry.c#1 $
when       who     what, where, why
--------   ---     ------------------------------------------------------- 
10/16/19   hl      Support Ghs Integrity
07/08/19   jz      Add VideoProcessing component
01/12/18   jz      Add MPEG2 TS demuxer component
01/02/18   rz      Fix MISRA warning 
11/29/17   am      Add DivX decoder
10/19/17   am      Add VP8 encoder support
09/13/17   jz      Add RTP Source component
08/25/17   jz      Add RTP Sink component
02/06/17   rz      Fix compiler warnings with print format check
11/04/16   rz      Add workaround for bullseye build 
09/16/16   rz      Add support of OMX HEVC encoder
05/27/16   hl      Add vp9 decoder
06/05/15   hc      Fixed KW P1 warnings
03/27/15   hc      Add new TS component in OMX base class
03/30/14   am      Fix Klockworks warnings.
02/04/14   am      Proper handling of failure in GetHandle.
07/10/13   yzgao   Declare the type before use to avoid build error in Window Csim.
07/10/13   yzgao   Decrease the instance Refcnt if the component initialization failed when loading the lib at omx registry.
07/02/13   rs      Changed the mode for library loading from GLOBAL to LOCAL
04/03/13   dwp     Restructure code to avoid testing unsigned value for negative value
02/27/13   rz      Add vp8 decoder component
02/02/13   am      Return status code for FreeDevLib() and FreeDevLibs().
11/22/12   yzgao   Fix "unresolved symbol" issue when customer remove the link dependency.
11/06/12   sk      Added mode for opening library
03/29/12   che     dlclose needs to be called in reverse order of dlopen calll. Need to
                   remove dlclose call in FreeDevLib which is invoked at OMX_FreeHandle time.
                   Need to wait until OMX_Deinit time to close all shared dlls in reverse order.
02/27/12   sk      Fixed KW compiler warnings
02/23/11   che     ported dynamic loading OmxCore registry from WM
03/01/11   zm      fix iv processor/bits parser init function name
03/25/11   zm      add vc1 decoder component
04/19/11   zm      add midi decoder component

 ===========================================================================*/

#include <string.h>
#include <stdio.h>
#include <dlfcn.h>

#include "MMDebugMsg.h"
#include "qc_omx_core.h"
#include "qc_omx_core_defs.h"
#ifdef __INTEGRITY
#include "qmmStaticLinkAdapter.h"
#define dlclose qmmUtil_UnloadLib
#define dlsym qmmUtil_MapLibSym
#define dlerror() "dl error"
#else
#include "qmmUtils.h"
#endif
typedef enum QC_OMX_COMPONENT
{
    // video decoders
    CMPNT_AVC_DEC = 0,
    CMPNT_MPEG4_DEC,
    CMPNT_VC1_DEC,
    CMPNT_WMV_DEC,
    CMPNT_H263_DEC,
    CMPNT_MPEG2_DEC,
    CMPNT_MJPEG_DEC,
    CMPNT_VP8_DEC,
    CMPNT_HEVC_DEC,
    CMPNT_VP9_DEC,
	CMPNT_DIVX_DEC,

    // video encoders
    CMPNT_AVC_ENC,
    CMPNT_MPEG4_ENC,
    CMPNT_H263_ENC,
    CMPNT_HEVC_ENC,
	CMPNT_VP8_ENC,
	
    // IVprocessor
    CMPNT_IVP,

    // IVRenderer
    CMPNT_IVRENDERER,

    //Transport stream component
    CMPNT_MPEG2TS,

    //Transport stream demuxer component
    CMPNT_MPEG2TS_DEMUXER,

    //Video processing component
    CMPNT_VPP,

    // bit parserer
    CMPNT_BITSPARSER,

    // crc sink
    CMPNT_CRCSINK,

    // rtp sink
    CMPNT_RTPSINK,

    // rtp source
    CMPNT_RTPSOURCE,

    // file demuxer
    CMPT_FILE_DEMUXER,

    // file muxer
    CMPT_FILE_MUXER,

    //audio decoder_renderer
    CMPNT_AUDIO_DECODER,
    CMPNT_AUDIO_RENDERER,
    CMPNT_AUDIO_ENCODER,
    CMPNT_AUDIO_CAPTURE,
    CMPNT_AUDIO_DTMF,

    // camera and still image
    CMPNT_CAMERA,
    CMPNT_JPEG_DEC,
    CMPNT_JPEG_ENC,
    CMPNT_IMG_WRITER,

    CMPNT_CLOCK,

    //Video Streaming
    CMPNT_RTSP,
    CMPNT_HTTP,

    // Timed-event Readers and Parsers
    CMPNT_TE_READER,
    CMPNT_TE_READER_RINGER,
    CMPNT_TE_PARSER,
    CMPNT_TE_PARSER_RINGER,


} QC_OMX_COMPONENT;

static OMX_U8* avcDecRoles[] =
{
    (OMX_U8*)"video_decoder.avc",
    (OMX_U8*)"video_decoder",
    (OMX_U8*)"*"
};

static OMX_U8* mpeg4DecRoles[] =
{
    (OMX_U8*)"video_decoder.mpeg4",
    (OMX_U8*)"video_decoder",
    (OMX_U8*)"*"
};

static OMX_U8* vc1DecRoles[] =
{
    (OMX_U8*)"video_decoder.vc1",
    (OMX_U8*)"video_decoder",
    (OMX_U8*)"*"
};

static OMX_U8* wmvDecRoles[] =
{
    (OMX_U8*)"video_decoder.wmv",
    (OMX_U8*)"video_decoder",
    (OMX_U8*)"*"
};

static OMX_U8* h263DecRoles[] =
{
    (OMX_U8*)"video_decoder.h263",
    (OMX_U8*)"video_decoder",
    (OMX_U8*)"*"
};

static OMX_U8* mpeg2DecRoles[] =
{
    (OMX_U8*)"video_decoder.mpeg2",
    (OMX_U8*)"video_decoder",
    (OMX_U8*)"*"
};

static OMX_U8* mjpegDecRoles[] =
{
    (OMX_U8*)"video_decoder.mjpeg",
    (OMX_U8*)"video_decoder",
    (OMX_U8*)"*"
};

static OMX_U8* vp8DecRoles[] =
{
    (OMX_U8*)"video_decoder.vp8",
    (OMX_U8*)"video_decoder",
    (OMX_U8*)"*"
};

static OMX_U8* hevcDecRoles[] =
{
    (OMX_U8*)"video_decoder.hevc",
    (OMX_U8*)"video_decoder",
    (OMX_U8*)"*"
};

static OMX_U8* vp9DecRoles[] =
{
    (OMX_U8*)"video_decoder.vp9",
    (OMX_U8*)"video_decoder",
    (OMX_U8*)"*"
};

static OMX_U8* divxDecRoles[] =
{
    (OMX_U8*)"video_decoder.divx",
    (OMX_U8*)"video_decoder",
    (OMX_U8*)"*"
};

static OMX_U8* avcEncRoles[] =
{
    (OMX_U8*)"video_encoder.avc",
    (OMX_U8*)"video_encoder",
    (OMX_U8*)"*"
};

static OMX_U8* mpeg4EncRoles[] =
{
    (OMX_U8*)"video_encoder.mpeg4",
    (OMX_U8*)"video_encoder",
    (OMX_U8*)"*"
};

static OMX_U8* h263EncRoles[] =
{
    (OMX_U8*)"video_encoder.h263",
    (OMX_U8*)"video_encoder",
    (OMX_U8*)"*"
};

static OMX_U8* hevcEncRoles[] =
{
    (OMX_U8*)"video_encoder.hevc",
    (OMX_U8*)"video_encoder",
    (OMX_U8*)"*"
};

static OMX_U8* vp8EncRoles[] =
{
    (OMX_U8*)"video_encoder.vp8",
    (OMX_U8*)"video_encoder",
    (OMX_U8*)"*"
};

/* OBSOLETE: Defined but not used **
*
*
static OMX_U8* aacDecRoles[] =
{
    "audio_decoder.aac",
    "audio_decoder",
    "*"
};

static OMX_U8* amrDecRoles[] =
{
    "audio_decoder.amr",
    "audio_decoder",
     "*"
};

static OMX_U8* mp3DecRoles[] =
{
    "audio_decoder.mp3",
    "audio_decoder",
    "*"
};


static OMX_U8* aacEncRoles[] =
{
    "audio_encoder.aac",
    "audio_encoder",
    "*"
};

static OMX_U8* videoRendererRoles[] =
{
    "video_renderer",
    "video_renderer",
    "*"
};
*/

static OMX_U8* audioDecoderRoles[] =
{
    (OMX_U8*)"OMX.qcom.audiodecoder",
    (OMX_U8*)"audio_decoder",
    (OMX_U8*)"*"
};

static OMX_U8* audioRendererRoles[] =
{
    (OMX_U8*)"OMX.qcom.audiorenderer",
    (OMX_U8*)"audio_renderer",
    (OMX_U8*)"*"
};

static OMX_U8* audioEncoderRoles[] =
{
    (OMX_U8*)"OMX.qcom.audioencoder",
    (OMX_U8*)"audio_encoder",
    (OMX_U8*)"*"
};

static OMX_U8* audioCapturerRoles[] =
{
    (OMX_U8*)"OMX.qcom.audiocapturer",
    (OMX_U8*)"audio_capturer",
    (OMX_U8*)"*"
};

static OMX_U8* audioDtmfRoles[] =
{
    (OMX_U8*)"OMX.qcom.audiodtmf",
    (OMX_U8*)"audio_dtmf",
    (OMX_U8*)"*"
};

static OMX_U8* ivpRoles[] =
{
    (OMX_U8*)"video.ivProcessor",
    (OMX_U8*)"*"
};

static OMX_U8* cameraRoles[] =
{
    (OMX_U8*)"camera",
    (OMX_U8*)"*"
};

static OMX_U8* ivrendererRoles[] =
{
    (OMX_U8*)"iv_renderer.yuv",
    (OMX_U8*)"iv_renderer",
    (OMX_U8*)"*"
};
static OMX_U8* mpeg2tsRoles[] =
{
    (OMX_U8*)"OMX.qcom.transport.mpeg2ts",
    (OMX_U8*)"transport",
    (OMX_U8*)"*"
};

static OMX_U8* mpeg2tsdemuxerRoles[] =
{
    (OMX_U8*)"OMX.qcom.demuxer.mpeg2ts",
    (OMX_U8*)"demuxer",
    (OMX_U8*)"*"
};

static OMX_U8* vppRoles[] =
{
    (OMX_U8*)"OMX.qcom.vpp",
    (OMX_U8*)"vpp",
    (OMX_U8*)"*"
};

static OMX_U8* bitsParserRoles[] =
{
    (OMX_U8*)"OMX.qcom.bitsParser",
    (OMX_U8*)"bitsParser",
    (OMX_U8*)"*"
};
static OMX_U8* crcSinkRoles[] =
{
    (OMX_U8*)"OMX.qcom.video.crcSink",
    (OMX_U8*)"crcSink",
    (OMX_U8*)"*"
};
static OMX_U8* rtpSinkRoles[] =
{
    (OMX_U8*)"OMX.qcom.rtpSink",
    (OMX_U8*)"rtpSink",
    (OMX_U8*)"*"
};
static OMX_U8* rtpSourceRoles[] =
{
    (OMX_U8*)"OMX.qcom.rtpSource",
    (OMX_U8*)"rtpSource",
    (OMX_U8*)"*"
};
static OMX_U8* jpegEncoderRoles[] =
{
    (OMX_U8*)"image_encoder.exif",
    (OMX_U8*)"image_encoder.jpeg",
    (OMX_U8*)"image_encoder",
    (OMX_U8*)"*"
};

static OMX_U8* jpegDecoderRoles[] =
{
    (OMX_U8*)"image_decoder.exif",
    (OMX_U8*)"image_decoder.jpeg",
    (OMX_U8*)"image_decoder",
    (OMX_U8*)"*"
};

static OMX_U8* imageWriterRoles[] =
{
    (OMX_U8*)"image_writer.exif",
    (OMX_U8*)"image_writer.jfif",
    (OMX_U8*)"image_writer",
    (OMX_U8*)"*"
};

static OMX_U8*  fileMuxerRoles[] =
{
    (OMX_U8*)"container_muxer.3g2",
    (OMX_U8*)"container_muxer.mp4",
    (OMX_U8*)"container_muxer.3gp",
    (OMX_U8*)"container_muxer.amc",
    (OMX_U8*)"container_muxer.skm",
    (OMX_U8*)"container_muxer.k3g",
    (OMX_U8*)"container_muxer.wav",
    (OMX_U8*)"container_muxer.amr",
    (OMX_U8*)"container_muxer.aac",
    (OMX_U8*)"container_muxer.evr",
    (OMX_U8*)"container_muxer.evw",
    (OMX_U8*)"container_muxer.qcp",
    (OMX_U8*)"*"
};

static OMX_U8* fileDemuxerRoles[] =
{
    (OMX_U8*)"container_demuxer.3g2",
    (OMX_U8*)"container_demuxer.mp4",
    (OMX_U8*)"container_demuxer.3gp",
    (OMX_U8*)"container_demuxer.amc",
    (OMX_U8*)"container_demuxer.skm",
    (OMX_U8*)"container_demuxer.k3g",
    (OMX_U8*)"container_demuxer.wav",
    (OMX_U8*)"container_demuxer.amr",
    (OMX_U8*)"container_demuxer.aac",
    (OMX_U8*)"container_demuxer.evr",
    (OMX_U8*)"container_demuxer.evw",
    (OMX_U8*)"container_demuxer.qcp",
    (OMX_U8*)"container_demuxer.mp3",
    (OMX_U8*)"container_demuxer.awb",
    (OMX_U8*)"container_demuxer.wav",
    (OMX_U8*)"container_demuxer.asf",
    (OMX_U8*)"container_demuxer.wma",
    (OMX_U8*)"container_demuxer.wmv",
    (OMX_U8*)"container_demuxer.avi",
    (OMX_U8*)"*"
};

static OMX_U8* clockRoles[] =
{
    (OMX_U8*)"clock",
    (OMX_U8*)"*"
};


static OMX_U8* pRTPMMIComonentRoles[] = {
  (OMX_U8*)"container_streaming.rtsp",
  (OMX_U8*)"*"
};

static OMX_U8* HTTPMMIStreamingRoles[] = {
  (OMX_U8*)"container_streaming.http",
  (OMX_U8*)"*"
};

// Timed-event Readers and Parsers
static OMX_U8* TEAudioReaderRoles[] =
{
  (OMX_U8*)"audio_reader.midi",
  (OMX_U8*)"audio_reader",
  (OMX_U8*)"*"
};

static OMX_U8* TEAudioReaderRingerRoles[] =
{
  (OMX_U8*)"audio_reader_ringer.midi",
  (OMX_U8*)"audio_reader_ringer",
  (OMX_U8*)"*"
};

static OMX_U8* TEAudioParserRoles[] =
{
  (OMX_U8*)"audio_parser.midi",
  (OMX_U8*)"audio_parser",
  (OMX_U8*)"*"
};

static OMX_U8* TEAudioParserRingerRoles[] =
{
  (OMX_U8*)"audio_parser_ringer.midi",
  (OMX_U8*)"audio_parser_ringer",
  (OMX_U8*)"*"
};

typedef struct MMI_DevLibT MMI_DevLib;

struct MMI_DevLibT
{
    const char *iLibName;
    const char *iInitFunctionName;
    void* iLibInstance;
    OMX_U32 iRefCnt;

    MMI_DevLib* iNext;
} ;

MMI_DevLib gMMIDevLib[] =
{
    // video decoders
    {
        "mmiVdec",
        "mmi_avc_dec_init",
        NULL,
        0,
        NULL
    },
    {
        "mmiVdec",
        "mmi_mpeg4_dec_init",
        NULL,
        0,
        NULL
    },
    {
        "mmiVdec",
        "mmi_vc1_dec_init",
        NULL,
        0,
        NULL
    },
    {
        "mmiVdec",
        "mmi_wmv_dec_init",   // for wmv
        NULL,
        0,
        NULL
    },
    {
        "mmiVdec",
        "mmi_h263_dec_init",
        NULL,
        0,
        NULL
    },
    {
        "mmiVdec",
        "mmi_mpeg2_dec_init",
        NULL,
        0,
        NULL
    },
    {
        "mmiMotionJpeg",
        "MJpegDecoderComponent_Init",
        NULL
    },

    {
        "mmiVdec",
        "mmi_vp8_dec_init",
        NULL,
        0,
        NULL
    },

    {
        "mmiVdec",
        "mmi_hevc_dec_init",
        NULL,
        0,
        NULL
    },

    {
        "mmiVdec",
        "mmi_vp9_dec_init",
        NULL,
        0,
        NULL
    },

    {
        "mmiVdec",
        "mmi_divx_dec_init",
        NULL,
        0,
        NULL
    },

    // video encoders
    {
        "mmiVenc",
        "mmi_avc_enc_init",
        NULL,
        0,
        NULL
    },

    {
        "mmiVenc",
        "mmi_mpeg4_enc_init",
        NULL,
        0,
        NULL
    },
    {
        "mmiVenc",
        "mmi_h263_enc_init",
        NULL,
        0,
        NULL
    },

	{
		"mmiVenc",
		"mmi_hevc_enc_init",
		NULL,
		0,
		NULL
	},

	{
		"mmiVenc",
		"mmi_vp8_enc_init",
		NULL,
		0,
		NULL
	},

    // iv processor
    {
        "mmiIvp",
        "mmi_ivp_init",
        NULL,
        0,
        NULL
    },

    // iv renderer
    {
        "ivrenderer",
        "MMIVRenderer_init",
        NULL,
        0,
        NULL
    },

    // mpeg2ts
    {
        "mmiTransport",
        "mmi_mpeg2ts_init",
        NULL,
        0,
        NULL
    },

    // mpeg2ts demuxer
    {
        "mmiTSDemuxer",
        "MMI_MPEG2TS_Demuxer_Component_Init",
        NULL,
        0,
        NULL
    },

    // vpp
    {
        "mmivpp",
        "MMI_VPP_Component_Init",
        NULL,
        0,
        NULL
    },

    // bits parser
    {
        "mmibitsparser",
        "mmiBitsParserComponentInit",
        NULL,
        0,
        NULL
    },

    // crc Sink
    {
        "mmicrcsink",
        "MMI_CRCRenderer_Component_Init",
        NULL,
        0,
        NULL
    },

    // rtp Sink
    {
        "mmirtpsink",
        "MMI_RTPSink_Component_Init",
        NULL,
        0,
        NULL
    },

    // rtp Source
    {
        "mmirtpsource",
        "MMI_RTPSource_Component_Init",
        NULL,
        0,
        NULL
    },

    // file demuxer
    {
        "omxdemux",
        "QOMX_File_Demuxer_ComponentInit",
        NULL,
        0,
        NULL
    },

    // file muxer
    {
        "omxmux",
        "QOMX_File_Muxer_ComponentInit",
        NULL,
        0,
        NULL
    },

    // audio components
    {
        "AOMXDecoder",
        "Omx_AudioDecoderComponentInit",
        NULL,
        0,
        NULL
    },
    {
        "AOMXRenderer",
        "Omx_AudioRendererComponentInit",
        NULL,
        0,
        NULL
    },
    {
        "AOMXEncoder",
        "Omx_AudioEncoderComponentInit",
        NULL,
        0,
        NULL
    },
    {
        "AOMXCapturer",
        "Omx_AudioCapturerComponentInit",
        NULL,
        0,
        NULL
    },
    {
        "AOMXDtmf",
        "Omx_AudioDtmfComponentInit",
        NULL,
        0,
        NULL
    },

    // camera component
    {
        "Camera",
        "QOMX_CameraComponentInit",
        NULL,
        0,
        NULL
    },
    // jpeg decoder component
    {
        "jpegd",
        "JpegDecoderComponent_Init",
        NULL,
        0,
        NULL
    },
    // jpeg encoder component
    {
        "jpege",
        "JpegEncoderComponent_Init",
        NULL,
        0,
        NULL
    },
    // image writer component
    {
        "jpege",
        "ImageWriterComponent_Init",
        NULL,
        0,
        NULL
    },

    // clock component
    {
        "mmiclock",
        "MMIClock_init",
        NULL,
        0,
        NULL
    },

    //Streaming Component
    {
        "IPStream_RTP",
        "QOMX_RTPMMIDevice_ComponentInit",
        NULL,
        0,
        NULL
    },

    {
        "IPStream_HTTP",
        "QOMX_MMIV_HTTP_ComponentInit",
        NULL,
        0,
        NULL
    },

    // Timed-event Reader and Parser
    {
        "MMITEReaderLib",
        "mmi_audio_tereader_init",
        NULL,
        0,
        NULL
    },

    {
        "MMITEReaderLib",
        "mmi_audio_tereader_ringer_init",
        NULL,
        0,
        NULL
    },

    {
        "MMITEParserLib",
        "mmi_audio_teparser_init",
        NULL,
        0,
        NULL
    },

    {
        "MMITEParserLib",
        "mmi_audio_teparser_ringer_init",
        NULL,
        0,
        NULL
    },

};

static MMI_DevLib* gMMIDevLoaded = NULL;

const OMX_U32 gDevLibCount = sizeof(gMMIDevLib)/sizeof(MMI_DevLib);

static OMX_ERRORTYPE LoadMMIDevComponent(QC_OMX_COMPONENT aCmpntIdx, OMX_HANDLETYPE hComponent);


static OMX_ERRORTYPE LoadMMIDevComponent(QC_OMX_COMPONENT aCmpntIdx, OMX_HANDLETYPE hComponent)
{
    OMX_ERRORTYPE ret = OMX_ErrorNone;
    OMX_COMPONENTINITTYPE pInitialize = NULL;
    OMX_COMPONENTTYPE_EXT *pOmxCompExt = (OMX_COMPONENTTYPE_EXT *)hComponent;
    void* aInstance;

    omx_core_lock();
    aInstance = gMMIDevLib[aCmpntIdx].iLibInstance;

    if (aInstance == NULL)
    {

#ifdef BULLSEYE
        // add workaround only for bullseye coverage, if not adding RTLD_NODELETE, application exit will crash for some reasons
        aInstance = qmmUtil_LoadLib(gMMIDevLib[aCmpntIdx].iLibName, QMM_MODE_LOCAL | RTLD_NODELETE ); 
#else
        aInstance = qmmUtil_LoadLib(gMMIDevLib[aCmpntIdx].iLibName, QMM_MODE_LOCAL ); 
#endif
        if (aInstance)
        {
            MM_MSG_SPRINTF_PRIO_1(MM_OMX_COMMON, MM_PRIO_MEDIUM, "Succesfully loaded %s", gMMIDevLib[aCmpntIdx].iLibName);
            gMMIDevLib[aCmpntIdx].iLibInstance  = aInstance;
        }
        else
        {
            MM_MSG_SPRINTF_PRIO_1(MM_OMX_COMMON, MM_PRIO_ERROR, "DLL %s Failed To Load!", gMMIDevLib[aCmpntIdx].iLibName);
            omx_core_unlock();
            return OMX_ErrorNotImplemented;
       }
    }
    gMMIDevLib[aCmpntIdx].iRefCnt++;
    gMMIDevLib[aCmpntIdx].iNext = gMMIDevLoaded;
    gMMIDevLoaded = &gMMIDevLib[aCmpntIdx];

    // save the lib instance so that FreeHandle can easily find the lib handle
    pOmxCompExt->pLibInfo = (void *)&gMMIDevLib[aCmpntIdx];
    
    omx_core_unlock();

    pInitialize = (OMX_COMPONENTINITTYPE)dlsym(aInstance, gMMIDevLib[aCmpntIdx].iInitFunctionName);
    if (pInitialize == NULL)
    {
        omx_core_lock();
        gMMIDevLib[aCmpntIdx].iRefCnt--;
        omx_core_unlock();
        MM_MSG_PRIO(MM_OMX_COMMON, MM_PRIO_ERROR, "the component does not export an initialize function");
        return OMX_ErrorInvalidComponent;
    }

    // call the init function
    ret = pInitialize(hComponent);
    if (ret != OMX_ErrorNone)
    {
       omx_core_lock();
       gMMIDevLib[aCmpntIdx].iRefCnt--;
       omx_core_unlock();
       MM_MSG_PRIO(MM_OMX_COMMON, MM_PRIO_ERROR, "component initialization failed");
    }

    return ret;
}

static OMX_ERRORTYPE LoadMMIVdecAVCComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_AVC_DEC, hComponent);
}

static OMX_ERRORTYPE LoadMMIVdecMPEG4Component(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_MPEG4_DEC, hComponent);
}

static OMX_ERRORTYPE LoadMMIVdecVC1Component(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_VC1_DEC, hComponent);
}

static OMX_ERRORTYPE LoadMMIVdecWMVComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_WMV_DEC, hComponent);
}

static OMX_ERRORTYPE LoadMMIVdecH263Component(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_H263_DEC, hComponent);
}

static OMX_ERRORTYPE LoadMMIVdecMPEG2Component(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_MPEG2_DEC, hComponent);
}

static OMX_ERRORTYPE LoadMMIVdecMJPEGComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_MJPEG_DEC, hComponent);
}

static OMX_ERRORTYPE LoadMMIVdecVP8Component(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_VP8_DEC, hComponent);
}

static OMX_ERRORTYPE LoadMMIVdecVP9Component(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_VP9_DEC, hComponent);
}

static OMX_ERRORTYPE LoadMMIVdecHevcComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_HEVC_DEC, hComponent);
}

static OMX_ERRORTYPE LoadMMIVdecDivxComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_DIVX_DEC, hComponent);
}

static OMX_ERRORTYPE LoadMMIVencAVCComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_AVC_ENC, hComponent);
}

static OMX_ERRORTYPE LoadMMIVencMPEG4Component(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_MPEG4_ENC, hComponent);
}

static OMX_ERRORTYPE LoadMMIVencH263Component(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_H263_ENC, hComponent);
}

static OMX_ERRORTYPE LoadMMIVencHEVCComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_HEVC_ENC, hComponent);
}

static OMX_ERRORTYPE LoadMMIVencVP8Component(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_VP8_ENC, hComponent);
}

static OMX_ERRORTYPE LoadMMIIVPComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_IVP, hComponent);
}
static OMX_ERRORTYPE LoadMMIVRendererComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_IVRENDERER, hComponent);
}

static OMX_ERRORTYPE LoadMMIMPEG2TSComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_MPEG2TS, hComponent);
}

static OMX_ERRORTYPE LoadMMIMPEG2TSDemuxerComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_MPEG2TS_DEMUXER, hComponent);
}

static OMX_ERRORTYPE LoadMMIVPPComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_VPP, hComponent);
}

static OMX_ERRORTYPE LoadMMIBitsParserComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_BITSPARSER, hComponent);
}

static OMX_ERRORTYPE LoadMMICrcSinkComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_CRCSINK, hComponent);
}

static OMX_ERRORTYPE LoadMMIRTPSinkComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_RTPSINK, hComponent);
}

static OMX_ERRORTYPE LoadMMIRTPSourceComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_RTPSOURCE, hComponent);
}

static OMX_ERRORTYPE LoadMMIFileDemuxerComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPT_FILE_DEMUXER, hComponent);
}

static OMX_ERRORTYPE LoadMMIFileMuxerComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPT_FILE_MUXER, hComponent);
}

static OMX_ERRORTYPE LoadMMIAudioDecoderComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_AUDIO_DECODER, hComponent);
}

static OMX_ERRORTYPE LoadMMIAudioRendererComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_AUDIO_RENDERER, hComponent);
}

static OMX_ERRORTYPE LoadMMIAudioEncoderComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_AUDIO_ENCODER, hComponent);
}

static OMX_ERRORTYPE LoadMMIAudioCapturerComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_AUDIO_CAPTURE, hComponent);
}

static OMX_ERRORTYPE LoadMMIAudioDTMFComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_AUDIO_DTMF, hComponent);
}

static OMX_ERRORTYPE LoadMMICameraComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_CAMERA, hComponent);
}

static OMX_ERRORTYPE LoadMMIJpegDecoderComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_JPEG_DEC, hComponent);
}

static OMX_ERRORTYPE LoadMMIJpegEncoderComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_JPEG_ENC, hComponent);
}

static OMX_ERRORTYPE LoadMMIImageWriterComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_IMG_WRITER, hComponent);
}

static OMX_ERRORTYPE LoadMMIClockComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_CLOCK, hComponent);
}

static OMX_ERRORTYPE LoadMMIRTPComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_RTSP, hComponent);
}

static OMX_ERRORTYPE LoadMMIHTTPComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_HTTP, hComponent);
}

// Timed-event Readers and Parsers
static OMX_ERRORTYPE LoadMMITEReaderComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_TE_READER, hComponent);
}
static OMX_ERRORTYPE LoadMMITEReaderRingerComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_TE_READER_RINGER, hComponent);
}
static OMX_ERRORTYPE LoadMMITEParserComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_TE_PARSER, hComponent);
}
static OMX_ERRORTYPE LoadMMITEParserRingerComponent(OMX_HANDLETYPE hComponent)
{
    return LoadMMIDevComponent(CMPNT_TE_PARSER_RINGER, hComponent);
}

OMX_ERRORTYPE FreeDevLib(OMX_HANDLETYPE pLibInfo)
{
    //OMX_COMPONENTTYPE_EXT *pOmxCompExt = (OMX_COMPONENTTYPE_EXT *)hComponent;
    MMI_DevLib *pDevLib =(MMI_DevLib *)pLibInfo;
    OMX_ERRORTYPE ret = OMX_ErrorNone;
    
    omx_core_lock();
    if ( (pDevLib && pDevLib->iLibInstance) && (pDevLib->iRefCnt > 0))
    {
        pDevLib->iRefCnt--;
    }
    else
    {
        MM_MSG_PRIO(MM_OMX_COMMON, MM_PRIO_ERROR, "FreeDevLib fail");
        ret = OMX_ErrorUndefined; 
    }
    omx_core_unlock();
    return ret;
}

OMX_ERRORTYPE FreeDevLibs()
{
    MMI_DevLib* pDevLib = NULL;
    OMX_ERRORTYPE ret = OMX_ErrorNone;

    /* close out the libraries */
    unsigned int i = 0;
    for(i=0; i< gDevLibCount; i++)
    {
        if(gMMIDevLib[i].iRefCnt)
        {
            MM_MSG_SPRINTF_PRIO_1(MM_OMX_COMMON, MM_PRIO_ERROR, "Can not close lib %s, still in use", gMMIDevLib[i].iLibName);
            ret = OMX_ErrorUndefined;   // There is no other suitable error code to describe the error.
        }
    }

    pDevLib = gMMIDevLoaded;
    while (pDevLib)
    {
        if(pDevLib->iLibInstance)
        {
            int failed = dlclose(pDevLib->iLibInstance);
            if(failed)
            {
#ifdef BULLSEYE
               ret = OMX_ErrorNone;  // ignore dlclose failure when dlopen with RTLD_NODELETE using bullseye
#else
                MM_MSG_SPRINTF_PRIO_2(MM_OMX_COMMON, MM_PRIO_ERROR, "Failed to dlclose lib %s %s", pDevLib->iLibName, dlerror());
                ret = OMX_ErrorUndefined;  // There is no other suitable error code to describe the error.
#endif
            }
            else
            {
                MM_MSG_SPRINTF_PRIO_1(MM_OMX_COMMON, MM_PRIO_HIGH, "Successfully dlclosed lib%s", pDevLib->iLibName);
            }
        }
        gMMIDevLoaded = pDevLib->iNext;
        pDevLib->iLibInstance = NULL;
        pDevLib->iNext = NULL;
        pDevLib = gMMIDevLoaded;
    }
    return ret;
}

const OMXILCORE_COMPONENTINFOTYPE gOmxCmpntRegistry[] =
{
    {
        "OMX.qcom.video.decoder.avc",
        LoadMMIVdecAVCComponent,
        sizeof(avcDecRoles)/sizeof(OMX_U8*),
        avcDecRoles
    },


    {
        "OMX.qcom.video.decoder.mpeg4",
        LoadMMIVdecMPEG4Component,
        sizeof(mpeg4DecRoles)/sizeof(OMX_U8*),
        mpeg4DecRoles
    },

    {
        "OMX.qcom.video.decoder.vc1",
        LoadMMIVdecVC1Component,
        sizeof(vc1DecRoles)/sizeof(OMX_U8*),
        vc1DecRoles
    },

    {
        "OMX.qcom.video.decoder.wmv",
        LoadMMIVdecWMVComponent,
        sizeof(wmvDecRoles)/sizeof(OMX_U8*),
        wmvDecRoles
    },

    {
        "OMX.qcom.video.decoder.h263",
        LoadMMIVdecH263Component,
        sizeof(h263DecRoles)/sizeof(OMX_U8*),
        h263DecRoles
    },

    {
        "OMX.qcom.video.decoder.mpeg2",
        LoadMMIVdecMPEG2Component,
        sizeof(mpeg2DecRoles)/sizeof(OMX_U8*),
        mpeg2DecRoles
    },

    {
        "OMX.qcom.video.decoder.mjpeg",
        LoadMMIVdecMJPEGComponent,
        sizeof(mjpegDecRoles)/sizeof(OMX_U8*),
        mjpegDecRoles
    },

    {
        "OMX.qcom.video.decoder.vp8",
        LoadMMIVdecVP8Component,
        sizeof(vp8DecRoles)/sizeof(OMX_U8*),
        vp8DecRoles
    },

    {
        "OMX.qcom.video.decoder.hevc",
        LoadMMIVdecHevcComponent,
        sizeof(hevcDecRoles)/sizeof(OMX_U8*),
        hevcDecRoles
    },

    {
        "OMX.qcom.video.decoder.vp9",
        LoadMMIVdecVP9Component,
        sizeof(vp9DecRoles)/sizeof(OMX_U8*),
        vp9DecRoles
    },

    {
        "OMX.qcom.video.decoder.divx",
        LoadMMIVdecDivxComponent,
        sizeof(divxDecRoles)/sizeof(OMX_U8*),
        divxDecRoles
    },

    {
        "OMX.qcom.video.encoder.avc",
        LoadMMIVencAVCComponent,
        sizeof(avcEncRoles)/sizeof(OMX_U8*),
        avcEncRoles
    },

    {
        "OMX.qcom.video.encoder.mpeg4",
        LoadMMIVencMPEG4Component,
        sizeof(mpeg4EncRoles)/sizeof(OMX_U8*),
        mpeg4EncRoles
    },

    {
        "OMX.qcom.video.encoder.h263",
        LoadMMIVencH263Component,
        sizeof(h263EncRoles)/sizeof(OMX_U8*),
        h263EncRoles
    },

	{
		"OMX.qcom.video.encoder.hevc",
		LoadMMIVencHEVCComponent,
		sizeof(hevcEncRoles)/sizeof(OMX_U8*),
		hevcEncRoles
	},

	{
		"OMX.qcom.video.encoder.vp8",
		LoadMMIVencVP8Component,
		sizeof(vp8EncRoles)/sizeof(OMX_U8*),
		vp8EncRoles
	},


	{
        "OMX.qcom.ivprocessor",
        LoadMMIIVPComponent,
        sizeof(ivpRoles)/sizeof(OMX_U8*),
        ivpRoles
    },

    {
        "OMX.qcom.video.mmirenderer",
        LoadMMIVRendererComponent,
        sizeof(ivrendererRoles)/sizeof(OMX_U8*),
        ivrendererRoles
    },

    {
        "OMX.qcom.transport.mpeg2ts",
        LoadMMIMPEG2TSComponent,
        sizeof(mpeg2tsRoles)/sizeof(OMX_U8*),
        mpeg2tsRoles
    },

    {
        "OMX.qcom.demuxer.mpeg2ts",
        LoadMMIMPEG2TSDemuxerComponent,
        sizeof(mpeg2tsdemuxerRoles)/sizeof(OMX_U8*),
        mpeg2tsdemuxerRoles
    },

    {
        "OMX.qcom.vpp",
        LoadMMIVPPComponent,
        sizeof(vppRoles)/sizeof(OMX_U8*),
        vppRoles
    },


    {
        "OMX.qcom.bitsParser",
        LoadMMIBitsParserComponent,
        sizeof(bitsParserRoles)/sizeof(OMX_U8*),
        bitsParserRoles
    },
    {
        "OMX.qcom.video.crcSink",
        LoadMMICrcSinkComponent,
        sizeof(crcSinkRoles)/sizeof(OMX_U8*),
        crcSinkRoles
    },
    {
        "OMX.qcom.rtpSink",
        LoadMMIRTPSinkComponent,
        sizeof(rtpSinkRoles)/sizeof(OMX_U8*),
        rtpSinkRoles
    },

    {
        "OMX.qcom.rtpSource",
        LoadMMIRTPSourceComponent,
        sizeof(rtpSourceRoles)/sizeof(OMX_U8*),
        rtpSourceRoles
    },

    {
        "OMX.qcom.file.demuxer",
        LoadMMIFileDemuxerComponent,
        sizeof(fileDemuxerRoles)/sizeof(OMX_U8*),
        fileDemuxerRoles
    },
    {
        "OMX.qcom.file.muxer",
        LoadMMIFileMuxerComponent,
        sizeof(fileMuxerRoles)/sizeof(OMX_U8*),
        fileMuxerRoles
    },

    {
        "OMX.qcom.audiodecoder",
        LoadMMIAudioDecoderComponent,
        sizeof(audioDecoderRoles)/sizeof(OMX_U8*),
        audioDecoderRoles
    },

    {
        "OMX.qcom.audiorenderer",
        LoadMMIAudioRendererComponent,
        sizeof(audioRendererRoles)/sizeof(OMX_U8*),
        audioRendererRoles
    },

    {
        "OMX.qcom.audioencoder",
        LoadMMIAudioEncoderComponent,
        sizeof(audioEncoderRoles)/sizeof(OMX_U8*),
        audioEncoderRoles
    },
    {
        "OMX.qcom.audiocapturer",
        LoadMMIAudioCapturerComponent,
        sizeof(audioCapturerRoles)/sizeof(OMX_U8*),
        audioCapturerRoles
    },

    {
        "OMX.qcom.audioDtmf",
        LoadMMIAudioDTMFComponent,
        sizeof(audioDtmfRoles)/sizeof(OMX_U8*),
        audioDtmfRoles
    },

    {
        "OMX.qcom.source.camera",
        LoadMMICameraComponent,
        sizeof(cameraRoles)/sizeof(OMX_U8*),
        cameraRoles
    },
    {
        "OMX.qcom.image.decoder.jpeg",
        LoadMMIJpegDecoderComponent,
        sizeof(jpegDecoderRoles)/sizeof(OMX_U8*),
        jpegDecoderRoles
    },
    {
        "OMX.qcom.image.encoder.jpeg",
        LoadMMIJpegEncoderComponent,
        sizeof(jpegEncoderRoles)/sizeof(OMX_U8*),
        jpegEncoderRoles
    },
    {
        "OMX.qcom.image.writer",
        LoadMMIImageWriterComponent,
        sizeof(imageWriterRoles)/sizeof(OMX_U8*),
        imageWriterRoles
    },

    // clock component
    {
        "OMX.qcom.mmiclock",
        LoadMMIClockComponent,
        sizeof(clockRoles)/sizeof(OMX_U8*),
        clockRoles
    },

    //RTSP Streaming Component
    {
        "OMX.qcom.source.rtspstream",
        LoadMMIRTPComponent,
        sizeof(pRTPMMIComonentRoles)/sizeof(OMX_U8*),
        pRTPMMIComonentRoles
    },

    //HTTP Streaming Component
    {
        "OMX.qcom.source.httpstream",
        LoadMMIHTTPComponent,
        sizeof(HTTPMMIStreamingRoles)/sizeof(OMX_U8*),
        HTTPMMIStreamingRoles
    },

    // TE Reader and Parser components
    {
        "OMX.qcom.audio.reader.midi",
        LoadMMITEReaderComponent,
        sizeof(TEAudioReaderRoles)/sizeof(OMX_U8*),
        TEAudioReaderRoles
    },

    {
        "OMX.qcom.audio.reader.midi.alert",
        LoadMMITEReaderRingerComponent,
        sizeof(TEAudioReaderRingerRoles)/sizeof(OMX_U8*),
        TEAudioReaderRingerRoles
    },

    {
        "OMX.qcom.audio.teparser",
        LoadMMITEParserComponent,
        sizeof(TEAudioParserRoles)/sizeof(OMX_U8*),
        TEAudioParserRoles
    },

    {
        "OMX.qcom.audio.teparser.alert",
        LoadMMITEParserRingerComponent,
        sizeof(TEAudioParserRingerRoles)/sizeof(OMX_U8*),
        TEAudioParserRingerRoles
    },

};

const OMX_U32 gOmxCmpntRegistrySize = sizeof(gOmxCmpntRegistry)/sizeof(OMXILCORE_COMPONENTINFOTYPE);



