/*============================================================================
                            O p e n M A X   w r a p p e r s
                             O p e n  M A X   C o r e

*//** @file qc_omx_core.c
  This module contains the implementation of the OpenMAX core.

Copyright (c) 2006-2017 QUALCOMM Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*============================================================================
                              Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/core/src/qc_omx_core.c#1 $
when       who     what, where, why
--------   ---     -------------------------------------------------------
02/06/17   rz      Fix compiler warnings with print format check
06/30/08   ssk     Created file.
07/08/08   bc      Updates for encoder. Portability updates.
06/17/09   che     Rewrite using new omx multimedia arch and omx base class
07/26/10   zm      Fix a Klockwork error.
12/17/12   am      clean up. move refcnt and mutex lock into omx_core.c
02/02/13   am      return status code for FreeDevLibs in DeInit()
============================================================================*/

//////////////////////////////////////////////////////////////////////////////
//                             Include Files
//////////////////////////////////////////////////////////////////////////////
#include <stdlib.h>
#include <pthread.h>
#include "qc_omx_core.h"
#include "MMDebugMsg.h"

extern const OMXILCORE_COMPONENTINFOTYPE gOmxCmpntRegistry[];
extern OMX_U32 gOmxCmpntRegistrySize;

#define MAX_OMX_COMPONENTS 50
static OMX_U32 sOmxDynamicCmpnts = 0;
static OMXILCORE_COMPONENTINFOTYPE* sOmxCmpnts[MAX_OMX_COMPONENTS] = {0};

static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
extern OMX_ERRORTYPE FreeDevLibs();

void omx_core_lock()
{
    pthread_mutex_lock(&mutex);
}

void omx_core_unlock()
{
    pthread_mutex_unlock(&mutex);
}

static OMX_ERRORTYPE Init()
{
   int aIdx = 0;
   for (aIdx = 0; aIdx < gOmxCmpntRegistrySize; aIdx++)
   {
      sOmxCmpnts[aIdx] = (OMXILCORE_COMPONENTINFOTYPE *)&gOmxCmpntRegistry[aIdx];
   }
   return OMX_ErrorNone;
}

static OMX_ERRORTYPE DeInit()
{
   OMX_ERRORTYPE eRet = OMX_ErrorNone;
   MM_MSG_PRIO(MM_OMX_COMMON,MM_PRIO_MEDIUM, "OMX_CORE DeInit free dev libs ");
   eRet = FreeDevLibs();
   return eRet;
}

static OMX_ERRORTYPE UpdateTable()
{
   return OMX_ErrorNone;
}

static OMX_ERRORTYPE ReadTable
(
   OMX_U32 *pNumEntries,
   OMXILCORE_COMPONENTINFOTYPE **ppComponentList
)
{
   if (pNumEntries == 0 || ppComponentList == NULL)
   {
      return OMX_ErrorBadParameter;
   }

   *pNumEntries = gOmxCmpntRegistrySize + sOmxDynamicCmpnts;
   *ppComponentList = (OMXILCORE_COMPONENTINFOTYPE *)sOmxCmpnts;

   return OMX_ErrorNone;
}

static OMX_ERRORTYPE ReleaseTable()
{
   return OMX_ErrorNone;
}

OMXILCCORE_TYPE omxcore = 
{
   Init,
   DeInit,
   UpdateTable,
   ReadTable,
   ReleaseTable
};

OMX_ERRORTYPE QOMX_RegisterComponent(OMXILCORE_COMPONENTINFOTYPE* pCompnentInfo)
{
   return OMX_ErrorNone;
}
