/*============================================================================
                             O p e n  M A X   C o r e

*//** @file omx_core.c
  This module contains the implementation of the os independent part of the OpenMAX core.

   It uses an extrerned virtual table omxcore to access the os dependent core. each os target will have
   to implement the omxcore table in its own verion of the qc_omx_core.c file

Copyright (c) 2006-2017 QUALCOMM Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*============================================================================
                              Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/core/src/omx_core.c#1 $
when       who     what, where, why
--------   ---     -------------------------------------------------------
02/06/17   rz      Fix compiler warnings with print format check
06/22/16   am      Fix compiler warnings for 64 bit OS environment.
05/27/16   rz      Fix csim compilation
06/05/15   hc      Fixed KW P1 warnings
05/22/14   rz      Add handle at FreeHandle complete for KPI logging
05/08/14   dp      Replace std_strcmp with std_strncmp.
03/30/14   am      Fix Klockworks warning.
02/04/14   am      Proper handling of failure in GetHandle.
10/07/13   dp      Fix reference conter in case of error, update messages for better visibility.
08/26/13   am      Update reference counting to handle concurrency scenarios.
08/08/13   am      nRefCnt manipulation under lock.
07/26/13   am      Fix OmxDeInit implementation.
07/24/13   am      Serialize OMX core Api's for concurrency scenario. Also added
                   additional checks.
07/04/13   dp      Use std typedefs.
02/02/13   am      Return status code from FreeDevLib()
12/17/12   am      Serialize OMX_Init and OMX_DeInit
11/12/10   zm      Use MMOSAL malloc/free.
06/12/09   che     new omx core arch.

 ===========================================================================*/

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#define __OMX_EXPORTS
#include <stdlib.h>
#include "MMMalloc.h"
#include "qc_omx_core.h"
#include "qc_omx_core_defs.h"

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */
extern OMXILCCORE_TYPE omxcore;
extern OMX_ERRORTYPE FreeDevLib(OMX_HANDLETYPE pLibInfo);

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */
#define OMXILCORE_MALLOC(p)                     MM_Malloc((p))
#define OMXILCORE_FREEIF(p)                     { if((p)) MM_Free(p); \
                                                  (p) = NULL; }

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */
static OMX_U32 gNumComponents = 0;
OMXILCORE_COMPONENTINFOTYPE **gComponentList = 0;
static int nRefCnt = 0;

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
**                 FUNCTION DECLARATIONS
** ----------------------------------------------------------------------- */
int get_cmp_index(char *cmp_name);

/*========================================================================

                        FUNCTION DEFINITIONS

========================================================================== */

/* ======================================================================
FUNCTION
  get_cmp_index

DESCRIPTION
  Get component index.

PARAMETERS
  the unique component name

RETURN VALUE
  the index of the componet if found, -1 otherwise
========================================================================== */
int get_cmp_index(char *cmp_name)
{
   OMX_S32 i = -1;

   MM_MSG_PRIO2(MM_OMX_COMMON,MM_PRIO_MEDIUM, "get_cmp_index %s total components %d", cmp_name, gNumComponents);

   for ( i = 0; i < (OMX_S32)gNumComponents; i++ )
   {
      if ( !std_strncmp(cmp_name, (char *)gComponentList[i]->cName, std_strlen((char *)gComponentList[i]->cName)) )
      {
         return ( i );
      }
   }

   return ( -1 );
}

/* ======================================================================
FUNCTION
  OMX_Init

DESCRIPTION
  This is the first function called by the application.
  There is nothing to do here since components shall be loaded
  whenever the get handle method is called.

PARAMETERS
  None

RETURN VALUE
  None.
========================================================================== */
OMX_API OMX_ERRORTYPE OMX_APIENTRY
OMX_Init()
{
   OMX_ERRORTYPE ret = OMX_ErrorNone;

   omx_core_lock();

   MM_MSG_PRIO1(MM_STATS_SLOG, MM_PRIO_HIGH, "OMX_Init, nRefCnt = %d", nRefCnt);

   if ( 0 == nRefCnt )
   {
      MM_Debug_Initialize();

      MM_MSG_PRIO(MM_OMX_COMMON,MM_PRIO_MEDIUM, "OMXCORE API - OMX_Init");
      ret = OMXILCORE_Init(&omxcore);

      if ( OMX_ErrorNone == ret )
      {
         ret = OMXILCORE_UpdateTable(&omxcore);
      }

      gNumComponents = 0;
      gComponentList = NULL;
      if ( OMX_ErrorNone == ret )
      {
         OMXILCORE_ReadTable(&omxcore, &gNumComponents, (OMXILCORE_COMPONENTINFOTYPE**)&gComponentList);
      }
   }

   if ( OMX_ErrorNone == ret )
   {
      nRefCnt++;
      MM_MSG_PRIO1(MM_STATS_SLOG, MM_PRIO_HIGH, "OMX_Init inc nRefCnt = %d", nRefCnt);
   }
   omx_core_unlock();

   return ( ret );
}

/* ======================================================================
FUNCTION
  OMX_DeInit

DESCRIPTION
  DeInitialize all the the relevant OMX components.

PARAMETERS
  None

RETURN VALUE
  Error None.
========================================================================== */
OMX_API OMX_ERRORTYPE OMX_APIENTRY
OMX_Deinit()
{
   OMX_ERRORTYPE ret = OMX_ErrorNone;

   omx_core_lock();

   MM_MSG_PRIO1(MM_STATS_SLOG, MM_PRIO_HIGH, "OMX_DeInit, nRefCnt = %d", nRefCnt);

   if ( nRefCnt > 0 )
   {
      nRefCnt--;
      MM_MSG_PRIO1(MM_STATS_SLOG, MM_PRIO_HIGH, "OMX_DeInit dec nRefCnt = %d", nRefCnt);

      if ( 0 == nRefCnt )
      {
         MM_MSG_PRIO(MM_OMX_COMMON,MM_PRIO_MEDIUM, "OMXCORE API - OMX_DeInit");

         ret = OMXILCORE_DeInit(&omxcore);

         if ( OMX_ErrorNone == ret )
         {
            ret = OMXILCORE_ReleaseTable(&omxcore);
         }

         MM_Debug_Deinitialize();
      }
   }
   else
   {
      MM_MSG_PRIO(MM_OMX_COMMON, MM_PRIO_ERROR, "OMX_Deinit already deinitialized");
      ret = OMX_ErrorUndefined;
   }

   omx_core_unlock();

   return ret;
}

/* ======================================================================
FUNCTION
  OMX_GetHandle

DESCRIPTION
  Constructs requested component. Relevant library is loaded if needed.

PARAMETERS
  None

RETURN VALUE
  Error None  if everything goes fine.
========================================================================== */

OMX_API OMX_ERRORTYPE OMX_APIENTRY
OMX_GetHandle(OMX_OUT OMX_HANDLETYPE*  handle,
              OMX_IN OMX_STRING        aName,
              OMX_IN OMX_PTR           appData,
              OMX_IN OMX_CALLBACKTYPE* callBacks)
{
   OMX_ERRORTYPE  eRet = OMX_ErrorNone;
   OMX_COMPONENTINITTYPE aInitializer = NULL;

   MM_MSG_PRIO3(MM_STATS_SLOG, MM_PRIO_HIGH, "OMX_GetHandle 0x%p %s total components %d",  handle, aName, gNumComponents);
   MM_MSG_PRIO3(MM_OMX_COMMON, MM_PRIO_MEDIUM, "OMX_GetHandle 0x%p %s total components %d", handle, aName, gNumComponents);

   omx_core_lock();
   nRefCnt++;
   MM_MSG_PRIO1(MM_STATS_SLOG, MM_PRIO_HIGH, "OMX_GetHandle inc nRefCnt = %d", nRefCnt);
   omx_core_unlock();

   if ( handle )
   {
      int index = get_cmp_index(aName);

      if ( ( -1 == index ) || ( index >= (int)gNumComponents ) )
      {
         eRet = OMX_ErrorNotImplemented;
      }
      else
      {
         // allocate the component
         OMX_COMPONENTTYPE_EXT *aComponentExt= (OMX_COMPONENTTYPE_EXT *)OMXILCORE_MALLOC(sizeof(OMX_COMPONENTTYPE_EXT));

         if ( NULL == aComponentExt)
         {
            MM_MSG_PRIO(MM_OMX_COMMON, MM_PRIO_ERROR, "Out of memory");
            eRet = OMX_ErrorInsufficientResources;
         }
         else
         {
            OMX_COMPONENTTYPE *aComponent;
            OMXILCORE_MEMSET(aComponentExt, 0, sizeof(OMX_COMPONENTTYPE_EXT));
            aComponent = (OMX_COMPONENTTYPE *) &(aComponentExt->cmpnt);
            aComponent->nSize = sizeof(OMX_COMPONENTTYPE);
            aComponent->nVersion.nVersion = OMX_SPEC_VERSION;
            aComponent->pApplicationPrivate = appData;
            aInitializer = gComponentList[index]->pInitialize;
            MM_MSG_PRIO2(MM_OMX_COMMON,MM_PRIO_MEDIUM, "Components index %d, initializer 0x%p", index, aInitializer);

            // initialize the component, this is the time for the component dynamic library to be loaded if not loaded yet
            if ( aInitializer )
            {
               eRet = aInitializer(aComponent);
            }
            else
            {
               MM_MSG_PRIO(MM_OMX_COMMON,MM_PRIO_ERROR, "The component does not have an initializer");
               eRet = OMX_ErrorNotImplemented;
            }

            if ( OMX_ErrorNone == eRet )
            {
               eRet = aComponent->SetCallbacks(aComponent, callBacks, appData);

               if ( OMX_ErrorNone != eRet )
               {
                  MM_MSG_PRIO(MM_OMX_COMMON,MM_PRIO_ERROR, "Component failed to set callbacks, deinitializing");
                  aComponent->ComponentDeInit(aComponent);
				  if(NULL != aComponentExt->pLibInfo)
				  {
                     FreeDevLib((OMX_HANDLETYPE) aComponentExt->pLibInfo);
				  }
                  *handle = NULL;
                  OMXILCORE_FREEIF(aComponentExt);
               }
               else
               {
                  *handle = aComponent;
               }
            }
            else
            {
               MM_MSG_PRIO(MM_OMX_COMMON,MM_PRIO_ERROR, "Component initialize failure");
               *handle = NULL;
               OMXILCORE_FREEIF(aComponentExt);
            }
         }
      }
   }
   else
   {
      eRet = OMX_ErrorBadParameter;
      MM_MSG_PRIO(MM_OMX_COMMON,MM_PRIO_MEDIUM, "OMX_GetHandle: NULL handle");
   }

   if ( eRet != OMX_ErrorNone )
   {
      omx_core_lock();
      nRefCnt--;
      MM_MSG_PRIO2(MM_STATS_SLOG, MM_PRIO_HIGH, "Error 0x%x OMX_GetHandle dec nRefCnt = %d", eRet, nRefCnt);
      omx_core_unlock();
   }

   return ( eRet );
}

/* ======================================================================
FUNCTION
  OMX_FreeHandle

DESCRIPTION
  Destructs the component handles.

PARAMETERS
  None

RETURN VALUE
  Error None.
========================================================================== */
OMX_API OMX_ERRORTYPE OMX_APIENTRY
OMX_FreeHandle(OMX_IN OMX_HANDLETYPE hComp)
{
   OMX_ERRORTYPE eRet = OMX_ErrorNone;
   OMX_COMPONENTTYPE * aComponent = (OMX_COMPONENTTYPE * )hComp;

   MM_MSG_PRIO1(MM_STATS_SLOG, MM_PRIO_HIGH, "OMX_FreeHandle = 0x%p", hComp);

   if ( NULL == hComp )
   {
      return OMX_ErrorBadParameter;
   }
   MM_MSG_PRIO1(MM_OMX_COMMON, MM_PRIO_MEDIUM, "OMXCORE API : Free Handle 0x%p",  hComp);

   eRet = aComponent->ComponentDeInit(hComp);
   if ( eRet != OMX_ErrorNone )
   {
      MM_MSG_PRIO(MM_OMX_COMMON,MM_PRIO_ERROR, "OMXCORE API : Free Handle failed");
   }
   else
   {
      OMX_COMPONENTTYPE_EXT *hCompExt = (OMX_COMPONENTTYPE_EXT *)hComp;
	  if(NULL != hCompExt->pLibInfo)
	  {
         eRet = FreeDevLib((OMX_HANDLETYPE)hCompExt->pLibInfo);
	  }

      omx_core_lock();
      if ( nRefCnt > 1 )
      {
         nRefCnt--;
         MM_MSG_PRIO2(MM_STATS_SLOG, MM_PRIO_HIGH, "OMX_FreeHandle 0x%p completed. nRefCnt = %d", hComp, nRefCnt);
      }
      else
      {
         MM_MSG_PRIO2(MM_OMX_COMMON, MM_PRIO_ERROR, "OMXCORE API : FreeHandle 0x%p error nRefCnt = %d", hComp, nRefCnt);
      }
      omx_core_unlock();

      OMXILCORE_FREEIF(hComp);
   }

   return ( eRet );
}

/* ======================================================================
FUNCTION
  OMX_SetupTunnel

DESCRIPTION
  Not Implemented.

PARAMETERS
  None

RETURN VALUE
  None.
========================================================================== */
OMX_API OMX_ERRORTYPE OMX_APIENTRY
OMX_SetupTunnel(OMX_IN OMX_HANDLETYPE aOutputComp,
                OMX_IN OMX_U32        aOutputPort,
                OMX_IN OMX_HANDLETYPE aInputComp,
                OMX_IN OMX_U32        aInputPort)
{
   OMX_ERRORTYPE result;
   OMX_COMPONENTTYPE* aComp;
   OMX_TUNNELSETUPTYPE tunnelSetup;

   MM_MSG_PRIO(MM_OMX_COMMON,MM_PRIO_MEDIUM, "OMXCORE API: OMX_SetupTunnel called");

   OMXILCORE_MEMSET(&tunnelSetup, 0, sizeof(OMX_TUNNELSETUPTYPE));
   tunnelSetup.nTunnelFlags = 0;
   tunnelSetup.eSupplier = OMX_BufferSupplyUnspecified;

   if ( ( NULL == aOutputComp ) && ( NULL == aInputComp ) )
   {
      return ( OMX_ErrorBadParameter );
   }

   aComp = (OMX_COMPONENTTYPE*)aOutputComp;
   if ( aComp )
   {
       result = (aComp->ComponentTunnelRequest)(aOutputComp, aOutputPort, aInputComp, aInputPort, &tunnelSetup);

       if ( result != OMX_ErrorNone )
       {
          MM_MSG_PRIO1(MM_OMX_COMMON,MM_PRIO_MEDIUM, "SetupTunnel rejected by output port (Error: %08x)", result);

          return ( result );
       }
   }

   MM_MSG_PRIO(MM_OMX_COMMON,MM_PRIO_MEDIUM, "SetupTunnel accepted by output port");

   aComp = (OMX_COMPONENTTYPE*)aInputComp;
   if ( aComp )
   {
      result = (aComp->ComponentTunnelRequest)(aInputComp, aInputPort, aOutputComp, aOutputPort, &tunnelSetup);

      if ( ( result != OMX_ErrorNone ) && ( aOutputComp ) )
      {
         MM_MSG_PRIO1(MM_OMX_COMMON,MM_PRIO_ERROR, "SetupTunnel rejected by input port (error: %08x)", result);
         aComp = (OMX_COMPONENTTYPE*)aOutputComp;
         (void)(aComp->ComponentTunnelRequest)(aOutputComp, aOutputPort, NULL, 0, &tunnelSetup);

         return ( OMX_ErrorPortsNotCompatible );
      }
   }
   MM_MSG_PRIO2(MM_OMX_COMMON,MM_PRIO_MEDIUM, "Setup Tunnel accepted by the input component, supplier: %d, flags: %u",
      tunnelSetup.eSupplier, tunnelSetup.nTunnelFlags);

   return ( OMX_ErrorNone );
}

/* ======================================================================
FUNCTION
  OMX_GetContentPipe

DESCRIPTION
  Not Implemented.

PARAMETERS
  None

RETURN VALUE
  None.
========================================================================== */
OMX_API OMX_ERRORTYPE
OMX_GetContentPipe(OMX_OUT OMX_HANDLETYPE* pipe,
                   OMX_IN OMX_STRING        uri)
{
   /* Not supported right now */
   MM_MSG_PRIO(MM_OMX_COMMON,MM_PRIO_MEDIUM,"OMXCORE API: OMX_GetContentPipe Not implemented");

   return ( OMX_ErrorNotImplemented );
}

/* ======================================================================
FUNCTION
  OMX_GetComponentNameEnum

DESCRIPTION
  Returns the component name associated with the index.

PARAMETERS
  None

RETURN VALUE
  None.
========================================================================== */
OMX_API OMX_ERRORTYPE OMX_APIENTRY
OMX_ComponentNameEnum(OMX_OUT OMX_STRING  aName,
                      OMX_IN  OMX_U32     nameLen,
                      OMX_IN  OMX_U32     index)
{
   OMX_ERRORTYPE eRet = OMX_ErrorNone;
   OMX_U32 count = 0;

   MM_MSG_PRIO3(MM_OMX_COMMON, MM_PRIO_MEDIUM, "OMXCORE API - OMX_ComponentNameEnum 0x%s %d %d", aName, nameLen, index);

   if ( 0 == gNumComponents )
   {
      // not inited yet
      return ( OMX_ErrorInvalidState );
   }
   else if ( index >= gNumComponents )
   {
      return ( OMX_ErrorNoMore );
   }
   if ( NULL == aName )
   {
      return ( OMX_ErrorBadParameter );
   }

   count = nameLen > OMX_MAX_STRINGNAME_SIZE ? OMX_MAX_STRINGNAME_SIZE : nameLen;
   OMXILCORE_MEMCPY(aName, gComponentList[index]->cName, count);

   return ( eRet );
}

/* ======================================================================
FUNCTION
  OMX_GetComponentsOfRole

DESCRIPTION
  Returns the component name which can fulfill the roles passed in the
  argument.

PARAMETERS
  None

RETURN VALUE
  None.
========================================================================== */
OMX_API OMX_ERRORTYPE
OMX_GetComponentsOfRole(OMX_IN OMX_STRING    role,
                        OMX_INOUT OMX_U32*   numComps,
                        OMX_INOUT OMX_U8**   compNames)
{
   OMX_U32 i;
   OMX_U32 j;

   if ( gNumComponents == 0 )
   {
      // not inited yet
      return ( OMX_ErrorInvalidState );
   }

   if ( NULL == numComps )
   {
      return ( OMX_ErrorBadParameter );
   }

   *numComps = 0;
   for ( i = 0; i < gNumComponents; i++ )
   {
      for ( j = 0; j < gComponentList[i]->nNumRoles; j++ )
      {
         if ( 0 == std_strncmp(role, (char*)gComponentList[i]->ppRoles[j], std_strlen((char*)gComponentList[i]->ppRoles[j])) )
         {
            if ( compNames )
            {
               OMXILCORE_MEMCPY(compNames[*numComps], gComponentList[i]->cName, std_strlen((char *)gComponentList[i]->cName) + 1);
            }
            *numComps = *numComps + 1;
            break;
         }
      }
   }
   return ( OMX_ErrorNone );
}

/* ======================================================================
FUNCTION
  OMX_GetRolesOfComponent

DESCRIPTION
  Returns the primary role of the components supported.

PARAMETERS
  None

RETURN VALUE
  None.
========================================================================== */
OMX_API OMX_ERRORTYPE
OMX_GetRolesOfComponent(OMX_IN OMX_STRING compName,
                        OMX_INOUT OMX_U32* numRoles,
                        OMX_OUT OMX_U8** roles)
{
   int index = -1;
   OMX_U32 count = 0;

   if ( 0 == gNumComponents )
   {
      // not inited yet
      return ( OMX_ErrorInvalidState );
   }

   if ( ( NULL == numRoles ) || ( NULL == compName ) )
   {
      return ( OMX_ErrorBadParameter );
   }

   index = get_cmp_index(compName);
   if ( -1 == index )
   {
      return ( OMX_ErrorInvalidComponentName );
   }

   if ( NULL == roles )
   {
      *numRoles = gComponentList[index]->nNumRoles;

      return ( OMX_ErrorNone );
   }

   *numRoles = *numRoles > gComponentList[index]->nNumRoles ? gComponentList[index]->nNumRoles : *numRoles;
   while ( count < *numRoles )
   {
      int len = std_strlen((char *)gComponentList[index]->ppRoles[count]) + 1;
      OMXILCORE_MEMCPY(roles[count], gComponentList[index]->ppRoles[count], len);
      count++;
   }

   return ( OMX_ErrorNone );
}
