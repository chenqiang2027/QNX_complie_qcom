/*============================================================================
                            O p e n M A X   w r a p p e r s
                             O p e n  M A X   C o r e

*//** @file qc_omx_core.h
  This module contains the definitions of the OpenMAX core.

Copyright (c) 2006-2013 QUALCOMM Technologies, Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*============================================================================
                              Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/core/src/qc_omx_core_defs.h#1 $
when       who     what, where, why
--------   ---     -------------------------------------------------------
07/04/13   dp      Use std typedefs.
06/17/09   che     New il core arch
06/30/08   ssk     Created file.

============================================================================*/

#ifndef QC_OMX_CORE_DEFS_H
#define QC_OMX_CORE_DEFS_H

#include "qc_omx_common.h"        // OMX API
#include "AEEstd.h" /* std typedefs, ie. byte, uint16, uint32, etc. and memcpy, memset */
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct OMX_COMPONENTTYPE_EXT
{
   OMX_COMPONENTTYPE cmpnt;
   void* pLibInfo;
} OMX_COMPONENTTYPE_EXT;

#ifdef __cplusplus
}
#endif

#endif /* QC_OMX_CORE_DEFS_H */
