#ifndef __H_QOMX_IVCOMMONEXTENSIONS_H__
#define __H_QOMX_IVCOMMONEXTENSIONS_H__ 

/*========================================================================
    Copyright (c) 2009-2018, 2020-2021 Qualcomm Technologies, Incorporated.
    All Rights Reserved.
    Qualcomm Confidential and Proprietary.
=========================================================================*/

/**
  @file QOMX_IVCommonExtensions.h 

     Qualcomm common extensions API for OpenMax IL.

      This file contains the description of the Qualcomm OpenMax IL
      common extention interface, through which the IL client and OpenMax 
      components can access additional capabilities.
*/

/*========================================================================
NOTE: For the output PDF generated using Doxygen and Latex, all file and 
      group descriptions are maintained in the QOMX_Video_Ext_mainpage file. To 
      change any of the the file/group text for the PDF, edit the 
      QOMX_Video_Ext_mainpage file, or contact Tech Pubs.

      The above description for this file is part of the "common_extensions" 
      group description in the QOMX_Video_Ext_mainpage file. 
=========================================================================*/

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/core/public/amss/multimedia/openmax/QOMX_IVCommonExtensions.h#1 $

when       who  what, where, why
--------  ---   ----------------------------------------------------------
29/03/21  yc    Add RGBA8888 color format
03/03/20  jz    Add UYVY10 and P010 color format
06/08/18  am    Add RGBA8888 compressed color format
11/07/17  rz    Add 10 bit compressed color format
02/03/11  sw    (Tech Pubs) Edited/added Doxygen comments and markup.
========================================================================== */
 
/*======================================================================== 
 
                     INCLUDE FILES FOR MODULE 
 
========================================================================== */ 
#include <OMX_Core.h>

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */

/** @cond
*/
#define OMX_QCOM_INDEX_CONFIG_MEDIAINFO                 "OMX.QCOM.index.config.mediainfo"
        /**< Refers to the following IV common extension string:
             "OMX.QCOM.index.config.mediainfo".
             
             Associated structure: QOMX_MEDIAINFOTYPE. */

#define OMX_QCOM_INDEX_CONFIG_CONTENTURI                "OMX.QCOM.index.config.contenturi"
        /**< Refers to the following IV common extension string:
             "OMX.QCOM.index.config.contenturi". 
             
             Associated structure: OMX_PARAM_CONTENTURITYPE. */

#define OMX_QCOM_INDEX_PARAM_IMAGESIZECONTROL           "OMX.Qualcomm.index.param.ImageSizeControl"
        /**< Refers to the following IV common extension string:
             "OMX.Qualcomm.index.param.ImageSizeControl". 
             
             Associated structure: QOMX_IMAGE_IMAGESIZECONTROLTYPE. */

#define OMX_QCOM_INDEX_CONFIG_PAUSEPORT                 "OMX.QCOM.index.config.PausePort"
        /**< Refers to the following IV common extension string:
             "OMX.QCOM.index.config.PausePort". 
             
             Associated structure: QOMX_CONFIG_PAUSEPORTTYPE. */
/** @endcond */


/**@addtogroup common_extensions
@{ */
#define OMX_QCOM_INDEX_PARAM_FRAMEWIDTHRANGESUPPORTED   "OMX.QCOM.index.param.FrameWidthRangeSupported" 
        /**< IV common extension string. nMin, nMax, and nStepSize provide the 
             width in pixels. 
             
             Associated structure: QOMX_URANGETYPE. */

#define OMX_QCOM_INDEX_PARAM_FRAMEHEIGHTRANGESUPPORTED  "OMX.QCOM.index.param.FrameHeightRangeSupported" 
        /**< IV common extension string. nMin, nMax, and nStepSize provide the 
             height in pixels.

             Associated structure: QOMX_URANGETYPE. */

#define OMX_QCOM_INDEX_PARAM_MACROBLOCKSPERFRAMERANGESUPPORTED "OMX.QCOM.index.param.MacroblocksPerFrameRangeSupported" 
        /**< IV common extension string. nMin, nMax, and nStepSize provide the 
             number of macroblocks per frame. 
             
             Associated structure: QOMX_URANGETYPE. */

#define OMX_QCOM_INDEX_PARAM_MACROBLOCKSPERSECONDRANGESUPPORTED "OMX.QCOM.index.param.MacroblocksPerSecondRangeSupported" 
        /**< IV common extension string. nMin, nMax, and nStepSize provide the 
             number of macroblocks per second. 
             
             Associated structure: QOMX_URANGETYPE. */

#define OMX_QCOM_INDEX_PARAM_FRAMERATERANGESUPPORTED    "OMX.QCOM.index.param.FrameRateRangeSupported" 
        /**< IV common extension string. nMin, nMax, amd nStepSize provide the 
             frame rate in frames per second in Q16 format. 
             
             Associated structure: QOMX_URANGETYPE. */
/**@} */ /* end_addtogroup common_extensions */


/** @addtogroup video_index_extra_data
@{ */
#define OMX_QCOM_INDEX_PARAM_PLANEDEFINITION            "OMX.QCOM.index.param.PlaneDefinition"
        /**< IV common extension string.
             
             Associated structure: QOMX_PLANEDEFINITIONTYPE. */
/** @} */ /* end_addtogroup video_index_extra_data */


/** @cond
*/
#define OMX_QOMX_INDEX_PARAM_CROPWIDTHRANGESUPPORTED        "OMX.QCOM.index.param.CropWidthRangeSupported"
        /**< IV common extension string. nMin, nMax, and nStepSize provide the 
             crop width in pixels.

             Associated structure: QOMX_URANGETYPE. */

#define OMX_QOMX_INDEX_PARAM_CROPHEIGHTRANGESUPPORTED        "OMX.QCOM.index.param.CropHeightRangeSupported"
        /**< IV common extension string. nMin, nMax, and nStepSize provide the 
             crop height in pixels.

             Associated structure: QOMX_URANGETYPE. */

#define OMX_QCOM_INDEX_PARAM_DIGITALZOOMWIDTHRANGESUPPORTED    "OMX.QCOM.index.param.DigitalZoomWidthRangeSupported"
        /**< IV common extension string.  Min, nMax, and nStepSize provide the 
             digital zoom factor on width in Q16 format.

             Associated structure: QOMX_URANGETYPE. */

#define OMX_QCOM_INDEX_PARAM_DIGITALZOOMHEIGHTRANGESUPPORTED    "OMX.QCOM.index.param.DigitalZoomHeightRangeSupported"
        /**< IV common extension string. nMin, nMax, and nStepSize provide the 
             digital zoom factor on height in Q16 format.
             
             Associated structure: QOMX_URANGETYPE. */
/** @endcond */

/** @cond
*/
/** Defines the extended uncompressed image/video formats.
*/
typedef enum QOMX_COLOR_FORMATTYPE
{
    QOMX_COLOR_FormatYVU420PackedSemiPlanar       = 0x7F000001,
         /**< Buffer containing all Y, and then V and U interleaved. */
    QOMX_COLOR_FormatYVU420PackedSemiPlanar32m4ka,
         /**< YUV planar format, similar to the YVU420PackedSemiPlanar format 
              but with the following restrictions:\n
              - The width and height of both planes must be a multiple of 32 
                texels.
              - The base address of both planes must be aligned to a 4 kB 
                boundary. */
    QOMX_COLOR_FormatYUV420PackedSemiPlanar16m2ka,
         /**< YUV planar format, similar to the YUV420PackedSemiPlanar format 
              but with the following restrictions:\n
              - The width and height of the both planes must be a multiple of 16 
                pixels.
              - The address of both planes must be aligned to a 2 kB boundary.*/
    QOMX_COLOR_FormatYUV420PackedSemiPlanar64x32Tile2m8ka,
         /**< YUV planar format, similar to the YUV420PackedSemiPlanar format 
              but with the following restrictions:\n
              - The data is laid out in a 4x2 MB tiling memory structure.
              - The width of each plane is a multiple of two 4x2 MB tiles.
              - The height of each plan is a multiple of one 4x2 MB tile.
              - The base address of both planes must be aligned to an 8 kB boundary.
              - The tiles are scanned in the order defined in the video
                hardware documentation. */
    QOMX_COLOR_FormatYUV420PackedSemiPlanar32m4ka,
         /**< YUV planar format, similar to the YUV420PackedSemiPlanar format 
              but with the following restrictions:\n
              - The width and height of both planes must be a multiple of 32 
                texels.
              - The base address of both planes must be aligned to a 4 kB 
                boundary. */
    QOMX_COLOR_FormatYUV420PackedSemiPlanarCompressed,
         /**< YUV planar format, similar to the YUV420PackedSemiPlanar format with 
              bit depth of 10 bits and in vendor proprietary compressed format that only vendor h/w
              IP can decode to uncompressed format for usage.*/
    QOMX_COLOR_FormatYUV420PackedSemiPlanar10bitCompressed,
         /**< RGBA8888 format, Red 31:24, Green 23:16, Blue 15:8, Alpha 7:0 */
    QOMX_COLOR_Format32bitRGBA8888,
         /**< RGBA compressed format in vendor proprietary compressed format that only vendor h/w
              IP can decode to uncompressed format for usage.*/
    QOMX_COLOR_Format32bitRGBA8888Compressed,
         /**< UYVY format with depth of 10 bits.*/
    QOMX_COLOR_FormatCbYCrY10Bit,
         /**< YUV420 P010 format .*/
    QOMX_COLOR_FormatYUV420P010
} QOMX_COLOR_FORMATTYPE;

/** Defines the types of media information.
*/
typedef enum QOMX_MEDIAINFOTAGTYPE {
    QOMX_MediaInfoTagVersion,       /**< OMX_VERSIONTYPE. Version of the standard 
                                         specifying the media information. */
    QOMX_MediaInfoTagUID,           /**< OMX_U8*. Unique ID of the media data, 
                                         i.e., image unique ID. */
    QOMX_MediaInfoTagDescription,   /**< OMX_U8*. Comments about the media. */
    QOMX_MediaInfoTagTitle,         /**< OMX_U8*. Title of the media. */
    QOMX_MediaInfoTagAuthor,        /**< OMX_U8*. Author of the media. */
    QOMX_MediaInfoTagCopyright,     /**< OMX_U8*. Copyright information. */
    QOMX_MediaInfoTagTrackNum,      /**< OMX_U32. Track number. */
    QOMX_MediaInfoTagGenre,         /**< OMX_U8*. Genre of the media. */
    QOMX_MediaInfoTagEquipmentMake, /**< OMX_U8*. Manufacturer of the recording 
                                         equipment. */
    QOMX_MediaInfoTagEquipmentModel,/**< OMX_U8*. Model or name of the recording 
                                         equipment. */
    QOMX_MediaInfoTagSoftware,      /**< OMX_U8*. Name and version of the software 
                                         or firmware of the device generating the 
                                         media. */
    QOMX_MediaInfoTagAssociatedFile,/**< OMX_U8*. Name of the file related to the 
                                         media. For example, an audio file related 
                                         to an image file. */
    QOMX_MediaInfoTagResolution,    /**< QOMX_RESOLUTIONTYPE. Number of pixels per 
                                         resolution unit. */
    QOMX_MediaInfoTagDateCreated,   /**< QOMX_DATESTAMPTYPE. Date when the media 
                                         was created. */
    QOMX_MediaInfoTagTimeCreated,   /**< QOMX_TIMESTAMPTYPE. Time when the media 
                                         was created. */
    QOMX_MediaInfoTagDateModified,  /**< QOMX_DATESTAMPETYPE. Date when the file 
                                         was last modified. */
    QOMX_MediaInfoTagTimeModified,  /**< QOMX_TIMESTAMPTYPE. Time when the file 
                                         was last modified. */
    QOMX_MediaInfoTagGPSAreaName,   /**< OMX_U8*. Name of the location. */
    QOMX_MediaInfoTagGPSVersion,    /**< OMX_VERSIONTYPE. GPS version. */
    QOMX_MediaInfoTagGPSCoordinates,/**< QOMX_GEODETICTYPE. Lngitude, latitude, 
                                         and altitude. */
    QOMX_MediaInfoTagGPSSatellites, /**< OMX_U8*. GPS satellites used for 
                                         measurements. */
    QOMX_MediaInfoTagGPSPrecision,  /**< OMX_U32. GPS degree of precision. */
    QOMX_MediaInfoTagGPSDateStamp,  /**< QOMX_DATESTAMPTYPE. Date of the GPS data. */
    QOMX_MediaInfoTagGPSTimeStamp,  /**< QOMX_TIMESTAMPTYPE. Time of the GPS data. */
    QOMX_MediaInfoTagMediaStreamType,/**< QOMX_MEDIASTREAMTYPE. Type of the stream. */ 
    QOMX_MediaInfoDuration,         /**< OMX_TICKS. Total duration of the media. */
    QOMX_MediaInfoSize,             /**< OMX_U32. Total size of the media in bytes. */ 
    QOMX_MediaInfoTagAlbum,         /**< OMX_U8*. Name of the album/movie/show. */ 
    QOMX_MediaInfoTagLocation,      /**< OMX_U8*. Recording location information. */ 
    QOMX_MediaInfoTagClassification,/**< OMX_U8*. Classification information of 
                                         the media. */ 
    QOMX_MediaInfoTagRatings,       /**< OMX_U8*. Media ratings based on popularity 
                                         and rating criteria. */ 
    QOMX_MediaInfoTagKeyword,       /**< OMX_U8*. Keyword associated with the media. 
                                         This keyword is to reflect mood of the A/V. */ 
    QOMX_MediaInfoTagPerformance,   /**< OMX_U8*. Media performer information. */ 
    QOMX_MediaInfoTagYear,          /**< OMX_U8*. Production year information of 
                                         the media. */ 
    QOMX_MediaInfoTagComposer,      /**< OMX_U8*. Name of the composer of the media, 
                                         i.e., audio. */ 
    QOMX_MediaInfoTagEncoderName,   /**< OMX_U8*. Name of the person or organization 
                                         who encoded the media. */ 
    QOMX_MediaInfoTagCopyProhibitFlag,/**< OMX_U8*. Flag that indicates whether the 
                                           media can be copied. */ 
    QOMX_MediaInfoTagLyricist,      /**< OMX_U8*. Name of the lyricist or text 
                                         writer in recording. Specific to the 
                                         ID3 tag. */ 
    QOMX_MediaInfoTagSubtitle,      /**< OMX_U8*. Subtitle/Description used for 
                                         information directly related to the title 
                                         of the media. */ 
    QOMX_MediaInfoTagOriginalFileName,/**< OMX_U8*. Original filename. */ 
    QOMX_MediaInfoTagOriginalLyricist,/**< OMX_U8*. Name of the original lyricist/text 
                                           writer of the original recording. */ 
    QOMX_MediaInfoTagOriginalArtist,  /**< OMX_U8*. Name of the original artist. */ 
    QOMX_MediaInfoTagOriginalReleaseYear,/**< OMX_U8*. Original release year of 
                                              the recorded media. */ 
    QOMX_MediaInfoTagFileOwner,     /**< OMX_U8*. Licensee or name of the file owner. */ 
    QOMX_MediaInfoTagOrchestra,     /**< OMX_U8*. Name of the orchestra or performers 
                                         who performed the recording. */ 
    QOMX_MediaInfoTagConductor,     /**< OMX_U8*. Name of the conductor. */ 
    QOMX_MediaInfoTagRemixedBy,     /**< OMX_U8*. Name of the person or organization 
                                         who did the remix. */ 
    QOMX_MediaInfoTagAlbumArtist,   /**< OMX_U8*. Name of the album artist. */ 
    QOMX_MediaInfoTagPublisher,     /**< OMX_U8*. Name of the publisher or label. */ 
    QOMX_MediaInfoTagRecordingDates,/**< OMX_U8*. Recording date of the media. */ 
    QOMX_MediaInfoTagInternetRadioStationName,/**< OMX_U8*. Name of the Internet 
                                                   radio station from which the 
                                                   audio is streamed. */ 
    QOMX_MediaInfoTagInternetRadioStationOwner,/**< OMX_U8*. Name of the owner of 
                                                    the Internet radio station from 
                                                    which the audio is streamed. */ 
    QOMX_MediaInfoTagInternationalRecordingCode,/**< OMX_U8*. International standard 
                                                     recording code. */ 
    QOMX_MediaInfoTagEncoderSwHwSettings, /**< OMX_U8*. Software/hardware settings 
                                               used by the encoder. */ 
    QOMX_MediaInfoTagInvolvedPeopleList,  /**< OMX_U8*. List of people involved. 
                                               Specific to the ID3 tag. */ 
    QOMX_MediaInfoTagComments,      /**< OMX_U8*. Comments about the media. This 
                                         can be any kind of full text informaton. */ 
    QOMX_MediaInfoTagCommissioned,  /**< OMX_U8*. Commissioned information of 
                                         the media. */ 
    QOMX_MediaInfoTagSubject,       /**< OMX_U8*. Subject associated with the media. */ 
    QOMX_MediaInfoTagContact,       /**< OMX_U8*. Conatct information; the URL 
                                         information of the seller. */ 
    QOMX_MediaInfoTagValidityPeriod,/**< OMX_U8*. Length or period of validity of 
                                         the media. */ 
    QOMX_MediaInfoTagValidityEffectiveDate, /**< OMX_U8*. Validity effective date 
                                                 of the media*/ 
    QOMX_MediaInfoTagNumberOfAllowedPlaybacks, /**< OMX_U8*. Number of allowed 
                                                    playbacks for the media. */ 
    QOMX_MediaInfoTagPlayCounter, /**< OMX_U8*. Current play counter of the media. 
                                       The number of times a file has been played. */ 
    QOMX_MediaInfoTagMemo,        /**< OMX_U8*. Memo associatd with the media. */ 
    QOMX_MediaInfoTagDeviceName,  /**< OMX_U8*. Name of the devices used in 
                                       creating the media. */ 
    QOMX_MediaInfoTagURL,         /**< OMX_U8*. List of the URLs of the 
                                       artist/genre/movie sites. */ 
    QOMX_MediaInfoTagFileType,    /**< OMX_U8*. Indicates the type of audio track. */ 
    QOMX_MediaInfoTagContentGroupDesc,/**< OMX_U8*. Content group description if 
                                           the sound belongs to a larger category 
                                           of of music/sound. */ 
    QOMX_MediaInfoTagInitialKeys, /**< OMX_U8*. Contains the musical key in which 
                                       the media starts. */ 
    QOMX_MediaInfoTagLanguages,   /**< OMX_U8*. Languages of the text or lyrics 
                                       spoken or sung in the media. */ 
    QOMX_MediaInfoTagMediaType,   /**< OMX_U8*. Describes from which media the 
                                       media sound originated. */ 
    QOMX_MediaInfoTagPlaylistDelay, /**< OMX_U8*. Denotes the number of milliseconds 
                                         between each song of the playlist. */ 
    QOMX_MediaInfoTagBeatsPerMinute,/**< OMX_U8*. Number of beats per minute in the
                                         main part of the audio. */ 
    QOMX_MediaInfoTagPartOfSet,     /**< OMX_U8*. Describes the part of the set 
                                         selected or played. */ 
    QOMX_MediaInfoTagInstrumentName,/**< OMX_U8*. Name of the instrument used in 
                                         creating the media. */ 
    QOMX_MediaInfoTagLyrics,    /**< OMX_U8*. Lyrics of the media/audio track. */ 
    QOMX_MediaInfoTagTrackName, /**< OMX_U8*. Name of the media/audio track. */ 
    QOMX_MediaInfoTagMarker,    /**< OMX_U8*. Text string cotnents placed at a 
                                     specific location to denote information about 
                                     the music at that point. */ 
    QOMX_MediaInfoTagCuePoint,  /**< OMX_U8*. Subset of the content that can be 
                                     optionally played. */ 
    QOMX_MediaInfoTagGPSPositioningName,  /**< OMX_U8*. GPS positioning name. */ 
    QOMX_MediaInfoTagGPSPositioningMethod,/**< OMX_U8*. GPS positioning method. */ 
    QOMX_MediaInfoTagGPSSurveyData,       /**< OMX_U8*. GPS survey data. */ 
    QOMX_MediaInfoTagGPSByteOrder,        /**< OMX_U16. GPS byte order. */ 
    QOMX_MediaInfoTagGPSLatitudeRef,      /**< OMX_U32. References the GPS latitude. */ 
    QOMX_MediaInfoTagGPSLongitudeRef,     /**< OMX_U32. References the GPS longitude */ 
    QOMX_MediaInfoTagGPSAltitudeRef,      /**< OMX_U32. References the GPS altitude. */ 
    QOMX_MediaInfoTagGPSExtensionMapScaleInfo,/**< OMX_U64. GPS extension map scale 
                                                   information. */ 
    QOMX_MediaInfoTagUUIDAtomInfo,     /**< OMX_U8*. User-defined data associated 
                                            with the UUID. */ 
    QOMX_MediaInfoTagUUIDAtomCount,    /**< OMX_U32 UUID atom count. */ 
    QOMX_MediaInfoTagLocationRole,     /**< OMX_32. Indicates the role of the place, 
                                            i.e., 0 indicate the shooting location, 
                                            and 1 indicates the real location. */ 
    QOMX_MediaInfoTagAstronomicalBody, /**< OMX_U8*. Astronomical body on which the 
                                            location exists. */ 
    QOMX_MediaInfoTagUserInfoData      /**< OMX_U8*. The user-defined tag informaton. */ 
} QOMX_MEDIAINFOTAGTYPE;

typedef struct QOMX_MEDIAINFOTYPE {
    OMX_U32 nSize;              /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion;   /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;         /**< Index of the port to which this structure applies. */
    QOMX_MEDIAINFOTAGTYPE eTag; /**< Type of media information being specified. */
    OMX_U32 nDataSize;          /**< Size of the associated cData. Set nDataSize to 0 
                                     to retrieve the size required for cData. */
    OMX_U8 cData[1];            /**< Media data information. */
} QOMX_MEDIAINFOTYPE;

typedef enum QOMX_RESOLUTIONUNITTYPE {
    QOMX_ResolutionUnitInch,
    QOMX_ResolutionCentimeter
} QOMX_RESOLUTIONUNITTYPE;

typedef struct QOMX_RESOLUTIONTYPE {
    QOMX_RESOLUTIONUNITTYPE eUnit; /**< Unit of measure. */
    OMX_U32 nX;                    /**< Number of pixels per unit in the width 
                                        direction. */
    OMX_U32 nY;                    /**< Number of pixels per unit in the height 
                                        direction. */
} QOMX_RESOLUTIONTYPE;

typedef struct QOMX_TIMESTAMPTYPE {
    OMX_U32 nHour;           /**< Hour portion of the timestamp, based on a 
                                  24-hour format. */
    OMX_U32 nMinute;         /**< Minute portion of the timestamp. */
    OMX_U32 nSecond;         /**< Second portion of the timestamp. */
    OMX_U32 nMillisecond;    /**< Millisecond portion of the timestamp. */
} QOMX_TIMESTAMPTYPE;

typedef struct QOMX_DATESTAMPTYPE {
    OMX_U32 nYear;   /**< Year portion of the date stamp. */
    OMX_U32 nMonth;  /**< Month portion of the date stamp. Valid values are 
                          1 to 12.*/
    OMX_U32 nDay;    /**< Day portion of the date stamp. Valid values are 1 to 31, 
                          depending on the month specified.*/
} QOMX_DATESTAMPTYPE;

typedef enum QOMX_GEODETICREFTYPE {
    QOMX_GeodeticRefNorth,  /**< North latitude. */
    QOMX_GeodeticRefSouth,  /**< South latitude. */
    QOMX_GeodeticRefEast,   /**< East longitude. */
    QOMX_GeodeticRefWest    /**< West longitude. */
} QOMX_GEODETICREFTYPE;

/** Used to set geodetic angle coordinates on an ellipsoid (the Earth). It is 
    explicitly used to specify latitude and longitude. This structure is 
    referenced by QOMX_GEODETICTYPE.
*/
typedef struct QOMX_GEODETICANGLETYPE {
    QOMX_GEODETICREFTYPE eReference; /**< Indicates whether the geodetic angle 
                                          is a latitude or longitude. */
    OMX_U32 nDegree;                 /**< Degree of the latitude or longitude. */
    OMX_U32 nMinute;                 /**< Minute of the latitude or longitude. */
    OMX_U32 nSecond;                 /**< Second of the latitude or longitude. */
} QOMX_GEODETICANGLETYPE;

typedef enum QOMX_ALTITUDEREFTYPE {
    QOMX_AltitudeRefSeaLevel,       /**< At sea level. */
    QOMX_AltitudeRefBelowSeaLevel   /**< Below sea level. */
} QOMX_ALTITUDEREFTYPE;

typedef struct QOMX_ALTITUDETYPE {
    QOMX_ALTITUDEREFTYPE eReference; /**< Reference point for the altitude. */
    OMX_U32 nMeter;                  /**< Absolute value of the number of 
                                          meters above or below sea level. */
    OMX_U32 nMillimeter;             /**< Absolute value of the number of 
                                          millimeters above or below sea level. */
} QOMX_ALTITUDETYPE;

/** Used to set geodetic coordinates such as longitude, latitude, and altitude.
    This structure references QOMX_GEODETICANGLETYPE and QOMX_ALTITUDETYPE. */
typedef struct QOMX_GEODETICTYPE {
    QOMX_GEODETICANGLETYPE sLatitude;   /**< Indicates the latitude.*/
    QOMX_GEODETICANGLETYPE sLongitude;  /**< Indicates the longitude.*/
    QOMX_ALTITUDETYPE sAltitude;        /**< Indicates the altitude.*/
} QOMX_GEODETICTYPE;

typedef struct QOMX_IMAGE_IMAGESIZECONTROLTYPE {
    OMX_U32 nSize;             /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion;  /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;        /**< Index of the port to which this structure applies. */
    OMX_U32 nTargetImageSize;  /**< Expected maximum target size in bytes. */
} QOMX_IMAGE_IMAGESIZECONTROLTYPE;

typedef enum QOMX_URITYPE {
    QOMX_URITYPE_RTSP,   /**< RTSP URI type. */ 
    QOMX_URITYPE_HTTP,   /**< HTTP URI type. */
    QOMX_URITYPE_LOCAL   /**< Local URI type (i.e., non-network). */
}QOMX_URITYPE;

typedef enum QOMX_STREAMTYPE {
    QOMX_STREAMTYPE_VOD,    /**< Video on-demand stream. */
    QOMX_STREAMTYPE_LIVE,   /**< Live stream. */
    QOMX_STREAMTYPE_FILE    /**< File-based stream. */
}QOMX_STREAMTYPE;

typedef struct QOMX_MEDIASTREAMTYPE{
    QOMX_URITYPE eURIType;
    QOMX_STREAMTYPE eStreamType;
}QOMX_MEDIASTREAMTYPE;               

/** @endcond */


/** @addtogroup video_index_extra_data
@{ */
/** @brief @latexonly\label{hdr:PLANEDEFINITIONTYPE}@endlatexonly
    Specifies the parameters associated with each plane of the uncompressed 
    image/video format.
 */
typedef struct QOMX_PLANEDEFINITIONTYPE {
    OMX_U32 nSize;              /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion;   /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;         /**< Index of the port to which this structure applies. */
    OMX_U32 nPlaneIndex;        /**< Specifies the plane enumeration index to which 
                                     this structure applies, starting with a base 
                                     value of 1. */
    OMX_U32 nMinStride;         /**< Read-only parameter that specifies the minimum 
                                     buffer stride. */
    OMX_U32 nMaxStride;         /**< Read-only parameter that specifies the maximum 
                                     buffer stride. */
    OMX_U32 nStrideMultiples;   /**< Read-only parameter that specifies the buffer 
                                     stride multiple supported. */
    OMX_S32 nActualStride;      /**< Specifies the actual stride to be applied. */
    OMX_U32 nMinPlaneBufferHeight; /**< Read-only parameter that specifies the minimum 
                                        buffer height (number of stride lines). */
    OMX_U32 nActualPlaneBufferHeight; /**< Specifies the actual buffer height (number 
                                           of stride lines) to be applied. */
    OMX_U32 nBufferSize;        /**< Read-only parameter that specifies the minimum 
                                     size of the buffer, in bytes. */
    OMX_U32 nBufferAlignment;   /**< Read-only field that specifies the required 
                                     alignment of the buffer, in bytes. */
    OMX_U32 nActualBufferAlignment; /**< Specifies the actual buffer alignment. */
} QOMX_PLANEDEFINITIONTYPE;

/** @} */ /* end_addtogroup video_index_extra_data */


/** @cond
*/
/** @brief Pause port parameters.
 */
typedef struct QOMX_CONFIG_PAUSEPORTTYPE {
  OMX_U32 nSize;              /**< Size of the structure in bytes. */
  OMX_VERSIONTYPE nVersion;   /**< OpenMAX IL specification version information. */
  OMX_U32 nPortIndex;         /**< Index of the port to which this structure applies. */
  OMX_BOOL bPausePort;        /**< Specifies whether the port is paused or resumed. 
                                   By default, bPausePort = OMX_FALSE. The port is 
                                   paused when bPausePort = OMX_TRUE. */
} QOMX_CONFIG_PAUSEPORTTYPE;

/** @endcond */


#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */

#endif /* end of macro __H_QOMX_IVCOMMONEXTENSIONS_H__ */
