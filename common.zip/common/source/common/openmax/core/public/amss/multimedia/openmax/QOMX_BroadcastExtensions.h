#ifndef __H_QOMX_BROADCASTEXTENSIONS_H__
#define __H_QOMX_BROADCASTEXTENSIONS_H__

/*========================================================================

  *//** @file QOMX_BroadcastExtensions.h

@par FILE SERVICES:
      Qualcomm extensions API for OpenMax IL Broadcast.

      This file contains the description of the Qualcomm OpenMax IL
      Broadcast extention interface, through which the IL client and OpenMax 
      components can access additional Broadcast capabilities.
   
    Copyright (c) 2009-2010 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/core/public/amss/multimedia/openmax/QOMX_BroadcastExtensions.h#1 $

===========================================================================*/


/*===========================================================================
                        INCLUDE FILES FOR MODULE
===========================================================================*/
#include <OMX_Types.h>

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */

/* Broadcast extension strings */

/* refer QOMX_BROADCAST_CONFIG_LIVEDATASOURCETYPE */
#define OMX_QCOM_INDEX_CONFIG_BROADCAST_LIVEDATASOURCE		    "OMX.QCOM.index.config.broadcast.LiveDataSource"

/* refer QOMX_BROADCAST_CONFIG_TSBSTATETYPE */
#define OMX_QCOM_INDEX_CONFIG_BROADCAST_TSBSTATE                "OMX.QCOM.index.config.broadcast.TSBState" 


/* Broadcast data structures */

/* extensions for OMX_BROADCAST_SOURCETYPE */
typedef enum QOMX_BROADCAST_SOURCETYPE {
QOMX_BROADCAST_LiveSource,
QOMX_BROADCAST_TSBSource,
QOMX_BROADCAST_SourceKhronosExtensions = 0x6F000000,  /**< Reserved region for introducing Khronos Standard Extensions */ 
QOMX_BROADCAST_SourceVendorStartUnused = 0x7F000000, /**< Reserved region for introducing Vendor Extensions */
QOMX_BROADCAST_SourceMax = 0x7FFFFFFF
} QOMX_BROADCAST_SOURCETYPE;

/* extensions for OMX_BROADCAST_TSBSTATETYPE */
typedef enum QOMX_BROADCAST_TSBSTATETYPE {
QOMX_BROADCAST_TSBStateNone,
QOMX_BROADCAST_TSBStateStart,
QOMX_BROADCAST_TSBStateEnd,
QOMX_BROADCAST_TSBStateDataLoss,
QOMX_BROADCAST_TSBStateDataUnderFlow,
QOMX_BROADCAST_TSBStateDataOverFlow,
QOMX_BROADCAST_TSBStateKhronosExtensions = 0x6F000000,  /**< Reserved region for introducing Khronos Standard Extensions */ 
QOMX_BROADCAST_TSBStateVendorStartUnused = 0x7F000000, /**< Reserved region for introducing Vendor Extensions */
QOMX_BROADCAST_TSBStateMax = 0x7FFFFFFF
} QOMX_BROADCAST_TSBSTATETYPE;

/*  refer OMX_QCOM_INDEX_CONFIG_BROADCAST_TSBSTATE:
    nPortIndex: is the value containing the index of the port.
	eState: It indicates the state of TSB mode,can be start,end underflow,overflow etc.
	        refer to QOMX_BROADCAST_TSBSTATETYPE. 
*/
typedef struct QOMX_BROADCAST_CONFIG_TSBSTATETYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    QOMX_BROADCAST_TSBSTATETYPE eState;
} QOMX_BROADCAST_CONFIG_TSBSTATETYPE;

/*  refer QOMX_BROADCAST_CONFIG_LIVEDATASOURCETYPE:
    nPortIndex: is the value containing the index of the port.
    eSource: can be LiveSource or TsbSource,
	         refer to QOMX_BROADCAST_SOURCETYPE. 
*/
typedef struct QOMX_BROADCAST_CONFIG_LIVEDATASOURCETYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    QOMX_BROADCAST_SOURCETYPE eSource;
} QOMX_BROADCAST_CONFIG_LIVEDATASOURCETYPE;

#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */

#endif /* end of macro __H_QOMX_BROADCASTEXTENSIONS_H__*/

