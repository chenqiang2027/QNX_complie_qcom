#ifndef __H_QOMX_SOURCEEXTENSIONS_H__
#define __H_QOMX_SOURCEEXTENSIONS_H__
/*========================================================================
*//** @file QOMX_SourceExtensions.h 

@par FILE SERVICES:
    Qualcomm extensions API for OpenMax IL demuxer component.

    This file contains the description of the Qualcomm OpenMax IL
    demuxer component extention interface, through which the IL client and 
    OpenMax components can access additional capabilities of the demuxer.
   
    Copyright (c) 2009-2010 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                            Edit History
$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/core/public/amss/multimedia/openmax/QOMX_SourceExtensions.h#1 $
========================================================================== */
 
/*======================================================================== 
                     INCLUDE FILES FOR MODULE 
========================================================================== */ 
#include <OMX_Core.h>
#include <OMX_IVCommon.h>
/*========================================================================
                      DEFINITIONS AND DECLARATIONS
========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */

/* Content interface extension strings */ 
#define OMX_QCOM_INDEX_PARAM_CONTENTINTERFACE_IXSTREAM     "OMX.QCOM.index.param.contentinterface.ixstream"    /**< reference: QOMX_CONTENTINTERFACETYPE*/
#define OMX_QCOM_INDEX_PARAM_CONTENTINTERFACE_ISTREAMPORT  "OMX.QCOM.index.param.contentinterface.istreamport" /**< reference: QOMX_CONTENTINTERFACETYPE*/

/* Source seek access extension string */
#define OMX_QCOM_INDEX_PARAM_SEEK_ACCESS		    "OMX.QCOM.index.param.SeekAccess"                   /**< reference: QOMX_PARAM_SEEKACCESSTYPE*/

/* End time position extension string */
#define OMX_QCOM_INDEX_CONFIG_ENDTIME_POSITION              "OMX.QCOM.index.config.EndTimePosition"             /**< reference: OMX_TIME_CONFIG_TIMESTAMPTYPE */

/* End time position extension string */
#define OMX_QCOM_INDEX_CONFIG_SAMPLEBASED_REPOSITION        "OMX.QCOM.index.config.SampleBasedResposition"      /**< reference: QOMX_CONFIG_SAMPLEREPOSITIONTYPE */


/**
 * Enumeration defining the extended uncompressed image/video
 * formats.
 *
 * ENUMS:
 *  QOMX_POSITION_CURRENT : Sample reposition reference to current sample
 *  QOMX_POSITION_START   : Sample reposition reference to first sample
 *  QOMX_POSITION_END     : Sample reposition reference to last sample
 */
typedef enum QOMX_REPOSITION_POINTTYPE {
    QOMX_POSITION_CURRENT,   /**< Reposition from current sample */
    QOMX_POSITION_START,     /**< Reposition from first sample   */
    QOMX_POSITION_END        /**< Reposition from last sample    */
} QOMX_REPOSITION_POINTTYPE;

/* Frame size query supported extension string */
#define OMX_QCOM_INDEX_PARAM_FRAMESIZEQUERYSUPPORTED       "OMX.QCOM.index.param.FrameSizeQuerySupported"      /**< reference: QOMX_FRAMESIZETYPE */

/** 
 *  Data interface Params
 * 
 *  STRUCT MEMBERS:
 *  nSize          : Size of the structure in bytes
 *  nVersion       : OMX specification version information
 *  nInterfaceSize : Size of the data pointed by pInterface
 *  pInterface     : Interface pointer
 */
typedef struct QOMX_CONTENTINTERFACETYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nInterfaceSize;
    OMX_U8 pInterface[1];
} QOMX_DATAINTERFACETYPE;

/**
 *  Seek Access Parameters
 *
 *  STRUCT MEMBERS:
 *  nSize          : Size of the structure in bytes
 *  nVersion       : OMX specification version information
 *  nPortIndex     : Index of port
 *  bSeekAllowed   : Flag to indicate whether seek is supported or not
 */
typedef struct QOMX_PARAM_SEEKACCESSTYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_BOOL bSeekAllowed;
} QOMX_PARAM_SEEKACCESSTYPE;

/**
 *  Sample based reposition parameters
 *
 *  STRUCT MEMBERS:
 *  nSize           : Size of the structure in bytes
 *  nVersion        : OMX specification version information
 *  nPortIndex      : Index of port
 *  nSampleNumber   : Number of sample to reposition
 *  eRepositionPoint: Reference point of reposition with respective to 
 *                    which sample will reposition
 */
typedef struct QOMX_CONFIG_SAMPLEREPOSITIONTYPE {
  OMX_U32 nSize;
  OMX_VERSIONTYPE nVersion;
  OMX_U32 nPortIndex;
  OMX_S32 nSampleNumber;
  QOMX_REPOSITION_POINTTYPE eRepositionPoint;
} QOMX_CONFIG_SAMPLEREPOSITIONTYPE;

/**
 *  The parameters for QOMX_FRAMESIZETYPE are defined as
 *  follows:
 *
 *  STRUCT MEMBERS:
 *  nSize           : Size of the structure in bytes
 *  nVersion        : OMX specification version information
 *  nPortIndex      : Represents the port that this structure
 *                    applies to
 *  sFrameSize      : Indicates the size of the frame
 *  nFrameSizeIndex : Enumerates the possible frame sizes for
 *                    the given session/URL configuration. The
 *                    caller specifies all fields and the
 *                    OMX_GetParameter call returns the value of
 *                    the frame size. The value of
 *                    nFrameSizeIndex goes from 0 to N-1, where
 *                    N is the number of frame sizes that may be
 *                    emitted by the port. The port does not
 *                    need to report N as the caller can
 *                    determine N by enumerating all the frame
 *                    sizes supported by the port. If the port
 *                    does not have advance knowledge of the
 *                    possible frame sizes, it may report no
 *                    frame sizes. If there are no more frame
 *                    sizes, OMX_GetParameter returns
 *                    OMX_ErrorNoMore.
 */
typedef struct QOMX_FRAMESIZETYPE 
{ 
  OMX_U32 nSize; 
  OMX_VERSIONTYPE nVersion; 
  OMX_U32 nPortIndex; 
  OMX_FRAMESIZETYPE sFrameSize;
  OMX_U32 nFrameSizeIndex;
} QOMX_FRAMESIZETYPE; 

#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */

#endif /* end of macro __H_QOMX_SOURCEEXTENSIONS_H__ */
