#ifndef __H_QOMX_TIMEEXTENSIONS_H__
#define __H_QOMX_TIMEEXTENSIONS_H__ 

/*========================================================================

*//** @file QOMX_TimeExtensions.h 

@par FILE SERVICES:
      Qualcomm extensions API for OpenMax IL Time.

      This file contains the description of the Qualcomm OpenMax IL
      time extention interface, through which the IL client and OpenMax 
      components can access additional time capabilities.
   
    Copyright (c) 2009-2010 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/core/public/amss/multimedia/openmax/QOMX_TimeExtensions.h#1 $

========================================================================== */
 
/*======================================================================== 
 
                     INCLUDE FILES FOR MODULE 
 
========================================================================== */ 
#include <OMX_Types.h>
#include <OMX_Other.h>

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */

/* Time extension strings */ 

/* refer QOMX_TIME_CONFIG_MEDIATIMESTOPUSINGWALLTIMETYPE */
#define OMX_QCOM_INDEX_CONFIG_TIME_MEDIATIMESTOPUSINGWALLTIME         "OMX.QCOM.index.config.time.MediaTimeStopUsingWallTime"

/* refer OMX_TIME_CONFIG_TIMESTAMPTYPE */
#define OMX_QCOM_INDEX_CONFIG_TIME_CURRENTSOURCEREFERENCE             "OMX.QCOM.index.config.time.CurrentSourceReference"

/* refer QOMX_TIME_CONFIG_SOURCEREFERENCECLOCKRESETTYPE */
#define OMX_QCOM_INDEX_CONFIG_TIME_SOURCEREFERENCECLOCKRESET          "OMX.QCOM.index.config.time.SourceReferenceClockReset"

/* Time data structures */ 

/*  refer OMX_QCOM_INDEX_CONFIG_TIME_MEDIATIMESTOPUSINGWALLTIME:
    nPortIndex: is the value containing the index of the port.
	bMediaTimeStopUsingWallTime: is OMX_TRUE to specify media time not to update from wall time. default is OMX_FALSE 
*/
typedef struct QOMX_TIME_CONFIG_MEDIATIMESTOPUSINGWALLTIMETYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_BOOL bMediaTimeStopUsingWallTime;
} QOMX_TIME_CONFIG_MEDIATIMESTOPUSINGWALLTIMETYPE;

/*  refer OMX_QCOM_INDEX_CONFIG_TIME_SOURCEREFERENCECLOCKRESET:
    nPortIndex: is the value containing the index of the port.
    bReset: is OMX_TRUE if source reference clock is reset. Default is OMX_FALSE 
*/
typedef struct QOMX_TIME_CONFIG_SOURCEREFERENCECLOCKRESETTYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_BOOL bReset;
} QOMX_TIME_CONFIG_SOURCEREFERENCECLOCKRESETTYPE;

/* extensions for OMX_TIME_REFCLOCKTYPE */
typedef enum QOMX_TIME_REFCLOCKTYPE {
   QOMX_TIME_RefClockSource = (OMX_TIME_RefClockVendorStartUnused+1)
} QOMX_TIME_REFCLOCKTYPE ;

/* extensions for OMX_TIME_UPDATETYPE */
typedef enum QOMX_TIME_UPDATETYPE {
   QOMX_TIME_UpdateActiveReferenceClockChanged = (OMX_TIME_UpdateVendorStartUnused +1)
} QOMX_TIME_UPDATETYPE;


#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */

#endif /* end of macro __H_QOMX_TIMEEXTENSIONS_H__ */
