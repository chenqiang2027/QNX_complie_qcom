#ifndef _QOMX_EXTENSIONS_H_
#define _QOMX_EXTENSIONS_H_

/* ===========================================================================

                      Q O M X _ C a m E x t e n s i o n s
                            D e c l a r a t i o n s

*//** @file QOMX_CamExtensions.h
  This module contains Qualcomm extensions for OpenMax IL Camera.

  This file contains the definition of the Qualcomm OpenMax IL
  camera extensions, which the component should handle so that
  the IL Client or other components can access additional camera
  capabilities.

Copyright (c) 2009-2014 Qualcomm Technologies, Inc. All Rights Reserved.
Qualcomm Proprietary and Confidential.
Export of this technology or software is regulated by the U.S. Government.
Diversion contrary to U.S. law prohibited.

=========================================================================== */
/* ===========================================================================

                             Edit History

 $Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/core/public/amss/multimedia/openmax/QOMX_CamExtensions.h#1 $

 when       who     what, where, why
 --------   ---     -------------------------------------------------------


=========================================================================== */

/* ===========================================================================
                     INCLUDE FILES FOR MODULE
=========================================================================== */
#include <OMX_Types.h>
#include <OMX_IVCommon.h>
#include <OMX_Component.h>

/* ===========================================================================
                      DEFINITIONS AND DECLARATIONS
=========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */

/**
 * Qualcomm vendor extensions.
 */
#define OMX_QCOM_INDEX_CONFIG_FLICKERREJECTION           "OMX.QCOM.index.config.FlickerRejection"
#define OMX_QCOM_INDEX_CONFIG_SHARPNESS                  "OMX.QCOM.index.config.Sharpness"
#define OMX_QCOM_INDEX_CONFIG_IMAGE_HISTOGRAM            "OMX.QCOM.index.config.image.Histogram"
#define OMX_QCOM_INDEX_CONFIG_IMAGE_HISTOGRAMDATA        "OMX.QCOM.index.config.image.HistogramData"
#define OMX_QCOM_INDEX_CONFIG_IMAGE_HISTOGRAMINFO        "OMX.QCOM.index.config.image.HistogramInfo"
#define OMX_QCOM_INDEX_CONFIG_BRACKETING                 "OMX.QCOM.index.config.Bracketing"
#define OMX_QCOM_INDEX_CONFIG_FOCUSMACRO                 "OMX.QCOM.index.config.FocusMacro"
#define OMX_QCOM_INDEX_CONFIG_IMAGEFRAMERATE             "OMX.QCOM.index.config.ImageFrameRate"
#define OMX_QCOM_INDEX_CONFIG_LUMAADAPTATION             "OMX.Qualcomm.index.config.LumaAdaptation"
#define OMX_QCOM_INDEX_PARAM_DEVICEINFO                  "OMX.QCOM.index.param.DeviceInfo"
#define OMX_QCOM_INDEX_CONFIG_ACTIVEDEVICE               "OMX.QCOM.index.config.ActiveDevice"
#define OMX_QCOM_INDEX_PARAM_ACTIVEDEVICE                "OMX.QCOM.index.param.ActiveDevice"
#define OMX_QCOM_INDEX_PARAM_AVAILABLEDEVICES            "OMX.QCOM.index.param.AvailableDevices"
#define OMX_QCOM_INDEX_PARAM_EMBEDDEDTHUMBNAILRESOLUTION "OMX.QCOM.index.param.EmbeddedThumbnailResolution"
#define OMX_QCOM_INDEX_PARAM_EMBEDDEDTHUMBNAILQFACTOR    "OMX.QCOM.index.param.EmbeddedThumbnailQFactor"
#define OMX_QCOM_INDEX_DEVICE_SHUTTER                    "OMX.QCOM.index.device.Shutter"
#define OMX_QCOM_INDEX_DEVICE_HALFSHUTTER                "OMX.QCOM.index.device.HalfShutter"
#define OMX_QCOM_INDEX_CONFIG_REGIONOFINTEREST           "OMX.QCOM.index.config.common.RegionsOfInterest"
#define OMX_QCOM_INDEX_CONFIG_REGIONOFINTERESTMODE       "OMX.QCOM.index.config.common.RegionOfInterestMode"
#define OMX_QCOM_INDEX_CONFIG_NOTIFYONROICHANGED         "OMX.QCOM.index.config.common.NotifyOnRegionOfInterestChanged"
#define OMX_QCOM_INDEX_CONFIG_REGIONOFINTERESTPRIORITY   "OMX.QCOM.index.config.common.RegionOfInterestPriority"
#define OMX_QCOM_INDEX_CONFIG_IMAGEEXPOSURELOCK          "OMX.QCOM.index.config.common.ImageExposureLock"
#define OMX_QCOM_INDEX_CONFIG_IMAGEWHITEBALANCELOCK      "OMX.QCOM.index.config.common.ImageWhiteBalanceLock"
#define OMX_QCOM_INDEX_CONFIG_IMAGEFOCUSLOCK             "OMX.QCOM.index.config.common.ImageFocusLock"
#define OMX_QCOM_INDEX_CONFIG_IMAGE_BRACKETING           "OMX.QCOM.index.config.image.Bracketing"
#define OMX_QCOM_INDEX_CONFIG_EXTCAPTUREMODE             "OMX.Qualcomm.index.config.ExtCaptureMode"
#define OMX_QCOM_INDEX_CONFIG_FACTORYTEST                "OMX.QCOM.index.config.common.FactoryTest"
#define QOMX_IMAGE_CONFIG_MAXFLASHCURRENT                "OMX.QCOM.index.config.MaxFlashCurrent"
#define OMX_QCOM_INDEX_CONFIG_AFASSISTANTLIGHT           "OMX.QCOM.index.config.common.AFAssistantLight"
#define OMX_QCOM_INDEX_CONFIG_FOCUSRANGE                 "OMX.QCOM.index.config.common.FocusRange"
#define OMX_QCOM_INDEX_CONFIG_AUTOFRAMERATERANGE         "OMX.QCOM.index.config.AutoFrameRateRange"
#define OMX_QCOM_INDEX_CONFIG_LOWLIGHTDETECTION          "OMX.QCOM.index.config.LowLightDetection"
#define OMX_QCOM_INDEX_CONFIG_WHITEBALTEMPERATURETYPE    "OMX.QCOM.index.config.WhiteBalanceTemperatureType"
#define OMX_QCOM_INDEX_CONFIG_SHUTTERSPEEDRANGETYPE      "OMX.QCOM.index.config.ShutterSpeedRangeType"
#define OMX_QCOM_INDEX_CONFIG_LUXTYPE                    "OMX.QCOM.index.config.LuxType"
#define OMX_QCOM_INDEX_CONFIG_ZSLFOCUSPRIORITY           "OMX.QCOM.index.config.ZSLFocusPriority"
#define OMX_QCOM_INDEX_CONFIG_ZSLSHARPNESSWINDOW         "OMX.QCOM.index.config.ZSLSharpnessWindow"
#define OMX_QCOM_INDEX_CONFIG_HIGHDYNAMICRANGECONTROL    "OMX.QCOM.index.config.HighDynamicRangeControl"
#define OMX_QCOM_INDEX_CONFIG_CAMERAORIENTATION          "OMX.QCOM.index.config.CameraOrientation"
#define OMX_QCOM_INDEX_CONFIG_ZSLINTERVALSTRETCH         "OMX.QCOM.index.config.ZSLIntervalStretch"
#define OMX_QCOM_INDEX_CONFIG_IMAGESTABILIZATIONCONTROL  "OMX.QCOM.index.config.ImageStabilizationControl"

/******************************************************************************
 * Camera Capture Extension                                                   *
 *****************************************************************************/
typedef struct QOMX_S32TYPE {
    OMX_U32 nSize; /**< size of the structure in bytes */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information */
    OMX_U32 nPortIndex; /**< port that this structure applies to */
    OMX_S32 nS32; /**< signed value */
} QOMX_S32TYPE;

typedef struct QOMX_BS32TYPE {
    OMX_U32 nSize; /**< size of the structure in bytes */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information */
    OMX_U32 nPortIndex; /**< port that this structure applies to */
    OMX_S32 nValue; /**< The actual signed value. */
    OMX_S32 nMin; /**< The minimum for value (i.e. nValue >= nMin) */
    OMX_S32 nMax; /**< The maximum for value (i.e. nValue >= nMin) */
} QOMX_BS32TYPE;


/** QOMX_EventParamOrConfigChanged is a generic callback to mark when a param or config has changed.
Callbacks are enabled and disabled on a component by registering a param or config index using
QOMX_CONFIG_REQUESTCALLBACKTYPE. */
#define QOMX_EventParamOrConfigChanged      (OMX_EventVendorStartUnused+1)

/** QOMX_EventDevice is a generic callback to provide notification for
device actions such as a shutter opening or closing.  Callbacks are
enabled and disabled on a component through specific param or config
calls as described below.  This mechanism is similar to
QOMX_EventParamOrConfigChanged with the primary distinction being
QOMX_EventDevice provides callbacks on device events while
QOMX_EventParamOrConfigChanged provides callbacks on changing param or config values.
The nData1 field of EventHandler specifies the registered device event
as listed in Table 2 which indicates the device action being reported.
The nData2 field specifies OMX_ALL since the device corresponds to the component.
The pEventData field is NULL.
*/
#define QOMX_EventDevice                    (OMX_EventVendorStartUnused+2)


/** QOMX_CONFIG_REQUESTCALLBACKTYPE is used to enable or disable
notifications on a specific index on a specific port. */
typedef struct QOMX_CONFIG_REQUESTCALLBACKTYPE {
    OMX_U32 nSize; /**< size of the structure in bytes */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information */
    OMX_U32 nPortIndex; /**< port that this structure applies to */
    OMX_INDEXTYPE nIndex; /**< config or param index on which notification will be sent. */
    OMX_BOOL bEnable; /**< indicates whether the callback is enabled or disabled. */
} QOMX_CONFIG_REQUESTCALLBACKTYPE;

typedef enum QOMX_EVENTDEVICETYPE {
    QOMX_EventDeviceStartUnused,
    QOMX_EventDeviceShutterOpening, /**< Shutter is opening.  Enabled/disabled through device shutter index config. */
    QOMX_EventDeviceShutterClosing, /**< Shutter is closing.  Enabled/disabled through device shutter index config. */
    QOMX_EventDeviceHalfShutter,    /**< Half shutter complete. Enabled/disabled through device half shutter config.*/
    QOMX_EventDeviceRegionOfInterestChanged, /**< Regions of Interest are updated. Enabled/disabled through device notify on Region of Interest changed config.*/
} QOMX_EVENTDEVICETYPE;

/** Exposure for landscapes. */
#define QOMX_ExposureControlLandscape       (OMX_ExposureControlVendorStartUnused+1)
/** Exposure at sunset. */
#define QOMX_ExposureControlSunset          (OMX_ExposureControlVendorStartUnused+2)
/** Exposure for portrait subject. */
#define QOMX_ExposureControlPortrait        (OMX_ExposureControlVendorStartUnused+3)
/** Exposure for closeup colorful subject. */
#define QOMX_ExposureControlFlowers         (OMX_ExposureControlVendorStartUnused+4)
/** Exposure for candlelit scenes. */
#define QOMX_ExposureControlCandlelight     (OMX_ExposureControlVendorStartUnused+5)
/** Exposure for indoor party scenes. */
#define QOMX_ExposureControlParty           (OMX_ExposureControlVendorStartUnused+6)
/** Exposure for photos of whiteboards and text. */
#define QOMX_ExposureControlWhiteboard      (OMX_ExposureControlVendorStartUnused+7)
/** Exposure for scanning bar codes. */
#define QOMX_ExposureControlBarcode         (OMX_ExposureControlVendorStartUnused+8)

/** Filters data to give a pastel appearance. */
#define QOMX_ImageFilterPastel              (OMX_ImageFilterVendorStartUnused+1)
/** Filters data to give a mosaic appearance. */
#define QOMX_ImageFilterMosaic              (OMX_ImageFilterVendorStartUnused+2)
/** Filters data to replace gradual transitions of tone with abrupt changes in grade and shading. */
#define QOMX_ImageFilterPosterize           (OMX_ImageFilterVendorStartUnused+3)
/** Filters data to emphasize symbols written on a whiteboard. */
#define QOMX_ImageFilterWhiteboard          (OMX_ImageFilterVendorStartUnused+4)
/** Filters data to emphasize symbols written on a blackboard. */
#define QOMX_ImageFilterBlackboard          (OMX_ImageFilterVendorStartUnused+5)
/** Filters data to provide a sepia appearance. */
#define QOMX_ImageFilterSepia               (OMX_ImageFilterVendorStartUnused+6)
/** Filters data to provide a gray scale appearance. */
#define QOMX_ImageFilterGrayscale           (OMX_ImageFilterVendorStartUnused+7)

/** White balance control type to allow setting color temperature. */
#define QOMX_WhiteBalControlKelvin           (OMX_WhiteBalControlVendorStartUnused+1)

typedef enum QOMX_DEVICEINFOTYPE {
    QOMX_DeviceInfoStartUnused = 0x00000000,
    QOMX_DeviceInfoMaxResolution, /**< OMX_FRAMESIZETYPE. Maximum supported resolution. */
    QOMX_DeviceInfoMaxFrameRate, /**< OMX_CONFIG_FRAMERATETYPE. Q16.
                                 Max frame rate for the resolution currently set on the port. */
    QOMX_DeviceInfoInstalledRotation, /**< OMX_CONFIG_ROTATIONTYPE.
                                      Degrees the device has been rotated in installed orientation. */
    QOMX_DeviceInfoSharpness, /**< QOMX_BS32TYPE. Maximum and minimum sharpness values.  The nValue param is not used. */
    QOMX_DeviceInfoMax = 0x7FFFFFFF
} QOMX_DEVICEINFOTYPE;

/** QOMX_PARAM_DEVICEINFOTYPE is used to retrieve the abilities of a device (i.e. camera).
All information retrieved is read-only. */
typedef struct QOMX_PARAM_DEVICEINFOTYPE {
    OMX_U32 nSize; /**< size of the structure in bytes */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information */
    OMX_U32 nPortIndex; /**< port that this structure applies to */
    QOMX_DEVICEINFOTYPE eInfo;
    OMX_U32 nDataSize;
    OMX_U8 data[1];
} QOMX_PARAM_DEVICEINFOTYPE;


typedef enum QOMX_BRACKETINGTYPE {
    /** Exposure value compensation is changed in relative adjustments defined in Q16 format.
    The priority is given to either shutter speed or aperture depending on whether auto aperture
    (shutter priority) or auto shutter speed (aperture priority) is set. */
    QOMX_BracketingExposureValue,
    /** Exposure value is change in relative adjustment of shutter speed in milliseconds defined as a U32. */
    QOMX_BracketingExposureTime,
    /** Exposure value is changed in relative aperture f-stop settings defined in Q16 format. */
    QOMX_BracketingExposureAperture,
    /** Focus is adjusted relative to the focus set by the current focus setting.
    The value is a U32 and is the same as incrementing nFocusStepsIndex of Focus Control. */
    QOMX_BracketingFocus,
    QOMX_BracketingMax = 0x7FFFFFFF
} QOMX_BRACKETINGTYPE;


/** QOMX_IMAGE_BRACKETINGTYPE is used specify that each captured image will use a slightly
different setting as defined by the bracketing type and value specified.
This setting is intended for use with the multi-shot shooting mode,
but can be used with success single-shot calls. */
typedef struct QOMX_IMAGE_BRACKETINGTYPE {
    OMX_U32 nSize; /**< size of the structure in bytes */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information */
    OMX_U32 nPortIndex; /**< port that this structure applies to */
    OMX_BOOL bBracketingEnable; /**< indicates whether bracketing mode is enabled. */
    OMX_U32 nBrackets; /**< the number of brackets desired. */
    QOMX_BRACKETINGTYPE eBracketing; /**< mutually exclusive bracket mode. */
    OMX_U32 nBracketValue; /**< relative bracket adjustment data. */
} QOMX_IMAGE_BRACKETINGTYPE;


typedef enum QOMX_HISTOGRAMTYPE {
    QOMX_Histogram_Off, /**< Histogram is disabled. */
    QOMX_Histogram_RGB, /**< RGB Color (R, G, B) histogram mode. */
    QOMX_Histogram_Luma, /**< Luma (Y) histogram mode. */
    QOMX_Histogram_Chroma, /**< Chroma (Cb, Cr) histogram. */
    QOMX_Histogram_Max = 0x7FFFFFFF
} QOMX_HISTOGRAMTYPE;

/** Histogram measurements can be controlled by the following data structure. */
typedef struct QOMX_IMAGE_HISTOGRAMTYPE {
    OMX_U32 nSize; /**< size of the structure in bytes */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information */
    OMX_U32 nPortIndex; /**< port that this structure applies to */
    OMX_U32 nBins; /**< Read-only value containing the number of bins the histogram allocates for each component. */
    OMX_S32 nLeft; /**< Leftmost coordinate of the measurement area rectangle. */
    OMX_S32 nTop; /**< Topmost coordinate of the measurement area rectangle. */
    OMX_U32 nWidth; /**< Width of the measurement area rectangle in pixels. */
    OMX_U32 nHeight; /**< Height of the measurement area rectangle in pixels. */
    QOMX_HISTOGRAMTYPE eHistType; /**< Histogram type. */
} QOMX_IMAGE_HISTOGRAMTYPE;

/** The histogram estimation data is described with the following structure. */
typedef struct QOMX_IMAGE_HISTOGRAMDATATYPE {
    OMX_U32 nSize; /**< size of the structure in bytes */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information */
    OMX_U32 nPortIndex; /**< port that this structure applies to */
    QOMX_HISTOGRAMTYPE eHistType; /**< Read-only value specifying the histogram type. */
    OMX_U32 nBins; /**< read-only value containing the number of bins the histogram allocates for each component. */
    OMX_U8 data[1]; /**< first byte of the histogram data. */
} QOMX_IMAGE_HISTOGRAMDATATYPE;

/** This structure is used to retrieve the histogram types supported by the component.
It will also report the maximum number of bins for the histogram type as well as the
number of bits used to represent the histogram data per bin. */
typedef struct QOMX_IMAGE_HISTOGRAMINFOTYPE {
    OMX_U32 nSize; /**< size of the structure in bytes */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information */
    OMX_U32 nPortIndex; /**< port that this structure applies to */
    QOMX_HISTOGRAMTYPE eHistType; /**< Histogram type being queried whether it is supported or not. */
    OMX_U32 nBins; /** < The read-only value containing the maximum number of bins available. */
    OMX_U16 nBitsPerBin; /**< The number of bits per bin. */
} QOMX_IMAGE_HISTOGRAMINFOTYPE;


/** QOMX_REGIONOFINTEREST is used to specify a set list of rectangles
each of which indicates a region of interest. */
typedef struct QOMX_REGIONOFINTERESTTYPE {
    OMX_U32 nSize; /**< size of the structure in bytes */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information */
    OMX_U32 nPortIndex; /**< port that this structure applies to */
    OMX_U32 nRegionIndex; /**< index of the region being specified. */
    OMX_U32 nPriority; /**< importance value placed on this region of interest. */
    OMX_U32 nLeft; /**< offset from the left of the frame from where the region of interest is defined. */
    OMX_U32 nTop; /**< offset from the top of the frame from where the region of interest is defined. */
    OMX_U32 nWidth; /**< width of the region of interest. */
    OMX_U32 nHeight; /**< width of the region of interest. */
} QOMX_REGIONOFINTERESTTYPE;

/**
 * Flicker Rejection values.
 */
typedef enum QOMX_FLICKERREJECTIONMODETYPE
{
    QOMX_FlickerRejectionOff = 0, /**< Antibanding is off. */
    QOMX_FlickerRejectionAuto, /**< Auto detect banding frequency and correct. */
    QOMX_FlickerRejection50, /**< Correct for 50Hz banding. */
    QOMX_FlickerRejection60, /**< Correct for 60Hz banding. */
    QOMX_FlickerRejectionMax = 0x7FFFFFFF /**< Maximum value. */
} QOMX_FLICKERREJECTIONMODETYPE;

/**
 * QOMX_FLICKERREJECTIONTYPE is used to remove flicker effect from
 * electrical lighting.
 */
typedef struct QOMX_FLICKERREJECTIONTYPE
{
    OMX_U32 nSize; /**< size of the structure in bytes */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information */
    OMX_U32 nPortIndex; /**< port that this structure applies to */
    QOMX_FLICKERREJECTIONMODETYPE eFlickerRejection; /**< flicker rejection mode. */
} QOMX_FLICKERREJECTIONTYPE;

/** Bits used to identify ROI function area. Used in
 *  QOMX_ROITYPE�s nRegionFunctionType field */
#define QOMX_ROI_FUNCTION_MASK_NONE  0x00000000
#define QOMX_ROI_FUNCTION_MASK_AE    0x00000001
#define QOMX_ROI_FUNCTION_MASK_AF    0x00000002
#define QOMX_ROI_FUNCTION_MASK_FACE  0x00000004

/** This structure define the parameters for the region of interest. */
typedef struct QOMX_ROITYPE{
    OMX_U32 nLeft; /**< Offset from the left of the frame from where the region of interest is defined. */
    OMX_U32 nTop; /**< Offset from the top of the frame from where the region of interest is defined. */
    OMX_U32 nWidth; /**< Width of the region of interest. */
    OMX_U32 nHeight; /**< Height of the region of interest. */
    OMX_U32 nRegionID; /**< Represents the identity of the region of interest. Value is 0 when region tracking is not supported. */
    OMX_U32 nPriority; /**< relative weight placed on this region of interest. Value is 0 when the region of interest is not used. */
    OMX_U32 nRegionFunctionType; /**< nRegionFunctionType specifies a mask of QOMX_ROI_FUNCTION_MASK values designating the function
                                      area that this region of interest is used for. */
} QOMX_ROITYPE;

/** This structure used to set user defined Regions of Interest to track or to retrieve auto-detected
  Regions of Interest, as with Face Detection. Regions of interest are used for focus and exposure metering.*/
typedef struct QOMX_CONFIG_REGIONSOFINTERESTTYPE{
    OMX_U32 nSize; /** < Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information. */
    OMX_U32 nPortIndex; /**< Port that this structure applies to. */
    OMX_U32 nRegionsSize; /**< Number of regions in the nRegions buffer, set as 0 to retrieve available regions of interest. */
    QOMX_ROITYPE nRegions[1]; /**< Buffer of regions of interest of type QOMX_ROITYPE. */
} QOMX_CONFIG_REGIONOFINTERESTTYPE;

/**
 * Region of Interest supported Modes.
 */
typedef enum QOMX_ROIMODETYPE {
    QOMX_RegionOfInterestModeOff = 0, /**< Region tracking is disabled. */
    QOMX_RegionOfInterestModeUser, /**< Regions of interest will be set by the IL client. */
    QOMX_RegionOfInterestModeFace, /**< Camera component will determine the regions of interest. */
    QOMX_RegionOfInterestModeFaceDetectionOnly, /** < Camera component will perform face detection but will not use them for focus
                                                      or exposure metering */
    QOMX_RegionOfInterestModeMax = 0x7FFFFFFF /**< Maximum value. */
} QOMX_ROIMODETYPE;

/** This structure is used to specify the region of interest that the camera component should run in */
typedef struct QOMX_CONFIG_REGIONOFINTERESTMODETYPE {
    OMX_U32 nSize; /** < Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information. */
    OMX_U32 nPortIndex; /**< Port that this structure applies to. */
    QOMX_ROIMODETYPE eMode; /** Mode for Region of Interest enumerated in QOMX_ROIMODETYPE. */
} QOMX_CONFIG_REGIONOFINTERESTMODETYPE;

/** This structure is used to specify or retrieve the priority for a specific the region of interest */
typedef struct QOMX_CONFIG_REGIONOFINTERESTPRIORITYTYPE {
    OMX_U32 nSize; /** < Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information. */
    OMX_U32 nPortIndex; /**< Port that this structure applies to. */
    OMX_U32 nRegionID; /**< Identity of the region of interest, retrieved from OMX.QCOM.index.config.common.RegionsOfInterest. Cannot be set as 0. */
    OMX_U32 nPriority; /**< Percentage of importance value placed on this region of interest until it is no longer present. Range is 0-100, both inclusive. */
} QOMX_CONFIG_REGIONOFINTERESTPRIORITYTYPE;

/**
 * Image setting lock values.
 */
typedef enum OMX_IMAGE_LOCKTYPE {
    OMX_IMAGE_LockOff = 0, /**< Lock is off. */
    OMX_IMAGE_LockImmediate, /**< Setting is locked and no longer automatically updated. */
    OMX_IMAGE_LockAtCapture, /**< Setting is locked on subsequent image capture, useful to lock at the start of multiple image captures. */
    OMX_IMAGE_LockKhronosExtensions = 0x6F000000, /**< Reserved region for introducing Khronos Standard Extensions */
    OMX_IMAGE_LockVendorStartUnused = 0x7F000000, /**< Reserved region for introducing Vendor Extensions */
    OMX_IMAGE_LockMax = 0x7FFFFFFF /**< Maximum value. */
} OMX_IMAGE_LOCKTYPE;

/**
 * This structure is used to lock image settings including exposure, white
 * balance and focus.
 */
typedef struct OMX_IMAGE_CONFIG_LOCKTYPE {
    OMX_U32 nSize; /** < Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information. */
    OMX_U32 nPortIndex; /**< Port that this structure applies to. */
    OMX_IMAGE_LOCKTYPE eImageLock; /**< Lock setting. */
} OMX_IMAGE_CONFIG_LOCKTYPE;

/**
 * Bracket configuration mode to use.
 */
typedef enum OMX_IMAGE_BRACKETMODETYPE {
    OMX_BracketExposureRelativeInEV = 0, /**< Exposure bracketing is specified with relative Exposure Value steps. */
    OMX_BracketExposureManual, /**< Exposure bracketing is controlled. */
} OMX_IMAGE_BRACKETMODETYPE;

/**
 * This structure is used to convey the parameters for configuring bracketing
 * functionality with relative exposure control.
 */
typedef struct QOMX_IMAGE_BRACKETING_EVCOMPENSATEDTYPE {
    OMX_S32 xEVCompensation; /**< Exposure Value compensation defined in Q16 format. */
} QOMX_IMAGE_BRACKETING_EVCOMPENSATEDTYPE;

/**
 * This structure is used to convey the parameters for configuring bracketing
 * functionality with manual exposure control.
 */
typedef struct QOMX_IMAGE_BRACKETING_MANUALEXPTYPE {
    OMX_U16 nExposureTimeUs; /**< Exposure time specified in units of microseconds. */
    OMX_U16 nSensitivity; /**< ISO sensitivity setting. */
} QOMX_IMAGE_BRACKETING_MANUALEXPTYPE;

/**
 * This structure is used to control the bracketing functionality.
 */
typedef struct QOMX_IMAGE_CONFIG_BRACKETINGTYPE {
    OMX_U32 nSize; /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information. */
    OMX_U32 nPortIndex; /**< Port that this structure applies to. */
    OMX_IMAGE_BRACKETMODETYPE eBracketMode; /**< Bracketing configuration mode to use. */
    OMX_U32 nNbrBracketingValues; /**< The number of different bracketing values used. */
    OMX_U8 nValues[1]; /**< The bracketing values to be used. */
} QOMX_IMAGE_CONFIG_BRACKETINGTYPE;

/**
 * This structure is used to configure the ZSL capture behavior.
 */
typedef struct QOMX_CONFIG_EXTCAPTUREMODETYPE {
    OMX_U32 nSize; /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information. */
    OMX_U32 nPortIndex; /**< Port that this structure applies to. */
    OMX_U32 nFrameBefore; /**<Specifies the number of captured frames that shall be buffered by the component after bPrepareCapture
                             has been set to OMX_TRUE, and while waiting for the capture bit (OMX_IndexConfigCapturing) to be set. */
    OMX_BOOL bPrepareCapture; /**<shall be set to OMX_TRUE when nFrameBefore is greater than zero and before capturing of
                             before-frames should start. */
} QOMX_CONFIG_EXTCAPTUREMODETYPE;

/**
 * Factory test commands.
 */
typedef enum QOMX_FACTORYTESTCOMMANDTYPE {
    QOMX_FactoryTestCommand_Unused = 0x00000000, /**< Factory test: reserved field. */
    QOMX_FactoryTestCommand_SensorColorBarOn, /**< Factory test: turn on sensor color bar mode. */
    QOMX_FactoryTestCommand_SensorColorBarOff, /**< Factory test: turn off sensor color bar mode. */
    QOMX_FactoryTestCommand_AFActuatorPositionMacro, /**< Factory test: set AF Actuator at macro position. */
    QOMX_FactoryTestCommand_AFActuatorPositionInfinity, /**< Factory test: set AF Actuator at infinity position. */
    QOMX_FactoryTestCommand_AFActuatorPositionRest, /**< Factory test: set AF Actuator at rest position. */
    QOMX_FactoryTestCommand_CalibrationDataRead, /**< Factory test: read camera sensor calibration data. */
    QOMX_FactoryTestCommand_FlashSyncLineToggleHigh, /**< Factory test: set flash sync line high. */
    QOMX_FactoryTestCommand_FlashSyncLineToggleLow, /**< Factory test: set flash sync line low. */
    QOMX_FactoryTestCommand_FlashSyncLineStatusRead, /**< Factory test: read flash sync line status. */
    QOMX_FactoryTestCommand_CameraIDRead, /**< Factory test: read camera ID. */
    QOMX_FactoryTestCommand_AFFullSweepModeOn, /**< Factory test: set AF full sweep mode on. */
    QOMX_FactoryTestCommand_AFFullSweepModeOff, /**< Factory test: set AF full sweep mode off. */
    QOMX_FactoryTestCommand_Max = 0x7FFFFFFF
} QOMX_FACTORYTESTCOMMANDTYPE;

#define QOMX_FactoryTestCommand_AFActuatorPositionMicro QOMX_FactoryTestCommand_AFActuatorPositionMacro

/**
 * Flash sync line status.
 */
typedef enum QOMX_FLASHSYNCLINETYPE {
    QOMX_FlashSyncLine_High, /**< Flash sync line high */
   QOMX_FlashSyncLine_Low /**< Flash sync line low */
} QOMX_FLASHSYNCLINETYPE;

/**
 * Auto Focus Assistant light type
 */
typedef enum QOMX_AFASSISTANTLIGHTTYPE{
    QOMX_AFAssistantLightOff,              /**< AF assistant light is off */
    QOMX_AFAssistantLightOn,               /**< AF assistant light is on  */
    QOMX_AFAssistantLightAuto,             /**< AF assistant light is automatic */
    QOMX_AFAssistantLightMax = 0x7FFFFFFF
} QOMX_AFASSISTANTLIGHTTYPE;

/**
 * Focus Range type
 */
typedef enum QOMX_FOCUSRANGETYPE {
    QOMX_FocusRangeAuto = 0,               /**< focus range to be chosen automatically by the component. */
    QOMX_FocusRangeHyperfocal,             /**< focus range to be from half the hyperfocal distance to infinity */
    QOMX_FocusRangeNormal,                 /**< focus range from approximately 40 cm to infinity */
    QOMX_FocusRangeSuperMacro,             /**< focus range from approximately 4 to 10 cm */
    QOMX_FocusRangeMacro,                  /**< focus range from approximately 10 to 50 cm */
    QOMX_FocusRangeInfinity,               /**< focus range to be at infinity */
    QOMX_FocusRangeNormalExtended,         /**< focus range from approximately 10 cm to infinity (ie. macro + normal) */
    QOMX_FocusRangeMax = 0x7FFFFFFF
} QOMX_FOCUSRANGETYPE;

/**
 * White Balance Temperature type
 */
typedef struct QOMX_CONFIG_WHITEBALTEMPERATURETYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_U32 nTemperatureKelvin;
} QOMX_CONFIG_WHITEBALTEMPERATURETYPE;

/**
 * This structure specifies Camera ID information.
 */
typedef struct QOMX_CAMERAIDTYPE {
    OMX_U32 nSensorSiliconID; /** < Camera silicon ID */
    OMX_U32 nModuleID; /**< Camera sensor module ID. */
    OMX_U32 nModuleRevision; /**< Camera sensor module revision. */
} QOMX_CAMERAIDTYPE;

/**
 * This structure is used to send factory test command.
 */
typedef struct QOMX_CONFIG_FACTORYTESTTYPE {
    OMX_U32 nSize; /** < Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information. */
    OMX_U32 nPortIndex; /**< Port that this structure applies to. */
    QOMX_FACTORYTESTCOMMANDTYPE eFactoryTestCommand; /**< Factory command enumerated in QOMX_FACTORYTESTCOMMANDTYPE. */
    OMX_U8 data[1]; /**< First byte of the factory command data. */
} QOMX_CONFIG_FACTORYTESTTYPE;

/**
 * This structure is used to configure max flash current used
 * in flash operations.
 */
typedef struct QOMX_IMAGE_CONFIG_MAXFLASHCURRENTTYPE {
    OMX_U32 nSize; /** < Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information. */
    OMX_U32 nMaxFlashCurrent; /**< The maximum flash current value defined in milli-amperes. */
} QOMX_IMAGE_CONFIG_MAXFLASHCURRENTTYPE;


/**
 * This structure is used to configure auto focus assistant light type
 */
typedef struct QOMX_CONFIG_AFASSISTANTLIGHTTYPE {
    OMX_U32 nSize; /** < Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information. */
    QOMX_AFASSISTANTLIGHTTYPE eAFAssistantLight; /**< Auto focus assistant light type enumerated in QOMX_AFASSISTANTLIGHTTYPE. */
} QOMX_CONFIG_AFASSISTANTLIGHTTYPE;

/**
 * This structure is used to configure focus range
 */
typedef struct QOMX_CONFIG_FOCUSRANGETYPE {
    OMX_U32 nSize; /** < Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information. */
    OMX_U32 nPortIndex; /**< Port that this structure applies to. */
    QOMX_FOCUSRANGETYPE eFocusRange; /**< Focus range enumerated in QOMX_AFASSISTANTLIGHTTYPE. */
} QOMX_CONFIG_FOCUSRANGETYPE;

/**
 * This structure is used to configure auto frame rate range
 */
typedef struct QOMX_CONFIG_AUTOFRAMERATERANGETYPE {
    OMX_U32 nSize; /** < Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information. */
    OMX_U32 nPortIndex; /**< Port that this structure applies to. */
    OMX_U32 xMaxFrameRate; /**< Maximum frame rate in Q16 format. */
    OMX_U32 xMinFrameRate; /**< Minimum frame rate in Q16 format. */
} QOMX_CONFIG_AUTOFRAMERATERANGETYPE;

/**
 * This structure is used to retrieve the shutter speed range supported by the sensor
 */
typedef struct QOMX_CONFIG_SHUTTERSPEEDRANGETYPE {
    OMX_U32 nSize; /** < Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information. */
    OMX_U32 nPortIndex; /**< Port that this structure applies to. */
    OMX_U32 nMaxShutterSpeed; /**< Maximum shutter speed supported by the sensor in microseconds. */
    OMX_U32 nMinShutterSpeed; /**< Minimum shutter speed supported by the sensor in microseconds. */
} QOMX_CONFIG_SHUTTERSPEEDRANGETYPE;

/**
 * This structure is used to retrieve the illuminance value and supported range
 */
typedef struct QOMX_CONFIG_LUXTYPE {
    OMX_U32 nSize; /** < Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information. */
    OMX_U32 nPortIndex; /**< Port that this structure applies to. */
    OMX_BU32 xLux; /**< OMX unsigned bounded value type which contains the lux value and the min/max lux supported by the sensor in Q16 format. */
} QOMX_CONFIG_LUXTYPE;

/**
 * This structure is used to configure the ZSL sharpness window (for considering other frames if they're sharper than the target frame)
 */
typedef struct _OMX_ZSL_SHARPNESSWINDOW {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nSharpnessBeforeMs;
    OMX_U32 nSharpnessAfterMs;
} OMX_ZSL_SHARPNESSWINDOW;

/**
 * This structure is used to control enablement, disablement of HDR feature in camera component
 */
typedef struct QOMX_CONFIG_HIGHDYNAMICRANGECONTROLTYPE {
    OMX_U32 nSize; /** < Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information. */
    OMX_U32 nPortIndex; /**< Port that this structure applies to. */
    OMX_BOOL bEnable; /**< Specifies if HDR feature is enabled. */
} QOMX_CONFIG_HIGHDYNAMICRANGECONTROLTYPE;


/**
 * This structure is used to set camera orientation
 */
typedef struct QOMX_CONFIG_CAMERAORIENTATIONTYPE {
    OMX_U32 nSize;              /** < Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion;   /** < OMX specification version information. */
    OMX_S32 nPitch;             /** < rotation of Camera Pitch in degrees */
    OMX_U32 nRoll;              /** < rotation of Camera Roll in degrees */
    OMX_U32 nYaw;               /** < rotation of Camera Yaw in degrees */
    OMX_U32 nConfidencePitch;   /** < confidence value of nPitch */
    OMX_U32 nConfidenceRoll;    /** < confidence value of nRoll */
    OMX_U32 nConfidenceYaw;     /** < confidence value of nYaw */
} QOMX_CONFIG_CAMERAORIENTATIONTYPE;

/**
 * This structure is used to configure image stabilization type
 */

#define QOMX_IMAGESTABILIZATION_TYPE_MASK_DIS   0x1
#define QOMX_IMAGESTABILIZATION_TYPE_MASK_OIS   0x2

typedef struct QOMX_CONFIG_IMAGESTABILIZATIONCONTROLTYPE {
    OMX_U32 nSize;                                /** < Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion;                     /**< OMX specification version information. */
    OMX_U32 nPortIndex;                           /**< Port that this structure applies to. */
    OMX_U8 nImageStabilizationTypeMask;           /**< Specifies the mask to select IS type. */
} QOMX_CONFIG_IMAGESTABILIZATIONCONTROLTYPE;

#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */

#endif

