#ifndef __H_QOMX_AVCOMMONEXTENSIONS_H__
#define __H_QOMX_AVCOMMONEXTENSIONS_H__ 

/*========================================================================
    Copyright (c) 2009-2011 Qualcomm Technologies, Incorporated.
    All Rights Reserved.
    Qualcomm Confidential and Proprietary.
=========================================================================*/

/**
  @file QOMX_AVCommonExtensions.h 

      Qualcomm audio-video common extensions API for OpenMax IL.

      This file contains the description of the Qualcomm OpenMax IL
      common extention interface for audio & video domains, through which 
      the IL client and OpenMax components can access additional capabilities.
*/
   
/*========================================================================
NOTE: For the output PDF generated using Doxygen and Latex, all file and 
      group descriptions are maintained in the QOMX_Video_Ext_mainpage file. To 
      change any of the the file/group text for the PDF, edit the 
      QOMX_Video_Ext_mainpage file, or contact Tech Pubs.

      The above description for this file is part of the "common_extensions" 
      group description in the QOMX_Video_Ext_mainpage file. 
=========================================================================*/

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/core/public/amss/multimedia/openmax/QOMX_AVCommonExtensions.h#1 $

when       who  what, where, why
--------  ---   ----------------------------------------------------------
02/03/11  sw    (Tech Pubs) Edited/added Doxygen comments and markup.
========================================================================== */
 
/*======================================================================== 
 
                     INCLUDE FILES FOR MODULE 
 
========================================================================== */ 
#include <OMX_Core.h>

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */


/**@addtogroup common_extensions
@{ */
#define OMX_QCOM_INDEX_PARAM_BITRATERANGESUPPORTED    "OMX.QCOM.index.param.BitrateRangeSupported"
        /**< Audio/video common extension strings. nMin, nMax, and nStepSize 
             provide the bitrate in bits per seconds.
 
             Associated structure: QOMX_URANGETYPE. */
/**@} */ /* end_addtogroup common_extensions */


#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */

#endif /* end of macro __H_QOMX_AVCOMMONEXTENSIONS_H__ */
