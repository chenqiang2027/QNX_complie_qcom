/*--------------------------------------------------------------------------
Copyright (c) 2009-2016, The Linux Foundation. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of The Linux Foundation nor
      the names of its contributors may be used to endorse or promote
      products derived from this software without specific prior written
      permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NON-INFRINGEMENT ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
--------------------------------------------------------------------------*/
#ifndef __OMX_QCOM_EXTENSIONS_H__
#define __OMX_QCOM_EXTENSIONS_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*============================================================================
*//** @file OMX_QCOMExtns.h
  This header contains constants and type definitions that specify the
  extensions added to the OpenMAX Vendor specific APIs.

*//*========================================================================*/


///////////////////////////////////////////////////////////////////////////////
//                             Include Files
///////////////////////////////////////////////////////////////////////////////
#include "OMX_Core.h"
#include "OMX_Video.h"
#include "QOMX_VideoExtensions.h"


// Added for camcorder compilation... to be cleaned up as QNX header already has it
enum OMX_QCOM_EXTN_INDEXTYPE
{
    /* "OMX.QCOM.index.param.syntaxhdr" */
    OMX_QcomIndexParamVideoSyntaxHdr = 0x7F000004,

    /* "OMX.QCOM.index.config.intraperiod" */
    OMX_QcomIndexConfigVideoIntraperiod = 0x7F000005,
};

/**
 * This structure describes the parameters corresponding to the 
 * OMX_QCOM_VIDEO_PARAM_SYNTAXHDRTYPE extension. This parameter can be queried
 * during the loaded state. 
 */
typedef struct OMX_QCOM_VIDEO_PARAM_SYNTAXHDRTYPE
{
   OMX_U32 nSize;           /** Size of the structure in bytes */
   OMX_VERSIONTYPE nVersion;/** OMX specification version information */
   OMX_U32 nPortIndex;      /** Portindex which is extended by this structure */

   OMX_U8* pBuff;           /** Buffer to store the header information */
   OMX_U32 nBuffLen;        /** The buffer length in bytes */
   OMX_U32 nFilledLen;      /** The number of bytes filled in to the buffer */
} OMX_QCOM_VIDEO_PARAM_SYNTAXHDRTYPE;


typedef enum OMX_QCOM_INTERLACETYPE
{
    OMX_QCOM_InterlaceFrameProgressive,
    OMX_QCOM_InterlaceInterleaveFrameTopFieldFirst,
    OMX_QCOM_InterlaceInterleaveFrameBottomFieldFirst,
    OMX_QCOM_InterlaceFrameTopFieldFirst,
    OMX_QCOM_InterlaceFrameBottomFieldFirst,
    OMX_QCOM_InterlaceFieldTop,
    OMX_QCOM_InterlaceFieldBottom
}OMX_QCOM_INTERLACETYPE;

typedef struct OMX_QCOM_PARAM_VIDEO_INTERLACETYPE
{
    OMX_U32 nSize;           /** Size of the structure in bytes */
    OMX_VERSIONTYPE nVersion;/** OMX specification version information */
    OMX_U32 nPortIndex;    /** Portindex which is extended by this structure */
    OMX_BOOL bInterlace;  /** Interlace content **/
}OMX_QCOM_PARAM_VIDEO_INTERLACETYPE;

typedef struct OMX_QCOM_CONFIG_INTERLACETYPE
{
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_U32 nIndex;
    OMX_QCOM_INTERLACETYPE eInterlaceType;
}OMX_QCOM_CONFIG_INTERLACETYPE;


typedef enum OMX_QCOM_EXTRADATATYPE
{
    OMX_ExtraDataFrameInfo =               QOMX_ExtraDataVideoUnused,
    OMX_ExtraDataH264,
    OMX_ExtraDataVC1,
    OMX_ExtraDataFrameDimension,
    OMX_ExtraDataVideoEncoderSliceInfo,
    OMX_ExtraDataConcealMB,
    OMX_ExtraDataInterlaceFormat,
    OMX_ExtraDataPortDef,
    OMX_ExtraDataMP2ExtnData,
    OMX_ExtraDataMP2UserData,
    OMX_ExtraDataVideoLTRInfo,
    OMX_ExtraDataFramePackingArrangement,
    OMX_ExtraDataQP,
    OMX_ExtraDataInputBitsInfo,
    OMX_ExtraDataVideoEncoderMBInfo,
    OMX_ExtraDataVQZipSEI,
} OMX_QCOM_EXTRADATATYPE;

typedef struct  OMX_STREAMINTERLACEFORMATTYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_BOOL bInterlaceFormat;
    OMX_U32 nInterlaceFormats;
} OMX_STREAMINTERLACEFORMAT;

typedef enum OMX_INTERLACETYPE
{
   OMX_InterlaceFrameProgressive,
   OMX_InterlaceInterleaveFrameTopFieldFirst,
   OMX_InterlaceInterleaveFrameBottomFieldFirst,
   OMX_InterlaceFrameTopFieldFirst,
   OMX_InterlaceFrameBottomFieldFirst
} OMX_INTERLACES;


#define OMX_EXTRADATA_HEADER_SIZE 20


// Added for comcorder. To be cleaned up as QNX header already has it
/**
 * This structure describes the parameters corresponding to the 
 * OMX_QCOM_VIDEO_CONFIG_INTRAPERIODTYPE extension. This parameter can be set 
 * dynamically during any state except the state invalid.  This is set on the out port.
 */
typedef struct OMX_QCOM_VIDEO_CONFIG_INTRAPERIODTYPE 
{
   OMX_U32 nSize;           /** Size of the structure in bytes */
   OMX_VERSIONTYPE nVersion;/** OMX specification version information */
   OMX_U32 nPortIndex;      /** Portindex which is extended by this structure */
   OMX_U32 nPFrames;        /** The number of "p" frames between two "I" frames */
} OMX_QCOM_VIDEO_CONFIG_INTRAPERIODTYPE;

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __OMX_QCOM_EXTENSIONS_H__ */
