#ifndef __H_QOMX_AUDIOEXTENSIONS_H__
#define __H_QOMX_AUDIOEXTENSIONS_H__

/*========================================================================

*//** @file QOMX_AudioExtensions.h

@par FILE SERVICES:
      Qualcomm extensions API for OpenMax IL Audio.

      This file contains the description of the Qualcomm OpenMax IL
      audio extention interface, through which the IL client and OpenMax
      components can access additional audio capabilities.

    Copyright (c) 2009-2010 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/core/public/amss/multimedia/openmax/QOMX_AudioExtensions.h#1 $

========================================================================== */

/*========================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include <OMX_Audio.h>

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */


/* Audio extension strings */
#define OMX_QCOM_INDEX_PARAM_AMRWBPLUS                          "OMX.Qualcomm.index.audio.amrwbplus"
#define OMX_QCOM_INDEX_PARAM_WMA                                "OMX.Qualcomm.index.audio.wma"
#define OMX_QCOM_INDEX_PARAM_DECID                              "OMX.Qualcomm.index.audio.decId"
#define OMX_QCOM_INDEX_PARAM_STEREOWIDENING                     "OMX.Qualcomm.index.audio.stereowidening"
#define OMX_QCOM_INDEX_PARAM_ADPCM                              "OMX.Qualcomm.index.audio.adpcm"
#define OMX_QCOM_INDEX_PARAM_EVRCB                              "OMX.Qualcomm.index.audio.evrcb"
#define OMX_QCOM_INDEX_PARAM_EVRCWB                             "OMX.Qualcomm.index.audio.evrcwb"
#define OMX_QCOM_INDEX_PARAM_VOICERECORD                        "OMX.Qualcomm.index.audio.VoiceRecord"
#define OMX_QCOM_INDEX_PARAM_DTMFGENERATION                     "OMX.Qualcomm.index.audio.dtmfGeneration"
#define OMX_QCOM_INDEX_CONFIG_VOLUMESTEPPING                    "OMX.Qualcomm.index.audio.config.volumesoftstepping"
#define OMX_QCOM_INDEX_PARAM_CLOCKHANDLE                        "OMX.Qualcomm.index.clockhandle"
#define OMX_QCOM_INDEX_CONFIG_SPECTRUMANALYZERTYPE              "OMX.Qualcomm.index.audio.spectrumanalyzer"
#define OMX_QCOM_INDEX_CONFIG_SPECTRUMANALYZERUPDATETYPE        "OMX.Qualcomm.index.audio.spectrumanalyzer.update"
#define OMX_QCOM_INDEX_PARAM_AUDIO_GAPLESSPLAYBACKTYPE          "OMX.Qualcomm.index.audio.gaplessplayback"
#define OMX_QCOM_INDEX_PARAM_TIMESTAMPSUPPORT                   "OMX.Qualcomm.index.timestampsupport"
#define OMX_QCOM_INDEX_PARAM_HIGHLATENCYBUFFER_CONFIGTYPE       "OMX.Qualcomm.index.audio.highlatencybufferconfig"
#define OMX_QCOM_INDEX_PARAM_FLAC                               "OMX.Qualcomm.index.audio.flac"
#define OMX_QCOM_INDEX_PARAM_NATIVE_DRIVER_INSTANCE_EVENT       "OMX.Qualcomm.index.audio.nativedriverinstanceevent"
#define OMX_QCOM_INDEX_AUDIO_CONFIG_CHANNELCONFIG               "OMX.Qualcomm.index.audio.channelconfig"
#define OMX_QCOM_INDEX_CONFIG_AUDIO_BITRATE                     "OMX.Qualcomm.index.audio.config.bitrate"
#define OMX_QCOM_INDEX_AUDIO_AC3                                "OMX.Qualcomm.index.audio.ac3"
#define OMX_QCOM_INDEX_PARAM_AC3                                "OMX.Qualcomm.index.audio.ac3"
#define OMX_QCOM_INDEX_AUDIO_AC3_DRC_MODE                       "OMX.Qualcomm.index.audio.ac3.drc.mode"
#define OMX_QCOM_INDEX_CONFIG_AUDIO_AC3_DRC_MODE                "OMX.Qualcomm.index.audio.ac3.drc.mode"
#define OMX_QCOM_INDEX_AUDIO_AC3_KARAOKE_MODE                   "OMX.Qualcomm.index.audio.ac3.karaoke.mode"
#define OMX_QCOM_INDEX_CONFIG_AUDIO_AC3_KARAOKE_MODE            "OMX.Qualcomm.index.audio.ac3.karaoke.mode"
#define OMX_QCOM_INDEX_CONFIG_AUDIO_DUALMONO_MODE               "OMX.Qualcomm.index.audio.dualmono"
#define OMX_QCOM_INDEX_CONFIG_AUDIO_DOWNMIX_MODE                "OMX.Qualcomm.index.audio.downmix.mode"
#define OMX_QCOM_INDEX_AUDIO_MP2                                "OMX.Qualcomm.index.audio.mp2"
#define OMX_QCOM_INDEX_CONFIG_AUDIO_SKIP_SILENCE_SAMPLES        "OMX.Qualcomm.index.audio.skip.silence.samples"
#define OMX_QCOM_INDEX_AUDIO_ALAC                               "OMX.Qualcomm.index.audio.alac"


typedef enum QOMX_AUDIO_DRIVER_INSTANCE_EVENTTYPE {
   QOMX_HANDLE_RELEASED_IN_IDLE = 0x01,
   QOMX_HANDLE_RETAINED_IN_IDLE = 0x02
}QOMX_AUDIO_DRIVER_INSTANCE_EVENTTYPE;

/**
 * Native Driver Instance Event Type
 * STRUCTURE MEMBERS
 * nSize       : Size of the structure in bytes
 * nVersion    : OMX specific version information
 * nEventType  : Event type which describes the behavior of the event
*/

typedef struct QOMX_AUDIO_PARAM_NATIVE_DRIVER_INSTANCE_EVENTTYPE {
   OMX_U32 nSize; 
   OMX_VERSIONTYPE nVersion;
   QOMX_AUDIO_DRIVER_INSTANCE_EVENTTYPE nEventType;
}QOMX_AUDIO_PARAM_NATIVE_DRIVER_INSTANCE_EVENTTYPE;


/** QOMX_EventNativeDriverInstance shares same value as QOMX_EventParamOrConfigChanged defined in QOMX_CamExtension.h
This is a generic callback to indicate when a cad handle param is set.
Associated EventMsg is MMI_ExtSpecificMsgType. EvtMsg Settings are as shown
    EvtMsg.eEvent = QOMX_EventNativeDriverInstance;   // OMX_EVENTTYPE OMX_EventCmdComplete;
    EvtMsg.nData1 = Handle Type;                    // QOMX_AUDIO_NATIVE_DRIVER_HANDLETYPE
    EvtMsg.nData2 = pD->hCadSession;                  // Additional Status info for Event (CAD Handle)
    EvtMsg.pEventData = NULL;                         // Data Associated with the Event
*/
#define QOMX_EventNativeDriverInstance  ((OMX_EVENTTYPE)((int)OMX_EventVendorStartUnused + 1))  /** 0x7F000001 < extension event for native driver (cad_handle) notfication > **/

typedef enum QOMX_AUDIO_NATIVE_DRIVER_HANDLETYPE {
   QOMX_AUDIO_NativeDriverHandleInvalid = 0x0,
   QOMX_AUDIO_NativeDriverHandleTx      = 0x1,
   QOMX_AUDIO_NativeDriverHandleRx      = 0x2,
   QOMX_AUDIO_NativeDriverHandleTxRx    = 0x3,
}QOMX_AUDIO_NATIVE_DRIVER_HANDLETYPE;

typedef enum QOMX_AUDIO_CODINGTYPE {
   QOMX_AUDIO_CodingVendorStartUnused = 0x7F000000, /**< Reserved region for introducing Vendor Extensions */
   QOMX_AUDIO_CodingEVRCB  = 0x7F000001,
   QOMX_AUDIO_CodingEVRCWB = 0x7F000002,
   QOMX_AUDIO_CodingFLAC   = 0x7F000003,
   QOMX_AUDIO_CodingAC3    = 0x7F000004,
   QOMX_AUDIO_CodingMP2    = 0x7F000005,
   QOMX_AUDIO_CodingALAC   = 0x7F000006,
   QOMX_AUDIO_CodingMax = 0x7FFFFFFF
}QOMX_AUDIO_CODINGTYPE;

typedef enum QOMX_AUDIO_AMRBANDMODETYPE {
    QOMX_AUDIO_AMRBandModeWB9              = 0x7F000001,/**< AMRWB Mode 9 = SID*/
    QOMX_AUDIO_AMRBandModeWB10             = 0x7F000002,/**< AMRWB Mode 10 = 13600 bps */
    QOMX_AUDIO_AMRBandModeWB11             = 0x7F000003,/**< AMRWB Mode 11 = 18000 bps */
    QOMX_AUDIO_AMRBandModeWB12             = 0x7F000004,/**< AMRWB Mode 12 = 24000 bps */
    QOMX_AUDIO_AMRBandModeWB13             = 0x7F000005,/**< AMRWB Mode 13 = 24000 bps */
    QOMX_AUDIO_AMRBandModeWB14             = 0x7F000006,/**< AMRWB Mode 14 = FRAME_ERASE*/
    QOMX_AUDIO_AMRBandModeWB15             = 0x7F000007,/**< AMRWB Mode 15 = NO_DATA */
    QOMX_AUDIO_AMRBandModeMax = 0x7FFFFFFF
}QOMX_AUDIO_AMRBANDMODETYPE;

/**
 * AMR WB PLUS type
 *
 *  STRUCT MEMBERS:
 *  nSize           : Size of the structure in bytes
 *  nVersion        : OMX specification version information
 *  nPortIndex      : Port that this structure applies to
 *  nChannels       : Number of channels
 *  nBitRate        : Bit rate read only field
 *  eAMRBandMode    : AMR Band Mode enumeration
 *  eAMRDTXMode     : AMR DTX Mode enumeration
 *  eAMRFrameFormat : AMR frame format enumeration
 *  nSampleRate     : Sampling frequency for the clip(16/24/32/48KHz)
 */

typedef struct QOMX_AUDIO_PARAM_AMRWBPLUSTYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_U32 nChannels;
    OMX_U32 nBitRate;
    OMX_AUDIO_AMRBANDMODETYPE    eAMRBandMode;
    OMX_AUDIO_AMRDTXMODETYPE     eAMRDTXMode;
    OMX_AUDIO_AMRFRAMEFORMATTYPE eAMRFrameFormat;
    OMX_U32 nSampleRate;
} QOMX_AUDIO_PARAM_AMRWBPLUSTYPE;

typedef enum QOMX_AUDIO_WMAFORMATTYPE {
    OMX_AUDIO_WMAFormat9_Lossless      = 0x7F000001, /**< Windows Media Audio Format 9 Lossless */
    OMX_AUDIO_WMAFormat10_Professional = 0x7F000002  /**<Windows Media Audio 10 Professional */
} QOMX_AUDIO_WMAFORMATTYPE;



/**
 * WMA 10 PRO type
 *
 *  STRUCT MEMBERS:
 *  nSize               : Size of the structure in bytes
 *  nVersion            : OMX specification version information
 *  nPortIndex          : Port that this structure applies to
 *  nChannels           : Number of channels
 *  nBitRate            : Bit rate read only field
 *  eFormat             : Version of WMA stream / data
 *  eProfile            : Profile of WMA stream / data
 *  nSamplingRate       : Sampling rate of the source data
 *  nBlockAlign         : block alignment, or block size, in bytes of the audio codec
 *  nEncodeOptions      : WMA Type-specific data
 *  nSuperBlockAlign    : WMA Type-specific data
 *  nBitsPerSample      : encoded stream (24-bit or 16-bit)
 *  formatTag           : codec ID(0x162 or 0x166)
 *  nAdvancedEncodeOpt  : bit packed words indicating the features supported for LBR bitstream
 *  nAdvancedEncodeOpt2 : bit packed words indicating the features supported for LBR bitstream
 */
typedef struct QOMX_AUDIO_PARAM_WMATYPE {
   OMX_U32 nSize;
   OMX_VERSIONTYPE nVersion;
   OMX_U32 nPortIndex;
   OMX_U16 nChannels;
   OMX_U32 nBitRate;
   OMX_AUDIO_WMAFORMATTYPE  eFormat;
   OMX_AUDIO_WMAPROFILETYPE eProfile;
   OMX_U32 nSamplingRate;
   OMX_U16 nBlockAlign;
   OMX_U16 nEncodeOptions;
   OMX_U32 nSuperBlockAlign;
   OMX_U32 nBitsPerSample;
   OMX_U32 nAdvancedEncodeOpt;
   OMX_U32 nAdvancedEncodeOpt2;
   OMX_U32 nChannelMask;
} QOMX_AUDIO_PARAM_WMATYPE;

/**
 * DRC type
 *
 *  STRUCT MEMBERS:
 *  nSize                : Size of the structure in bytes
 *  nVersion             : OMX specification version information
 *  nPortIndex           : Port that this structure applies to
 *  nDrcPeakReference    : Dynamic Range Control Peak reference
 *  nDrcPeakTarget       : Dynamic Range Control Peak target
 *  nDrcAverageReference : Dynamic Range Control Average Reference
 *  nDrcAverageTarget    : Dynamic Range Control Average Target

 */

typedef struct QOMX_AUDIO_PARAM_DRCTYPE {
   OMX_U32 nSize;
   OMX_VERSIONTYPE nVersion;
   OMX_U32 nPortIndex;
   OMX_U32 nDrcPeakReference;
   OMX_U32 nDrcPeakTarget;
   OMX_U32 nDrcAverageReference;
   OMX_U32 nDrcAverageTarget;
}QOMX_AUDIO_PARAM_DRCTYPE;



/**
 * Stream info data
 *
 *  STRUCT MEMBERS:
 *  decId :  decoder Id for alsa to route data
 */
typedef struct QOMX_AUDIO_STREAM_INFO_DATA {
    OMX_U8  decId;
} QOMX_AUDIO_STREAM_INFO_DATA;

typedef enum QOMX_AUDIO_STEREOWIDENING_TYPE
{
   QOMX_AUDIO_StereoWideningHeadPhones,
   QOMX_AUDIO_StereoWideningNarrowMobileSpeakers,
   QOMX_AUDIO_StereoWideningWideMobileSpeakers,
   QOMX_AUDIO_StereoWideningDesktopSpeakers,
   QOMX_AUDIO_StereoWideningMax
} QOMX_AUDIO_STEREOWIDENING_TYPE;

typedef enum QOMX_AUDIO_STEREOWIDENING_PRESET
{
    QOMX_AUDIO_STEREOWIDENING_PRESET_SMALLROOM,
    QOMX_AUDIO_STEREOWIDENING_PRESET_MEDIUMROOM,
    QOMX_AUDIO_STEREOWIDENING_PRESET_MEDIUMHALL,
    QOMX_AUDIO_STEREOWIDENING_PRESET_CONCERTHALL,
    QOMX_AUDIO_STEREOWIDENING_PRESET_SURROUND,
    QOMX_AUDIO_STEREOWIDENING_PRESET_WARMSTAGE,
    QOMX_AUDIO_STEREOWIDENING_PRESET_CRYSTAL,
    QOMX_AUDIO_STEREOWIDENING_PRESET_LIVINGROOM,
    QOMX_AUDIO_STEREOWIDENING_PRESET_MAX
} QOMX_AUDIO_STEREOWIDENING_PRESET;

typedef struct QOMX_AUDIO_CONFIG_STEREOWIDENINGTYPE {

   OMX_U32                            nSize;
   OMX_VERSIONTYPE                    nVersion;
   OMX_U32                            nPortIndex;
   OMX_BOOL                           bEnable;
   QOMX_AUDIO_STEREOWIDENING_TYPE     eWideningType;
   QOMX_AUDIO_STEREOWIDENING_PRESET   ePreset;
   OMX_U32                            nStrength;
}QOMX_AUDIO_CONFIG_STEREOWIDENINGTYPE;

/** ADPCM stream format parameters */
typedef struct QOMX_AUDIO_PARAM_ADPCMTYPE {
    OMX_U32 nSize;              /**< size of the structure in bytes */
    OMX_VERSIONTYPE nVersion;   /**< OMX specification version information */
    OMX_U32 nPortIndex;         /**< port that this structure applies to */
    OMX_U32 nChannels;          /**< Number of channels in the data stream (not
                                     necessarily the same as the number of channels
                                     to be rendered. */
    OMX_U32 nBitsPerSample;     /**< Number of bits in each sample */
    OMX_U32 nSampleRate;        /**< Sampling rate of the source data.  Use 0 for
                                    variable or unknown sampling rate. */
    OMX_U32 nBlockSize;         /**< ADPCM block encoding size present in format header */
} QOMX_AUDIO_PARAM_ADPCMTYPE;


/**
 * Voice record mode type
 */
typedef enum QOMX_AUDIO_VOICERECORDMODETYPE {
   QOMX_AUDIO_VOICE_TX              = 0x7F000001, /**< Record voice call Tx */
   QOMX_AUDIO_VOICE_RX              = 0x7F000002, /**< Record voice call Rx */
   QOMX_AUDIO_VOICE_MIXED           = 0x7F000003, /**< Record voice call Tx/Rx mixed */
} QOMX_AUDIO_VOICERECORDMODETYPE;


/**
 * Voice record type
 *
 *  STRUCT MEMBERS:
 *  nSize              : Size of the structure in bytes
 *  nVersion           : OMX specification version information
 *  bVoiceRecordEnabled: flag to enable/disable voice record
 *  eVoiceRecordMode   : voice record mode
 */
typedef struct QOMX_AUDIO_CONFIG_VOICERECORDTYPE {
   OMX_U32                            nSize;
   OMX_VERSIONTYPE                    nVersion;
   OMX_BOOL                           bVoiceRecordEnabled;
   QOMX_AUDIO_VOICERECORDMODETYPE     eVoiceRecordMode;
}  QOMX_AUDIO_CONFIG_VOICERECORDTYPE;

typedef enum QOMX_AUDIO_DTMFPATHTYPE {
   QOMX_AUDIO_DTMFGEN_PATH_LOCAL = 0,
   QOMX_AUDIO_DTMFGEN_PATH_TRANSMIT,
   QOMX_AUDIO_DTMFGEN_PATH_ALL
} QOMX_AUDIO_DTMFPATHTYPE;
/**
  * Dtmf Generation type
  *
  * STRUCT MEMBERS:
  * nSize              : Size of the structure in bytes
  * nVersion           : OMX specification version information
  * nPortIndex         : Port index
  * ePath              : DTMF Generation path Rx
  * nHighFrequency     : High Frequency for the tone
  * nLowFrequency      : Low Frequency for the tone
  * bLinear            : TRUE:nGain is Liner(0-100);FALSE:nGain is logarithmic(mB)
  * nGain              : Volume level for the Rx tone
  * nDuration          : Duration of the tone in ms
                        (>0 - Duration time applicable in ms ; <0 Continous tone; =0 Stop the tone)
  * bPCMOutput         : PCM output is enbled on output port
  */

typedef struct QOMX_AUDIO_PARAM_DTMFGENTYPE
{
   OMX_U32  nSize;
   OMX_VERSIONTYPE nVersion;
   OMX_U32  nPortIndex;
   QOMX_AUDIO_DTMFPATHTYPE ePath;
   OMX_U16  nHighFrequency;
   OMX_U16  nLowFrequency;
   OMX_BOOL bLinear;
   OMX_BS32 nGain;
   OMX_S16  nDuration;
   OMX_BOOL bPCMOutput;
} QOMX_AUDIO_PARAM_DTMFGENTYPE;

/* Note: This may get changed to enum */

#define QOMX_AUDIO_SOFTSTEPPING_RAMPINGCURVE_LINEAR 0
#define QOMX_AUDIO_SOFTSTEPPING_RAMPINGCURVE_EXP 1
#define QOMX_AUDIO_SOFTSTEPPING_RAMPINGCURVE_LOG 2
/**
  * Volume soft stepping type
  *
  * STRUCT MEMBERS:
  * nSize              : Size of the structure in bytes
  * nVersion           : OMX specification version information
  * nPortIndex         : Port index
  * nRampPeriod        : Ramping time for volume change from current level to target level in
                         milliseconds. Value 0 indicates soft stepping is disabled.
  * nStepPeriod        : Duration for which the intermediate volume level is held during the ramping.
                         It is measured in milliseconds.
  * nRampingCurve      : Ramping curve for the rampup and rampdown in volume levels.
                         QOMX_AUDIO_SOFTSTEPPING_RAMPINGCURVE_LINEAR
                         QOMX_AUDIO_SOFTSTEPPING_RAMPINGCURVE_EXP
                         QOMX_AUDIO_SOFTSTEPPING_RAMPINGCURVE_LOG
  */
typedef struct QOMX_AUDIO_VOLUMESTEPPINGTYPE
{
   OMX_U32 nSize;
   OMX_VERSIONTYPE nVersion;
   OMX_U32 nPortIndex;
   OMX_U32 nRampPeriod;
   OMX_U32 nStepPeriod;
   OMX_U32 nRampingCurve;
}QOMX_AUDIO_VOLUMESTEPPINGTYPE;

/*
This is common extension for Audio and Video
should be placed in common area
*/
typedef struct QOMX_CLOCK_PARAM_HANDLETYPE {
   OMX_U32           nSize;
   OMX_VERSIONTYPE   nVersion;
   OMX_HANDLETYPE    pClockHandle;
   OMX_U32           nClockPortIndex;
} QOMX_CLOCK_PARAM_HANDLETYPE;

/**
  * Spectrum Analyzer
  *
  * STRUCT MEMBERS:
  * nSize                  : Size of the structure in bytes
  * nVersion               : OMX specification version information
  * nEnable                : Enable or disable the post proc
  * nUpdateRate            : Update interval for the spa updates
  * nNumSpectralPoints     : Number of spa coefficients
  * nSpectralPointSize     : Size of Each SPA Coefficient
  */
typedef struct QOMX_AUDIO_CONFIG_SPECTRUMANALYZERTYPE
{
   OMX_U32         nSize;
   OMX_VERSIONTYPE nVersion;
   OMX_BOOL        nEnable;               /**< Variable to Enable/Disable the SPA Filter PostProc */
   OMX_U16         nSampleInterval;       // will be depricated soon
   OMX_U16         nNumCoeff;             // will be depricated soon
   OMX_BU32        nUpdateRate;           /**< Time Interval for Getting the SPA Update (in MHz)  */
   OMX_BU32        nNumSpectralPoints;    /**< Number of Spectral Coefficients to be read   */
   OMX_U8          nSpectralPointSize;    /**< Size of Each Spectral Coefficient (in Bytes) */
} QOMX_AUDIO_CONFIG_SPECTRUMANALYZERTYPE;


/**
  * STRUCT MEMBERS:
  * nSize               : Size of the structure in bytes
  * nVersion            : OMX specification version information
  * nPortIndex          : Port index that it applies to
  * nDataSize           : Size of the coefficients that will be sent
  * nData               : Data
  */
typedef struct QOMX_AUDIO_CONFIG_SPECTRUMANALYZERUPDATETYPE
{
   OMX_U32         nSize;
   OMX_VERSIONTYPE nVersion;
   OMX_U32         nPortIndex;
   OMX_U32         nDataSize;
   OMX_U8          nData[1];
} QOMX_AUDIO_CONFIG_SPECTRUMANALYZERUPDATETYPE;

/**
  * STRUCT MEMBERS:
  * nSize               : Size of the structure in bytes
  * nVersion            : OMX specification version information
  * nPortIndex          : Port index that it applies to
  * bGaplessPlaybackMode: Enable the feature
  */

typedef struct QOMX_AUDIO_PARAM_GAPLESS_PLAYBACKTYPE
{
   OMX_U32         nSize;
   OMX_VERSIONTYPE nVersion;
   OMX_U32         nPortIndex;
   OMX_BOOL        bGaplessPlaybackMode;
}QOMX_AUDIO_PARAM_GAPLESS_PLAYBACKTYPE;


/**
* AV SYNC - TimeStampSupport
*
* STRUCT MEMBERS:
* nSize                  : Size of the structure in bytes
* nVersion               : OMX specification version information
* bValid                 : Boolean for valid or not
*/
typedef struct QOMX_TIMESTAMP_SUPPORT_PARAMTYPE {
   OMX_U32         nSize;
   OMX_VERSIONTYPE nVersion;
   OMX_BOOL        bValid;
} QOMX_TIMESTAMP_SUPPORT_PARAMTYPE;

/**
  * STRUCT MEMBERS:
  * nSize               : Size of the structure in bytes
  * nVersion            : OMX specification version information
  * nPortIndex          : Port to enable/disable HLB on
  * bEnableHighLatencyBuffer: OMX_TRUE : enable HLB for the session
  *                         : OMX_FALSE: disable HLB for the session
  * bEnableAutoLLBSwitch: OMX_TRUE : switch automatically to LLB on HLB acquire fail
  *                       OMX_FALSE: notify the HLB acquire fail to client
  */
typedef struct QOMX_AUDIO_PARAM_HIGHLATENCYBUFFER_CONFIGTYPE
{
    OMX_U32         nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32         nPortIndex;
    OMX_BOOL        bEnableHighLatencyBuffer;
    OMX_BOOL        bEnableAutoLLBSwitch;
} QOMX_AUDIO_PARAM_HIGHLATENCYBUFFER_CONFIGTYPE;


/** Qualcomm FLAC params
  * bIsStreamInfoPresent : METADATA_BLOCK_STREAMINFO is successfully parsed by the ARM or not
  * nNumChannels         : number of channels
  * nMinBlockSize        : minimum block size (in samples)
  * nMaxBlockSize        : mamimum block size (in samples)
  * nSampleSize          : Bits per sample
  * nSampleRate          : Sampling rate in Hz
  * nMinFrameSize        : minimum frame size (in bytes)
  * nMaxFrameSize        : maximum frame size (in bytes)
  * nMd5Sum              : MD5 signature of the unencoded audio data
  */
typedef struct QOMX_AUDIO_PARAM_FLACTYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32    nPortIndex;
    OMX_BOOL   bIsStreamInfoPresent;
    OMX_U32    nMinBlockSize;
    OMX_U32    nMaxBlockSize;
    OMX_U16    nNumChannels;
    OMX_U16    nSampleSize;
    OMX_U32    nSampleRate;
    OMX_U16    nMd5Sum[8];
} QOMX_AUDIO_PARAM_FLACTYPE;


typedef enum QOMX_AUDIO_CHANNELTYPE {
    QOMX_AUDIO_ChannelVendorStartUnused = 0x7F000000, /**< Reserved region for introducing Vendor Extensions */
    QOMX_AUDIO_ChannelLCF  = 0x7F000001,    /**< Left of center front. */
    QOMX_AUDIO_ChannelRCF  = 0x7F000002,    /**< Right of center front. */
    QOMX_AUDIO_ChannelLHS  = 0x7F000003,    /**< Left (Hand) side. */
    QOMX_AUDIO_ChannelRHS  = 0x7F000004,    /**< Right (Hand) side. */
    QOMX_AUDIO_ChannelCT   = 0x7F000005,    /**< Center top. */
    QOMX_AUDIO_ChannelFLT  = 0x7F000006,    /**< Front left top. */
    QOMX_AUDIO_ChannelFCT  = 0x7F000007,    /**< Front center top. */
    QOMX_AUDIO_ChannelFRT  = 0x7F000008,    /**< Front right top. */
    QOMX_AUDIO_ChannelBLT  = 0x7F000009,    /**< Back left top. */
    QOMX_AUDIO_ChannelBCT  = 0x7F00000A,    /**< Back center top. */
    QOMX_AUDIO_ChannelBRT  = 0x7F00000B,    /**< Back right top. */
    QOMX_AUDIO_ChannelMax  = 0x7FFFFFFF 
} QOMX_AUDIO_CHANNELTYPE;

#define QOMX_AUDIO_MAXCHANNELS 36
/**
 * CHANNEL MAPPING type
 *
 *  STRUCT MEMBERS:
 *  nSize               : Size of the structure in bytes
 *  nVersion            : OMX specification version information
 *  nPortIndex          : Port that this structure applies to
 *  nChannels           : Number of channels
 *  nChannelsMapping    : channel mapping array
 */
typedef struct QOMX_AUDIO_CONFIG_CHANNELCONFIGTYPE
{
    OMX_U32 nSize;            
    OMX_VERSIONTYPE nVersion; 
    OMX_U32 nPortIndex;       
    OMX_U32 nChannels;
    QOMX_AUDIO_CHANNELTYPE eChannelMapping[QOMX_AUDIO_MAXCHANNELS];
} QOMX_AUDIO_CONFIG_CHANNELCONFIGTYPE;

/** Qualcomm Audio Config Bitrate params
  * nSize               : Size of the structure in bytes
  * nVersion            : OMX specification version information
  * nPortIndex          : Port index that it applies to
  * nEncodeBitrate      : The new bitrate to be used by the encoder
  */
typedef struct QOMX_AUDIO_CONFIG_BITRATETYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_U32 nEncodeBitrate;
} QOMX_AUDIO_CONFIG_BITRATETYPE;



/**
 * AC3 Format Type
 */
typedef enum QOMX_AUDIO_AC3FORMATTYPE {
   QOMX_AUDIO_AC3       = 0x7F000001, /**< AC-3 */
   QOMX_AUDIO_EAC3      = 0x7F000002  /**< EAC-3 */
} QOMX_AUDIO_AC3FORMATTYPE;


/**
 * AC3 Bitstream mode
 */
typedef enum QOMX_AUDIO_AC3_BITSTREAM_MODE
{
   QOMX_AUDIO_AC3_BSMODE_CM = 0, /** Complete Main */
   QOMX_AUDIO_AC3_BSMODE_ME,     /** Music and effects */
   QOMX_AUDIO_AC3_BSMODE_VI,     /** Visually Impaired */
   QOMX_AUDIO_AC3_BSMODE_HI,     /** Hearing Impaired */
   QOMX_AUDIO_AC3_BSMODE_D,      /** Dialogue */
   QOMX_AUDIO_AC3_BSMODE_C,      /** Commentary */
   QOMX_AUDIO_AC3_BSMODE_E,      /** Emergency */
   QOMX_AUDIO_AC3_BSMODE_VO      /** Voice Over */
} QOMX_AUDIO_AC3_BITSTREAM_MODE;

/**
 * AC3 Audio Coding mode
 */
typedef enum QOMX_AUDIO_AC3_AUDIO_CODING_MODE
{
   QOMX_AUDIO_AC3_ACMODE_1_1 = 0, /** Ch1 , CH2  - dual mono*/
   QOMX_AUDIO_AC3_ACMODE_1_0,     /** Center (C) */
   QOMX_AUDIO_AC3_ACMODE_2_0,     /** Left, Right */
   QOMX_AUDIO_AC3_ACMODE_3_0,     /** Left, Center, Right */
   QOMX_AUDIO_AC3_ACMODE_2_1,     /** Left, Right, Surround */
   QOMX_AUDIO_AC3_ACMODE_3_1,     /** Left, Center, Right, Surround */
   QOMX_AUDIO_AC3_ACMODE_2_2,     /** Left, Right, Surround Left, Surround Right */
   QOMX_AUDIO_AC3_ACMODE_3_2,     /** Left, Center, Right, Surround Left, Surround Right */
} QOMX_AUDIO_AC3_AUDIO_CODING_MODE;

/** Qualcomm Audio Config Bitrate params
  * nSize               : Size of the structure in bytes
  * nVersion            : OMX specification version information
  * nPortIndex          : Port index that it applies to
  * nChannels           : Number of channels 
  * nBitRate            : Bitrate of the clip 
  * nSamplingRate       : Sampling rate of the clip 
  * eFormat             : AC-3 or eAC-3 
  * nProgramID          : which audio program should be played. 
  *                       AC3 support maximum 8 program, 0-7
  * eBitStreamMode      : bit stream mode (bsmod) of the clip 
  * eAudioCodingMode    : audio coding mode (acmod) of the clip
  */
typedef struct QOMX_AUDIO_PARAM_AC3TYPE {
   OMX_U32 nSize;            
   OMX_VERSIONTYPE nVersion;
   OMX_U32 nPortIndex;
   OMX_U16 nChannels;
   OMX_U32 nBitRate;
   OMX_U32 nSamplingRate;
   QOMX_AUDIO_AC3FORMATTYPE eFormat;
   OMX_U8 nProgramID;   
   QOMX_AUDIO_AC3_BITSTREAM_MODE eBitStreamMode;
   QOMX_AUDIO_AC3_AUDIO_CODING_MODE eAudioCodingMode;
} QOMX_AUDIO_PARAM_AC3TYPE;

/**
 * AC3 Audio DRC modes
 */
typedef enum QOMX_AUDIO_AC3_DRC_MODE
{
   QOMX_AUDIO_AC3_DRC_MODE_RF_MODE,
   QOMX_AUDIO_AC3_DRC_MODE_LINE_OUT,
   QOMX_AUDIO_AC3_DRC_MODE_ANALOG_DIALNORM,
   QOMX_AUDIO_AC3_DRC_MODE_DIGITAL_DIALNORM,
} QOMX_AUDIO_AC3_DRC_MODE;


/** Qualcomm Audio Config ACE DRC mode type
  * nSize               : Size of the structure in bytes
  * nVersion            : OMX specification version information
  * nPortIndex          : Port index that it applies to
  * eDRCMode            : Dynamic Range Control mode.
  * usDynamicScaleBoost : for increasing the level of the quiet sounds.  
                          Percentage between 0 and 100 (Default value is 100).
  * usDynamicScaleCut   : to reduce the level of the loudest sounds.  
                          Percentage between 0 and 100 (Default value is 100).  
  */
typedef struct QOMX_AUDIO_CONFIG_AC3_DRC_MODE_TYPE
{
   OMX_U32 nSize;            
   OMX_VERSIONTYPE nVersion;
   OMX_U32 nPortIndex;
   QOMX_AUDIO_AC3_DRC_MODE eDRCMode;
   OMX_U32 usDynamicScaleBoost;
   OMX_U32 usDynamicScaleCut;
} QOMX_AUDIO_CONFIG_AC3_DRC_MODE_TYPE;   

/**
 * AC3 Audio Karaoke modes
 */
typedef enum QOMX_AUDIO_AC3_KARAOKE_MODE
{
   QOMX_AUDIO_AC3_KARAOKE_MODE_NO_VOCAL,
   QOMX_AUDIO_AC3_KARAOKE_MODE_LEFT_VOCAL,
   QOMX_AUDIO_AC3_KARAOKE_MODE_RIGHT_VOCAL,
   QOMX_AUDIO_AC3_KARAOKE_MODE_BOTH_VOCAL,
} QOMX_AUDIO_AC3_KARAOKE_MODE;

/** Qualcomm Audio Config ACE DRC mode type  
  * nSize               : Size of the structure in bytes
  * nVersion            : OMX specification version information
  * nPortIndex          : Port index that it applies to
  * eKaraokeMode        : Decoder behavior when handling Karaoke frames in the bitstream. 
  */
typedef struct QOMX_AUDIO_CONFIG_AC3_KARAOKE_MODE_TYPE
{
   OMX_U32 nSize;            
   OMX_VERSIONTYPE nVersion;
   OMX_U32 nPortIndex;
   QOMX_AUDIO_AC3_KARAOKE_MODE eKaraokeMode;
} QOMX_AUDIO_CONFIG_AC3_KARAOKE_MODE_TYPE;


/* Enum for mapping dual-mono contents to left and right channels */
typedef enum QOMX_AUDIO_DUAL_MONO_CHANNEL_CONFIG {
   OMX_AUDIO_DUAL_MONO_MODE_FL_FR,/* 1st SCE to left & right */
   OMX_AUDIO_DUAL_MONO_MODE_SL_SR,/* 2nd SCE to left & right */
   OMX_AUDIO_DUAL_MONO_MODE_SL_FR,/* 2nd SCE to left, 1st SCE to right */
   OMX_AUDIO_DUAL_MONO_MODE_FL_SR,/* 1st SCE to left, 2nd SCE to right default */
   OMX_AUDIO_DUAL_MONO_MODE_MIXED,/* 1st SCE and 2nd SCE equally mixed to both left and right */
   OMX_AUDIO_DUAL_MONO_MODE_DEFAULT = OMX_AUDIO_DUAL_MONO_MODE_FL_SR
} QOMX_AUDIO_DUAL_MONO_CHANNEL_CONFIG;

/** 
 *  Qualcomm Audio Config DUAL-MONO mode type
 * 
 *  STRUCT MEMBERS:
 *  nSize               : Size of the structure in bytes
 *  nVersion            : OMX specification version information
 *  nPortIndex          : Port that this structure applies to
 *  eChannelConfig      : Setting for the Dual mono mode
 * 
 */
typedef struct QOMX_AUDIO_PARAM_DUALMONOTYPE {
   OMX_U32 nSize;            
   OMX_VERSIONTYPE nVersion;
   OMX_U32 nPortIndex;
   QOMX_AUDIO_DUAL_MONO_CHANNEL_CONFIG eChannelConfig;
} QOMX_AUDIO_PARAM_DUALMONOTYPE;


/**
 * Audio Downmix modes
 */
typedef enum QOMX_AUDIO_DOWNMIX_MODE
{
   QOMX_AUDIO_STEREO_MODE_AUTO_DETECT,
   QOMX_AUDIO_SURROUND_STEREO_PAIR,     /** Left Total , Right Total */
   QOMX_AUDIO_CONVENTIONAL_STEREO_MODE, /** Left Only , Right Only */
} QOMX_AUDIO_DOWNMIX_MODE;


/** 
 *  Qualcomm Audio Config Downmix mode type  
 * 
 *  STRUCT MEMBERS:
 *  nSize               : Size of the structure in bytes
 *  nVersion            : OMX specification version information
 *  nPortIndex          : Port that this structure applies to
 *  eChannelConfig      : Setting for the Dual mono mode
 * 
 */
typedef struct QOMX_AUDIO_CONFIG_DOWNMIX_MODE_TYPE
{
   OMX_U32 nSize;            
   OMX_VERSIONTYPE nVersion;
   OMX_U32 nPortIndex;
   QOMX_AUDIO_DOWNMIX_MODE eDownMixMode;
} QOMX_AUDIO_CONFIG_DOWNMIX_MODE_TYPE;

/**
 * MP2 STREAM FORMAT TYPE
 *
 *  ENUM MEMBERS:
 *  QOMX_AUDIO_MP2StreamFormatMP1Layer2 : MPEG1 Layer2 Stream format
 *  QOMX_AUDIO_MP2StreamFormatMP2Layer2 : MPEG2 Layer2 Stream format
 *
 */
typedef enum QOMX_AUDIO_MP2STREAMFORMATTYPE {
    QOMX_AUDIO_MP2StreamFormatMP1Layer2 = 0,
    QOMX_AUDIO_MP2StreamFormatMP2Layer2
} QOMX_AUDIO_MP2STREAMFORMATTYPE;

/**
 * MP2 TYPE
 *
 *  STRUCT MEMBERS:
 *  nSize               : Size of the structure in bytes.
 *  nVersion            : OMX specification version information.
 *  nPortIndex          : Port that this structure applies to.
 *  nChannels           : Number of channels.
 *  nBitRate            : Bit rate of the input data. Use 0 for
 *                        variable rate or unknown bit rates.
 *  nSampleRate         : Sampling rate of the source data. Use 0 for
 *                        variable or unknown sampling rate.
 *  nAudioBandWidth     : Audio band width (in Hz) to which an encoder
 *                        should limit the audio signal. Use 0 to let
 *                        encoder decide.
 *  eChannelMode        : Channel mode enumeration.
 *  eFormat             : MP2 stream format.
 *
 */
typedef struct QOMX_AUDIO_PARAM_MP2TYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_U32 nChannels;
    OMX_U32 nBitRate;
    OMX_U32 nSampleRate;
    OMX_U32 nAudioBandWidth;
    OMX_AUDIO_CHANNELMODETYPE eChannelMode;
    QOMX_AUDIO_MP2STREAMFORMATTYPE eFormat;
} QOMX_AUDIO_PARAM_MP2TYPE;

typedef enum QOMX_AUDIO_SKIP_SILENCE_SAMPLES_MODE
{
   QOMX_AUDIO_INITIAL_SILENCE = 0,     /** Initial Silence Samples  */
   QOMX_AUDIO_TRAILING_SILENCE         /** Trailing silence samples */
} QOMX_AUDIO_SKIP_SILENCE_SAMPLES_MODE;

/**
 * Skip Silent Samples Type 
 *
 * nSize            : size of the structure in bytes.
 * nVersion         : OMX IL specification version info.
 * nPortIndex       : port that this structure applies to.
 * bEnable          : enablement of the feature.
 * nNumofPCMSamples : number of PCM samples to be skipped from rendering.
 * eMode            : certain mode of silence samples to removed.
 */
typedef struct QOMX_AUDIO_CONFIG_SKIP_SILENCE_SAMPLES_TYPE
{
   OMX_U32 nSize;            
   OMX_VERSIONTYPE nVersion;
   OMX_U32 nPortIndex;
   OMX_BOOL bEnable;
   OMX_U32 nNumofPCMSamples; 
   QOMX_AUDIO_SKIP_SILENCE_SAMPLES_MODE eMode;
} QOMX_AUDIO_CONFIG_SKIP_SILENCE_SAMPLES_TYPE;
     
/**
 *  ALAC CHANNEL LAYOUT TAG TYPE
 */
typedef enum QOMX_AUDIO_ALAC_CHANNEL_LAYOUT_TAG_TYPE
{
    QOMX_AUDIO_ALAC_Channel_Layout_Tag_Unused     = 0x0, /** Unused/Unknown Channel Layout Tag */
    QOMX_AUDIO_ALAC_Channel_Layout_Tag_Mono       = 0x1, /** Center */
    QOMX_AUDIO_ALAC_Channel_Layout_Tag_Stereo     = 0x2, /** Left, Right */
    QOMX_AUDIO_ALAC_Channel_Layout_Tag_MPEG_3_0_B = 0x3, /** Center, Left, Right */
    QOMX_AUDIO_ALAC_Channel_Layout_Tag_MPEG_4_0_B = 0x4, /** Center, Left, Right, Center Surround */
    QOMX_AUDIO_ALAC_Channel_Layout_Tag_MPEG_5_0_D = 0x5, /** Center, Left, Right, Left Surround, Right Surround */
    QOMX_AUDIO_ALAC_Channel_Layout_Tag_MPEG_5_1_D = 0x6, /** Center, Left, Right, Left Surround, Right Surround, LFE */
    QOMX_AUDIO_ALAC_Channel_Layout_Tag_AAC_6_1    = 0x7, /** Center, Left, Right, Left Surround, Right Surround, Center Surround, LFE */
    QOMX_AUDIO_ALAC_Channel_Layout_Tag_MPEG_7_1_B = 0x8, /** Center, Left Center, Right Center, Left, Right, Left Surround, Right Surround, LFE */
    QOMX_AUDIO_ALAC_Channel_Layout_Tag_Max
} QOMX_AUDIO_ALAC_CHANNEL_LAYOUT_TAG_TYPE;

/**
 *  ALAC TYPE
 *
 *  STRUCT MEMBERS:
 *  nSize               : Size of the structure in bytes.
 *  nVersion            : OMX specification version information.
 *  nPortIndex          : Port that this structure applies to.
 *  nFrameLength        : Frames per packet when no explicit frames 
 *                        per packet setting is present in the packet 
 *                        header.
 *  nCompatibleVersion  : Compatible version.
 *  nBitsPerSample      : Bits per sample.
 *  nPb                 : Parameter used to set up the adpative golomb
 *                        entropy coder, present in format header.
 *  nMb                 : Parameter used to set up the adpative golomb
 *                        entropy coder, present in format header.
 *  nKb                 : Parameter used to set up the adpative golomb
 *                        entropy coder, present in format header.
 *  nChannels           : Number of channels.
 *  nMaxRun             : Parameter used to set up the adpative golomb
 *                        entropy coder, present in format header.
 *  nMaxFrameBytes      : Maximum size of an Apple Lossless packet 
 *                        within the encoded stream. Use 0 for
 *                        unknown maximum size.
 *  nBitRate            : Bit rate of the input data. Use 0 for 
 *                        variable or unknown bit rate.
 *  nSampleRate         : Sampling rate of the source data. Use 0 for 
 *                        variable or unknown sampling rate.
 *  eChannelLayoutTag   : ALAC channel layout tag enumeration.
 */
typedef struct QOMX_AUDIO_PARAM_ALACTYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_U32 nFrameLength;
    OMX_U8 nCompatibleVersion;
    OMX_U8 nBitsPerSample;
    OMX_U8 nPb;
    OMX_U8 nMb;
    OMX_U8 nKb;
    OMX_U8 nChannels;
    OMX_U16 nMaxRun;
    OMX_U32 nMaxFrameBytes;
    OMX_U32 nBitRate;
    OMX_U32 nSampleRate;
    QOMX_AUDIO_ALAC_CHANNEL_LAYOUT_TAG_TYPE eChannelLayoutTag;
} QOMX_AUDIO_PARAM_ALACTYPE;

#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */

#endif /* end of macro __H_QOMX_AUDIOEXTENSIONS_H__ */
