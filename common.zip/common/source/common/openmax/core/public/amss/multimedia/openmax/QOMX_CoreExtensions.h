#ifndef __H_QOMX_COREEXTENSIONS_H__
#define __H_QOMX_COREEXTENSIONS_H__

/*========================================================================

*//** @file QOMX_CoreExtensions.h

@par FILE SERVICES:
      Qualcomm Core extensions API for OpenMax IL.

      This file contains the description of the Qualcomm OpenMax IL
      Core extentions interface, through which the IL client and OpenMax
      components can access additional capabilities.

    Copyright (c) 2009-2013 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/core/public/amss/multimedia/openmax/QOMX_CoreExtensions.h#1 $

========================================================================== */

/*========================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include <OMX_Core.h>
#include <OMX_IndexExt.h>
/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */

/**
 * Qualcom vendor extensions.
 */
#define OMX_QCOM_INDEX_PARAM_INDEXEXTRADATA "OMX.QCOM.index.param.IndexExtraData" /**< reference: QOMX_INDEXEXTRADATATYPE */
#define OMX_QCOM_INDEX_PARAM_HELDBUFFERCOUNT "OMX.QCOM.index.param.HeldBufferCount" /**< reference: QOMX_HELDBUFFERCOUNTTYPE */
#define OMX_QCOM_INDEX_PARAM_SESSIONPROCESSINGMODE "OMX.QCOM.index.param.SessionProcessingMode" /**< reference: QOMX_SESSIONPROCESSINGMODETYPE */
#define OMX_QCOM_INDEX_CONFIG_SINGLESTEP     "OMX.QCOM.index.config.SingleStep" /**< reference: QOMX_CONFIG_SINGLESTEPTYPE */
#define OMX_QCOM_INDEX_PARAM_DUALIMAGELAYOUT "OMX.QCOM.index.param.DualImageLayout" /**< reference: QOMX_DUALIMAGELAYOUTTYPE */
/**
 * Buffer header nFlags field extension.
 *
 * The source of a stream sets the TIMESTAMPINVALID flag to
 * indicate that the buffer header nTimeStamp field does not
 * hold valid timestamp information. The component that updates
 * the nTimeStamp field to reflect a valid timestamp shall clear
 * this flag.
 */
#define QOMX_BUFFERFLAG_TIMESTAMPINVALID 0x80000000

/**
 * Buffer header nFlags field extension.
 *
 * The READONLY flag is set when the component emitting the
 * buffer on an output port identifies the buffer's contents to
 * be read-only. The IL client or input port that receives a
 * filled read-only buffer cannot alter the contents of the
 * buffer. This flag can be cleared by the component when the
 * emptied buffer is returned to it.
 */
#define QOMX_BUFFERFLAG_READONLY         0x40000000

/**
 * Buffer header nFlags field extension.
 *
 * The ENDOFSUBFRAME flag is an optional flag that is set by an
 * output port when the last byte that a buffer payload contains
 * is an end-of-subframe. Any component that implements setting
 * the ENDOFSUBFRAME flag on an output port shall set this flag
 * for every buffer sent from the output port containing an
 * end-of-subframe.
 *
 * A subframe is defined by the next level of natural
 * partitioning in a logical unit for a given format. For
 * example, a subframe in an H.264 access unit is defined as the
 * "network abstraction layer" unit, or NAL unit.
 */
#define QOMX_BUFFERFLAG_ENDOFSUBFRAME    0x20000000

/**
 * Buffer header nFlags field extension.
 *
 * Source component to mark last buffer of previous continuous data with discontinuity buffer flag.
 * This is to ensure down stream components knows about the data discontinuity.
 */
#define QOMX_BUFFERFLAG_DISCONTINUITY     0x10000000

/**
 * A component sends this error to the IL client (via the EventHandler callback)
 * in the event that application of a config or parameter has failed some time
 * after the return of OMX_SetConfig or OMX_SetParameter. This may happen when a
 * component transitions between states and discovers some incompatibility
 * between multiple settings. Configuration indicies sent via extra data may also
 * fail when set to a down stream component. The index that failed will be
 * included as the nData2 parameter of the EventHandler callback.
 */
#define QOMX_ErrorAsyncIndexFailed        (OMX_ErrorVendorStartUnused+1)

/* In some scenarios there may be a possibilty to run out of the storage space
 * and components may want to notify this error to IL client to take appropriate
 * action by the IL client.
 *
 * For example, In recording scenario, MUX component can know the available
 * space in the recording media and can compute peridically to accommodate the
 * meta data before we reach to a stage where we end up no space to write even
 * the meta data. When the space limit reached in recording media, MUX component
 * would like to notify the IL client with  QOMX_ErrorSpaceLimitReached.
 * After this error all the buffers that are returned will have nFilledLen
 * unchanges i.e not consumed.
 */
#define QOMX_ErrorStorageLimitReached     (OMX_ErrorVendorStartUnused + 2)

/* This error event is used for H.264 long-term reference (LTR) encoding. When
 * IL client specifies an LTR frame with its identifier via
 * OMX_QCOM_INDEX_CONFIG_VIDEO_LTRUSE to the encoder, if the specified LTR frame
 * can not be located by the encoder in its LTR list, the encoder issues this
 * error event to IL client to notify the failure of LTRUse config.
 */
#define QOMX_ErrorLTRUseFailed            (OMX_ErrorVendorStartUnused + 3)

/* The stream passed to the component (e.g. syntax header) requires processing
 * that exceeds the capability of the component such that it is unable to continue
 * processing the stream even if the required processing were to change.
 * IL client intervention is required, as the use-case cannot continue.
 * The component shall output no more data on the affected port,
 * but will remain in OMX_StateExecuting.
 */
#define QOMX_ErrorStreamUnsupportedFatal  (OMX_ErrorVendorStartUnused + 4)

/**
 * This structure is used to enable/disable the generation or
 * consumption of the QOMX_ExtraDataOMXIndex extra data type for
 * the specified OpenMax index.
 *
 * STRUCT MEMBERS:
 *  nSize      : Size of the structure in bytes
 *  nVersion   : OMX specification version info
 *  nPortIndex : Port that this structure applies to
 *  bEnabled   : Enable/Disable the extra data processing
 *  nIndex     : The index associated with the extra data
 */
typedef struct QOMX_INDEXEXTRADATATYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_BOOL bEnabled;
    OMX_INDEXTYPE nIndex;
} QOMX_INDEXEXTRADATATYPE;

/**
 * This structure is used to indicate the maximum number of buffers
 * that a port will hold during data flow.
 *
 * STRUCT MEMBERS:
 *  nSize              : Size of the structure in bytes
 *  nVersion           : OMX specification version info
 *  nPortIndex         : Port that this structure applies to
 *  nHeldBufferCount   : Read-only, maximum number of buffers that will be held
 */
typedef struct QOMX_HELDBUFFERCOUNTTYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_U32 nHeldBufferCount;
} QOMX_HELDBUFFERCOUNTTYPE;


/**
 * Enumeration used to define the session processing modes.
 *
 * ENUMS:
 *  SessionProcessModeRealTime : Real time session processing.
 *                       (default mode)
 *  SessionProcessModeNonRealTime : Non Real time session
 *                         processing.
 */
typedef enum QOMX_SESSIONPROCESSMODETYPE
{
    QOMX_SessionProcessModeRealTime,
    QOMX_SessionProcessModeNonRealTime,
    QOMX_SessionProcessModeMax = 0x7FFFFFFF
} QOMX_SESSIONPROCESSMODETYPE;

/**
 * This structure is used to set the session processing mode.
 *
 * STRUCT MEMBERS:
 *  nSize              : Size of the structure in bytes
 *  nVersion           : OMX specification version info
 *  nPortIndex         : Port that this structure applies to
 *  eProcessMode        : One of the processing modes
 */
typedef struct QOMX_SESSIONPROCESSINGMODETYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    QOMX_SESSIONPROCESSMODETYPE eProcessMode;
} QOMX_SESSIONPROCESSINGMODETYPE;

/**
 * This extension defines the capability for ILClient to issue �single step� config to OMX component under �OMX_StatePause� state, so that component can process a single buffer.
 * Component is expected process one buffer for each �single step� config call.
 * nPortIndex: is the value containing the index of the port.
 * bSingleStep: is OMX_TRUE for single stepping.
 */
typedef struct QOMX_CONFIG_SINGLESTEPTYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_BOOL bSingleStep;
} QOMX_CONFIG_SINGLESTEPTYPE;

/** 3D Buffer Layout enumerated value indicating the layout of two images within a single buffer
 */
typedef enum QOMX_LAYOUTTYPE {
    QOMX_LayoutSideBySide = 0,  /**< The buffer contains two images.
                                     The images are laid out in an interleaved manner such that:
                                       a. The buffer begins with the first line of the first image.
                                       b. Each consecutive line of the first image starts nStride bytes
                                          after the previous line from the first image.
                                       c. Each line of the first image is followed by an optional
                                          horizontal gap (defined by nGap), and then by the corresponding
                                          line from the second image
                                       d. Each line of the second image is followed by the next line of the first image.
                                       e. The buffer stride must be greater or equal to 2*nFrameWidth+nGap */
    QOMX_LayoutTopBottom,       /**< The buffer contains two images.
                                     The images are laid out as follows:
                                       a. The first image starts at the beginning of the buffer and is laid out
                                          contiguously in memory as per the color format specified in the port definition.
                                       b. A potential gap of nGap bytes follows the first image.
                                       c. The second image begins nGap bytes after the end of the first image and is laid out
                                          contiguously in memory as per the color format specified in the port definition. */
    QOMX_LayoutMax = 0x7FFFFFFF
} QOMX_LAYOUTTYPE;

/**
 * QOMX_DUALIMAGELAYOUTTYPE is used specify the layout of a 3D dual image buffer in memory.
 * The component will return OMX_ErrorUnsupportedSetting if it does not support the
 * specified layout type on the requested port.
 */
typedef struct QOMX_DUALIMAGELAYOUTTYPE {
    OMX_U32 nSize;               /**< size of the structure in bytes */
    OMX_VERSIONTYPE nVersion;    /**< OMX specification version information */
    OMX_U32 nPortIndex;          /**< port that this structure applies to */
    OMX_BOOL bDualImageEnable;   /**< indicates whether the buffer contains a dual 3d image or a single 2d image. */
    OMX_BOOL bRightImageFirst;   /**< indicates whether the first image in the buffer represents a left or a right view.
                                      If true, the first image in the buffer represents the view from the right camera,
                                      otherwise, it represents the view from the left camera. */
    QOMX_LAYOUTTYPE eLayout;     /**< enumerated value indicating the layout of two images within a single buffer */
    OMX_U32 nGap;                /**< specifies the gap between the left and right images.
                                      This can be either a vertical gap or a horizontal one depending on the value of eLayout:
                                       a. In case eLayout==QOMX_LayoutSideBySide, nGap represents the vertical gap in bytes
                                          between the images.
                                       b. In case eLayout==QOMX_LayoutTopBottom, nGap represents the horizontal gap in bytes
                                           between the images. */
} QOMX_DUALIMAGELAYOUTTYPE;

/* When this flag is set for a port, it means that its tunneled port accepts
 * OMX_UseBuffer calls.
 */
#define QOMX_PORTSTATUS_ACCEPTSUSEBUFFER 0x00000001

/* When this flag is set for a port, it means that its tunneled port would 
 * accept OMX_EmptyThisBuffer or OMX_FillThisBuffer calls, provided the two
 * ports are populated.
 */

#define QOMX_PORTSTATUS_ACCEPTSBUFFEREXCHANGE 0x00000002

enum {
   QOMX_IndexConfigTunneledPortStatus = OMX_IndexExtOtherStartUnused + 1, /**< reference: QOMX_CONFIG_TUNNELEDPORTSTATUSTYPE */
};

/** Communicate to a port what API calls are allowed on its tunneled port. */
typedef struct QOMX_CONFIG_TUNNELEDPORTSTATUSTYPE{
    OMX_U32 nSize;               /**< size of the structure in bytes */
    OMX_VERSIONTYPE nVersion;    /**< OMX specification version information */
    OMX_U32 nPortIndex;          /**< port that this structure applies to */
    OMX_U32 nTunneledPortStatus; /**< integer parameter that contains one or more bit flags
                                  * applied to the port that receives this structure
                                  */
} QOMX_CONFIG_TUNNELEDPORTSTATUSTYPE;

#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */

#endif /* end of macro __H_QOMX_COREEXTENSIONS_H__ */
