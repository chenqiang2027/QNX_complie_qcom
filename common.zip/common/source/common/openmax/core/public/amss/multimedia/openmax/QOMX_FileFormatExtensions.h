#ifndef __QOMX_FILE_FORMAT_EXTENSIONS_H__
#define __QOMX_FILE_FORMAT_EXTENSIONS_H__

/*============================================================================
*//** @file QOMX_FileFormatExtensions.h
  This header contains constants and type definitions that specify the 
  extensions added to the OpenMAX Vendor specific APIs.

Copyright (c) 2008 Qualcomm Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*============================================================================
                              Edit History

$Header: //source/qcom/qct/multimedia2/OpenMAX/api/extensions/main/latest/inc/QOMX_FileFormatExtensions.h#1 
when       who     what, where, why
--------   ---     -------------------------------------------------------

============================================================================*/

//////////////////////////////////////////////////////////////////////////////
//                             Include Files
//////////////////////////////////////////////////////////////////////////////
#include "OMX_Core.h"


/* :OMX.QCOM.index.param.container.info*/
#define QOMX_QcomIndexParamContainerInfo 0x7F000009

#define QOMX_INDEX_CONTAINER_INFO_STRING    "QOMX.Qualcomm.index.param.containerinfo"
#define OMX_QCOM_INDEX_FILE_FORMAT          "OMX.QCOM.index.config.FileFormat"

/**-----------------------------------------------------------------------------
            OMX.QCOM.index.param.container.info 
--------------------------------------------------------------------------------
*/

typedef enum QOMX_CONTAINER_FORMATTYPE {
    QOMX_FORMAT_RAW,
    QOMX_FORMAT_MP4,
    QOMX_FORMAT_3GP,
    QOMX_FORMAT_3G2,
    QOMX_FORMAT_AMC,
    QOMX_FORMAT_SKM,
    QOMX_FORMAT_K3G,
    QOMX_FORMAT_VOB,
    QOMX_FORMAT_AVI,
    QOMX_FORMAT_ASF,
    QOMX_FORMAT_RM ,
    QOMX_FORMAT_MPEG_ES,
    QOMX_FORMAT_DIVX,
    QOMX_FORMATMPEG_TS,
    QOMX_FORMAT_QT,
    QOMX_FORMAT_M4A,
    QOMX_FORMAT_MP3,
    QOMX_FORMAT_WAVE, 
    QOMX_FORMAT_XMF,
    QOMX_FORMAT_AMR,
    QOMX_FORMAT_AAC,
    QOMX_FORMAT_EVRC,
    QOMX_FORMAT_QCP,
    QOMX_FORMAT_SMF,
    QOMX_FORMAT_OGG,
    QOMX_FORMAT_BMP,
    QOMX_FORMAT_JPG,
    QOMX_FORMAT_JPG2000
}QOMX_CONTAINER_FORMATTYPE;

typedef struct QOMX_CONTAINER_INFOTYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    QOMX_CONTAINER_FORMATTYPE eFmtType;
} QOMX_CONTAINER_INFOTYPE;

typedef enum QOMX_FILEFORMATTYPE {
    QOMX_FileFormatNone, /**< no file format naming convention is followed. */
    QOMX_FileFormatDCF, /**< DCF file naming convention. */
    QOMX_FileFormatMax = 0x7FFFFFFF
} QOMX_FILEFORMATTYPE;

/** QOMX_CONFIG_FILEFORMATTYPE is used to determine how the file writer will interpret
the provided content URI and whether it will increment the index of the file name. */
typedef struct QOMX_CONFIG_FILEFORMATTYPE {
    OMX_U32 nSize; /**< size of the structure in bytes */
    OMX_VERSIONTYPE nVersion; /**< OMX specification version information */
    OMX_U32 nPortIndex; /**< port that this structure applies to */
    QOMX_FILEFORMATTYPE eFileFormat; /** file format type */
} QOMX_CONFIG_FILEFORMATTYPE;

/**The QOMX_RECORDINGSTATISTICSINTERVALTYPE structure is used to enable
IL client to indicate the interval of the statistics notification to file mux
component. Time interval will indicate the frequency(in ms) when client needs 
the statistics data*/
typedef struct QOMX_RECORDINGSTATISTICSINTERVALTYPE {
    OMX_U32 nSize; /**< size of the structure in bytes */
    OMX_VERSIONTYPE nVersion;/**< OMX specification version information */
    OMX_TICKS  interval;/**< specifies the time(milliseconds) between updates */
   }QOMX_RECORDINGSTATISTICSINTERVALTYPE;

/**QOMX_RECORDINGSTATISTICSTYPE indicates the current recording
time and space statistics of this session, which can be used by client to 
identify current status of recorded data in milliseconds and bytes */
typedef struct QOMX_RECORDINGSTATISTICSTYPE {
    OMX_U32 nSize;/**< size of the structure in bytes */
    OMX_VERSIONTYPE nVersion;/**< OMX specification version information */
    OMX_TICKS  nRecordedTime; /**  duration that we already recorded*/
    OMX_TICKS  nTimeCanRecord;/** the time we can record at the same bitrate*/
    OMX_U64   nSpaceConsumed;/** space that consumed in bytes*/
    OMX_U64  nSpaceLeft;/** space left in bytes*/
} QOMX_RECORDINGSTATISTICSTYPE;

#endif /*__QOMX_FILE_FORMAT_EXTENSIONS_H__*/
