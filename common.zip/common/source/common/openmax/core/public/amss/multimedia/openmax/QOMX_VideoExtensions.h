#ifndef __H_QOMX_VIDEOEXTENSIONS_H__
#define __H_QOMX_VIDEOEXTENSIONS_H__

/*========================================================================
    Copyright (c) 2009-2017, 2019-2020 QUALCOMM Technologies, Incorporated.
    All Rights Reserved.
    Qualcomm Confidential and Proprietary.
=========================================================================*/

/**
  @file QOMX_VideoExtensions.h

  Qualcomm extensions API for OpenMAX IL Video.

  This file contains the descriptions of the Qualcomm OpenMAX IL
  video extension interfaces, through which the IL client and OpenMAX
  components can access additional video capabilities.
*/

/*========================================================================
NOTE: For the output PDF generated using Doxygen and Latex, all file and
      group descriptions are maintained in the QOMX_Video_Ext_mainpage file. To
      change any of the the file/group text for the PDF, edit the
      QOMX_Video_Ext_mainpage file, or contact Tech Pubs.

      The above description for this file is part of the "video_extensions"
      group description in the QOMX_Video_Ext_mainpage file.
=========================================================================*/

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/core/public/amss/multimedia/openmax/QOMX_VideoExtensions.h#1 $

when      who  what, where, why
--------  ---   ---------------------------------------------------------- 
08/19/20  jz    Extend color frame mode
11/21/19  sm    Extend RC modes
03/04/19  sm    Extented AVC profile levels
10/11/17  rz    Match extra data define with mobile define
09/04/17  jz    Add RTP connection info extension
08/29/17  rz    Add hevc index param 
11/08/16  rz    Consolidate video extension headers
05/27/16  hl    Add vp9 decoder
05/12/15  hc    Add transport extension
04/27/15  rz    Add video deinteralcer extension 
01/28/14  dp    Change QOMX_ExtraDataVideoLTRInfo to 0x7F100004 to resolve conflict with EXTRADATA_ASPECT_RATIO
02/03/11  sw    (Tech Pubs) Edited/added Doxygen comments and markup.
========================================================================== */

/*========================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include <OMX_Core.h>
#include <OMX_Video.h>

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */


/** @addtogroup video_syntax_header
@{ */
#define OMX_QCOM_INDEX_PARAM_VIDEO_SYNTAXHDR                "OMX.QCOM.index.param.video.SyntaxHdr"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.SyntaxHdr". */
/** @} */ /* end_addtogroup video_syntax_header */


/** @addtogroup video_encoder_modes
@{ */
#define OMX_QCOM_INDEX_PARAM_VIDEO_ENCODERMODE              "OMX.QCOM.index.param.video.EncoderMode"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.EncoderMode". */
/** @} */ /* end_addtogroup video_encoder_modes */


/** @addtogroup video_intrarefresh
@{ */
#define OMX_QCOM_INDEX_CONFIG_VIDEO_INTRAREFRESH            "OMX.QCOM.index.config.video.IntraRefresh"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.IntraRefresh". */
/** @} */ /* end_addtogroup video_intrarefresh */


/** @addtogroup video_intraperiod
@{ */
#define OMX_QCOM_INDEX_CONFIG_VIDEO_INTRAPERIOD             "OMX.QCOM.index.config.video.IntraPeriod"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.IntraPeriod". */
/** @} */ /* end_addtogroup video_intraperiod */


/** @addtogroup temporal_spatial
@{ */
#define OMX_QCOM_INDEX_CONFIG_VIDEO_TEMPORALSPATIALTRADEOFF "OMX.QCOM.index.config.video.TemporalSpatialTradeOff"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.TemporalSpatialTradeOff". */
/** @} */ /* end_addtogroup temporal_spatial */


/** @addtogroup mb_concealment
@{ */
#define OMX_QCOM_INDEX_CONFIG_VIDEO_MBCONCEALMENTREPORTING  "OMX.QCOM.index.config.video.MBConcealmentReporting"
        /**< Refers to the following video extension string:
             "MX.QCOM.index.config.video.MBConcealmentReporting". */
/** @} */ /* end_addtogroup mb_concealment */


/** @addtogroup video_extensions
@{ */
#define OMX_QCOM_INDEX_PARAM_VIDEO_EXTRADATAMULTISLICEINFO  "OMX.QCOM.index.param.video.ExtraDataMultiSliceInfo"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.ExtraDataMultiSliceInfo".

             Associated structure: QOMX_ENABLETYPE. */
/** @} */ /* end_addtogroup video_extensions */


/** @cond
*/
#define OMX_QCOM_INDEX_CONFIG_VIDEO_FLOWSTATUS              "OMX.QCOM.index.config.video.FlowStatus"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.FlowStatus".

             Associated structure: QOMX_FLOWSTATUSTYPE. */
/** @endcond */


/** @addtogroup picture_type_decode
@{ */
#define OMX_QCOM_INDEX_PARAM_VIDEO_PICTURETYPEDECODE        "OMX.QCOM.index.param.video.PictureTypeDecode"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.PictureTypeDecode".

             Associated structure: QOMX_VIDEO_DECODEPICTURETYPE. */
/** @} */ /* end_addtogroup picture_type_decode */


/** @addtogroup video_index_extra_data
@{ */
#define OMX_QCOM_INDEX_PARAM_VIDEO_SAMPLEASPECTRATIO        "OMX.QCOM.index.param.video.SampleAspectRatio"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.SampleAspectRatio".

             Associated structure: QOMX_VIDEO_SAMPLEASPECTRATIO. */
/** @} */ /* end_addtogroup video_index_extra_data */


/** @addtogroup video_decoder_display_picture_buffer
@{ */
#define OMX_QCOM_INDEX_CONFIG_VIDEO_DISPLAYPICTUREBUFFER    "OMX.QCOM.index.config.video.DisplayPictureBuffer"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.DisplayPictureBuffer".

             Associated structure: QOMX_VIDEO_DISPLAYPICTUREBUFFERTYPE. */
/** @} */ /* end_addtogroup video_decoder_display_picture_buffer */


/** @cond
*/
#define OMX_QCOM_INDEX_CONFIG_VIDEO_TIMESTAMPSCALE          "OMX.QCOM.index.config.video.TimestampScale"
        /**< Refers to the following video extension string:
             "MX.QCOM.index.config.video.TimestampScale".

             Associated structure: QOMX_VIDEO_TIMESTAMPSCALETYPE. */

#define OMX_QCOM_INDEX_CONFIG_VIDEO_FRAMERATEENHANCEMENT    "OMX.QCOM.index.config.video.FrameRateEnhancement"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.FrameRateEnhancement".

             Associated structure: QOMX_VIDEO_FRAMERATEENHANCEMENTTYPE. */
/** @endcond */

/** @addtogroup video_deinterlacer
@{ */
#define OMX_QCOM_INDEX_PARAM_VIDEO_DEINTERLACER   "OMX.QCOM.index.param.video.Deinterlacer"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.Deinterlacer".

             Associated structure: QOMX_VIDEO_PARAM_DEINTERLACER. */
/** @} */ /* end_addtogroup video_deinterlacer */

/** @addtogroup transport
@{ */
#define OMX_QCOM_INDEX_CONFIG_TRANSPORT_BITRATE             "OMX.QCOM.index.config.transport.bitrate"
        /**< Refers to the following transport extension string:
             "OMX.QCOM.index.config.transport.bitrate". 
             
             Associated structure: OMX_QOMX_INDEX_CONFIG_TRANSPORT_BITRATETYPE. */

#define OMX_QCOM_INDEX_CONFIG_TRANSPORT_NUM_PACKETS         "OMX.QCOM.index.config.transport.numpackets"
        /**< Refers to the following transport extension string:
             "OMX.QCOM.index.config.transport.numpackets". 
             
             Associated structure: OMX_QOMX_INDEX_CONFIG_TRANSPORT_NUMPACKETTYPE. */

#define OMX_QCOM_INDEX_CONFIG_MPEG2TS_PID                   "OMX.QCOM.index.config.transport.mpeg2ts.pid"
        /**< Refers to the following transport extension string:
             "OMX.QCOM.index.config.transport.mpeg2ts.pid".
             
             Associated structure: OMX_QOMX_INDEX_CONFIG_MEPG2TS_PIDTYPE. */
/** @} */ /* end_addtogroup transport */

/** @addtogroup video_coding_types
@{ */
#define OMX_QCOM_INDEX_PARAM_VIDEO_DIVX                     "OMX.QCOM.index.param.video.DivX"
        /**< Refers to the following video extension string:
             "MX.QCOM.index.param.video.DivX". */

#define OMX_QCOM_INDEX_PARAM_VIDEO_VP                       "OMX.QCOM.index.param.video.VP"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.VP". */

#define OMX_QCOM_INDEX_PARAM_VIDEO_SPARK                    "OMX.QCOM.index.param.video.Spark"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.Spark". */

#define OMX_QCOM_INDEX_PARAM_VIDEO_VC1                      "OMX.QCOM.index.param.video.VC1"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.VC1". */

#define OMX_QCOM_INDEX_PARAM_VIDEO_HEVC                      "OMX.QCOM.index.param.video.hevc"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.hevc". */

/** @} */ /* end_addtogroup video_coding_types */

/** @addtogroup video_LTR_encoding (long-term reference encoding)
@{ */
#define OMX_QCOM_INDEX_PARAM_VIDEO_LTRMODE                 "OMX.QCOM.index.param.video.LTRMode"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.LTRMode". */

#define OMX_QCOM_INDEX_PARAM_VIDEO_LTRCOUNTRANGESUPPORTED    "OMX.QCOM.index.param.video.LTRCountRangeSupported"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.LTRCountRangeSupported". */

#define OMX_QCOM_INDEX_PARAM_VIDEO_LTRCOUNT                 "OMX.QCOM.index.param.video.LTRCount"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.LTRCount". */

#define OMX_QCOM_INDEX_CONFIG_VIDEO_LTRPERIOD                "OMX.QCOM.index.config.video.LTRPeriod"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.LTRPeriod". */

#define OMX_QCOM_INDEX_CONFIG_VIDEO_LTRMARK                   "OMX.QCOM.index.config.video.LTRMark"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.LTRMark". */

#define OMX_QCOM_INDEX_CONFIG_VIDEO_LTRUSE                   "OMX.QCOM.index.config.video.LTRUse"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.LTRUse". */
/** @} */ /* end_addtogroup video_LTR_encoding */


#define OMX_QCOM_INDEX_PARAM_VIDEO_MBINFO                   "OMX.QCOM.index.param.video.MBInfo"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.MBInfo".

             Associated structure: QOMX_ENABLETYPE. */

#define OMX_QCOM_INDEX_PARAM_EXTENSIONDATA                  "OMX.QCOM.index.config.video.ExtDataParameters"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.ExtDataParameters".

             Associated structure: . */

#define OMX_QCOM_INDEX_PARAM_USERDATA                       "OMX.QCOM.index.config.video.UserDataParameters"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.UserDataParameters".

             Associated structure: . */

#define OMX_QCOM_INDEX_PARAM_QPARRAY                        "OMX.QCOM.index.config.video.QPArrayParameters"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.QPArrayParameters".

             Associated structure: . */

#define OMX_QCOM_INDEX_PARAM_SEI                            "OMX.QCOM.index.config.video.SEIParameters"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.SEIParameters".

             Associated structure: . */

#define OMX_QCOM_INDEX_PARAM_VUI                            "OMX.QCOM.index.config.video.VUIParameters"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.VUIParameters".

             Associated structure: . */

#define OMX_QCOM_INDEX_PARAM_MVC_VUI                        "OMX.QCOM.index.config.video.MvcVUIParameters"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.MvcVUIParameters".

             Associated structure: . */

#define OMX_QCOM_INDEX_PARAM_META_VC1                       "OMX.QCOM.index.config.video.MetaVC1Parameters"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.MetaVC1Parameters". */

#define OMX_QCOM_INDEX_MVCCODECCONFIGPARAMETERS                      "OMX.QCOM.index.config.MVCCodecConfigParameters"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.MVCCodecConfigParameters".

             Associated structure: QOMX_VIDEO_MVCCONFIGTYPES. */

#define OMX_QCOM_INDEX_CONFIG_MVCVIEWIDPARAMETERS                    "OMX.QCOM.index.config.MVCViewIDParameters"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.MVCViewIDParameters".

             Associated structure: QOMX_VIDEO_MVCVIEWIDTYPES. */

#define OMX_QCOM_INDEX_PARAM_VIDEO_HIERARCHICALLAYERS                "OMX.QCOM.index.param.video.HierarchicalLayers"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.HierarchicalLayers".

           Associated structure: QOMX_VIDEO_HIERARCHICALLAYERS. */

#define OMX_QCOM_INDEX_PARAM_VIDEO_HIERARCHICALLAYERSTRUCTURE        "OMX.QCOM.index.param.video.HierarchicalLayerStructure"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.HierarchicalLayerStructure".

           Associated structure: QOMX_VIDEO_HIERARCHICALLAYERSTRUCTURE. */

#define OMX_QCOM_INDEX_PARAM_VIDEO_HIERARCHICALPQUANTIZATION         "OMX.QCOM.index.param.video.HierarchicalQuantization"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.HierarchicalQuantization".

             Associated structure: QOMX_VIDEO_HIERARCHICALLAYERQP. */

#define OMX_QCOM_INDEX_CONFIG_VIDEO_HIERARCHICALBITRATE              "OMX.QCOM.index.config.video.HierarchicalBitRate"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.HierarchicalBitRate".

             Associated structure: QOMX_VIDEO_HIERARCHICALLAYERBITRATE. */

#define OMX_QCOM_INDEX_PARAM_VIDEO_HIERARCHICALLAYERRANGESUPPORTED   "OMX.QCOM.index.param.video.HierarchicalLayerRangeSupported"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.HierarchicalLayerRangeSupported".

             Associated structure: QOMX_URANGETYPE. */

//@todo: Added temporarily till extension is approved
#define OMX_QCOM_INDEX_PARAM_VIDEO_SLICEDELIVERYMODE    "OMX.QCOM.index.param.video.SliceDeliveryMode"
          /**< Refers to the following video extension string:
              "OMX.QCOM.index.param.video.SliceDeliveryMode".
             Associated structure: QOMX_ENABLETYPE. */

#define OMX_QCOM_INDEX_CONFIG_VIDEO_QPRANGE   "OMX.QCOM.index.param.video.QPRange"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.QPRange".

             Associated structure: QOMX_VIDEO_CONFIG_QPRANGE. */

#define OMX_QCOM_INDEX_PARAM_VIDEO_MAXFRAMERATE   "OMX.QCOM.index.param.video.MaxFrameRate"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.MaxFrameRate".

             Associated structure: QOMX_VIDEO_CONFIG_MAXFRAMERATE. */

#define OMX_QCOM_INDEX_PARAM_VIDEO_SESSION_NAME   "OMX.QCOM.index.param.video.SessionName"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.SessionName".

             Associated structure: QOMX_VIDEO_PARAM_SESSION_NAME. */

#define OMX_QCOM_INDEX_CONFIG_VIDEO_IFRAME_QPRANGE   "OMX.QCOM.index.param.video.IFrameQPRange"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.IFrameQPRange".

             Associated structure: QOMX_VIDEO_CONFIG_QPRANGE. */

#define OMX_QCOM_INDEX_CONFIG_VIDEO_PEAK_BITRATE   "OMX.QCOM.index.config.video.PeakBitRate"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.config.video.PeakBitRate".

             Associated structure: OMX_VIDEO_CONFIG_BITRATETYPE. */

#define OMX_QCOM_INDEX_PARAM_VIDEO_SIGNAL_METADATA   "OMX.QCOM.index.param.video.SignalMetadata"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.SignalMetadata".

             Associated structure: QOMX_VIDEO_PARAM_SIGNAL_METADATA. */

#define OMX_QCOM_INDEX_PARAM_VIDEO_DISPLAYLINFO_METADATA   "OMX.QCOM.index.param.video.DisplayInfoMetadata"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.video.DisplayInfoMetadata".

             Associated structure: QOMX_VIDEO_PARAM_DISPLAY_INFO_METADATA. */

#define OMX_QCOM_INDEX_PARAM_RTP_CONNECTIONINFO   "OMX.QCOM.index.param.rtp.connectioninfo"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.param.rtp.connectioninfo".

             Associated structure: QOMX_PARAM_RTP_CONNECTIONINFO */

/*
 * This rate control will be used for low bitrate applications to get better
 * video quality for a given bitrate.
 */
#define QOMX_Video_ControlRateMaxBitrate (OMX_Video_ControlRateVendorStartUnused + 1)
#define QOMX_Video_ControlRateMaxBitrateSkipFrames (OMX_Video_ControlRateVendorStartUnused + 2)

/* Contant quality mode */
#define QOMX_Video_ControlRateConstantQuality (OMX_Video_ControlRateVendorStartUnused + 3)

#define OMX_QCOM_INDEX_PARAM_RENDER_COLORFRAME   "OMX.QCOM.index.render.ColorFrame"
        /**< Refers to the following video extension string:
             "OMX.QCOM.index.render.ColorFrame".

             Associated structure: QOMX_PARAM_RENDER_COLORFRAME */

/** @addtogroup video_LTR_encoding
@{ */
/** @latexonly\label{hdr:LTRENCODINGTYPE}@endlatexonly
    Specifies the values of the video H.264 LTR encoding extensions.
*/

/** @latexonly\label{hdr:LTRMODETYPE}@endlatexonly
    Specifies LTR mode types.
*/
typedef enum QOMX_VIDEO_LTRMODETYPE
{
    QOMX_VIDEO_LTRMode_Disable    = 0x01, /**< LTR encoding is disabled */
    QOMX_VIDEO_LTRMode_Manual     = 0x02, /**< In this mode, IL client configures
                                           **  the encoder the LTR count and manually
                                           **  controls the marking and use of LTR
                                           **  frames during video encoding.
                                           */
    QOMX_VIDEO_LTRMode_Auto       = 0x03, /**< In this mode, IL client configures
                                           **  the encoder the LTR count and LTR
                                           **  period. The encoder marks LTR frames
                                           **  automatically based on the LTR period
                                           **  during video encoding. IL client controls
                                           **  the use of LTR frames.
                                           */
    QOMX_VIDEO_LTRMode_MAX    = 0x7FFFFFFF /** Maximum LTR Mode type */
} QOMX_VIDEO_LTRMODETYPE;

/** @latexonly\label{hdr:LTRCOUNT}@endlatexonly
    Specifies LTR count configuration.
*/
typedef struct QOMX_VIDEO_LTRMODE {
    OMX_U32 nSize;            /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;       /**< Index of the port to which this structure applies. */
    QOMX_VIDEO_LTRMODETYPE eLTRMode;      /**< Specifies the LTR mode used in encoder
                                           */
} QOMX_VIDEO_LTRMODE;


/** @latexonly\label{hdr:LTRCOUNT}@endlatexonly
    Specifies LTR count configuration.
*/
typedef struct QOMX_VIDEO_LTRCOUNT {
    OMX_U32 nSize;            /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;       /**< Index of the port to which this structure applies. */
    OMX_U32 nCount;           /**< Specifies the number of LTR frames stored in the
                               **  encoder component
                               */
} QOMX_VIDEO_LTRCOUNT;

/** @latexonly\label{hdr:LTRPERIOD}@endlatexonly
    Specifies LTR period configuration.
*/
typedef struct QOMX_VIDEO_LTRPERIOD {
    OMX_U32 nSize;            /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;       /**< Index of the port to which this structure applies. */
    OMX_U32 nFrames;          /**< Specifies the number of frames between two consecutive
                               **  LTR frames.
                               */
} QOMX_VIDEO_LTRPERIOD;

/** @latexonly\label{hdr:LTRMARK}@endlatexonly
    Marks the next encoded frame as an LTR frame.
*/
typedef struct QOMX_VIDEO_LTRMARK {
    OMX_U32 nSize;            /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;       /**< Index of the port to which this structure applies. */
} QOMX_VIDEO_LTRMARK;

/** @latexonly\label{hdr:LTRUSE}@endlatexonly
    Specifies an LTR frame to encode subsequent frames.
*/
typedef struct QOMX_VIDEO_LTRUSE {
    OMX_U32 nSize;            /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;       /**< Index of the port to which this structure applies. */
    OMX_U32 nID;              /**< Specifies the identifier of the LTR frame to be used
                               **  as reference frame for encoding subsequent frames.
                               **/
    OMX_U32 nFrames;          /**< Specifies the number of subsequent frames to be
                               **  encoded using the LTR frame with its identifier nID
                               **  as reference frame. Short-term reference frames
                               **  will be used thereafter. The value of 0xFFFFFFFF
                               **  indicates that all subsequent frames will be encoded
                               **  using this LTR frame as reference frame.
                               */
} QOMX_VIDEO_LTRUSE;
/** @} */ /* end_addtogroup video_LTR_encoding */


/** @addtogroup video_coding_types
@{ */
/** @latexonly\label{hdr:CODINGTYPE}@endlatexonly
    Specifies the values of the video coding extensions.

    The extended video compression codings are supported for the following video
    coding types: VC-1, Sorenson Spark, DivX, On2 Voice Privacy (VP) codecs, and
    Multiview Video Coding (MVC) codecs. These coding types are not in the
    OpenMAX IL specification.
*/

typedef enum QOMX_VIDEO_CODINGTYPE
{
    QOMX_VIDEO_CodingDivX   = 0x7F000001, /**< All versions of the DivX video
                                               format. */
    QOMX_VIDEO_CodingVP     = 0x7F000002, /**< All versions of the On2 VP video
                                               format. */
    QOMX_VIDEO_CodingSpark  = 0x7F000003, /**< All versions of the Sorenson Spark
                                               video format. */
    QOMX_VIDEO_CodingVC1    = 0x7F000004, /**< SMPTE VC-1 video format. */
    QOMX_VIDEO_MPEG1        = 0x7F000005, /**< MPEG-1 video format. */
    QOMX_VIDEO_CodingHEVC   = 0x7F000006,  /**< H.265/HEVC */
    QOMX_VIDEO_CodingVP9    = 0x7F000007  /**< VP9 */
} QOMX_VIDEO_CODINGTYPE;


/** @latexonly\label{hdr:DIVXFORMATTYPE}@endlatexonly
    DivX versions.
*/
typedef enum QOMX_VIDEO_DIVXFORMATTYPE {
    QOMX_VIDEO_DIVXFormatUnused = 0x01,   /**< Format is unused or unknown. */
    QOMX_VIDEO_DIVXFormat311    = 0x02,   /**< DivX format 3.11. */
    QOMX_VIDEO_DIVXFormat4      = 0x04,   /**< DivX format 4.0. */
    QOMX_VIDEO_DIVXFormat5      = 0x08,   /**< DivX format 5.0. */
    QOMX_VIDEO_DIVXFormat6      = 0x10,   /**< DivX format 6.0. */
    QOMX_VIDEO_DIVXFormatKhronosExtensions = 0x6F000000,
                                          /**< Reserved region for introducing
                                               Khronos Standard Extensions. */
    QOMX_VIDEO_DIVXFormatVendorStartUnused = 0x7F000000,
                                          /**< Reserved region for introducing
                                               Vendor Extensions. */
    QOMX_VIDEO_DIVXFormatMax = 0x7FFFFFFF /**< Maximum DivX format. */
} QOMX_VIDEO_DIVXFORMATTYPE;

/** @latexonly\label{hdr:DIVXPROFILETYPE}@endlatexonly
    DivX profile types. Each profile indicates support for performance bounds.
*/
typedef enum QOMX_VIDEO_DIVXPROFILETYPE {
    QOMX_VIDEO_DivXProfileqMobile = 0x01,  /**< DivX qMobile profile. */
    QOMX_VIDEO_DivXProfileMobile  = 0x02,  /**< DivX Mobile profile. */
    QOMX_VIDEO_DivXProfileMT      = 0x04,  /**< DivX Mobile Theater profile. */
    QOMX_VIDEO_DivXProfileHT      = 0x08,  /**< DivX Home Theater profile. */
    QOMX_VIDEO_DivXProfileHD      = 0x10,  /**< DivX High Definition profile. */
    QOMX_VIDEO_DIVXProfileKhronosExtensions = 0x6F000000,
                                           /**< Reserved region for introducing
                                                Khronos Standard Extensions. */
    QOMX_VIDEO_DIVXProfileVendorStartUnused = 0x7F000000,
                                           /**< Reserved region for introducing
                                                Vendor Extensions. */
    QOMX_VIDEO_DIVXProfileMax = 0x7FFFFFFF /**< Maximum DivX profile. */
} QOMX_VIDEO_DIVXPROFILETYPE;

/** @} */ /* end_addtogroup video_coding_types */


/** @addtogroup video_coding_types
@{ */
/** @brief @latexonly\label{hdr:PARAMDIVXTYPE}@endlatexonly
    Specifies the DivX video format parameters.
*/
typedef struct QOMX_VIDEO_PARAM_DIVXTYPE {
    OMX_U32 nSize;            /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;       /**< Index of the port to which this structure applies. */
    QOMX_VIDEO_DIVXFORMATTYPE eFormat; /**< Version of the DivX stream/data.
                                              For details, see Section
                             @latexonly\ref{hdr:DIVXFORMATTYPE}@endlatexonly. */
    QOMX_VIDEO_DIVXPROFILETYPE eProfile; /**< Profile of the DivX stream/data.
                                              For details, see Section
                             @latexonly\ref{hdr:DIVXPROFILETYPE}@endlatexonly.*/
} QOMX_VIDEO_PARAM_DIVXTYPE;

/** @} */ /* end_addtogroup video_coding_types */


/** @addtogroup video_coding_types
@{ */
/** @latexonly\label{hdr:VPFORMATTYPE}@endlatexonly
    VP codec versions.
*/
typedef enum QOMX_VIDEO_VPFORMATTYPE {
    QOMX_VIDEO_VPFormatUnused = 0x01,   /**< Format is unused or unknown. */
    QOMX_VIDEO_VPFormat6      = 0x02,   /**< VP6 video format. */
    QOMX_VIDEO_VPFormat7      = 0x04,   /**< VP7 video format. */
    QOMX_VIDEO_VPFormat8      = 0x08,   /**< VP8 video format. */
    QOMX_VIDEO_VPFormatKhronosExtensions = 0x6F000000,
                                        /**< Reserved region for introducing
                                             Khronos Standard Extensions. */
    QOMX_VIDEO_VPFormatVendorStartUnused = 0x7F000000,
                                        /**< Reserved region for introducing
                                             Vendor Extensions. */
    QOMX_VIDEO_VPFormatMax = 0x7FFFFFFF /**< Maximum VP format. */
} QOMX_VIDEO_VPFORMATTYPE;

/** @latexonly\label{hdr:VPPROFILETYPE}@endlatexonly
    VP profile types. Each profile indicates support for the encoding tools.
*/
typedef enum QOMX_VIDEO_VPPROFILETYPE {
    QOMX_VIDEO_VPProfileSimple   = 0x01, /**< Simple profile; applies to VP6 only. */
    QOMX_VIDEO_VPProfileAdvanced = 0x02, /**< Advanced profile; applies to VP6 only. */
    QOMX_VIDEO_VPProfileVersion0 = 0x04, /**< Applies to both VP7 and VP8. */
    QOMX_VIDEO_VPProfileVersion1 = 0x08, /**< Applies to both VP7 and VP8. */
    QOMX_VIDEO_VPProfileVersion2 = 0x10, /**< Applies to VP8 only. */
    QOMX_VIDEO_VPProfileVersion3 = 0x20, /**< Applies to VP8 only. */
    QOMX_VIDEO_VPProfileKhronosExtensions = 0x6F000000,
                                         /**< Reserved region for introducing
                                              Khronos Standard Extensions. */
    QOMX_VIDEO_VPProfileVendorStartUnused = 0x7F000000,
                                         /**< Reserved region for introducing
                                              Vendor Extensions. */
    QOMX_VIDEO_VPProfileMax = 0x7FFFFFFF /**< Maximum VP profile. */
} QOMX_VIDEO_VPPROFILETYPE;

/** @} */ /* end_addtogroup video_coding_types */


/** @addtogroup video_coding_types
@{ */
/** @brief @latexonly\label{hdr:PARAMVPTYPE}@endlatexonly
    Specifies the On2 VP video format parameters.
*/
typedef struct QOMX_VIDEO_PARAM_VPTYPE {
    OMX_U32 nSize;            /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;       /**< Index of the port to which this structure applies.  */
    QOMX_VIDEO_VPFORMATTYPE eFormat;   /**< Format of the VP stream/data. For
                                            details, see Section
                             @latexonly\ref{hdr:VPFORMATTYPE}@endlatexonly. */
    QOMX_VIDEO_VPPROFILETYPE eProfile; /**< Profile or version of the VP
                                            stream/data. For details, see Section
                             @latexonly\ref{hdr:VPPROFILETYPE}@endlatexonly. */
} QOMX_VIDEO_PARAM_VPTYPE;

/** @} */ /* end_addtogroup video_coding_types */


/** @addtogroup video_coding_types
@{ */
/** @latexonly\label{hdr:SPARKFORMATTYPE}@endlatexonly
    Spark versions.
*/
typedef enum QOMX_VIDEO_SPARKFORMATTYPE {
    QOMX_VIDEO_SparkFormatUnused = 0x01,   /**< Format is unused or unknown. */
    QOMX_VIDEO_SparkFormat0      = 0x02,   /**< Video format version 0. */
    QOMX_VIDEO_SparkFormat1      = 0x04,   /**< Video format version 1. */
    QOMX_VIDEO_SparkFormatKhronosExtensions = 0x6F000000,
                                           /**< Reserved region for introducing
                                                Khronos Standard Extensions. */
    QOMX_VIDEO_SparkFormatVendorStartUnused = 0x7F000000,
                                           /**< Reserved region for introducing
                                                Vendor Extensions. */
    QOMX_VIDEO_SparkFormatMax = 0x7FFFFFFF /**< Maximum Spark format. */
} QOMX_VIDEO_SPARKFORMATTYPE;

/** @} */ /* end_addtogroup video_coding_types */


/** @addtogroup video_coding_types
@{ */
/** @brief @latexonly\label{hdr:PARAMSPARKTYPE}@endlatexonly
    Specifies the Sorenson Spark video format parameters.
*/
typedef struct QOMX_VIDEO_PARAM_SPARKTYPE {
    OMX_U32 nSize;            /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;       /**< Index of the port to which this structure applies. */
    QOMX_VIDEO_SPARKFORMATTYPE eFormat; /**< Version of the Spark stream/data.
                                             For details, see Section
                             @latexonly\ref{hdr:SPARKFORMATTYPE}@endlatexonly. */
} QOMX_VIDEO_PARAM_SPARKTYPE;

/** @} */ /* end_addtogroup video_coding_types */


/** @addtogroup video_coding_types
@{ */
/** @latexonly\label{hdr:VC1PROFILETYPE}@endlatexonly
    VC-1 profile types. Each profile indicates support for encoding tools.
*/
typedef enum QOMX_VIDEO_VC1PROFILETYPE {
    QOMX_VIDEO_VC1ProfileSimple   = 0x01, /**< VC-1 Simple profile. */
    QOMX_VIDEO_VC1ProfileMain     = 0x02, /**< VC-1 Main profile. */
    QOMX_VIDEO_VC1ProfileAdvanced = 0x04, /**< VC-1 Advanced profile. */
    QOMX_VIDEO_VC1ProfileKhronosExtensions = 0x6F000000,
                                          /**< Reserved region for introducing
                                               Khronos Standard Extensions. */
    QOMX_VIDEO_VC1ProfileVendorStartUnused = 0x7F000000,
                                          /**< Reserved region for introducing
                                               Vendor Extensions. */
    QOMX_VIDEO_VC1ProfileMax = 0x7FFFFFFF /**< Maximum VC-1 profile. */
} QOMX_VIDEO_VC1PROFILETYPE;

/** @latexonly\label{hdr:VC1LEVELTYPE}@endlatexonly
    VC-1 level types. Each level indicates support for performance bounds.
*/
typedef enum QOMX_VIDEO_VC1LEVELTYPE {
    QOMX_VIDEO_VC1LevelLow    = 0x01,   /**< VC-1 Low Level (applies to the
                                             Simple and Main profiles). */
    QOMX_VIDEO_VC1LevelMedium = 0x02,   /**< VC-1 Medium Level (applies to the
                                             Simple and Main profiles). */
    QOMX_VIDEO_VC1LevelHigh   = 0x04,   /**< VC-1 High Level (applies to the
                                             Main profile only). */
    QOMX_VIDEO_VC1Level0      = 0x08,   /**< VC-1 Level 0 (applies to the
                                             Advanced profile only). */
    QOMX_VIDEO_VC1Level1      = 0x10,   /**< VC-1 Level 1 (applies to the
                                             Advanced profile only). */
    QOMX_VIDEO_VC1Level2      = 0x20,   /**< VC-1 Level 2 (applies to the
                                             Advanced profile only). */
    QOMX_VIDEO_VC1Level3      = 0x40,   /**< VC-1 Level 3 (applies to the
                                             Advanced profile only). */
    QOMX_VIDEO_VC1Level4      = 0x80,   /**< VC-1 Level 4 (applies to the
                                             Advanced profile only). */
    QOMX_VIDEO_VC1LevelKhronosExtensions = 0x6F000000,
                                        /**< Reserved region for introducing
                                             Khronos Standard Extensions. */
    QOMX_VIDEO_VC1LevelVendorStartUnused = 0x7F000000,
                                        /**< Reserved region for introducing
                                             Vendor Extensions. */
    QOMX_VIDEO_VC1LevelMax = 0x7FFFFFFF /**< Maximum VC-1 level. */
} QOMX_VIDEO_VC1LEVELTYPE;

/** @} */ /* end_addtogroup video_coding_types */


/** @addtogroup video_coding_types
@{ */
/** @brief @latexonly\label{hdr:PARAMVC1TYPE}@endlatexonly
    Specifies the VC-1 video format parameters.
*/
typedef struct QOMX_VIDEO_PARAM_VC1TYPE {
    OMX_U32 nSize;            /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;       /**< Index of the port to which this structure applies. */
    QOMX_VIDEO_VC1PROFILETYPE eProfile; /**< Profile of the VC-1 stream/data.
                                        For details, see Section
                             @latexonly\ref{hdr:VC1PROFILETYPE}@endlatexonly. */
    QOMX_VIDEO_VC1LEVELTYPE eLevel;     /**< Level of the VC-1 stream/data.
                                        For details, see Section
                             @latexonly\ref{hdr:VC1LEVELTYPE}@endlatexonly. */
} QOMX_VIDEO_PARAM_VC1TYPE;

/** @} */ /* end_addtogroup video_coding_types */


/** @addtogroup video_extensions
@{ */
/** Extended MPEG-4 level types that are not defined in the OpenMAX IL
    specification. Each level indicates support for frame sizes, bitrates,
    and decoder frame rates.
*/
typedef enum QOMX_VIDEO_MPEG4LEVELTYPE {
    QOMX_VIDEO_MPEG4Level6 = 0x7F000001,   /**< MPEG-4 level 6. */
    QOMX_VIDEO_MPEG4Level7 = 0x7F000002,   /**< MPEG-4 level 7. */
    QOMX_VIDEO_MPEG4Level8 = 0x7F000003,   /**< MPEG-4 level 8. */
    QOMX_VIDEO_MPEG4Level9 = 0x7F000004,   /**< MPEG-4 level 9. */
    QOMX_VIDEO_MPEG4LevelMax = 0x7FFFFFFF  /**< MPEG-4 maximum level. */
} QOMX_VIDEO_MPEG4LEVELTYPE;

/** @} */ /* end_addtogroup video_extensions */

/** @addtogroup video_extensions
@{ */
/** Extended AVC profile types that are not defined in the OpenMAX IL
    specification. Each profile indicates support for various
    performance bounds and different annexes.
*/
typedef enum QOMX_VIDEO_AVCPROFILETYPE {
   QOMX_VIDEO_AVCProfileConstrainedBaseline = 0x7F000001,   /**< Constrained Baseline profile */
   QOMX_VIDEO_AVCProfileConstrainedHigh = 0x7F000002,       /**< Constrained High profile */
   QOMX_VIDEO_AVCProfileMax = 0x7FFFFFFF
} QOMX_VIDEO_AVCPROFILETYPE;


/** @addtogroup video_extensions
@{ */
/** Extended AVC level types that are not defined in the OpenMAX IL
    specification. Each level indicates support for frame sizes, bitrates,
    and decoder frame rates.
*/
typedef enum QOMX_VIDEO_AVCLEVELTYPE {
    QOMX_VIDEO_AVCLevel52  = 0x7F000001,    /**< AVC level 5.2 */
    QOMX_VIDEO_AVCLevel6   = 0x7F000002,    /**< AVC level 6 */
    QOMX_VIDEO_AVCLevel61  = 0x7F000004,    /**< AVC level 6.1 */
    QOMX_VIDEO_AVCLevel62  = 0x7F000008,    /**< AVC level 6.2 */
    QOMX_VIDEO_AVCLevelMax = 0x7FFFFFFF  /**< AVC maximum level */
} QOMX_VIDEO_AVCLEVELTYPE;


/** @addtogroup video_coding_types
@{ */
/** @latexonly\label{hdr:HEVCPROFILETYPE}@endlatexonly
    HEVC profile types. Each profile indicates support for encoding tools.
*/
typedef enum QOMX_VIDEO_HEVCPROFILETYPE {
    QOMX_VIDEO_HEVCProfileMain    = 0x01,
    QOMX_VIDEO_HEVCProfileMain10  = 0x02,
    QOMX_VIDEO_HEVCProfileUnknown = 0x6EFFFFFF,
    QOMX_VIDEO_HEVCProfileMax = 0x7FFFFFFF
} QOMX_VIDEO_HEVCPROFILETYPE;


/** @latexonly\label{hdr:HEVCLEVELTYPE}@endlatexonly
    HEVC level types. Each level indicates support for performance bounds.
*/

typedef enum QOMX_VIDEO_HEVCLEVELTYPE {
   QOMX_VIDEO_HEVCMainTierLevel1  = 0x01,       /**< HEVC Main tier, level 1 */  
   QOMX_VIDEO_HEVCHighTierLevel1  = 0x02,       /**< HEVC High tier, level 1 */  
   QOMX_VIDEO_HEVCMainTierLevel2  = 0x04,       /**< HEVC Main tier, level 2 */  
   QOMX_VIDEO_HEVCHighTierLevel2  = 0x08,       /**< HEVC High tier, level 2 */  
   QOMX_VIDEO_HEVCMainTierLevel21 = 0x10,       /**< HEVC Main tier, level 2.1 */
   QOMX_VIDEO_HEVCHighTierLevel21 = 0x20,       /**< HEVC High tier, level 2.1 */
   QOMX_VIDEO_HEVCMainTierLevel3  = 0x40,       /**< HEVC Main tier, level 3 */  
   QOMX_VIDEO_HEVCHighTierLevel3  = 0x80,       /**< HEVC High tier, level 3 */  
   QOMX_VIDEO_HEVCMainTierLevel31 = 0x100,      /**< HEVC Main tier, level 3.1 */
   QOMX_VIDEO_HEVCHighTierLevel31 = 0x200,      /**< HEVC High tier, level 3.1 */
   QOMX_VIDEO_HEVCMainTierLevel4  = 0x400,      /**< HEVC Main tier, level 4 */  
   QOMX_VIDEO_HEVCHighTierLevel4  = 0x800,      /**< HEVC High tier, level 4 */  
   QOMX_VIDEO_HEVCMainTierLevel41 = 0x1000,     /**< HEVC Main tier, level 4.1 */
   QOMX_VIDEO_HEVCHighTierLevel41 = 0x2000,     /**< HEVC High tier, level 4.1 */
   QOMX_VIDEO_HEVCMainTierLevel5  = 0x4000,     /**< HEVC Main tier, level 5 */  
   QOMX_VIDEO_HEVCHighTierLevel5  = 0x8000,     /**< HEVC High tier, level 5 */  
   QOMX_VIDEO_HEVCMainTierLevel51 = 0x10000,    /**< HEVC Main tier, level 5.1 */
   QOMX_VIDEO_HEVCHighTierLevel51 = 0x20000,    /**< HEVC High tier, level 5.1 */
   QOMX_VIDEO_HEVCMainTierLevel52 = 0x40000,    /**< HEVC Main tier, level 5.2 */
   QOMX_VIDEO_HEVCHighTierLevel52 = 0x80000,    /**< HEVC High tier, level 5.2 */
   QOMX_VIDEO_HEVCMainTierLevel6  = 0x100000,   /**< HEVC Main tier, level 6 */  
   QOMX_VIDEO_HEVCHighTierLevel6  = 0x200000,   /**< HEVC High tier, level 6 */  
   QOMX_VIDEO_HEVCMainTierLevel61 = 0x400000,   /**< HEVC Main tier, level 6.1 */
   QOMX_VIDEO_HEVCHighTierLevel61 = 0x800000,   /**< HEVC High tier, level 6.1 */
   QOMX_VIDEO_HEVCMainTierLevel62 = 0x1000000,  /**< HEVC Main tier, level 6.2 */
   QOMX_VIDEO_HEVCHighTierLevel62 = 0x2000000,  /**< HEVC High tier, level 6.2 */
   QOMX_VIDEO_HEVCLevelUnknown    = 0x6EFFFFFF,
   QOMX_VIDEO_HEVCLevelMax        = 0x7FFFFFFF
} QOMX_VIDEO_HEVCLEVELTYPE;

/** @addtogroup video_coding_types
@{ */
/** @brief @latexonly\label{hdr:PARAMHEVCTYPE}@endlatexonly
    Specifies the HEVC video format parameters.
*/
typedef struct QOMX_VIDEO_PARAM_HEVCTYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    QOMX_VIDEO_HEVCPROFILETYPE eProfile;
    QOMX_VIDEO_HEVCLEVELTYPE eLevel;
} QOMX_VIDEO_PARAM_HEVCTYPE;

/** @addtogroup video_coding_types
@{ */
/** @latexonly\label{hdr:VP9PROFILETYPE}@endlatexonly
    VP9 profile types. Each profile indicates support for encoding tools.
*/
typedef enum QOMX_VIDEO_VP9PROFILETYPE {
    QOMX_VIDEO_VP9Profile0       = 0x01,
    QOMX_VIDEO_VP9Profile1       = 0x02,
    QOMX_VIDEO_VP9Profile2       = 0x04,
    QOMX_VIDEO_VP9Profile3       = 0x08,
    QOMX_VIDEO_VP9ProfileUnknown = 0x6EFFFFFF,
    QOMX_VIDEO_VP9ProfileMax = 0x7FFFFFFF
} QOMX_VIDEO_VP9PROFILETYPE;


/** @latexonly\label{hdr:VP9LEVELTYPE}@endlatexonly
    VP9 level types. Each level indicates support for performance bounds.
*/

typedef enum QOMX_VIDEO_VP9LEVELTYPE {
   QOMX_VIDEO_VP9Level1         = 0x01,        /**< VP9 level 1   */
   QOMX_VIDEO_VP9Level11        = 0x02,        /**< VP9 level 1.1 */
   QOMX_VIDEO_VP9Level2         = 0x04,        /**< VP9 level 2   */
   QOMX_VIDEO_VP9Level21        = 0x08,        /**< VP9 level 2.1 */
   QOMX_VIDEO_VP9Level3         = 0x10,        /**< VP9 level 3   */
   QOMX_VIDEO_VP9Level31        = 0x20,        /**< VP9 level 3.1 */
   QOMX_VIDEO_VP9Level4         = 0x40,        /**< VP9 level 4   */
   QOMX_VIDEO_VP9Level41        = 0x80,        /**< VP9 level 4.1 */
   QOMX_VIDEO_VP9Level5         = 0x100,       /**< VP9 level 5   */
   QOMX_VIDEO_VP9Level51        = 0x200,       /**< VP9 level 5.1 */
   QOMX_VIDEO_VP9Level6         = 0x400,       /**< VP9 level 6   */
   QOMX_VIDEO_VP9Level61        = 0x800,       /**< VP9 level 6.1 */
   QOMX_VIDEO_VP9Level62        = 0x1000,      /**< VP9 level 6.2 */
   QOMX_VIDEO_VP9LevelUnknown   = 0x6EFFFFFF,
   QOMX_VIDEO_VP9LevelMax       = 0x7FFFFFFF
} QOMX_VIDEO_VP9LEVELTYPE;

/** @addtogroup video_coding_types
@{ */
/** @brief @latexonly\label{hdr:PARAMVP9TYPE}@endlatexonly
    Specifies the VP9 video format parameters.
*/
typedef struct QOMX_VIDEO_PARAM_VP9TYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    QOMX_VIDEO_VP9PROFILETYPE eProfile;
    QOMX_VIDEO_VP9LEVELTYPE eLevel;
} QOMX_VIDEO_PARAM_VP9TYPE;


/** @} */ /* end_addtogroup video_extensions */

/** @addtogroup video_syntax_header
@{ */
/** @brief @latexonly\label{hdr:SYNTAXHDRTYPE}@endlatexonly
    Retrieves a Video Encoder component's syntax header, or sets a video
    decoder component's syntax header configuration data.

    This structure is used to retrieve the syntax header from a video encoder
    component, or to set the out-of-band syntax header configuration data on a
    Video Decoder component.

    @return
    Error condition -- If the IL client provides a buffer array whose size is
    insufficient, OMX_GetParameter returns with nBytes set to the actual size of
    the syntax header and with the OMX_ErrorBadParameter error code.

    @dependencies
    OMX_SetParameter is valid only in the OMX_StateLoaded state.\n
    OMX_GetParameter is valid only in the OMX_StateIdle, OMX_StateExecuting, and
    OMX_StatePause states.
*/
typedef struct QOMX_VIDEO_SYNTAXHDRTYPE {
    OMX_U32 nSize;            /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;       /**< Index of the port to which this structure applies. */
    OMX_U32 nBytes;           /**< Buffer length in bytes.

           When used with OMX_GetParameter for the encoder component:\n
           - This nBytes parameter is a read-write field.
           - When QOMX_VIDEO_SYNTAXHDRTYPE is passed in, nBytes is the size of
             the buffer array pointed to by the data field. When the OMX_GetParameter
             call returns, nBytes is the amount of data within the buffer array.
           - The IL client must allocate the buffer array and then request the syntax
             header. If the size of the buffer array to allocate is unknown to the IL
             client, the client can call OMX_GetParameter with nBytes set to 0. In
             this case, when OMX_GetParameter returns, the nBytes field is set to the
             size of the syntax header. The IL client can then allocate a buffer of
             this size and call OMX_GetParameter again.
           - The format of the syntax header that is retrieved in OMX_GetParameter
             is specific to the video codec and is listed in Table
             @latexonly\ref{tbl:SyntaxHdrFormat4GetParam}@endlatexonly.

             @latexonly\input{tables/tableSyntaxHdrFormat4GetParam.tex}@endlatexonly

           When used with OMX_SetParameter for the decoder component:\n
           - This nBytes parameter is a read-only field that specifies the amount
             of data in the buffer array.
           - The format of the syntax header that is to be passed in
             OMX\_SetParameter is specific to the video codec and is listed in
             Table @latexonly\ref{tbl:SyntaxHdrFormat4SetParam}@endlatexonly.

             @latexonly\input{tables/tableSyntaxHdrFormat4SetParam.tex}@endlatexonly
           */

    OMX_U8  data[1]; /**< Syntax header data. This is an array of one or more
                          bytes of data as indicated by the nBytes field. */
} QOMX_VIDEO_SYNTAXHDRTYPE;

/** @} */ /* end_addtogroup video_syntax_header */


/** @addtogroup video_intrarefresh
@{ */
/** @latexonly\label{hdr:INTRAREFRESHTYPE}@endlatexonly
    Extended video intra-refresh types that are not present in the OpenMAX IL
    specification.
*/
typedef enum QOMX_VIDEO_INTRAREFRESHTYPE
{
    QOMX_VIDEO_IntraRefreshRandom      = 0x7F100000
         /**< @latexonly\label{hdr:IntraRefreshRandom}@endlatexonly
              Random Intra-refresh mode. */
} QOMX_VIDEO_INTRAREFRESHTYPE;

/** @} */ /* end_addtogroup video_intrarefresh */


/** @addtogroup video_intraperiod
@{ */
/** @brief @latexonly\label{hdr:INTRAPERIODTYPE}@endlatexonly
    Used to configure the intra-periodicity for the video encoder.
*/
typedef struct QOMX_VIDEO_INTRAPERIODTYPE  {
    OMX_U32 nSize;            /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;       /**< Index of the port to which this structure applies. */
    OMX_U32 nIDRPeriod;       /**< Defines the periodicity of an Instantaneous
                                   Decoding Refresh (IDR) occurrence.

                                   A frame is coded as IDR after a specific
                                   number of intra-frames. The periodicity of the
                                   intra-frame coding is specified by the nPFrames
                                   parameter.

                                   If nIDRPeriod is set to 0, only the first frame
                                   of the encode session is an IDR frame.

                                   This field is ignored for non-AVC codecs and is
                                   used only for codecs that support an IDR period. */
    OMX_U32 nPFrames; /**< Number of P (Predicted picture) frames between each I
                           (Intra-coded) frame. */
    OMX_U32 nBFrames; /**< Number of B (Bi-predictive picture) frames between each
                           I frame.\n
                           Not all codec/profile types support configuring the
                           presence of B frames. This setting is ignored for such
                           codecs/profiles. */
} QOMX_VIDEO_INTRAPERIODTYPE;

/** @} */ /* end_addtogroup video_intraperiod */


/** @addtogroup video_extensions
@{ */
/** @latexonly\label{hdr:EXTRADATATYPE}@endlatexonly
    Extended video extra data payload types that are not present in the OpenMAX
    IL specification.
*/
typedef enum QOMX_VIDEO_EXTRADATATYPE
{
   QOMX_ExtraDataVideoMultiSliceInfo = 0x7F100000,
     /**< @latexonly\label{hdr:ExtraDataVideoMultiSliceInfo}@endlatexonly
          Indicates that the data payload contains multi-slice layout information. */

   QOMX_ExtraDataVideoNumConcealedMB,
     /**< @latexonly\label{hdr:ExtraDataVideoNumConcealedMB}@endlatexonly
          Number of concealed macroblocks.

          The data array consists of an unsigned 32-bit size field indicating
          the number of concealed macroblocks in the uncompressed frame. */

   QOMX_ExtraDataOMXIndex,
     /**< Indicates that the data payload contains an OpenMAX index and
          associated payload.

          The associated payload contains the value of the OMX_INDEXTYPE
          corresponding to the requested operation as an unsigned 32-bit number
          occupying the first four bytes of the payload. The index is
          immediately followed by the associated structure. Padding bytes are
          appended to ensure 32-bit address alignment, if needed. */

   QOMX_ExtraDataVideoLTRInfo,
     /**< @latexonly\label{hdr:ExtraDataVideoLTRInfo}@endlatexonly
          LTR frame identifier.

          The data array consists of an unsigned 32-bit size field specifing
          the identider of the LTR frame in the payload. */

   QOMX_ExtraDataVideoExtensionData,

   QOMX_ExtraDataVideoUserData,

   QOMX_ExtraDataVideoMBInfo,

   QOMX_ExtraDataVideoQPArray,

   QOMX_ExtraDataVideoSEI,

   QOMX_ExtraDataVideoVUI,

   QOMX_ExtraDataVideoMvcVUI,

   QOMX_ExtraDataVideoMetaVC1,

   QOMX_ExtraDataVideoDisplayInfo,

   QOMX_ExtraDataVideoUnused
     /**< @latexonly\label{hdr:QOMX_ExtraDataVideoUnused}@endlatexonly */

} QOMX_VIDEO_EXTRADATATYPE;

/** @} */ /* end_addtogroup video_extensions */


/** @addtogroup video_encoder_modes
@{ */
/** @latexonly\label{hdr:ENCODERMODETYPE}@endlatexonly
    Video encoder modes.
*/
typedef enum QOMX_VIDEO_ENCODERMODETYPE
{
    QOMX_VIDEO_EncoderModeDefault        = 0x01,
      /**< Default video recording mode.
           All encoder settings made through OMX_SetParameter/OMX_SetConfig
           are applied. No parameter is overridden. */

    QOMX_VIDEO_EncoderModeMMS            = 0x02,
      /**< Video recording mode for the Multimedia Messaging Service (MMS).
           This mode is similar to EncoderModeDefault, except that here the
           rate control mode is overridden internally and set as a variant
           of a variable bitrate with a variable frame rate.

           After this mode is set, if the IL client tries to set
           OMX_VIDEO_CONTROLRATETYPE via OMX_IndexParamVideoBitrate, it is
           rejected. The client must set the mode back to EncoderModeDefault
           first and then change OMX_VIDEO_CONTROLRATETYPE. */

    QOMX_VIDEO_EncoderModeMax            = 0x7FFFFFFF
      /**< Maximum Encoder mode. */

} QOMX_VIDEO_ENCODERMODETYPE;

/** @} */ /* end_addtogroup video_encoder_modes */


/** @addtogroup video_encoder_modes
@{ */
/** @brief @latexonly\label{hdr:PARAMENCODERMODETYPE}@endlatexonly
    Used to configure the video encoder mode.
*/
typedef struct QOMX_VIDEO_PARAM_ENCODERMODETYPE {
    OMX_U32 nSize;            /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;       /**< Index of the port to which this structure applies. */
    QOMX_VIDEO_ENCODERMODETYPE nMode; /**< Enumeration for the type of video encoder
                                           mode. Possible values are described in
                          Section @latexonly\ref{hdr:ENCODERMODETYPE}@endlatexonly. */
} QOMX_VIDEO_PARAM_ENCODERMODETYPE;

/** @} */ /* end_addtogroup video_encoder_modes */


/** @addtogroup temporal_spatial
@{ */
/** @brief @latexonly\label{hdr:TEMPORALSPATIALTYPE}@endlatexonly
    Used to set the temporal (picture rate)/spatial (picture quality) trade-off
    factor.

    This structure specifies whether picture quality (spatial) or picture rate
    (temporal) is to be emphasized in rate control decisions of an encoder. The
    setting is valid only when rate control is enabled and set to a mode with a
    variable frame rate. For all other rate control modes this setting is ignored.
*/
typedef struct QOMX_VIDEO_TEMPORALSPATIALTYPE {
    OMX_U32 nSize;            /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;       /**< Index of the port to which this structure applies.*/
    OMX_U32 nTSFactor;        /**< Temporal-spatial tradeoff factor value in the
                                   range of 0 to 100.

           A factor of 0 does not emphasize the picture rate in rate control
           decisions (i.e., only the picture quality is emphasized). For
           increasing values from 1 to 99, the emphasis of picture rate in
           rate control decisions increases. A factor of 100 emphasizes
           only the picture rate in rate control decisions. */

} QOMX_VIDEO_TEMPORALSPATIALTYPE;

/** @} */ /* end_addtogroup temporal_spatial */


/** @addtogroup mb_concealment
@{ */
/** @brief @latexonly\label{hdr:MBCONCEALMENTREPORTINGTYPE}@endlatexonly
    Enables/disables macroblock concealment reporting.

    This structure enables or disables the reporting of the number of concealed
    macroblocks for uncompressed frames emitted from the port. This number is
    communicated through an extra data section.

    @return
    Error condition -- If the IL client specifies a parameter value that is not
    supported by the component, OMX_ErrorUnsupportedSetting is returned.

    @dependencies
    OMX_SetConfig and OMX_GetConfig are valid in all states except OMX_StateInvalid.
*/
typedef struct QOMX_VIDEO_MBCONCEALMENTREPORTINGTYPE {
    OMX_U32 nSize;            /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;       /**< Index of the port to which this structure applies. */
    OMX_BOOL bEnableMBConcealmentReporting;
                              /**< Flag that indicates whether macroblock
                                   concealment reporting is enabled or disabled.
                                   - OMX_TRUE --  Enables reporting.
                                   - OMX_FALSE -- Disables reporting. */
} QOMX_VIDEO_MBCONCEALMENTREPORTINGTYPE;

/** @} */ /* end_addtogroup mb_concealment */


/** @addtogroup picture_type_decode
@{ */
/** Specifies the extended picture types. These values are to be ORed with the
    types defined in OMX_VIDEO_PICTURETYPE to signal all pictures types that
    are allowed.

    H.264 Specific Picture Types enumerations: IDR
 */
typedef enum QOMX_VIDEO_PICTURETYPE {
    QOMX_VIDEO_PictureTypeIDR = OMX_VIDEO_PictureTypeVendorStartUnused + 0x1000
} QOMX_VIDEO_PICTURETYPE;

/** @} */ /* end_addtogroup picture_type_decode */


/** @addtogroup picture_type_decode
@{ */
/** @brief @latexonly\label{hdr:DECODEPICTURETYPE}@endlatexonly
    Used to configure the processing of specific picture types.
*/
typedef struct QOMX_VIDEO_DECODEPICTURETYPE {
    OMX_U32 nSize;              /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion;   /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;         /**< Port to which this structure applies. */
    OMX_U32 nPictureTypes;      /**< Picture types that are to be processed. The
                                     value consists of the picture types defined
                                     by the OMX_VIDEO_PICTURETYPE and
                                     QOMX_VIDEO_PICTURETYPE enumerations, ORed to
                                     signal that all the pictures types that are allowed. */
} QOMX_VIDEO_DECODEPICTURETYPE;

/** @} */ /* end_addtogroup picture_type_decode */


/** @addtogroup video_index_extra_data
@{ */
/** @brief @latexonly\label{hdr:SAMPLEASPECTRATIO}@endlatexonly
    Describes the sample aspect ratio information.
*/
typedef struct QOMX_VIDEO_SAMPLEASPECTRATIO {
    OMX_U32 nSize;            /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;   /**< Index of the port to which this structure applies. */
    OMX_U16 nWidth;       /**< Horizontal aspect size of the sample. */
    OMX_U16 nHeight;      /**< Vertical aspect size of the sample. */
} QOMX_VIDEO_SAMPLEASPECTRATIO;

/** @} */ /* end_addtogroup picture_type_decode */


/** @addtogroup video_index_extra_data
@{ */
/** @brief @latexonly\label{hdr:DISPLAYPICTUREBUFFERTYPE}@endlatexonly
    Used to enable or disable the display picture buffer size configuration.
*/
typedef struct QOMX_VIDEO_DISPLAYPICTUREBUFFERTYPE {
    OMX_U32 nSize;            /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion; /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;   /**< Index of the port to which this structure applies. */
    OMX_BOOL bEnable;     /**< Specifies whether to enable or disable the display
                               picture buffer size configuration. If disabled,
                               the decoder uses its default value equal to the
                               minimum output buffers required, which it derives
                               from the properties of the input bitstream. */
    OMX_U32 nPictureCount;/**< Configures the size of display ordering picture
                               buffer. The decoder buffers nPictureCount number
                               of output frames before providing an output
                               frame for rendering.\n
                               This field is valid only when bEnable is enabled.\n
                               A value of 0 is invalid and not supported.
                               Supported values are 1 <= nPictureCount <=
                               minimum output buffer count derived from the input
                               bitstream properties. */
} QOMX_VIDEO_DISPLAYPICTUREBUFFERTYPE;

/** @} */ /* end_addtogroup video_decoder_display_picture_buffer */


/** @cond
*/
/** @brief Used to configure a port to apply a scaling factor to a frame's
    associated timestamp.
*/
typedef struct QOMX_VIDEO_TIMESTAMPSCALETYPE {
    OMX_U32 nSize;             /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion;  /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;        /**< Port to which this structure applies. */
    OMX_U32 nTimestampScale;   /**< Scale factor to be applied to the buffer
                                    header timestamp. The value is represented
                                    in Q16 format. */
} QOMX_VIDEO_TIMESTAMPSCALETYPE;

/** @brief Used to specify Frame Rate Enhancement (FRE) information.
*/
typedef struct QOMX_VIDEO_FRAMERATEENHANCEMENTTYPE {
    OMX_U32 nSize;               /**< Size of the structure in bytes. */
    OMX_VERSIONTYPE nVersion;    /**< OpenMAX IL specification version information. */
    OMX_U32 nPortIndex;          /**< Port to which this structure applies. */
    OMX_BOOL bEnable;            /**< Enables or disables frame rate enhancement
                                      functionality. The client sets one of these
                                      values:
                                      - OMX_TRUE  -- Enables FRE functionality.
                                      - OMX_FALSE -- Disables FRE functionality. */
    OMX_BOOL bUseQualitySetting; /**< Enables or disables the quality setting.
                                      - True  -- The quality setting applies.
                                      - False -- The quality setting is ignored,
                                        and the quality is defined automatically. */
    OMX_U32 nQuality;            /**< Sets the enhancement frame quality to n,
                                      between 0 (lowest) and 10 (highest). */
    OMX_U32 nFramerateScale;     /**< Sets the interpolated frame rate scale.
                                      For example, a value of 2 sets an
                                      interpolated frame rate scale of 2x,
                                      effectively doubling the number of frames. */
} QOMX_VIDEO_FRAMERATEENHANCEMENTTYPE;

/** @endcond */

/** @brief Used to enable deinterlacer .
*/
typedef struct QOMX_VIDEO_DEINTERLACERTYPE
{
   OMX_U32 nSize;                     /** Size of the structure in bytes */
   OMX_VERSIONTYPE nVersion;          /** OMX specification version information */
   OMX_U32 nPortIndex;                /** Portindex which is extended by this structure */
   OMX_BOOL  bEnable;                 /** Set to 0: disable video deinterlacer
                                       *  Set to 1: enable  video deinteralcer
                                       */
} QOMX_VIDEO_DEINTERLACERTYPE;

/** @endcond */


/** @brief Used to config output bit rate for transport
*/ 
typedef struct OMX_QOMX_INDEX_CONFIG_TRANSPORT_BITRATETYPE{
    OMX_U32 nSize;                          
    OMX_VERSIONTYPE nVersion;               
    OMX_U32 nPortIndex;                     
    OMX_U32 nBitRate;                 
} OMX_QOMX_INDEX_CONFIG_TRANSPORT_BITRATETYPE;

/** @endcond */

/** @brief Used to config PID value in transport stream
*/

typedef struct OMX_QOMX_INDEX_CONFIG_MEPG2TS_PIDTYPE{
    OMX_U32 nSize;                          
    OMX_VERSIONTYPE nVersion;               
    OMX_U32 nPortIndex;                     
    OMX_U32 nPid;                 
} OMX_QOMX_INDEX_CONFIG_MEPG2TS_PIDTYPE;

/** @endcond */

/** @brief Used to config number fo packets in an output buffer
*/

typedef struct OMX_QOMX_INDEX_CONFIG_TRANSPORT_NUMPACKETTYPE{
    OMX_U32 nSize;                          
    OMX_VERSIONTYPE nVersion;               
    OMX_U32 nPortIndex;                     
    OMX_U32 nPackets;                 
} OMX_QOMX_INDEX_CONFIG_TRANSPORT_NUMPACKETTYPE;

/** @brief Used to specify the MVC Configurations.
*/
enum {
   QOMX_VIDEO_MVCProfileMultiViewHigh = OMX_VIDEO_AVCProfileVendorStartUnused + 3, /**< Multiview High profile */
   QOMX_VIDEO_MVCProfileStereoHigh = OMX_VIDEO_AVCProfileVendorStartUnused +  4    /**< Stereo High profile */
};

typedef struct QOMX_VIDEO_MVCCONFIGTYPES {
   OMX_U32 nSize;
   OMX_VERSIONTYPE nVersion;
   OMX_U8  nViews;
   OMX_U8 nCompleteRepresentation;
   OMX_U8 nExplicitAUTrack;
}QOMX_VIDEO_MVCCONFIGTYPES;

typedef struct QOMX_VIDEO_MVCVIEWPARAMETERS {
   OMX_U32 nSize;
   OMX_VERSIONTYPE  nVersion;
   OMX_U16  nViewId;
   OMX_U16  nViewOrderIndex;
   OMX_U16  nBaseViewType;
   OMX_U16  nReferenceViews;
   OMX_U16  nReferenceViewIds[16];
} QOMX_VIDEO_MVCVIEWPARAMETERS;

typedef struct QOMX_VIDEO_MVCVIEWIDTYPES {
   OMX_U32 nSize;
   OMX_VERSIONTYPE nVersion;
   OMX_U8  nMinimumTemporalId;
   OMX_U8  nMaximuxTemporalId;
   OMX_U16 nViews;
   QOMX_VIDEO_MVCVIEWPARAMETERS views[16];
}QOMX_VIDEO_MVCVIEWIDTYPES;

typedef enum QOMX_VIDEO_HIERARCHICALCODINGTYPE {
   QOMX_VIDEO_HIERARCHICALCODING_P = 0,      /**< Hierarchical-P Encoding */
   QOMX_VIDEO_HIERARCHICALCODING_B = 1       /**< Hierarchical-B Encoding */
} QOMX_VIDEO_HIERARCHICALCODINGTYPE;

/** @brief Used to specify RTP payload type.
 *  Refer to RFC 3551 - RTP Profile for Audio and Video Conferences
 *  with Minimal Control
*/
typedef enum QOMX_RTP_PAYLOAD_TYPE
{
   QOMX_RTP_PAYLOAD_MPEG2_TS = 33, 
   QOMX_RTP_PAYLOAD_H264 = 96
} QOMX_RTP_PAYLOAD_TYPE;

typedef struct QOMX_VIDEO_HIERARCHICALLAYERS {
   OMX_U32 nSize;             /**< Size of the structure in bytes. */
   OMX_VERSIONTYPE nVersion;  /**< OpenMAX IL specification version information. */
   OMX_U32 nPortIndex;        /**< Port to which this structure applies. */
   OMX_U32 nNumLayers;        /**< number of layers */
   QOMX_VIDEO_HIERARCHICALCODINGTYPE eHierarchicalCodingType;  /**< hierarchical coding type */
} QOMX_VIDEO_HIERARCHICALLAYERS;

typedef struct QOMX_VIDEO_HIERARCHICALLAYERSTRUCTURE {
   OMX_U32 nSize;             /**< Size of the structure in bytes. */
   OMX_VERSIONTYPE nVersion;  /**< OpenMAX IL specification version information. */
   OMX_U32 nPortIndex;        /**< Port to which this structure applies. */
   OMX_U32 nLayerID;          /**< identifier for hierarchical layers (i.e., layer 1 and above */
   OMX_U32 nPFrames;          /**< number of P frames at specified
                               *   hierarchical layer in a GOP
                               */
   OMX_U32 nBFrames;          /**< number of B frames at specified
                               *   hierarchical layer in a GOP
                               */
} QOMX_VIDEO_HIERARCHICALLAYERSTRUCTURE;

typedef struct QOMX_VIDEO_HIERARCHICALLAYERQP
{
   OMX_U32 nSize;             /**< Size of the structure in bytes. */
   OMX_VERSIONTYPE nVersion;  /**< OpenMAX IL specification version information. */
   OMX_U32 nPortIndex;        /**< Port to which this structure applies. */
   OMX_U32 nLayerID;          /**< layer identifier */
   OMX_U32 nQPI;              /**< QP value for the first I Frame at
                               *   the base layer.
                               *   This value will be used for all
                               *   I frames if rate control is
                               *   disabledQP value for I-frame.
                               *   This value is only effective for the
                               *   base layer and is ignored for other
                               *   layers.
                               */
   OMX_U32 nQPP;              /**< QP value for the first P Frame at
                               *   specified layer.
                               *   This value will be used for all
                               *   P frames for the specified layer
                               *   if rate control is disabled.
                               */
   OMX_U32 nQPB;              /**< QP value for the first B Frame at
                               *   specified layer.
                               *   This value will be used for all
                               *   B frames for the specified layer
                               *   if rate control is disabled.
                               *   This value is ignored for codec not
                               *   supporting B-frame or hierarchical-B
                               *   is not enabled.
                               */
} QOMX_VIDEO_HIERARCHICALLAYERQP;

typedef struct QOMX_VIDEO_HIERARCHICALLAYERBITRATE
{
   OMX_U32 nSize;             /**< Size of the structure in bytes. */
   OMX_VERSIONTYPE nVersion;  /**< OpenMAX IL specification version information. */
   OMX_U32 nPortIndex;        /**< Port to which this structure applies. */
   OMX_U32 nNumLayers;        /**< Number of layers for hierarchical
                               *   encoding. This is the size for
                               *   for the bit rate array of nBitRate
                               */
   OMX_U32 nBitRate[1];       /**< Contains bit rates for one or more
                               *   layers specified in nNumLayers.
                               */
} QOMX_VIDEO_HIERARCHICALLAYERBITRATE;

/**
 * This structure describes the parameters corresponding to the
 * QOMX_VIDEO_CONFIG_QPRANGE extension. This parameter can be set
 * dynamically during any state except the state invalid. This is primarily used for the min/max QP to be set from
 * the application.  This is set on the out port.
 */
typedef struct QOMX_VIDEO_CONFIG_QPRANGE
{
   OMX_U32 nSize;           /** Size of the structure in bytes */
   OMX_VERSIONTYPE nVersion;/** OMX specification version information */
   OMX_U32 nPortIndex;      /** Portindex which is extended by this structure */
   OMX_U32 nMinQP;          /** The number for minimum quantization parameter */
   OMX_U32 nMaxQP;          /** The number for maximum quantization parameter */
} QOMX_VIDEO_CONFIG_QPRANGE;

typedef struct QOMX_VIDEO_PARAM_SESSION_NAME
{
   OMX_U32 nSize;            /** Size of the structure in bytes */
   OMX_VERSIONTYPE nVersion; /** OMX specification version information */
   OMX_U32 nPortIndex;       /** Portindex which is extended by this structure */
   OMX_U32 nBufSz;           /** Buffer size in bytes */
   OMX_U8  sBuf[1];          /** Buffer pointer that contains client name string */
} QOMX_VIDEO_PARAM_SESSION_NAME;

typedef struct QOMX_VIDEO_PARAM_SIGNAL_METADATA
{
   OMX_U32 nSize;                     /** Size of the structure in bytes */
   OMX_VERSIONTYPE nVersion;          /** OMX specification version information */
   OMX_U32 nPortIndex;                /** Portindex which is extended by this structure */
   OMX_BOOL  bEnable;                 /** Set to 0: No metadata generated
                                       *  Set to 1: Encode video signal metadata information
                                       */
   OMX_U32   nVideoFormat;            /** Video format
                                       *  If unknown, set 5 for Unspecified video format
                                       *  0 : Component
                                       *  1 : PAL
                                       *  2 : NTSC
                                       *  3 : SECAM
                                       *  4 : MAC
                                       */
   OMX_BOOL  bVideoFullRangeEnable;   /** video_full_range_flag for H264/HEVC
                                       *  Allowed values:
                                       *  0 : [16 - 235] for 8 bits
                                       *  1 : [0 - 235] for 8 bits
                                       */
   OMX_BOOL  bColorDescriptionEnable; /** HEVC/H264: colour_description_present_flag */
   OMX_U32   nColourPrimaries;        /** colour_primaries */
   OMX_U32   nTransferCharacteristics;/** transfer_characteristics */
   OMX_U32   nMatrixCoeffs;           /** matrix_coeffs */
} QOMX_VIDEO_PARAM_SIGNAL_METADATA;

/**
   Property to enable extradata generation for display related information from VUI present in SPS.
   This information is to be used by downstream components such as display
   or graphics engine for proper consumption of the decoder output.

   This extradata is generated when video_signal_type_present_flag or chroma_loc_info_present_flag is
   set in VUI of H.264/HEVC stream. If a stream does not have VUI or has a VUI but video_signal_type_present_flag
   is clear, the extradata is not generated.
*/
typedef struct QOMX_VIDEO_PARAM_DISPLAY_INFO_METADATA
{
   OMX_BOOL  bVideoSignalPresentFlag; /** Set to 0: No video signal metadata generated
                                       *  Set to 1: Encode video signal metadata information
                                       */
   OMX_U32   nVideoFormat;            /** Video format
                                       *  If unknown, set 5 for Unspecified video format
                                       *  0 : Component
                                       *  1 : PAL
                                       *  2 : NTSC
                                       *  3 : SECAM
                                       *  4 : MAC
                                       */
   OMX_U32   nBitDepthY;                   /** specifies bit depth of Luma samples */
   OMX_U32   nBitDepthC;                   /** specifies bit depth of Chroma samples */
   OMX_BOOL  bVideoFullRangeFlag;   /** video_full_range_flag for H264/HEVC
                                     *  Allowed values:
                                     *  0 : [16 - 235] for 8 bits
                                     *  1 : [0 - 235] for 8 bits
                                     */
   OMX_BOOL  bColorDescriptionPresentFlag; /** HEVC/H264: colour_description_present_flag */
   OMX_U32   nColourPrimaries;             /** colour_primaries */
   OMX_U32   nTransferCharacteristics;     /** transfer_characteristics */
   OMX_U32   nMatrixCoeffs;                /** matrix_coeffs */
   OMX_BOOL  bChromaLocInfoPresentFlag;  /** Set to 1 : indicating if chroma_sample_loc_type_top_field 
                                                        and chroma_sample_loc_type_bottom_field are present 
                                             Set to 0 : no present 
                                          */
   OMX_U32   nChromaFormatIdc;
   OMX_BOOL  bSeparateColourPlaneFlag;   /** Present only if chroma_format_idc = 3 
                                             Set to 1: the three colour component of the 4:4:4 chroma format are coded separately 
                                             Set to 0: the colour components are not coded separatedly 
                                             When not present, it is nfered to be equal to 0.
                                          */
   OMX_U32   nChromaSampleLocTypeTopField;      /** Chroma sample location in top field */
   OMX_U32   nChromaSampleLocTypeBottomField;   /** Chroma sample location in bottom field */
} QOMX_VIDEO_PARAM_DISPLAY_INFO_METADATA;

/**
 * Property to config the RTP sink/source connection info.
 * This structure describes the parameters corresponding to the
 * OMX.QCOM.index.param.rtp.connectioninfo extension.
*/
typedef struct QOMX_PARAM_RTP_CONNECTIONINFO
{
   OMX_U32               nSize;            /** Size of the structure in bytes */
   OMX_VERSIONTYPE       nVersion;         /** OpenMAX IL specification version information */
   OMX_U32               nPortIndex;       /** Index of the port to which this structure applies */
   OMX_STRING            pDestAddr;        /** Destination IP address */
   OMX_U32               nDestPort;        /** Destination port */
   OMX_U32               nLocalPort;       /** Local port */
   OMX_U32               nBitrate;         /** Target transmition bitrate */
   QOMX_RTP_PAYLOAD_TYPE eRTPPayloadType;  /** RTP payload type */
   OMX_BOOL              bIPv6;            /** Flag that indicates whether IPv6 is enabled */
   OMX_BOOL              bMulticast;       /** Flag that indicates whether multicast is enabled */
} QOMX_PARAM_RTP_CONNECTIONINFO;

/**
 * Property to config the color frame for rendering. A spcified color frame will be shown
 * if the render component is not receiving frames for given timeout in this mode.
 * This structure describes the parameters corresponding to the
 * OMX.QCOM.index.render.ColorFrame extension.
*/
typedef struct QOMX_PARAM_RENDER_COLORFRAME
{
   OMX_U32               nSize;               /** Size of the structure in bytes */
   OMX_VERSIONTYPE       nVersion;            /** OpenMAX IL specification version information */
   OMX_U32               nPortIndex;          /** Index of the port to which this structure applies */
   OMX_BOOL              bEnable;             /** Flag that indicates whether color frame mode is enabled */
   OMX_U32               nTimeoutMiliSeconds; /** Timeout of the interval of two commits before a color frame be shown */
   OMX_U8                nRGBValue[3];        /** Array to store the R/G/B value of the color frame */
} QOMX_PARAM_RENDER_COLORFRAME;

/** @endcond */

#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */

#endif /* end of macro __H_QOMX_VIDEOEXTENSIONS_H__ */
