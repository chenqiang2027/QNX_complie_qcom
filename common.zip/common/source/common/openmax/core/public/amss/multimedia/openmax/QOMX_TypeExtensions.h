#ifndef __H_QOMX_TYPEEXTENSIONS_H__
#define __H_QOMX_TYPEEXTENSIONS_H__ 

/*========================================================================

*//** @file QOMX_TypeExtensions.h 

@par FILE SERVICES:
      Common Qualcomm type definitions used by Qualcomm extensions.

      This file contains the common type definitions that are used by the
      Qualcomm OpenMax IL extentions, through which the IL client and 
      OpenMax components can access additional  capabilities.
   
    Copyright (c) 2010 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/core/public/amss/multimedia/openmax/QOMX_TypeExtensions.h#1 $

========================================================================== */
 
/*======================================================================== 
 
                     INCLUDE FILES FOR MODULE 
 
========================================================================== */ 
#include <OMX_Core.h>

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */

/** 
 * QOMX_ENABLETYPE is a generic structure that is used by
 * extensions that only require an enable/disable mechanism to
 * be exposed through the API.
 * 
 *  STRUCT MEMBERS:
 *  nSize      : Size of the structure in bytes
 *  nVersion   : OMX specification version information
 *  nPortIndex : Port that this structure applies to
 *  bEnable    : Enables the parameter or configuration if set
 *               to OMX_TRUE or disables the it if set to
 *               OMX_FALSE.
 */
typedef struct QOMX_ENABLETYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_BOOL bEnable;
} QOMX_ENABLETYPE;

/** 
 * QOMX_URANGETYPE is a generic structure that is used by 
 * extensions to query or set a range of UNSIGNED values for a 
 * particular parameter. 
 * 
 *  STRUCT MEMBERS:
 *  nSize      : Size of the structure in bytes
 *  nVersion   : OMX specification version information
 *  nPortIndex : Port that this structure applies to
 *  nMin       : is the lower bound or minimum value of the range
 *  nMax       : is the upper bound or maximum value of the range
 *  nStepSize  : gives the step up value that can be used to derive the values
 *               within the range nMin to nMax using increments of nStepSize
 *               or conversely it can be used as step down value to derive
 *               values starting from nMax using decrements of nStepSize
 */
typedef struct QOMX_URANGETYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_U32 nMin;
    OMX_U32 nMax;
    OMX_U32 nStepSize;
} QOMX_URANGETYPE;


/** 
 * QOMX_SRANGETYPE is a generic structure that is used by 
 * extensions to query or set a range of SIGNED values for a 
 * particular parameter. 
 * 
 *  STRUCT MEMBERS:
 *  nSize      : Size of the structure in bytes
 *  nVersion   : OMX specification version information
 *  nPortIndex : Port that this structure applies to
 *  nMin       : is the lower bound or minimum value of the range
 *  nMax       : is the upper bound or maximum value of the range
 *  nStepSize  : gives the step up value that can be used to derive the values
 *               within the range nMin to nMax using increments of nStepSize
 *               or conversely it can be used as step down value to derive
 *               values starting from nMax using decrements of nStepSize
 */
typedef struct QOMX_SRANGETYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_S32 nMin;
    OMX_S32 nMax;
    OMX_U32 nStepSize;
} QOMX_SRANGETYPE;

/** 
 * The QOMX_FLOWSTATUSTYPE structure is used to provide the
 * performance status of the buffer processing rate with respect
 * to the current presentation time and/or required consumption
 * rate.
 * 
 *  STRUCT MEMBERS:
 *  nSize      : Size of the structure in bytes
 *  nVersion   : OMX specification version information
 *  nPortIndex : Port that this structure applies to
 *  nTime      : Indicates the time duration, in milliseconds,
 *               that a recently processed frame is behind
 *               with respect to the current presentation time
 *               and/or required consumption rate.
 */
typedef struct QOMX_FLOWSTATUSTYPE {
    OMX_U32 nSize;
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_U32 nTime;
} QOMX_FLOWSTATUSTYPE;

#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */

#endif /* end of macro __H_QOMX_TYPEEXTENSIONS_H__ */
