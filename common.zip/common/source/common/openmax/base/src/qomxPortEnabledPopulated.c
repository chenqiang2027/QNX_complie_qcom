/*========================================================================

*//** @file qomxPortEnabledPopulated.c

@par FILE SERVICES:
      Implementation file for Port state QOMX_StatePortEnabledPopulated.

      This file contains the definitions for the port methods which are
      called when port state is QOMX_StatePortEnabledPopulated. This state
      is assumed when port is enabled and all the required buffers are
      aquired. Buffer processing is carried out in this state.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxPortEnabledPopulated.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
10/23/13   dp     Add missing variable to messages.
10/19/11   zm     Allow flush command.
07/22/10   zm     Add component handle/port index in base class logging.
07/15/10   yt     Changes for tunneling and new EnabledDepopulating state.
06/10/10   dm     Added return type in event handler.
03/26/10   spl    Modified to support interop-profile.
10/20/09   dm     Port state split.
08/17/08   dm     Allow port detected in this state.
07/24/09   dm     Changed order of buffer count decrement and callback.
07/21/09   dm     Handled buffer supplier settings.
06/16/09   dm     Initial Creation.

========================================================================== */

/*========================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxPortCommon.h"
#include "qomxPortUtils.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/**
 *
 * Forward declaration for the functions defined statically in this file.
 *
 */

static void  qomx_PortEnabledPopulated_StateEntryHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
);

static void  qomx_PortEnabledPopulated_StateExitHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
);

static OMX_ERRORTYPE    qomx_PortEnabledPopulated_Run
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
);

static OMX_ERRORTYPE    qomx_PortEnabledPopulated_DeviceEventHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEventCode,
   OMX_IN   OMX_U32                       nEventStatus,
   OMX_IN   OMX_U32                       nParamSize,
   OMX_IN   OMX_PTR                      *pParam
);


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledPopulated_LoadStateTable

         DESCRIPTION:
                        This function will load the port state table
                        supported by the QOMX_StatePortEnabledPopulated state
                        in the object of state table being passed.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable    - Pointer to the state primitive table
                                      object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortEnabledPopulated_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType      *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      port is in QOMX_StatePortEnabledPopulated state. NULL entry indicates
      that the specific function call is not allowed in this state, thus
      port utilities should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/
   pStTable->Enable           = NULL;
   pStTable->Disable          = qomx_PortCommon_Disable;
   pStTable->TunnelRequest    = NULL;
   pStTable->Populate         = NULL;
   pStTable->Unpopulate       = qomx_PortCommon_Unpopulate;
   pStTable->Run              = qomx_PortEnabledPopulated_Run;
   pStTable->Stop             = NULL;
   pStTable->UseBuffer        = NULL;
   pStTable->AllocateBuffer   = NULL;
   pStTable->FreeBuffer       = qomx_PortCommon_FreeBufferUnexpected;
   pStTable->EmptyThisBuffer  = NULL;
   pStTable->FillThisBuffer   = NULL;
   pStTable->Flush            = qomx_PortCommon_DummyFlush;
   pStTable->DeInit           = qomx_PortCommon_DeInit;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler  = qomx_PortEnabledPopulated_DeviceEventHandler;

   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler  = qomx_PortEnabledPopulated_StateEntryHandler;
   pStTable->pfnExitHandler   = qomx_PortEnabledPopulated_StateExitHandler;

   return;

} /* end of function qomx_PortEnabledPopulated_LoadStateTable */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledPopulated_StateEntryHandler

         DESCRIPTION:
*//**                   This function executes initial routines when port
                        moves in QOMX_StatePortEnabledPopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the Port context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_PortEnabledPopulated_StateEntryHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
)
{
   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Entering EnabledPopulated"
      " State, nPortIndex = 0x%x, nEvent = 0x%x",
      pPortCtx->portDef.nPortIndex, nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pPortCtx->eState = QOMX_StatePortEnabledPopulated;

   return;

} /* end of function qomx_PortEnabledPopulated_StateEntryHandler */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledPopulated_StateExitHandler

         DESCRIPTION:
*//**                   This function executes initial routines when port
                        moves out of QOMX_StatePortEnabledPopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the Port context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_PortEnabledPopulated_StateExitHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
)
{
   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Exiting EnabledPopulated"
      " State, nPortIndex = 0x%x, nEvent = 0x%x",
      pPortCtx->portDef.nPortIndex, nEvent );

   return;

} /* end of function qomx_PortEnabledPopulated_StateExitHandler */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledPopulated_Run

         DESCRIPTION:
                        This function will put the port in running state. Port
                        will start buffer processing when tunneling after this
                        function call.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortEnabledPopulated_Run
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
)
{
   OMX_ERRORTYPE  eRetVal = OMX_ErrorNone;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "qomx_PortEnabledPopulated_Run,"
      " Move to EnabledRunning state nPortIndex = 0x%x",
      pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Move to Running state.
   -------------------------------------------------------------------------*/
   ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                                 pPortCtx, QOMX_StatePortEnabledRunning, 0 );

   return( eRetVal );

} /* end of function qomx_PortEnabledPopulated_Run */





/*==========================================================================

         FUNCTION:      qomx_PortEnabledPopulated_DeviceEventHandler

         DESCRIPTION:
*//**                   This function processes events from device when port
                        is in one of the EnabledPopulated state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  nEventCode  - Event code.
            @param [in] nEventStatus- Status of the event.
            @param [in] nParamSize  - Size in bytes for the event related
                                      data which is pointed by the payload.
            @param [in] pParam      - Event related payload.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortEnabledPopulated_DeviceEventHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEventCode,
   OMX_IN   OMX_U32                       nEventStatus,
   OMX_IN   OMX_U32                       nParamSize,
   OMX_IN   OMX_PTR                      *pParam
)
{
   OMX_ERRORTYPE  eRetVal = OMX_ErrorNone;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
      "qomx_PortEnabledPopulated_DeviceEventHandler, nPortIndex = 0x%x,"
      " nEventCode = 0x%x", pPortCtx->portDef.nPortIndex, nEventCode );

   /**------------------------------------------------------------------------
      Check event code.
   -------------------------------------------------------------------------*/
   switch( nEventCode )
   {
   case MMI_EVT_PORT_CONFIG_CHANGED:
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "MMI_EVT_PORT_CONFIG_CHANGED"
            " event nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Process config change event and update port definition.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_ConfigChange(
                                          pPortCtnr->pCommonRef, pPortCtx );

      }

      break;

   default:
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Unexpected parameters in"
            " device event: nEventCode = 0x%x, nPortIndex = 0x%x",
            nEventCode, pPortCtx->portDef.nPortIndex );
      }

      break;

   } /* end of switch( nEventCode ) */

   return( eRetVal );

} /* end of function qomx_PortEnabledPopulated_DeviceEventHandler */
