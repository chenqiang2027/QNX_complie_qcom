#ifndef __QOMX_UTILS_H__
#define __QOMX_UTILS_H__

/*========================================================================

*//** @file qomxUtils.h

@par FILE SERVICES:
      Utility functions Header File.

      This file contains the various standard header file inclusions,
      utility functions etc. used by the component.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxUtils.h#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
06/22/16   am     Fix compiler warnings for 64 bit OS environment.
10/30/15   rz     Update logging for Windows environment
04/22/14   dp     Add AEEstd.h for Windows 32 environment too
04/01/14   rz     Replace std_strcmp with macro of std_strncmp
09/30/13   am     Use low prio STATS message for STATISTICS.
07/04/13   dp     Use std typedefs.
11/22/10   zm     Added support for customized heap management APIs.
09/30/10   zm     Use new diag category for base class logging messages.
09/13/10   dm     Adding component name and handle in logging messages.
10/28/09   dm     Featurize OMX_OSAL_Interfaces.
10/23/09   dm     Print QOMX messages in conformance test log file.
08/08/09   dm     Memory functions abstracted.
07/13/09   dm     Added macros for target based compilation.
07/01/09   dm     Added memcmp macro.
04/18/09   srk    Created file.

========================================================================== */

/*========================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */
#include <stdlib.h>        /* Standard 'C' library headers */
#include <string.h>
#include <MMDebugMsg.h>
#include "AEEstd.h" /* std typedefs, ie. byte, uint16, uint32, etc. and memcpy, memset */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */


/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */
/**
 *
 * These macros define memory allocation, release, memset, memory copy
 * functions for component methods to use. Free function will validate
 * pointer being freed and nullify memory pointer too.
 *
 */

/* To get memory module handle */
#define QOMX_CMPNT_MEM_GET_HANDLE( pfnGetHeapHandle, pHHeap )                \
            pfnGetHeapHandle( pHHeap )

/* To release memory module handle */
#define QOMX_CMPNT_MEM_RELEASE_HANDLE( pfnReleaseHeapHandle, hHeap )         \
            pfnReleaseHeapHandle( hHeap )

/* To allocate memory from given memory module */
#define QOMX_CMPNT_MALLOC( pfnMalloc, hHeap, nSize )                         \
            pfnMalloc( hHeap, nSize )

/* To release memory from given memory module */
#define QOMX_CMPNT_FREEIF( pfnFree, hHeap, pMem )                            \
            if( NULL != pMem )                                               \
            {                                                                \
               pfnFree( hHeap, ( void * ) pMem );                            \
               pMem = NULL;                                                  \
            }

/* To fill memory area with a given value */
#define QOMX_CMPNT_MEM_SET( pDest, nValue, nSize )                           \
            ( void ) std_memset( pDest, nValue, nSize )

/* To copy nSize contents from pSrc to pDest */
#define QOMX_CMPNT_MEM_COPY( pDest, pSrc, nSize )                            \
            ( void ) std_memmove( pDest, pSrc, nSize )

/* To compare two buffers for given size */
#define QOMX_CMPNT_MEM_CMP( pBuffer1, pBuffer2, nSize )                      \
            std_memcmp( pBuffer1, pBuffer2, nSize )

/* To compare two strings */
#define QOMX_CMPNT_STR_CMP( pStr1, pStr2 )                                   \
            std_strncmp( pStr1, pStr2, std_strlen(pStr2) )

/**
 *
 * These macros define debug messsages for various targets.
 *
 */

/*--------------------------------------------------------------------------*/
/* BEGIN */
/*--------------------------------------------------------------------------*/
/* For QOMX_Utils internal use only, NOT to be referred directly */
/*--------------------------------------------------------------------------*/

#define QOMX_MSG_PRIORITY_HIGH      MM_PRIO_HIGH
#define QOMX_MSG_PRIORITY_MED       MM_PRIO_MEDIUM
#define QOMX_MSG_PRIORITY_LOW       MM_PRIO_LOW
#define QOMX_MSG_PRIORITY_ERROR     MM_PRIO_ERROR

/* General messages with component name & handle references */
#define QOMX_STATS_MSG( ref, prio, fmt, ... )             \
   if ( MM_PRIO_MEDIUM <= prio )                                          \
   {                                                                      \
      MM_MSG_PRIO_EX( MM_STATS_SLOG, prio, "h=0x%lx, " fmt,                  \
         ( intptr_t ) ( ref )->hCmpnt, ## __VA_ARGS__ );                 \
   }                                                                      \
   else                                                                   \
   {                                                                      \
      MM_MSG_PRIO_EX( MM_STATISTICS, MM_PRIO_MEDIUM, "h=0x%lx, %s " fmt,      \
         ( intptr_t ) ( ref )->hCmpnt,                                        \
         ( const char * ) ( & ( ( ref )->debugMsgProp.acCustomName[ 0 ] ) ), \
         ## __VA_ARGS__ );                                                 \
   }                                                                         \

#define QOMX_NORMAL_MSG_EX( prio, fmt, ... )          \
         MM_MSG_PRIO_EX( MM_OMX_COMMON, prio, fmt, ## __VA_ARGS__ )

#define QOMX_MSG_PROP_GEN_REQ_REF( req, prio, ref, fmt, ... ) \
      if( ( QOMX_DEBUG_MSG_COMPONENT_NAME                                    \
               & ( ref )->debugMsgProp.nDebugMsgLevelFlags )                 \
         && ( req & ( ref )->debugMsgProp.nDebugMsgLevelFlags ) )            \
      {                                                                      \
         QOMX_NORMAL_MSG_EX( prio, "%s, h=0x%p, " fmt,                       \
         ( const char * ) ( & ( ( ref )->debugMsgProp.acCustomName[ 0 ] ) ), \
           ( ref )->hCmpnt, ## __VA_ARGS__ );                                \
      }                                                                      \
      else if( req & ( ref )->debugMsgProp.nDebugMsgLevelFlags )             \
      {                                                                      \
         QOMX_NORMAL_MSG_EX( prio, "h=0x%p, " fmt,                           \
                            ( ref )->hCmpnt, ## __VA_ARGS__  );              \
      }

/* Messages with component name and handle */
#define QOMX_MSG_L_HIGH( pRef, msgFmt, ... )                          \
            QOMX_MSG_PROP_GEN_REQ_REF( QOMX_DEBUG_MSG_HIGH,                        \
                  QOMX_MSG_PRIORITY_HIGH, pRef, msgFmt, ## __VA_ARGS__ )

#define QOMX_MSG_L_MED( pRef, msgFmt, ... )                           \
            QOMX_MSG_PROP_GEN_REQ_REF( QOMX_DEBUG_MSG_MEDIUM,                      \
                  QOMX_MSG_PRIORITY_MED, pRef, msgFmt, ## __VA_ARGS__ )


#define QOMX_MSG_L_LOW( pRef, msgFmt, ... )                           \
            QOMX_MSG_PROP_GEN_REQ_REF( QOMX_DEBUG_MSG_LOW,                         \
                  QOMX_MSG_PRIORITY_LOW, pRef, msgFmt, ## __VA_ARGS__ )


#define QOMX_MSG_L_ERROR( pRef, msgFmt, ... )                         \
            QOMX_MSG_PROP_GEN_REQ_REF( QOMX_DEBUG_MSG_CRITICAL,                    \
                  QOMX_MSG_PRIORITY_ERROR, pRef, msgFmt, ## __VA_ARGS__ )

/* Regular messages */
#define QOMX_MSG_HIGH( msgFmt, ... )                                  \
   MM_MSG_PRIO_EX( MM_OMX_COMMON, QOMX_MSG_PRIORITY_HIGH, msgFmt, ## __VA_ARGS__ )

#define QOMX_MSG_MED( msgFmt, ... )                                   \
   MM_MSG_PRIO_EX( MM_OMX_COMMON, QOMX_MSG_PRIORITY_MED, msgFmt, ## __VA_ARGS__ )

#define QOMX_MSG_LOW( msgFmt, ... )                                   \
   MM_MSG_PRIO_EX( MM_OMX_COMMON, QOMX_MSG_PRIORITY_LOW, msgFmt, ## __VA_ARGS__ )

#define QOMX_MSG_ERROR( msgFmt, ... )                                 \
   MM_MSG_PRIO_EX( MM_OMX_COMMON, QOMX_MSG_PRIORITY_ERROR, msgFmt, ## __VA_ARGS__ )




/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Functions
** ----------------------------------------------------------------------- */

#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */


#endif /* __QOMX_UTILS_H__ */
