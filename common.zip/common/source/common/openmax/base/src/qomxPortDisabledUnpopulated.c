/*========================================================================

*//** @file qomxPortDisabledUnpopulated.c

@par FILE SERVICES:
      Implementation file for Port state QOMX_StatePortDisabledDepopulating.

      This file contains the definitions for the port methods which are
      called when port state is QOMX_StatePortDisabledUnpopulated. This
      state is assumed when port is disabled command and all the buffers
      are released.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxPortDisabledUnpopulated.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
10/23/13   dp     Add missing variable to messages.
10/19/11   zm     Allow flush command.
08/05/10   yt     Refactoring of disable procedure for tunneling.
07/22/10   zm     Add component handle/port index in base class logging.
06/10/10   dm     Added return type in event handler.
05/10/10   dm     Allow port config changed on disabled ports.
03/26/10   spl    Modified to support interop-profile.
11/25/09   dm     Corrected auto port detection behavior.
10/21/09   dm     Port state split.
07/21/09   dm     Added auto port detection event handling.
06/16/09   dm     Initial Creation.

========================================================================== */

/*========================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxPortCommon.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/**
 *
 * Forward declaration for the functions defined statically in this file.
 *
 */

static void    qomx_PortDisabledUnpopulated_StateEntryHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
);

static void    qomx_PortDisabledUnpopulated_StateExitHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
);

static OMX_ERRORTYPE    qomx_PortDisabledUnpopulated_DeviceEventHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEventCode,
   OMX_IN   OMX_U32                       nEventStatus,
   OMX_IN   OMX_U32                       nParamSize,
   OMX_IN   OMX_PTR                      *pParam
);


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_PortDisabledUnpopulated_LoadStateTable

         DESCRIPTION:
                        This function will load the port state table
                        supported by the QOMX_StatePortDisabledUnpopulated
                        state in the object of state table being passed.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable    - Pointer to the state primitive table
                                      object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortDisabledUnpopulated_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType      *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      port is in QOMX_StatePortDisabledUnpopulated state. NULL entry indicates
      that the specific function call is not allowed in this state, thus
      port utilities should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/
   pStTable->Enable           = qomx_PortCommon_Enable;
   pStTable->Disable          = NULL;
   pStTable->TunnelRequest    = qomx_PortCommon_TunnelRequest;
   pStTable->Populate         = NULL;
   pStTable->Unpopulate       = NULL;
   pStTable->Run              = NULL;
   pStTable->Stop             = NULL;
   pStTable->UseBuffer        = NULL;
   pStTable->AllocateBuffer   = NULL;
   pStTable->FreeBuffer       = NULL;
   pStTable->EmptyThisBuffer  = NULL;
   pStTable->FillThisBuffer   = NULL;
   pStTable->Flush            = qomx_PortCommon_DummyFlush;
   pStTable->DeInit           = qomx_PortCommon_DeInit;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler
                     = qomx_PortDisabledUnpopulated_DeviceEventHandler;

   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler
                     = qomx_PortDisabledUnpopulated_StateEntryHandler;
   pStTable->pfnExitHandler
                     = qomx_PortDisabledUnpopulated_StateExitHandler;

   return;

} /* end of function qomx_PortDisabledUnpopulated_LoadStateTable */


/*==========================================================================

         FUNCTION:      qomx_PortDisabledUnpopulated_StateEntryHandler

         DESCRIPTION:
*//**                   This function executes initial routines when port
                        moves in QOMX_StatePortEnabledPopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the Port context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_PortDisabledUnpopulated_StateEntryHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
)
{
   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Entering DisabledUnpopulated"
      " State, nPortIndex = 0x%x, nEvent = 0x%x",
      pPortCtx->portDef.nPortIndex, nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pPortCtx->eState = QOMX_StatePortDisabledUnpopulated;

   /**------------------------------------------------------------------------
      If disable request is being processed, send response now.
   -------------------------------------------------------------------------*/
   if( OMX_TRUE == pPortCtx->bAlterCmdFinished )
   {

      ( void ) qomx_CmpntCmdComplete(
                              pPortCtnr->pCommonRef, OMX_CommandPortDisable,
                              pPortCtx->portDef.nPortIndex, NULL );

   }

   /**------------------------------------------------------------------------
      Reset tunneling signal flags appropriately.
   -------------------------------------------------------------------------*/
   if( NULL != pPortCtx->hTunneledComp && pPortCtx->bTunnelPeerIsQOMX )
   {
      pPortCtx->bTunnelPeerAcceptsUseBuffer      = OMX_FALSE;
      pPortCtx->bTunnelPeerAcceptsBufferExchange = OMX_FALSE;
      pPortCtx->bTunnelPeerAcceptsFreeBuffer     = OMX_FALSE;
      pPortCtx->bVendorTunnelPeerLoadedToIdle    = OMX_FALSE;
      pPortCtx->bVendorTunnelPeerPortEnable      = OMX_FALSE;
   }
   else
   {
      pPortCtx->bTunnelPeerAcceptsUseBuffer      = OMX_TRUE;
      pPortCtx->bTunnelPeerAcceptsBufferExchange = OMX_TRUE;
      pPortCtx->bTunnelPeerAcceptsFreeBuffer     = OMX_TRUE;
      pPortCtx->bVendorTunnelPeerLoadedToIdle    = OMX_TRUE;
      pPortCtx->bVendorTunnelPeerPortEnable      = OMX_TRUE;
   }

   return;

} /* end of function qomx_PortDisabledUnpopulated_StateEntryHandler */


/*==========================================================================

         FUNCTION:      qomx_PortDisabledUnpopulated_StateExitHandler

         DESCRIPTION:
*//**                   This function executes initial routines when port
                        moves out of QOMX_StatePortEnabledPopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the Port context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_PortDisabledUnpopulated_StateExitHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
)
{
   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Exiting DisabledUnpopulated"
      " State, nPortIndex = 0x%x, nEvent = 0x%x",
      pPortCtx->portDef.nPortIndex, nEvent );

   return;

} /* end of function qomx_PortDisabledUnpopulated_StateExitHandler */



/*==========================================================================

         FUNCTION:      qomx_PortDisabledUnpopulated_DeviceEventHandler

         DESCRIPTION:
*//**                   This function processes events from device when port
                        is in QOMX_StatePortDisabledUnpopulated state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  nEventCode  - Event code.
            @param [in] nEventStatus- Status of the event.
            @param [in] nParamSize  - Size in bytes for the event related
                                      data which is pointed by the payload.
            @param [in] pParam      - Event related payload.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortDisabledUnpopulated_DeviceEventHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEventCode,
   OMX_IN   OMX_U32                       nEventStatus,
   OMX_IN   OMX_U32                       nParamSize,
   OMX_IN   OMX_PTR                      *pParam
)
{
   OMX_ERRORTYPE  eRetVal = OMX_ErrorNone;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
      "qomx_PortDisabledUnpopulated_DeviceEventHandler, nPortIndex = 0x%x,"
      " nEventCode = 0x%x", pPortCtx->portDef.nPortIndex, nEventCode );

   /**------------------------------------------------------------------------
      Check event code.
   -------------------------------------------------------------------------*/
   switch( nEventCode )
   {
   case MMI_RESP_DISABLE_PORT:
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
            "Received disable port response." );

         /**------------------------------------------------------------------
            Handle disable command response.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_DisableResp(
                              pPortCtnr, pPortCtx, nEventStatus, OMX_FALSE );

      }

      break;

   case MMI_RESP_FLUSH:
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
            "Received Flush response." );

         /**------------------------------------------------------------------
            Call internal function to process this flush response.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_DisableFlushResp( pPortCtnr, pPortCtx );
      }

      break;

   case MMI_EVT_PORT_CONFIG_CHANGED:
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "MMI_EVT_PORT_CONFIG_CHANGED"
            " event nPortIndex = 0x%x,", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Process config change event and update port definition.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_ConfigChange(
                                          pPortCtnr->pCommonRef, pPortCtx );

      }

      break;

   default:
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Unexpected parameters in"
            " device event: nEventCode = 0x%x, nPortIndex = 0x%x",
            nEventCode, pPortCtx->portDef.nPortIndex );

      }

      break;

   } /* end of switch( nEventCode ) */

   return( eRetVal );

} /* end of function qomx_PortDisabledUnpopulated_DeviceEventHandler */

