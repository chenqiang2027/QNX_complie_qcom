/*========================================================================

*//** @file qomxCmpntIdleToPause.c 

@par FILE SERVICES:
      Component IdleToPause State Implementation File.

      This file implements all the methods which are applicable for
      OMX_StateIdleToPause state.
      
      Main functions is Send Command. Functions which are common for all
      states are implemented in the common functions table.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2018 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCmpntIdleToPause.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
08/08/11   dm     Hardware critical error handling.
07/22/10   zm     Add component handle in each base class logging message.
06/29/10   zm     Allow ETB/FTB calls in IdleToPause state.
06/10/10   dm     Added return type in event handler.
03/26/10   spl    Modified to support interop-profile.
10/08/09   dm     Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxCmpntCommon.h"
#include "qomxPortUtils.h"

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 * 
 * Forward declaration for the functions statically defined in this file.
 * 
 */

static void    qomx_CmpntIdleToPause_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
);

static void    qomx_CmpntIdleToPause_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
   
);

static OMX_ERRORTYPE    qomx_CmpntIdleToPause_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
);

static void    qomx_CmpntIdleToPause_Pause
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);

static void    qomx_CmpntIdleToPause_PauseResponse
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nStatus
);


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_CmpntIdleToPause_LoadStateTable

         DESCRIPTION:
                        This function will load the component state table
                        supported by the IdleToPause state in the object
                        of state table being passed.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable - Pointer to the state primitive table
                                   object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntIdleToPause_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      component is in QOMX_StateIdleToPause state. NULL entry indicates
      that the specific function call is not allowed in this state, thus
      component API should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/
   pStTable->GetComponentVersion    = qomx_CmpntCommon_GetComponentVersion;
   pStTable->SendCommand            = qomx_CmpntCommon_SendCommand;
   pStTable->GetParameter           = qomx_CmpntCommon_GetParameter;
   pStTable->SetParameter           = qomx_CmpntCommon_SetParameter;
   pStTable->GetConfig              = qomx_CmpntCommon_GetConfig;
   pStTable->SetConfig              = qomx_CmpntCommon_SetConfig;
   pStTable->GetExtensionIndex      = qomx_CmpntCommon_GetExtensionIndex;
   pStTable->GetState               = qomx_CmpntCommon_GetState;
   pStTable->ComponentTunnelRequest = qomx_CmpntCommon_TunnelRequest;
   pStTable->UseBuffer              = qomx_CmpntCommon_UseBuffer;
   pStTable->AllocateBuffer         = qomx_CmpntCommon_AllocateBuffer;
   pStTable->FreeBuffer             = qomx_CmpntCommon_FreeBuffer;
   pStTable->EmptyThisBuffer        = qomx_CmpntCommon_EmptyThisBuffer;
   pStTable->FillThisBuffer         = qomx_CmpntCommon_FillThisBuffer;
   pStTable->SetCallbacks           = NULL;
   pStTable->ComponentDeInit        = qomx_CmpntCommon_ComponentDeInit;
   pStTable->UseEGLImage            = NULL;
   pStTable->ComponentRoleEnum      = qomx_CmpntCommon_ComponentRoleEnum;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler        
                        = qomx_CmpntIdleToPause_DeviceEventHandler;
   
   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler     
                        = qomx_CmpntIdleToPause_StateEntryHandler;
   pStTable->pfnExitHandler      
                        = qomx_CmpntIdleToPause_StateExitHandler;

   return;

} /* end of function qomx_CmpntIdleToPause_LoadStateTable */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntIdleToPause_StateEntryHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateIdleToPause is entered. Entry into the
                        state performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntIdleToPause_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Entering IdleToPause State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Entering IdleToPause State, nEvent = 0x%x", nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pCmpntCtx->eMainState = QOMX_StateIdleToPause;

   /**------------------------------------------------------------------------
      Command device to pause.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntIdleToPause_Pause( pCmpntCtx );

   return;

} /* end of function qomx_CmpntIdleToPause_StateEntryHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntIdleToPause_StateExitHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateIdleToPause is exited. Exit from this
                        state performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntIdleToPause_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent 
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Exiting IdleToPause State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Exiting IdleToPause State, nEvent = 0x%x", nEvent );

   return;

} /* end of function qomx_CmpntIdleToPause_StateExitHandler */


/*==========================================================================

         FUNCTION:      qomx_CmpntIdleToPause_DeviceEventHandler

         DESCRIPTION:
*//**                   This function is called when the device want to 
                        communicate with the component when it is in 
                        IdleToPause state.
         
@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx      -  Context structure pointer.
            @param[in]  nEventCode     -  Event code.
            @param[in]  nEventStatus   -  Event status.
            @param[in]  nParamSize     -  Payload length.
            @param[in]  pParam         -  Payload corresponding to this event.

*//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None
                                                                        
===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntIdleToPause_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_CmpntIdleToPause_DeviceEventHandler, nEventCode = 0x%x,"
         " nEventStatus = 0x%x", nEventCode, nEventStatus );

   /**------------------------------------------------------------------------
      Finish moving to Pause state on successful pause response.
   -------------------------------------------------------------------------*/
   if( MMI_RESP_PAUSE == nEventCode ) 
   {
      QOMX_MSG_L_HIGH( pCommonRef, "MMI_RESP_PAUSE event." );

      /**---------------------------------------------------------------------
         Process the pause command status now.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntIdleToPause_PauseResponse( 
                                                pCmpntCtx, nEventStatus );

   }
   else if( MMI_EVT_RESOURCES_LOST == nEventCode )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "MMI_EVT_RESOURCES_LOST event." );

      /**---------------------------------------------------------------------
         Set resources state to lost.
      ----------------------------------------------------------------------*/
      pCmpntCtx->eResState = QOMX_RESOURCES_PERMANENTLY_LOST;

      /**---------------------------------------------------------------------
         Report resources lost error to IL client.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
         "Send OMX_ErrorResourcesLost notification." );

      ( void ) qomx_CmpntNotifyError( 
                     & ( pCmpntCtx->commonRef ), OMX_ErrorResourcesLost );

      /**---------------------------------------------------------------------
         Move to transitional state IdleToLoaded which will check ports
         population status, wait for buffer release and unload resources.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, "Move to QOMX_StateIdleToLoaded." );

      ( void ) qomx_CmpntCommon_DoStateTransition( 
                     pCmpntCtx, QOMX_StateIdleToLoaded, QOMX_EVENT_UNKNOWN );

   }
   else
   {
      /**---------------------------------------------------------------------
         Pass this to common device handler routine.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntCommon_DeviceEventHandler( pCmpntCtx, 
                              nEventCode, nEventStatus, nParamSize, pParam );

   }

   return( eRetVal );

} /* end of function qomx_CmpntIdleToPause_DeviceEventHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntIdleToPause_Pause

         DESCRIPTION:
*//**                   This function will pause the device and move component
                        to Pause state based on the device return code.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntIdleToPause_Pause
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   OMX_U32              nStatus     = MMI_S_EFAIL;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntIdleToPause_Pause" );

   /**------------------------------------------------------------------------
      Send pause command to MMI device.
   -------------------------------------------------------------------------*/
   nStatus = pCommonRef->device.pfnCmd( 
                                 pCommonRef->hFd, MMI_CMD_PAUSE, NULL );

   QOMX_MSG_L_HIGH( pCommonRef, "MMI_CMD_PAUSE status = 0x%x", nStatus );

   /**------------------------------------------------------------------------
      If device is processing the command asynchronously, wait for the
      callback, otherwise process the response.
   -------------------------------------------------------------------------*/
   if( MMI_S_PENDING != nStatus )
   {
      /**---------------------------------------------------------------------
         Process the pause command status now.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntIdleToPause_PauseResponse( pCmpntCtx, nStatus );

   }

   return;

} /* end of function qomx_CmpntIdleToPause_Pause */


/*==========================================================================

         FUNCTION:      qomx_CmpntIdleToPause_PauseResponse

         DESCRIPTION:
*//**                   This function processes the pause command response
                        received from the device.
         
@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   -  Context structure pointer.
            @param[in]  nStatus     -  Event / Response status.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
                                                                        
===========================================================================*/
static void    qomx_CmpntIdleToPause_PauseResponse
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nStatus
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntIdleToPause_PauseResponse" );

   if( MMI_S_COMPLETE == nStatus )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Pause successful." );

      /**---------------------------------------------------------------------
         Pause is successful. Move to destination state QOMX_StatePause.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, "Move to QOMX_StatePause." );

      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                                    QOMX_StatePause, QOMX_EVENT_UNKNOWN );

      /**---------------------------------------------------------------------
         Command ports to start buffer processing.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, "Start buffer processing." );

      ( void ) qomx_PortStartBufferProcessing( pCmpntCtx->hPortCtnr );

      /**---------------------------------------------------------------------
         Send state transition success callback.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
            "Send OMX_StatePause transition callback." );

      ( void ) qomx_CmpntCommon_StateTransitionCallback( 
                                    pCmpntCtx, OMX_StatePause );

   }
   else if( ( MMI_S_EFATAL == nStatus )
            || ( MMI_S_EFATALHW == nStatus ) )
   {
      QOMX_MSG_L_ERROR( 
         pCommonRef, "Critical error = %d during pause.", nStatus );

      /**---------------------------------------------------------------------
         Irrecoverable error. Move component to Invalid state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                  QOMX_StateInvalid, qomx_GetQOMXBaseEventCode( nStatus ) );

   }
   else
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Unexpected status in pause response,"
         " nStatus = 0x%x, Transition back to Idle state.", nStatus );

      /**---------------------------------------------------------------------
         Move back the component to Idle state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                                    QOMX_StateIdle, QOMX_EVENT_UNKNOWN );

      /**---------------------------------------------------------------------
         Report hardware error for this command failure.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
            "Send OMX_ErrorHardware notification." );

      ( void ) qomx_CmpntNotifyError( 
                           & ( pCmpntCtx->commonRef ), OMX_ErrorHardware );

   }

   return;

} /* end of function qomx_CmpntIdleToPause_PauseResponse */
