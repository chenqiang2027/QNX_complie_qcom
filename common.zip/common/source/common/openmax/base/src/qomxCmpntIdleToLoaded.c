/*========================================================================

*//** @file qomxCmpntIdleToLoaded.c 

@par FILE SERVICES:
      Component IdleToLoaded State Implementation File.

      This file implements all the methods which are applicable for
      IdleToLoaded state.

      Main functions are Send Command, and Free Buffer. Functions which are 
      common for all states are implemented in the common functions table.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCmpntIdleToLoaded.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
03/20/13   am     Rename QOMX_CONFIG_TUNNELEDPORTSTATUSTYPE and associated variables
                  to QC omx extension for 1.1.2
08/08/11   dm     Hardware critical error handling.
07/22/10   zm     Add component handle in each base class logging message.
07/15/10   yt     Special SetConfig handling for tunneling.
06/10/10   dm     Added return type in event handler.
03/26/10   spl    Modified to support interop-profile.
02/18/10   sl     Fixed tunneling shutdown code (bufferes are now freed)
09/30/09   dm     Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxCmpntCommon.h"
#include "qomxPortUtils.h"

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */


/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/**
 * 
 * Forward declaration for the functions statically defined in this file.
 * 
 */

static void    qomx_CmpntIdleToLoaded_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
);

static void    qomx_CmpntIdleToLoaded_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
   
);

static OMX_ERRORTYPE    qomx_CmpntIdleToLoaded_FreeBuffer
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr
);

static OMX_ERRORTYPE    qomx_CmpntIdleToLoaded_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
);

static void    qomx_CmpntIdleToLoaded_UpdateResources
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);

static void    qomx_CmpntIdleToLoaded_ReleaseResourcesResp
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nStatus,
   OMX_IN   OMX_BOOL                bSyncResp
);

static OMX_ERRORTYPE  qomx_CmpntIdleToLoaded_SetConfig
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE           nIndex, 
   OMX_IN   OMX_PTR                 pCmpntCfg
);

/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_CmpntIdleToLoaded_LoadStateTable

         DESCRIPTION:
                        This function will load the component state table
                        supported by the IdleToLoaded state in the object
                        of state table being passed.
            
@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable - Pointer to the state primitive table
                                   object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntIdleToLoaded_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      component is in QOMX_StateIdleToLoaded state. NULL entry indicates that
      the specific function call is not allowed in this state, thus component
      API should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/   
   pStTable->GetComponentVersion    = qomx_CmpntCommon_GetComponentVersion;
   pStTable->SendCommand            = qomx_CmpntCommon_SendCommand;
   pStTable->GetParameter           = qomx_CmpntCommon_GetParameter;
   pStTable->SetParameter           = qomx_CmpntCommon_SetParameter;
   pStTable->GetConfig              = qomx_CmpntCommon_GetConfig;
   pStTable->SetConfig              = qomx_CmpntIdleToLoaded_SetConfig;
   pStTable->GetExtensionIndex      = qomx_CmpntCommon_GetExtensionIndex;
   pStTable->GetState               = qomx_CmpntCommon_GetState;
   pStTable->ComponentTunnelRequest = qomx_CmpntCommon_TunnelRequest;
   pStTable->UseBuffer              = NULL;
   pStTable->AllocateBuffer         = NULL;
   pStTable->FreeBuffer             = qomx_CmpntIdleToLoaded_FreeBuffer;
   pStTable->EmptyThisBuffer        = NULL;
   pStTable->FillThisBuffer         = NULL;
   pStTable->SetCallbacks           = NULL;
   pStTable->ComponentDeInit        = qomx_CmpntCommon_ComponentDeInit;
   pStTable->UseEGLImage            = NULL;
   pStTable->ComponentRoleEnum      = qomx_CmpntCommon_ComponentRoleEnum;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler
                        = qomx_CmpntIdleToLoaded_DeviceEventHandler;
   
   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler
                        = qomx_CmpntIdleToLoaded_StateEntryHandler;
   pStTable->pfnExitHandler
                        = qomx_CmpntIdleToLoaded_StateExitHandler;
   
   return;

} /* end of function qomx_CmpntIdleToLoaded_LoadStateTable */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntIdleToLoaded_StateEntryHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateIdleToLoaded is entered. Entry into the 
                        state performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntIdleToLoaded_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Entering IdleToLoaded State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Entering IdleToLoaded State, nEvent = 0x%x", nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pCmpntCtx->eMainState = QOMX_StateIdleToLoaded;

   /**------------------------------------------------------------------------
      Start depopulating the ports.
   -------------------------------------------------------------------------*/
   ( void ) qomx_PortUnpopulate( pCmpntCtx->hPortCtnr );

   /**------------------------------------------------------------------------
      Call internal function which checks port population and request
      device to unload resources if needed.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntIdleToLoaded_UpdateResources( pCmpntCtx );

   return;

} /* end of function qomx_CmpntIdleToLoaded_StateEntryHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntIdleToLoaded_StateExitHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateTransToIdle is exited. Exit from this state
                        performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntIdleToLoaded_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Exiting IdleToLoaded State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Exiting IdleToLoaded State, nEvent = 0x%x", nEvent );

   return;
   
} /* end of function qomx_CmpntIdleToLoaded_StateExitHandler */


/*==========================================================================

         FUNCTION:      qomx_CmpntIdleToLoaded_FreeBuffer

         DESCRIPTION:
*//**                   This function is the equivalent of OMX_FreeBuffer
                        macro. Please refer to OMX IL spec for more details.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.
            @param[in]  nPortIndex  - Index for the port on which method 
                                      need to be executed.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntIdleToLoaded_FreeBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_U32                    nPortIndex,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBufferHdr
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntIdleToLoaded_FreeBuffer,"
      " nPortIndex = 0x%x", nPortIndex );

   /**------------------------------------------------------------------------
      Call common FreeBuffer routine to do necessary processing.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_CmpntCommon_FreeBuffer( pCmpntCtx, nPortIndex, pBufferHdr );

   /**------------------------------------------------------------------------
      If the port has handled the buffer and there was no error, check the
      resources status and see if we can transition to Loaded the destination
      state.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      /**---------------------------------------------------------------------
         Call internal function which checks port population and
         request device to unload resource if needed.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntIdleToLoaded_UpdateResources( pCmpntCtx );

   }

   return( eRetVal );
   
} /* end of function qomx_CmpntIdleToLoaded_FreeBuffer */


/*==========================================================================

         FUNCTION:      qomx_CmpntIdleToLoaded_DeviceEventHandler

         DESCRIPTION:
*//**                   This function is called when the device want to 
                        communicate with the component when it is in 
                        IdleToLoaded state.
         
@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx      -  Context structure pointer.
            @param[in]  nEventCode     -  Event code.
            @param[in]  nEventStatus   -  Event status.
            @param[in]  nParamSize     -  Payload length.
            @param[in]  pParam         -  Payload corresponding to this event.

*//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None
                                                                        
===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntIdleToLoaded_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_CmpntIdleToLoaded_DeviceEventHandler, nEventCode = 0x%x,"
         " nEventStatus = 0x%x", nEventCode, nEventStatus );

   /**------------------------------------------------------------------------
      Check ports population and finish moving to Loaded state, if release
      resource response from device is received.
   -------------------------------------------------------------------------*/
   if( MMI_RESP_RELEASE_RESOURCES == nEventCode ) 
   {
      QOMX_MSG_L_HIGH( pCommonRef,
         "MMI_RESP_RELEASE_RESOURCES event." );

      /**---------------------------------------------------------------------
         Process release resource response.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntIdleToLoaded_ReleaseResourcesResp(
                                       pCmpntCtx, nEventStatus, OMX_FALSE );

   }
   else
   {
      /**---------------------------------------------------------------------
         Pass this to common device handler routine.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntCommon_DeviceEventHandler( pCmpntCtx,
                           nEventCode, nEventStatus, nParamSize, pParam );

   }
   
   return( eRetVal );
   
} /* end of function qomx_CmpntIdleToLoaded_DeviceEventHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntIdleToLoaded_UpdateResources

         DESCRIPTION:
*//**                   This function will check the resources reservation
                        status / port population status and do next step
                        so that component can move to the destination state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntIdleToLoaded_UpdateResources
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, 
      "qomx_CmpntIdleToLoaded_UpdateResources" );   

   /**------------------------------------------------------------------------
      If all ports are unpopulated, check and start releasing resources
      reservation now.
   -------------------------------------------------------------------------*/
   if( OMX_TRUE == qomx_GuardIsTrue( pCommonRef->hCmpnt,
                              QOMX_GUARD_ALL_PORTS_UNPOPULATED ) )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "All ports are unpopulated." );

      /**---------------------------------------------------------------------
         If all ports are populated and release request is not yet sent to
         the device, send it now.
         If resources are unloaded / never reserved / lost / reservation 
         failed, complete transition to Loaded state. 
      ----------------------------------------------------------------------*/
      if( pCmpntCtx->eResState == QOMX_RESOURCES_RESERVED )
      {
         OMX_U32  nStatus = MMI_S_EFAIL;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_MED( pCommonRef, "Release resources now." );

         /**------------------------------------------------------------------
            Send unload resources request to device.
         -------------------------------------------------------------------*/
         nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                                       MMI_CMD_RELEASE_RESOURCES, NULL );

         QOMX_MSG_L_HIGH( pCommonRef, 
            "MMI_CMD_RELEASE_RESOURCES status = 0x%x", nStatus );

         /**------------------------------------------------------------------
            Process device response.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntIdleToLoaded_ReleaseResourcesResp(
                                       pCmpntCtx, nStatus, OMX_TRUE );

      }
      else
      {
         QOMX_MSG_L_MED( pCommonRef, 
            "Resources are unreserved / released." );

         /**------------------------------------------------------------------
            Move ports to unpopulated state.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_MED( pCommonRef, "Unpopulate ports." );

         ( void ) qomx_PortUnpopulate( pCmpntCtx->hPortCtnr );

         /**------------------------------------------------------------------
            Move to destination state QOMX_StateLoaded.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_MED( pCommonRef, "Move to QOMX_StateLoaded." );

         ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                                       QOMX_StateLoaded, QOMX_EVENT_UNKNOWN );

         /**------------------------------------------------------------------
            Send state transition success callback.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_MED( pCommonRef, 
            "Send OMX_StateLoaded transition callback." );

         ( void ) qomx_CmpntCommon_StateTransitionCallback( 
                                       pCmpntCtx, OMX_StateLoaded );

      }

   }

   return;

} /* end of function qomx_CmpntIdleToLoaded_UpdateResources */


/*==========================================================================

         FUNCTION:      qomx_CmpntIdleToLoaded_ReleaseResourcesResp

         DESCRIPTION:
*//**                   This function processes the release resource command
                        response received from the device.
         
@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Context structure pointer.
            @param[in]  nStatus     - Event status.
            @param[in]  bCmdStatus  - True if this function is called when
                                      processing device command status which
                                      is returned as function return type.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
                                                                        
===========================================================================*/
static void    qomx_CmpntIdleToLoaded_ReleaseResourcesResp
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nStatus,
   OMX_IN   OMX_BOOL                bSyncResp
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_CmpntIdleToLoaded_ReleaseResourcesResp" );

   /**------------------------------------------------------------------------
      MMI_S_PENDING is expected only as device command return type.
   -------------------------------------------------------------------------*/
   if ( MMI_S_COMPLETE == nStatus )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Release resources successful." );

      /**---------------------------------------------------------------------
         Mark that the component has all the resources required for 
         realization of the functionality.
      ----------------------------------------------------------------------*/
      pCmpntCtx->eResState = QOMX_RESOURCES_UNRESERVED;

      /**---------------------------------------------------------------------
         If all enabled ports are unpopulated, complete transition to Loaded.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntIdleToLoaded_UpdateResources( pCmpntCtx );

   }
   else if( ( MMI_S_PENDING == nStatus ) && ( OMX_TRUE == bSyncResp ) )
   {
      QOMX_MSG_L_HIGH( pCommonRef,
         "Wait for release resources response." );

      /**---------------------------------------------------------------------
         Device is processing command asynchronously, set resource state
         and wait for callback.
      ----------------------------------------------------------------------*/
      pCmpntCtx->eResState = QOMX_RESOURCES_RELEASING;

   }
   else
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Unexpected status in release resources"
         " response, nStatus = 0x%x, Move to Invalid state.", nStatus );

      /**---------------------------------------------------------------------
         Move component in Invalid state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx,
                  QOMX_StateInvalid, qomx_GetQOMXBaseEventCode( nStatus ) );

   }

   return;

} /* end of function qomx_CmpntIdleToLoaded_ReleaseResourcesResp */

/*==========================================================================

         FUNCTION:      qomx_CmpntIdleToLoaded_SetConfig

         DESCRIPTION:
                        Refer to OMX_SetConfig in OMX_Core.h or the
                        OMX IL specification for details on the 
                        SetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  nIndex         - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[in]  pCmpntCfg      - Refer OMX_Core.h or OMX IL
                                         specification.
**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE  qomx_CmpntIdleToLoaded_SetConfig
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE           nIndex, 
   OMX_IN   OMX_PTR                 pCmpntCfg
)
{
   OMX_ERRORTYPE  eRetVal = OMX_ErrorNone;
   /*-----------------------------------------------------------------------*/

   eRetVal = qomx_CmpntCommon_SetConfig( pCmpntCtx, nIndex, pCmpntCfg);

   /**------------------------------------------------------------------------
      If this is a signal from tunneling peer, need to check guards again.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal && 
       ((OMX_U32)QOMX_IndexConfigTunneledPortStatus) == ((OMX_U32)nIndex) )
   {
      ( void ) qomx_CmpntIdleToLoaded_UpdateResources( pCmpntCtx );
   }

   return eRetVal;
} /* end of function qomx_CmpntIdleToLoaded_SetConfig */
