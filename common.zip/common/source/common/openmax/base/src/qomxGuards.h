#ifndef __QOMX_GUARDS_H__
#define __QOMX_GUARDS_H__

/*========================================================================

*//** @file qomxGuards.h 

@par FILE SERVICES:       
      Guards Header File.

      This file contains data types and accessor methods for various guards
      used in the component and port interfaces.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2010 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxGuards.h#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
08/28/10   zm     Added support for vendor tunneling.
03/26/10   spl    Modified to support interop-profile.
05/13/09   dm      Added the interfaces for port guards.
04/18/09   srk     Created file.

========================================================================== */

/*======================================================================== 
 
                     INCLUDE FILES FOR MODULE 
 
========================================================================== */
#include "qomxCommon.h"

/*======================================================================== 

                      DEFINITIONS AND DECLARATIONS

========================================================================== */


#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */


/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/**
 * 
 *  This enumeration defines QOMX component guards which are used to evaluate
 *  certain conditions based on the type of guard.
 * 
 */
typedef enum
{

   QOMX_GUARD_ALL_PORTS_UNPOPULATED,            /**<
                                                * This guard is used to check if
                                                * all the port are unpopulated
                                                * and thus does not hold any
                                                * buffer.
                                                */

   QOMX_GUARD_ALL_ENABLED_PORTS_POPULATED,      /**<
                                                * This guard is used to check if
                                                * all the enabled port are 
                                                * populated and thus aquired
                                                * required number of buffers.
                                                */

   QOMX_GUARD_ALL_ENABLED_TUNNELED_PORTS_IDLE,  /**<
                                                * This guard is used to check if
                                                * all the enabled tunneled ports
                                                * are in the idle state (no 
                                                * outstanding buffers etc.).
                                                */

   QOMX_GUARD_ALL_ENABLED_VTPORTS_PEER_ACCEPTS_MMISTART,
												/**<
												* This guard is used to check if
												* all the vendor-tunneled ports 
												* have received their peer ports
												* acknowlegment for MMI START.
												*/

} QOMX_GuardType;


/* -----------------------------------------------------------------------
** Functions
** ----------------------------------------------------------------------- */


/*==========================================================================

         FUNCTION:      qomx_GuardIsTrue

         DESCRIPTION:
                        This function checks a guard condition and returns
                        true or false based on the guard check result.
            
@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component Handle.
            @param[in]  eGuard      - Guard which need to be checked.

**//*     RETURN VALUE:
*//**       @return     Pointer to the state primitive table as appripriate.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_BOOL    qomx_GuardIsTrue
(
   OMX_IN   OMX_HANDLETYPE          hCmpnt,
   OMX_IN   QOMX_GuardType          eGuard
);


#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */

#endif /* end of macro __QOMX_GUARDS_H__ */
