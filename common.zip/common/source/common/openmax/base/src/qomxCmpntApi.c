/*========================================================================

*//** @file qomxCmpntApi.c

@par FILE SERVICES:
   QOMX base class component API implementation file.

   This function makes up the component constructor function and entry point
   into the component.
   
   IL Vtable is translated into a component specific internal functions.

   Basically internal Component context and function pointer translation is
   done in this file.
   
   Only function which is exposed is ComponentInit equivalent.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCmpntApi.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
06/22/16   am     Fix compiler warnings for 64 bit OS environment.
02/04/14   am     Fix dfc thread clean up on failure on CmpntBaseInit.
12/03/10   zm     Consolidate common code in CmpntInit and CmpntInit2.
11/22/10   zm     Added new qomxCmpntInit2 API.
09/13/10   dm     Adding component name and handle in logging messages.
07/22/10   zm     Add component handle in each base class logging message.
07/16/10   dm     Allow GetComponentVersion for optional parameters as NULL.
06/10/10   dm     Added return type in event handler.
03/18/10   spl    Tunneling can be enabled without changing the code.
03/17/10   dm     Post all event callbacks to DFC queue.
02/25/10   dm     Release locks before calling FBD / EBD.
11/20/09   dm     Return different error codes on open failure.
10/30/09   dm     Return incorrect operation error on NULL function.
10/09/09   dm     Split component states.
08/19/09   dm     Removed UUID parameter validation as it can be NULL.
08/18/09   dm     Removed DeInit function pointer check.
08/08/09   dm     Memory functions abstracted.
06/16/09   dm     Error checks and clean up.
03/26/09   srk    Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxCmpntCommon.h"
#include "qomxPortUtils.h"

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 * 
 * Forward declaration for the functions defined statically in this file.
 * 
 */

static OMX_ERRORTYPE    qomx_GetComponentVersion
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_OUT  OMX_STRING                 pComponentName,
   OMX_OUT  OMX_VERSIONTYPE           *pComponentVersion,
   OMX_OUT  OMX_VERSIONTYPE           *pSpecVersion,
   OMX_OUT  OMX_UUIDTYPE              *pComponentUUID
);

static OMX_ERRORTYPE    qomx_SendCommand
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_IN   OMX_COMMANDTYPE            eCmd,
   OMX_IN   OMX_U32                    nParam,
   OMX_IN   OMX_PTR                    pCmdData
);

static OMX_ERRORTYPE    qomx_GetParameter
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt, 
   OMX_IN   OMX_INDEXTYPE              nIndex,
   OMX_OUT  OMX_PTR                    pCmpntParm
);

static OMX_ERRORTYPE    qomx_SetParameter
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt, 
   OMX_IN   OMX_INDEXTYPE              nIndex,
   OMX_IN   OMX_PTR                    pCmpntParm
);

static OMX_ERRORTYPE    qomx_GetConfig
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_IN   OMX_INDEXTYPE              nIndex, 
   OMX_IN   OMX_PTR                    pCmpntCfg
);

static OMX_ERRORTYPE    qomx_SetConfig
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_IN   OMX_INDEXTYPE              nIndex, 
   OMX_IN   OMX_PTR                    pCmpntCfg
);

static OMX_ERRORTYPE    qomx_GetExtensionIndex
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_IN   OMX_STRING                 cParameterName,
   OMX_OUT  OMX_INDEXTYPE             *pIndexType
);

static OMX_ERRORTYPE    qomx_GetState
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_OUT  OMX_STATETYPE             *pState
);

static OMX_ERRORTYPE    qomx_ComponentTunnelRequest
(
   OMX_IN      OMX_HANDLETYPE          hCmpnt,
   OMX_IN      OMX_U32                 nPort,
   OMX_IN      OMX_HANDLETYPE          hTunneledComp,
   OMX_IN      OMX_U32                 nTunneledPort,
   OMX_INOUT   OMX_TUNNELSETUPTYPE    *pTunnelSetup
);

static OMX_ERRORTYPE    qomx_UseBuffer
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_OUT  OMX_BUFFERHEADERTYPE     **ppBuffer,
   OMX_IN   OMX_U32                    nPortIndex,
   OMX_IN   OMX_PTR                    pAppPrivate,
   OMX_IN   OMX_U32                    nSizeBytes,
   OMX_IN   OMX_U8                    *pBuffer
);

static OMX_ERRORTYPE    qomx_AllocateBuffer
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_OUT  OMX_BUFFERHEADERTYPE     **ppBuffer,
   OMX_IN   OMX_U32                    nPortIndex,
   OMX_IN   OMX_PTR                    pAppPrivate,
   OMX_IN   OMX_U32                    nSizeBytes
);

static OMX_ERRORTYPE    qomx_FreeBuffer
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_IN   OMX_U32                    nPortIndex,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBuffer
);

static OMX_ERRORTYPE    qomx_EmptyThisBuffer
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBuffer
);

static OMX_ERRORTYPE    qomx_FillThisBuffer
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBuffer
);

static OMX_ERRORTYPE    qomx_SetCallbacks
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_IN   OMX_CALLBACKTYPE          *pCallbacks,
   OMX_IN   OMX_PTR                    pAppData
);

static OMX_ERRORTYPE    qomx_CmpntBaseInit
(                  
   OMX_IN   QOMX_CmpntConfig          *pConfig,
   OMX_IN   MMI_GetHeapHandleType      pfnGetHeapHandle,     
   OMX_IN   MMI_ReleaseHeapHandleType  pfnReleaseHeapHandle, 
   OMX_IN   MMI_MallocType             pfnMalloc,            
   OMX_IN   MMI_FreeType               pfnFree,              
   OMX_IN   MMI_DeviceType            *pDev,
   OMX_IN   OMX_COMPONENTTYPE         *pComp
);

static OMX_ERRORTYPE    qomx_ComponentDeInit 
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt
);

static OMX_ERRORTYPE    qomx_UseEGLImage
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_OUT  OMX_BUFFERHEADERTYPE     **ppBufferHdr,
   OMX_IN   OMX_U32                    nPortIndex,
   OMX_IN   OMX_PTR                    pAppPrivate,
   OMX_IN   void                      *eglImage
);

static OMX_ERRORTYPE    qomx_ComponentRoleEnum
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_OUT  OMX_U8                    *cRole,
   OMX_IN   OMX_U32                    nIndex
);

static void    qomx_DeviceEventHandler
(
   OMX_IN   OMX_U32                    nEventCode,
   OMX_IN   OMX_U32                    nEventStatus,
   OMX_IN   OMX_U32                    nPayloadLen,
   OMX_IN   OMX_PTR                    pEvtData,
   OMX_IN   OMX_PTR                    pClientData
);

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */

/*==========================================================================

         FUNCTION:      qomx_CmpntInit

         DESCRIPTION:
*//**
                        This function validates the input parameters and 
                        then call the internal qomx_CmpntBaseInit() 
                        function to create the component instance.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  pConfig  -  Port and related information for
                                    component initialization.
            @param[in]  pDev     -  Device function table. 
            @param[in]  hCmpnt   -  Handle to already Allocated IL
                                    component structure.

*//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None
===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntInit
(
   OMX_IN   QOMX_CmpntConfig          *pConfig,
   OMX_IN   MMI_DeviceType            *pDev,
   OMX_IN   OMX_HANDLETYPE             hCmpnt
)
{
   OMX_COMPONENTTYPE         *pComp       = ( OMX_COMPONENTTYPE * ) hCmpnt;
   OMX_ERRORTYPE              eRetVal     = OMX_ErrorNone;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_HIGH( "h=0x%p, qomx_CmpntInit", pComp );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( ( NULL == pConfig ) || ( NULL == pComp ) || ( NULL == pDev ) )
   {
      QOMX_MSG_ERROR( "h=0x%p, NULL params.",  pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else if( ( NULL == pDev->pfnOpen ) || ( NULL == pDev->pfnEvtHdlr )
            || ( NULL == pDev->pfnCmd ) || ( NULL == pDev->pfnClose ) )
   {
      QOMX_MSG_ERROR( "h=0x%p, NULL device params.", pComp );

      /**---------------------------------------------------------------------
         Some MMI device functions are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else if( NULL == pConfig->pCmpnntName )
   {
      QOMX_MSG_ERROR( "h=0x%p, NULL component name.", pComp );

      /**---------------------------------------------------------------------
         Some IL config parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }

   if ( OMX_ErrorNone == eRetVal )
   {
      /**---------------------------------------------------------------------
         Call qomx_CmpntBaseInit() to initialize the component.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntBaseInit(pConfig, qomx_OSHeapGetHandle, 
                           qomx_OSHeapReleaseHandle, qomx_OSMalloc, 
                           qomx_OSFree, pDev, pComp);

   }

   return( eRetVal );

} /* end of function qomx_CmpntInit */


/*==========================================================================

         FUNCTION:      qomx_ComponentInit2
                                                
         DESCRIPTION:
*//**
                        This function validates the input parameters 
                        and then call the internal qomx_CmpntBaseInit() 
                        function to create the component instance.

                        This is the new CmpntInit API which introduces the 
                        config version and the platform specific config 
                        structure; this is the recommended API to init 
                        component.
                        The old qomx_CmpntInit() is still supported.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  pCmpntConfigVersion -  String for config version.
            @param[in]  pConfig             -  Port and related information 
                                               for component initialization.
            @param[in]  pPlatformConfig     -  Platform specific information 
                                               for component initialization.
            @param[in]  pDev                -  Device function table. 
            @param[in]  hCmpnt              -  Handle to already Allocated IL
                                               component structure.

*//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.
@par     SIDE EFFECTS:
                        None
===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntInit2
(
   OMX_IN   OMX_STRING                    pCmpntConfigVersion,                    
   OMX_IN   OMX_PTR                       pCmpntConfig,
   OMX_IN   OMX_PTR                       pPlatformConfig,
   OMX_IN   MMI_DeviceType                *pDev,
   OMX_IN   OMX_HANDLETYPE                hCmpnt
)
{
   OMX_COMPONENTTYPE         *pComp       = ( OMX_COMPONENTTYPE * ) hCmpnt;
   QOMX_CmpntConfig          *pConfig              = NULL;
   MMI_GetHeapHandleType      pfnGetHeapHandle     = qomx_OSHeapGetHandle;
   MMI_ReleaseHeapHandleType  pfnReleaseHeapHandle = qomx_OSHeapReleaseHandle;
   MMI_MallocType             pfnMalloc            = qomx_OSMalloc;
   MMI_FreeType               pfnFree              = qomx_OSFree;
   OMX_ERRORTYPE              eRetVal              = OMX_ErrorNone;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_HIGH( "h=0x%p, qomx_CmpntInit2", pComp );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( ( NULL == pCmpntConfigVersion ) || ( NULL == pCmpntConfig ) 
       || ( NULL == pComp ) || ( NULL == pDev ) )
   {
      QOMX_MSG_ERROR( "h=0x%p, NULL params.", pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else if( ( NULL == pDev->pfnOpen ) || ( NULL == pDev->pfnEvtHdlr )
            || ( NULL == pDev->pfnCmd ) || ( NULL == pDev->pfnClose ) )
   {
      QOMX_MSG_ERROR( "h=0x%p, NULL device params.",  pComp );

      /**---------------------------------------------------------------------
         Some MMI device functions are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }

   /**------------------------------------------------------------------------
      Typecast the config structures according to the config version and
      set component config and platform specific configs.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      if( 0 == QOMX_CMPNT_STR_CMP ( 
                  pCmpntConfigVersion, QOMX_COMPONENT_CONFIG_VERSION_1 ) ) 
      {
         QOMX_CmpntConfig_V1 *pCmpntConfig_V1 = 
                  ( QOMX_CmpntConfig_V1 * ) pCmpntConfig;

         QOMX_CmpntPlatformConfig_V1 *pPlatformConfig_V1 = 
                  ( QOMX_CmpntPlatformConfig_V1 * ) pPlatformConfig;

         /**------------------------------------------------------------------
            Validate parameters and set component config.
         -------------------------------------------------------------------*/
         QOMX_IF_VALID_STRUCT_SIZE( pCmpntConfig_V1, 
                        QOMX_CmpntConfig_V1, eRetVal)
         {
            pConfig = & ( pCmpntConfig_V1->sConfig );

            if( NULL == pConfig->pCmpnntName )
            {
               QOMX_MSG_ERROR( "h=0x%p, NULL component name.", 
                         pComp );

               /**------------------------------------------------------------
                  Some IL config parameters are not valid.
               -------------------------------------------------------------*/
               eRetVal = OMX_ErrorBadParameter;

            }

         }

         /**------------------------------------------------------------------
            Validate parameters and set platform specific configs.
         -------------------------------------------------------------------*/
         if( OMX_ErrorNone != eRetVal )
         {
            QOMX_MSG_ERROR( "h=0x%p, pCmpntConfig_V1 validation failed.", 
                         pComp );

         }
         else if( NULL == pPlatformConfig_V1 )
         {
            /**---------------------------------------------------------------
               It is OK if caller does not provide any platform specific 
               config; default heap management functions will be used.
            ----------------------------------------------------------------*/
            QOMX_MSG_MED( "h=0x%p, platform specific component Config "
                  "structure is NULL.", pComp );

         }
         else
         {
            QOMX_IF_VALID_STRUCT_SIZE( pPlatformConfig_V1, 
                           QOMX_CmpntPlatformConfig_V1, eRetVal)
            {
               /**------------------------------------------------------------
                  Validate platform config either defines all the customized 
                  memory allocation/free/getHandle/releaseHandle APIs or 
                  defines none of them.
               -------------------------------------------------------------*/
               if ( ( NULL == pPlatformConfig_V1->pfnGetHeapHandle ) && 
                  ( NULL == pPlatformConfig_V1->pfnReleaseHeapHandle ) && 
                  ( NULL == pPlatformConfig_V1->pfnMalloc ) && 
                  ( NULL == pPlatformConfig_V1->pfnFree ) ) 
               {
                  QOMX_MSG_MED( "h=0x%p,use default memory alloc/free APIs",
                        pComp );

               }
               else if ( ( NULL == pPlatformConfig_V1->pfnGetHeapHandle ) || 
                        ( NULL == pPlatformConfig_V1->pfnReleaseHeapHandle ) || 
                        ( NULL == pPlatformConfig_V1->pfnMalloc ) || 
                        ( NULL == pPlatformConfig_V1->pfnFree ) )
               {
                  QOMX_MSG_ERROR( "h=0x%p, incomplete device memory getHandle/"
                     "releaseHandle/alloc/free params.", pComp );

                  eRetVal = OMX_ErrorBadParameter;

               }
               else
               {
                  pfnGetHeapHandle = pPlatformConfig_V1->pfnGetHeapHandle;
                  pfnReleaseHeapHandle = pPlatformConfig_V1->pfnReleaseHeapHandle;
                  pfnMalloc = pPlatformConfig_V1->pfnMalloc;
                  pfnFree = pPlatformConfig_V1->pfnFree;

               }

            }

         }

      }
      else
      {
         QOMX_MSG_HIGH( "h=0x%p, Unsupported component Config structure "
                  "version.", pComp );

         eRetVal = OMX_ErrorVersionMismatch;

      }

   }

   if ( OMX_ErrorNone == eRetVal )
   {
      /**---------------------------------------------------------------------
         Call qomx_CmpntBaseInit() to initialize the component.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntBaseInit(pConfig, pfnGetHeapHandle, 
                     pfnReleaseHeapHandle, pfnMalloc, pfnFree, pDev, pComp);

   }

   return( eRetVal );

} /* end of function qomx_CmpntInit2 */


/*==========================================================================

         FUNCTION:      qomx_ComponentBaseInit
                                                
         DESCRIPTION:
*//**
                        This function is the internal common function that 
                        is called by both the old CmpntInit() and the new 
                        CmpntInit2() to create component instance.

                        This function will create the component instance 
                        which would be populated in component handler's 
                        component private data.

                        Ports are created and initialized based on the
                        configuration specified.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  pConfig             -  Port and related information 
                                               for component initialization.
            @param[in]  pfnGetHeapHandle    -  Function pointer to the
                                               GetHeapHandle routine.
            @param[in]  pfnReleaseHeapHandle-  Function pointer to the
                                               ReleaseHeapHandle routine.
            @param[in]  pfnMalloc           -  Function pointer to the
                                               Malloc routine.
            @param[in]  pfnFree             -  Function pointer to the
                                               Free routine.
            @param[in]  pDev                -  Device function table.
            @param[in]  pComp               -  Pointer to already Allocated IL
                                               component structure.

*//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.
@par     SIDE EFFECTS:
                        None
===========================================================================*/
static OMX_ERRORTYPE  qomx_CmpntBaseInit
(                  
   OMX_IN   QOMX_CmpntConfig           *pConfig,
   OMX_IN   MMI_GetHeapHandleType       pfnGetHeapHandle,     
   OMX_IN   MMI_ReleaseHeapHandleType   pfnReleaseHeapHandle, 
   OMX_IN   MMI_MallocType              pfnMalloc,            
   OMX_IN   MMI_FreeType                pfnFree,              
   OMX_IN   MMI_DeviceType             *pDev,
   OMX_IN   OMX_COMPONENTTYPE          *pComp
)
{
   OMX_ERRORTYPE              eRetVal     = OMX_ErrorNone;
   QOMX_CmpntCtxType         *pCmpntCtx   = NULL;
   QOMX_CommonRefType        *pCommonRef  = NULL;
   OMX_HANDLETYPE             hHeap       = NULL;
   OMX_HANDLETYPE             hFd         = NULL;
   OMX_BOOL                   bFdReady    = OMX_FALSE;
   QDFC_ErrorType             eErrDFC     = QDFC_ERROR_NONE;
   /*-----------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Instantiate and get handle for memory module which will be further used
      for all memory allocations.
   -------------------------------------------------------------------------*/
   if( MMI_S_COMPLETE != QOMX_CMPNT_MEM_GET_HANDLE( 
                                       pfnGetHeapHandle, & hHeap ) )
   {
      QOMX_MSG_ERROR( 
           "h=0x%p, Memory module creation failed.", pComp );

      /**---------------------------------------------------------------------
         Insufficient resources.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorInsufficientResources;

   }

   /**------------------------------------------------------------------------
      Allocate context memory now.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      OMX_U32     nCmpntCtxSize;
      OMX_U32     nAllocSize;
      OMX_U32     nStTableSize;
      OMX_U8     *pAllocBuf;
      /*--------------------------------------------------------------------*/

      /**---------------------------------------------------------------------
         Calculate the total size which need to be allocated component 
         context + for all state tables.
      ----------------------------------------------------------------------*/
      nCmpntCtxSize = ( OMX_U32 ) sizeof( QOMX_CmpntCtxType );

      nStTableSize  = ( OMX_U32 ) sizeof( QOMX_CmpntStateTableType );
      nStTableSize *= QOMX_StateMax;

      nAllocSize    = ( nCmpntCtxSize + nStTableSize );

      /**---------------------------------------------------------------------
         Allocate memory block.
      ----------------------------------------------------------------------*/
      pAllocBuf = ( OMX_U8 * ) QOMX_CMPNT_MALLOC( pfnMalloc, hHeap, nAllocSize );

      if( NULL == pAllocBuf )
      {
         QOMX_MSG_ERROR( "h=0x%p, Allocation failed, Size = %d, hHeap = 0x%p",
              pComp, nAllocSize, hHeap );

         /**------------------------------------------------------------------
            Memory allocation failed, return insufficient resource error.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorInsufficientResources;

      }
      else
      {
         QOMX_CmpntStateTableType  *pStTableBase;
         /*-----------------------------------------------------------------*/

         /**------------------------------------------------------------------
            Initialize the allocated memory area with 0.
         -------------------------------------------------------------------*/
         QOMX_CMPNT_MEM_SET( pAllocBuf, 0, nAllocSize );

         /**------------------------------------------------------------------
            Get component context address.
         -------------------------------------------------------------------*/
         pCmpntCtx   = ( QOMX_CmpntCtxType * ) pAllocBuf;
         pCommonRef  = & ( pCmpntCtx->commonRef );

         /**------------------------------------------------------------------
            Get base address of state primitive table array and load the 
            state tables.
         -------------------------------------------------------------------*/
         pStTableBase = ( QOMX_CmpntStateTableType * ) ( 
                                                pAllocBuf + nCmpntCtxSize );

         ( void ) qomx_CmpntCommon_LoadStateTables( pStTableBase );


         /**------------------------------------------------------------------
            Store the component context and size in the component handle 
            private members for further references.
         -------------------------------------------------------------------*/
         pComp->pComponentPrivate      = ( OMX_PTR ) pCmpntCtx;
         pComp->nSize                  = nCmpntCtxSize;

         /**------------------------------------------------------------------
            Store the heap handle, component handle and state table base in
            the component context for further references.
         -------------------------------------------------------------------*/
         pCommonRef->hHeap       = hHeap;
         pCommonRef->pfnGetHeapHandle = pfnGetHeapHandle;
         pCommonRef->pfnReleaseHeapHandle = pfnReleaseHeapHandle;
         pCommonRef->pfnMalloc   = pfnMalloc;
         pCommonRef->pfnFree     = pfnFree;

         pCommonRef->hCmpnt      = ( OMX_HANDLETYPE ) pComp;
         pCmpntCtx->hStateTables = ( OMX_HANDLETYPE ) pStTableBase;

         /**------------------------------------------------------------------
            Copy the component characterstics in component context memory.
            Copy only 127 characters from component name, so that name can
            be NULL terminated, if string length passed by client exceeds 127
            bytes. Component UUID can be NULL, so store only if it is valid.
         -------------------------------------------------------------------*/
         QOMX_CMPNT_MEM_COPY( & ( pCommonRef->acCmpntName[ 0 ] ),
            pConfig->pCmpnntName, ( sizeof( pCommonRef->acCmpntName ) - 1 ) );

         if( NULL != pConfig->pCmpnntUUID )
         {
            QOMX_CMPNT_MEM_COPY( & ( pCommonRef->cmpntUUID[ 0 ] ), 
                  pConfig->pCmpnntUUID, sizeof( pCommonRef->cmpntUUID ) );

         }

         /**------------------------------------------------------------------
            Inialize debug messages properties.
         -------------------------------------------------------------------*/
         pCommonRef->debugMsgProp.nDebugMsgLevelFlags 
            = QOMX_DEBUG_MSG_LEVEL_ENABLE_ALL;

         QOMX_CMPNT_MEM_COPY( 
            & ( pCommonRef->debugMsgProp.acCustomName[ 0 ] ), 
            pConfig->pCmpnntName, ( sizeof( pCommonRef->acCmpntName ) - 1 ) );

         /**------------------------------------------------------------------
            Create critical section area.
         -------------------------------------------------------------------*/
         ( void ) qomx_CreateCriticalSection( & ( pCmpntCtx->hCritSection ) );

      }

   }


   /**------------------------------------------------------------------------
      Create DFC queue.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QDFC_ConfigType   qdfcConfig;
      /*--------------------------------------------------------------------*/
   
      /**---------------------------------------------------------------------
         Create a shared DFC queue.
      ----------------------------------------------------------------------*/
      qdfcConfig.sharedThread = QDFC_TRUE;
      qdfcConfig.nQueDepth    = QOMX_DFC_QUEUE_DEPTH;

      eErrDFC = qdfc_Init( & ( pCommonRef->hDfc ), & qdfcConfig  );

      if( QDFC_ERROR_NONE != eErrDFC )
      {
         QOMX_MSG_L_ERROR( pCommonRef,
            "QDFC Init failed. Error = %d", eErrDFC );

         /**------------------------------------------------------------------
            Could not create DFC queue, return insufficient resource error.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorInsufficientResources;

      }

   }


   /**------------------------------------------------------------------------
      Open a File Descriptor and register event handler with device.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      OMX_U32  nStatus = MMI_S_EFAIL;
      /*--------------------------------------------------------------------*/

      QOMX_MSG_L_MED( pCommonRef, "Calling device open now.");

      /**---------------------------------------------------------------------
         Open file descriptor now.
      ----------------------------------------------------------------------*/
      nStatus = pDev->pfnOpen( & hFd );

      if( MMI_S_COMPLETE == nStatus )
      {
         QOMX_MSG_L_MED( pCommonRef,
            "Registering event handler now. hFd = 0x%p", hFd );

         /**------------------------------------------------------------------
            Register event handler.
         -------------------------------------------------------------------*/
         nStatus = pDev->pfnEvtHdlr( hFd,
                           qomx_DeviceEventHandler, ( void * ) pCmpntCtx );

         if( MMI_S_COMPLETE != nStatus )
         {
            QOMX_MSG_L_ERROR( pCommonRef, 
               "Reg. failed. nStatus = 0x%x, hFd = 0x%p", nStatus, hFd );

            /**---------------------------------------------------------------
               Close the device.
            ----------------------------------------------------------------*/
            ( void ) pDev->pfnClose( hFd );

         }

      }

      if( MMI_S_COMPLETE != nStatus )
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Device command failed."
             "nStatus = 0x%x, hFd = 0x%p", nStatus, hFd );

         /**------------------------------------------------------------------
            There is an error during MMI setup, return HW error.
         -------------------------------------------------------------------*/
         eRetVal = qomx_GetOMXErrorCode( nStatus );

      }
      else
      {
         QOMX_MSG_L_HIGH( pCommonRef, "Device is ready. hFd = 0x%p", hFd );

         /**------------------------------------------------------------------
            Device is ready now for use.
         -------------------------------------------------------------------*/
         bFdReady = OMX_TRUE;

         /**------------------------------------------------------------------
            Store the device information.
         -------------------------------------------------------------------*/
         pCommonRef->device   = ( *pDev );
         pCommonRef->hFd      = hFd;

      }

   }

   /**------------------------------------------------------------------------
      If the file descriptor is opened and registered, create ports.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_MSG_L_MED( pCommonRef, "Create port container." );

      eRetVal = qomx_PortContainer_GetHandle( 
                     pConfig, pCommonRef, & ( pCmpntCtx->hPortCtnr ) );

   }

   /**------------------------------------------------------------------------
      If the ports are created, get Loaded state table and execute the entry
      handler for this state.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      /*--------------------------------------------------------------------*/

      pStTable = qomx_CmpntCommon_GetStateTable(
                                 pCmpntCtx, QOMX_StateLoaded );

      /**---------------------------------------------------------------------
         Call the entry handler now.
      ----------------------------------------------------------------------*/
      if( NULL != pStTable->pfnEntryHandler )
      {
         ( void ) pStTable->pfnEntryHandler( pCmpntCtx, 0xffff );

      }
      else
      {
         QOMX_MSG_L_ERROR( pCommonRef, 
            "Loaded state entry handler not defined." );

         eRetVal = OMX_ErrorNotImplemented;

      }

   }

   /**------------------------------------------------------------------------
      If component moved to Loaded state successfully, initialize the 
      component object and fill the component function pointers table.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      /**---------------------------------------------------------------------
         Set all the access function into the component handle.
      ----------------------------------------------------------------------*/
      pComp->GetComponentVersion    = qomx_GetComponentVersion;
      pComp->SendCommand            = qomx_SendCommand;
      pComp->GetParameter           = qomx_GetParameter;
      pComp->SetParameter           = qomx_SetParameter;
      pComp->GetConfig              = qomx_GetConfig;
      pComp->SetConfig              = qomx_SetConfig;
      pComp->GetExtensionIndex      = qomx_GetExtensionIndex;
      pComp->GetState               = qomx_GetState;
      pComp->ComponentTunnelRequest = qomx_ComponentTunnelRequest;
      pComp->UseBuffer              = qomx_UseBuffer;
      pComp->AllocateBuffer         = qomx_AllocateBuffer;
      pComp->FreeBuffer             = qomx_FreeBuffer;
      pComp->EmptyThisBuffer        = qomx_EmptyThisBuffer;
      pComp->FillThisBuffer         = qomx_FillThisBuffer;
      pComp->SetCallbacks           = qomx_SetCallbacks;
      pComp->ComponentDeInit        = qomx_ComponentDeInit;
      pComp->ComponentRoleEnum      = qomx_ComponentRoleEnum;
      pComp->UseEGLImage            = qomx_UseEGLImage;

   }
   else
   {
      /**---------------------------------------------------------------------
         There is some failure, release reserved resources now.
      ----------------------------------------------------------------------*/
      if( NULL != pCmpntCtx )
      {
         /**------------------------------------------------------------------
            Close device instance first.
         -------------------------------------------------------------------*/
         if( OMX_TRUE == bFdReady )
         {
            QOMX_MSG_L_HIGH( pCommonRef, "Close device now." );

            ( void ) pDev->pfnClose ( hFd );

         }

         /**------------------------------------------------------------------
            Release port memory area now.
         -------------------------------------------------------------------*/
         if( NULL != pCmpntCtx->hPortCtnr )
         {
            QOMX_MSG_L_HIGH( pCommonRef, "Release port container." );

            ( void ) qomx_PortContainer_FreeHandle(
                              pCommonRef, pCmpntCtx->hPortCtnr );

         }

         /**------------------------------------------------------------------
            Deinit DFC queue.
         -------------------------------------------------------------------*/
         if( QDFC_ERROR_NONE == eErrDFC )
         {
            QOMX_MSG_L_HIGH( pCommonRef, "Deinit QDFC." );

            eErrDFC = qdfc_DeInit( pCommonRef->hDfc );

            if( QDFC_ERROR_NONE != eErrDFC )
            {
               QOMX_MSG_L_ERROR( pCommonRef, "QDFC deinit failed. "
                 "eErrDFC = 0x%x, hDfc = 0x%p", eErrDFC, pCommonRef->hDfc );

            }

         }

         /**------------------------------------------------------------------
            Release critical section area.
         -------------------------------------------------------------------*/
         ( void ) qomx_ReleaseCriticalSection( pCmpntCtx->hCritSection );

         /**------------------------------------------------------------------
            Release context memory area.
         -------------------------------------------------------------------*/
         QOMX_CMPNT_FREEIF( pfnFree, hHeap, pCmpntCtx );

      }

      /**---------------------------------------------------------------------
         Release heap module.
      ----------------------------------------------------------------------*/
      QOMX_CMPNT_MEM_RELEASE_HANDLE( pfnReleaseHeapHandle, hHeap );

      /**---------------------------------------------------------------------
         Clear the component context set in the component handle.
      ----------------------------------------------------------------------*/
      if( NULL != pComp )
      {
         pComp->pComponentPrivate = NULL;
         pComp->nSize             = 0;

      }

   }

   return( eRetVal );

} /* end of function qomx_CmpntBaseInit */


/*==========================================================================

         FUNCTION:      qomx_GetComponentVersion

         DESCRIPTION:
                        Refer to OMX_GetComponentVersion in OMX_Core.h
                        or the OMX IL specification for details on the 
                        GetComponentVersion method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt            - Component handle.
            @param[out] pComponentName    - Refer OMX_Core.h / OMX IL spec.
            @param[out] pComponentVersion - Refer OMX_Core.h / OMX IL spec.
            @param[out] pSpecVersion      - Refer OMX_Core.h / OMX IL spec.
            @param[out] pComponentUUID    - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_GetComponentVersion
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_OUT  OMX_STRING                 pComponentName,
   OMX_OUT  OMX_VERSIONTYPE           *pComponentVersion,
   OMX_OUT  OMX_VERSIONTYPE           *pSpecVersion,
   OMX_OUT  OMX_UUIDTYPE              *pComponentUUID
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_MED(
      "h=0x%p, qomx_GetComponentVersion", pComp );

   /**------------------------------------------------------------------------
      Do a quick sanity check first. All output parameters can not be NULL.
   -------------------------------------------------------------------------*/
   if( ( NULL == pComponentName ) && ( NULL == pComponentVersion )
      && ( NULL == pSpecVersion ) && ( NULL == pComponentUUID ) )
   {
      QOMX_MSG_ERROR( "h=0x%p, Bad Parameters.", pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else 
   {   
      /**---------------------------------------------------------------------
         Validate the component handle.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntValidateHandle( pComp, OMX_TRUE );

   }

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      /*--------------------------------------------------------------------*/

      pCmpntCtx = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      if( NULL != pStTable->GetComponentVersion )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->GetComponentVersion( pCmpntCtx, pComponentName,
                        pComponentVersion, pSpecVersion, pComponentUUID );

      }
      else
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "Incorrect state "
            "operation, eMainState = 0x%x.", pCmpntCtx->eMainState );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

   }

   return( eRetVal );

} /* end of function qomx_GetComponentVersion */


/*==========================================================================

         FUNCTION:      qomx_SendCommand

         DESCRIPTION:
                        Refer to OMX_SendCommand in OMX_Core.h
                        or the OMX IL specification for details on the 
                        SendCommand method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component handle.
            @param[in]  eCmd        - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nParam      - Refer OMX_Core.h / OMX IL spec.
            @param[in]  pCmdData    - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_SendCommand
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_IN   OMX_COMMANDTYPE            eCmd,
   OMX_IN   OMX_U32                    nParam,
   OMX_IN   OMX_PTR                    pCmdData
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_MED( "h=0x%p, qomx_SendCommand" 
      " eCmd = 0x%x", pComp, eCmd );

   /**------------------------------------------------------------------------
      Validate the component handle.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_CmpntValidateHandle( pComp, OMX_TRUE );

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      /*--------------------------------------------------------------------*/

      pCmpntCtx = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      if( NULL != pStTable->SendCommand ) 
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->SendCommand( pCmpntCtx, eCmd, nParam, pCmdData );

      }
      else
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "Incorrect state "
            "operation, eMainState = 0x%x.", pCmpntCtx->eMainState );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

   }

   return( eRetVal );

} /* end of function qomx_SendCommand */


/*==========================================================================

         FUNCTION:      qomx_GetParameter

         DESCRIPTION:
                        Refer to OMX_GetParameter in OMX_Core.h
                        or the OMX IL specification for details on the 
                        GetParameter method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component handle.
            @param[in]  nIndex      - Refer OMX_Core.h / OMX IL spec.
            @param[inout] pCmpntParm  
                                    - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_GetParameter
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt, 
   OMX_IN   OMX_INDEXTYPE              nIndex,
   OMX_OUT  OMX_PTR                    pCmpntParm
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_MED( "h=0x%p, qomx_GetParameter"
      " nIndex = 0x%x",  pComp, ( OMX_U32 ) nIndex );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( NULL == pCmpntParm )
   {
      QOMX_MSG_ERROR( "h=0x%p, Bad Parameters.", pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else 
   {   
      /**---------------------------------------------------------------------
         Validate the component handle.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntValidateHandle( pComp, OMX_TRUE );

   }

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      /*--------------------------------------------------------------------*/

      pCmpntCtx = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      if( NULL != pStTable->GetParameter ) 
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->GetParameter( pCmpntCtx, nIndex, pCmpntParm );

      }
      else
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "Incorrect state "
            "operation, eMainState = 0x%x.", pCmpntCtx->eMainState );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

   }

   return( eRetVal );

} /* end of function qomx_GetParameter */


/*==========================================================================

         FUNCTION:      qomx_SetParameter

         DESCRIPTION:
                        Refer to OMX_SetParameter in OMX_Core.h
                        or the OMX IL specification for details on the 
                        SetParameter method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component handle.
            @param[in]  nIndex      - Refer OMX_Core.h / OMX IL spec.
            @param[in]  pCmpntParm  - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_SetParameter
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt, 
   OMX_IN   OMX_INDEXTYPE              nIndex,
   OMX_IN   OMX_PTR                    pCmpntParm
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_MED( "h=0x%p, qomx_SetParameter"
      " nIndex = 0x%x", pComp, ( OMX_U32 ) nIndex );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( NULL == pCmpntParm ) 
   {
      QOMX_MSG_ERROR( "h=0x%p, Bad Parameters.", pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else 
   {   
      /**---------------------------------------------------------------------
         Validate the component handle.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntValidateHandle( pComp, OMX_TRUE );

   }

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      /*--------------------------------------------------------------------*/

      pCmpntCtx = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      if( NULL != pStTable->SetParameter )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->SetParameter( 
                                    pCmpntCtx, nIndex, pCmpntParm );

      }
      else
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "Incorrect state "
            "operation, eMainState = 0x%x.", pCmpntCtx->eMainState );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

   }

   return( eRetVal );

} /* end of function qomx_SetParameter */


/*==========================================================================

         FUNCTION:      qomx_GetConfig

         DESCRIPTION:
                        Refer to OMX_GetConfig in OMX_Core.h
                        or the OMX IL specification for details on the 
                        GetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component handle.
            @param[in]  nIndex      - Refer OMX_Core.h / OMX IL spec.
            @param[out] pCmpntCfg   - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_GetConfig
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_IN   OMX_INDEXTYPE              nIndex, 
   OMX_OUT  OMX_PTR                    pCmpntCfg
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_MED( "h=0x%p, qomx_GetConfig"
      " nIndex = 0x%x",  pComp, ( OMX_U32 ) nIndex );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( NULL == pCmpntCfg ) 
   {
      QOMX_MSG_ERROR( "h=0x%p, Bad Parameters.", pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else 
   {   
      /**---------------------------------------------------------------------
         Validate the component handle.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntValidateHandle( pComp, OMX_TRUE );

   }

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      /*--------------------------------------------------------------------*/

      pCmpntCtx = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      if( NULL != pStTable->GetConfig )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->GetConfig( pCmpntCtx, nIndex, pCmpntCfg );

      }
      else
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "Incorrect state "
            "operation, eMainState = 0x%x.", pCmpntCtx->eMainState );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

   }

   return( eRetVal );

} /* end of function qomx_GetConfig */


/*==========================================================================

         FUNCTION:      qomx_SetConfig

         DESCRIPTION:
                        Refer to OMX_SetConfig in OMX_Core.h
                        or the OMX IL specification for details on the 
                        SetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component handle.
            @param[in]  nIndex      - Refer OMX_Core.h / OMX IL spec.
            @param[in]  pCmpntCfg   - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_SetConfig
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_IN   OMX_INDEXTYPE              nIndex, 
   OMX_IN   OMX_PTR                    pCmpntCfg
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_MED( "h=0x%p, qomx_SetConfig"
      " nIndex = 0x%x", pComp, ( OMX_U32 ) nIndex );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( NULL == pCmpntCfg )
   {
      QOMX_MSG_ERROR( "h=0x%p, Bad Parameters.", pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else 
   {   
      /**---------------------------------------------------------------------
         Validate the component handle.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntValidateHandle( pComp, OMX_TRUE );

   }

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      /*--------------------------------------------------------------------*/

      pCmpntCtx = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      if( NULL != pStTable->SetConfig ) 
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->SetConfig( pCmpntCtx, nIndex, pCmpntCfg );

      }
      else
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "Incorrect state "
            "operation, eMainState = 0x%x.", pCmpntCtx->eMainState );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

   }

   return( eRetVal );

} /* end of function qomx_SetConfig */


/*==========================================================================

         FUNCTION:      qomx_GetExtensionIndex

         DESCRIPTION:
                        Refer to OMX_GetExtensionIndex in OMX_Core.h
                        or the OMX IL specification for details on the 
                        GetExtensionIndex method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt         - Component handle.
            @param[in]  cParameterName - Refer OMX_Core.h / OMX IL spec.
            @param[out] pIndexType     - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_GetExtensionIndex
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_IN   OMX_STRING                 cParameterName,
   OMX_OUT  OMX_INDEXTYPE             *pIndexType
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_MED( "h=0x%p, qomx_GetExtensionIndex", pComp );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( ( NULL == cParameterName ) || ( NULL == pIndexType ) )
   {
      QOMX_MSG_ERROR( "h=0x%p, Bad Parameters.", pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else 
   {   
      /**---------------------------------------------------------------------
         Validate the component handle.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntValidateHandle( pComp, OMX_TRUE );

   }

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      /*--------------------------------------------------------------------*/

      pCmpntCtx = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      if( NULL != pStTable->GetExtensionIndex )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->GetExtensionIndex( pCmpntCtx,
                                    cParameterName, pIndexType );

      }
      else
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "Incorrect state "
            "operation, eMainState = 0x%x.", pCmpntCtx->eMainState );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

   }

   return( eRetVal );

} /* end of function qomx_GetExtensionIndex */


/*==========================================================================

         FUNCTION:      qomx_GetState

         DESCRIPTION:
                        Refer to OMX_GetState in OMX_Core.h
                        or the OMX IL specification for details on the 
                        GetState method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component handle.
            @param[out] pState      - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_GetState
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_OUT  OMX_STATETYPE             *pState
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_MED( "h=0x%p, qomx_GetState", pComp );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( NULL == pState ) 
   {
      QOMX_MSG_ERROR( "h=0x%p, Bad Parameters.", pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else 
   {   
      /**---------------------------------------------------------------------
         Validate the component handle.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntValidateHandle( pComp, OMX_TRUE );

   }

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      /*--------------------------------------------------------------------*/

      pCmpntCtx = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      if( NULL != pStTable->GetState ) 
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->GetState( pCmpntCtx, pState );

      }
      else
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "Incorrect state "
            "operation, eMainState = 0x%x.", pCmpntCtx->eMainState );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

   }

   return( eRetVal );

} /* end of function qomx_GetState */


/*==========================================================================

         FUNCTION:      qomx_ComponentTunnelRequest

         DESCRIPTION:
                        Refer to OMX_ComponentTunnelRequest in OMX_Core.h
                        or the OMX IL specification for details on the 
                        ComponentTunnelRequest method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt         - Component handle.
            @param[in]  nPort          - Refer OMX_Core.h / OMX IL spec.
            @param[in]  hTunneledComp  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nTunneledPort  - Refer OMX_Core.h / OMX IL spec.
            @param[out] pTunnelSetup   - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_ComponentTunnelRequest
(
   OMX_IN      OMX_HANDLETYPE          hCmpnt,
   OMX_IN      OMX_U32                 nPort,
   OMX_IN      OMX_HANDLETYPE          hTunneledComp,
   OMX_IN      OMX_U32                 nTunneledPort,
   OMX_INOUT   OMX_TUNNELSETUPTYPE    *pTunnelSetup
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_MED( 
      "h=0x%p, qomx_ComponentTunnelRequest", pComp );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( NULL == pTunnelSetup ) 
   {
      QOMX_MSG_ERROR( "h=0x%p, Bad Parameters.", pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else 
   {   
      /**---------------------------------------------------------------------
         Validate the component handle.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntValidateHandle( pComp, OMX_TRUE );

   }

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      /*--------------------------------------------------------------------*/

      pCmpntCtx = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      /**---------------------------------------------------------------------
         Tunnelled component is also a QOMX component, attempt to setup a
         vendor tunnel.
      ----------------------------------------------------------------------*/
      if( NULL != pStTable->ComponentTunnelRequest )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->ComponentTunnelRequest( pCmpntCtx, nPort, 
                                 hTunneledComp, nTunneledPort, pTunnelSetup );

      }
      else
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "Incorrect state "
            "operation, eMainState = 0x%x.", pCmpntCtx->eMainState );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

   }

   return( eRetVal );

} /* end of function qomx_ComponentTunnelRequest */


/*==========================================================================

         FUNCTION:      qomx_UseBuffer

         DESCRIPTION:
                        Refer to OMX_UseBuffer in OMX_Core.h
                        or the OMX IL specification for details on the 
                        UseBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component handle.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nPortIndex  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nSizeBytes  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  pBuffer     - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_UseBuffer
(
   OMX_IN      OMX_HANDLETYPE          hCmpnt,
   OMX_OUT     OMX_BUFFERHEADERTYPE  **ppBufferHdr,
   OMX_IN      OMX_U32                 nPortIndex,
   OMX_IN      OMX_PTR                 pAppPrivate,
   OMX_IN      OMX_U32                 nSizeBytes,
   OMX_IN      OMX_U8                 *pBuffer
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_MED( "h=0x%p, qomx_UseBuffer", pComp );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( ( NULL == ppBufferHdr ) || ( NULL == pBuffer ) || ( 0 == nSizeBytes ) )
   {
      QOMX_MSG_ERROR( "h=0x%p, Bad Parameters.", pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else 
   {   
      /**---------------------------------------------------------------------
         Validate the component handle.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntValidateHandle( pComp, OMX_TRUE );

   }

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      /*--------------------------------------------------------------------*/

      pCmpntCtx = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      if( NULL != pStTable->UseBuffer )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->UseBuffer( pCmpntCtx, ppBufferHdr, nPortIndex, 
                                 pAppPrivate, nSizeBytes, pBuffer );

      }
      else
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "Incorrect state "
            "operation, eMainState = 0x%x.", pCmpntCtx->eMainState );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

   }

   return( eRetVal );

} /* end of function qomx_UseBuffer */


/*==========================================================================

         FUNCTION:      qomx_AllocateBuffer

         DESCRIPTION:
                        Refer to OMX_AllocateBuffer in OMX_Core.h
                        or the OMX IL specification for details on the 
                        AllocateBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component handle.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nPortIndex  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nSizeBytes  - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_AllocateBuffer
(
   OMX_IN      OMX_HANDLETYPE          hCmpnt,
   OMX_OUT     OMX_BUFFERHEADERTYPE  **ppBufferHdr,
   OMX_IN      OMX_U32                 nPortIndex,
   OMX_IN      OMX_PTR                 pAppPrivate,
   OMX_IN      OMX_U32                 nSizeBytes
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_MED( "h=0x%p, qomx_AllocateBuffer", pComp );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( ( NULL == ppBufferHdr ) || ( 0 == nSizeBytes ) )
   {
      QOMX_MSG_ERROR( "h=0x%p, Bad Parameters.", pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else 
   {   
      /**---------------------------------------------------------------------
         Validate the component handle.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntValidateHandle( pComp, OMX_TRUE );

   }

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      /*--------------------------------------------------------------------*/

      pCmpntCtx = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      if( NULL != pStTable->AllocateBuffer )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->AllocateBuffer( pCmpntCtx, ppBufferHdr, 
                                    nPortIndex, pAppPrivate, nSizeBytes );

      }
      else
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "Incorrect state "
            "operation, eMainState = 0x%x.", pCmpntCtx->eMainState );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

   }

   return( eRetVal );

} /* end of function qomx_AllocateBuffer */


/*==========================================================================

         FUNCTION:      qomx_FreeBuffer

         DESCRIPTION:
                        Refer to OMX_FreeBuffer in OMX_Core.h
                        or the OMX IL specification for details on the 
                        FreeBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component handle.
            @param[in]  nPortIndex  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_FreeBuffer
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_IN   OMX_U32                    nPortIndex,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBufferHdr
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_MED( "h=0x%p, qomx_FreeBuffer",  pComp );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( NULL == pBufferHdr ) 
   {
      QOMX_MSG_ERROR( "h=0x%p, Bad Parameters.",  pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else 
   {   
      /**---------------------------------------------------------------------
         Validate the component handle.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntValidateHandle( pComp, OMX_TRUE );

   }

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      /*--------------------------------------------------------------------*/

      pCmpntCtx = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      if( NULL != pStTable->FreeBuffer )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->FreeBuffer( pCmpntCtx, nPortIndex, pBufferHdr );

      }
      else
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "Incorrect state "
            "operation, eMainState = 0x%x.", pCmpntCtx->eMainState );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

   }

   return( eRetVal );

} /* end of function qomx_FreeBuffer */


/*==========================================================================

         FUNCTION:      qomx_EmptyThisBuffer

         DESCRIPTION:
                        Refer to OMX_EmptyThisBuffer in OMX_Core.h
                        or the OMX IL specification for details on the 
                        EmptyThisBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component handle.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_EmptyThisBuffer
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBufferHdr
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_LOW( "h=0x%p, qomx_EmptyThisBuffer",  pComp );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( NULL == pBufferHdr ) 
   {
      QOMX_MSG_ERROR( "h=0x%p, Bad Parameters.",  pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else 
   {   
      /**---------------------------------------------------------------------
         Validate the component handle.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntValidateHandle( pComp, OMX_TRUE );

   }

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      /*--------------------------------------------------------------------*/

      pCmpntCtx = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      if( NULL != pStTable->EmptyThisBuffer )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->EmptyThisBuffer( pCmpntCtx, pBufferHdr );

      }
      else
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "Incorrect state "
            "operation, eMainState = 0x%x.", pCmpntCtx->eMainState );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

   }

   return( eRetVal );

} /* end of function qomx_EmptyThisBuffer */


/*==========================================================================

         FUNCTION:      qomx_FillThisBuffer

         DESCRIPTION:
                        Refer to OMX_FillThisBuffer in OMX_Core.h
                        or the OMX IL specification for details on the 
                        FillThisBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component handle.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_FillThisBuffer
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBufferHdr
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_LOW( "h=0x%p, qomx_FillThisBuffer",  pComp );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( NULL == pBufferHdr ) 
   {
      QOMX_MSG_ERROR( "h=0x%p, Bad Parameters.",  pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else 
   {
      /**---------------------------------------------------------------------
         Validate the component handle.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntValidateHandle( pComp, OMX_TRUE );

   }

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      /*--------------------------------------------------------------------*/

      pCmpntCtx = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      if( NULL != pStTable->FillThisBuffer )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->FillThisBuffer( pCmpntCtx, pBufferHdr );

      }
      else
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "Incorrect state "
            "operation, eMainState = 0x%x.", pCmpntCtx->eMainState );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

   }

   return( eRetVal );

} /* end of function qomx_FillThisBuffer */


/*==========================================================================

         FUNCTION:      qomx_SetCallbacks

         DESCRIPTION:
                        Refer to OMX_SetCallBacks in OMX_Core.h
                        or the OMX IL specification for details on the 
                        SetCallBacks method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component handle.
            @param[in]  pCallbacks  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  pAppData    - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_SetCallbacks                        
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_IN   OMX_CALLBACKTYPE          *pCallbacks, 
   OMX_IN   OMX_PTR                    pAppData
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/
 
   QOMX_MSG_MED( "h=0x%p, qomx_SetCallbacks",  pComp );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( NULL == pCallbacks ) 
   {
      QOMX_MSG_ERROR( "h=0x%p, Bad Parameters.",  pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else 
   {   
      /**---------------------------------------------------------------------
         Validate the component handle.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntValidateHandle( pComp, OMX_FALSE );

   }

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      /*--------------------------------------------------------------------*/

      pCmpntCtx = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      if( NULL != pStTable->SetCallbacks ) 
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->SetCallbacks( pCmpntCtx, pCallbacks, pAppData );

      }
      else
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "Incorrect state "
            "operation, eMainState = 0x%x.", pCmpntCtx->eMainState );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

   }

   return( eRetVal );

} /* end of function qomx_SetCallbacks */


/*==========================================================================

         FUNCTION:      qomx_ComponentDeInit

         DESCRIPTION:
                        Refer to OMX_ComponentDeInit in OMX_Core.h
                        or the OMX IL specification for details on the 
                        ComponentDeInit method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component handle.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_ComponentDeInit
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_HIGH( "h=0x%p, qomx_ComponentDeInit", pComp );

   /**------------------------------------------------------------------------
      Validate the component handle.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_CmpntValidateHandle( pComp, OMX_TRUE );

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      QDFC_ErrorType             eErrDFC;
      OMX_HANDLETYPE             hHeap;
      QOMX_CommonRefType        *pCommonRef;
      /*--------------------------------------------------------------------*/

      pCmpntCtx   = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;
      pCommonRef  = & ( pCmpntCtx->commonRef );

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Call the state table function now.
      ----------------------------------------------------------------------*/
      eRetVal = pStTable->ComponentDeInit( pCmpntCtx );

      if( OMX_ErrorNone == eRetVal )
      {
         /**------------------------------------------------------------------
            Save the function pointer to the ReleaseHeapHandle routine;
            after the Free call, it will be used to release heap handle.
         -------------------------------------------------------------------*/
         MMI_ReleaseHeapHandleType pfnReleaseHeapHandle =
                           pCommonRef->pfnReleaseHeapHandle;
         /*-----------------------------------------------------------------*/

         /**------------------------------------------------------------------
            Get heap handle.
         -------------------------------------------------------------------*/
         hHeap = pCommonRef->hHeap;

         /**------------------------------------------------------------------
            Deinit DFC queue.
         -------------------------------------------------------------------*/
         eErrDFC = qdfc_DeInit( pCommonRef->hDfc );

         if( QDFC_ERROR_NONE != eErrDFC )
         {
            QOMX_MSG_L_ERROR( pCommonRef, "QDFC deinit failed."
               "eErrDFC = 0x%x, hDfc = 0x%p", eErrDFC, pCommonRef->hDfc );

         }

         /**------------------------------------------------------------------
            Release critical section area.
         -------------------------------------------------------------------*/
         ( void ) qomx_ReleaseCriticalSection( pCmpntCtx->hCritSection );

         /**------------------------------------------------------------------
            Free Component handle.
         -------------------------------------------------------------------*/
         QOMX_CMPNT_FREEIF( pCommonRef->pfnFree, hHeap, pComp->pComponentPrivate );

         /**------------------------------------------------------------------
            Release heap handle.
         -------------------------------------------------------------------*/
         QOMX_CMPNT_MEM_RELEASE_HANDLE( pfnReleaseHeapHandle, hHeap );

      }

   }

   return( eRetVal );

} /* end of function qomx_ComponentDeInit */


/*==========================================================================

         FUNCTION:      qomx_UseEGLImage

         DESCRIPTION:
                        Refer to OMX_UseEGLImage in OMX_Core.h
                        or the OMX IL specification for details on the 
                        UseEGLImage method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component handle.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nPortIndex  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL spec.
            @param[out] eglImage    - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_UseEGLImage
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_OUT  OMX_BUFFERHEADERTYPE     **ppBufferHdr,
   OMX_IN   OMX_U32                    nPortIndex,
   OMX_IN   OMX_PTR                    pAppPrivate,
   OMX_IN   void                      *eglImage
)
{
   QOMX_MSG_MED( "h=0x%p, qomx_UseEGLImage, nPortIndex = 0x%x",
      hCmpnt, ( OMX_U32 ) nPortIndex );

   /**------------------------------------------------------------------------
      UseEGLImage is not defined.
   -------------------------------------------------------------------------*/

   return( OMX_ErrorUndefined );

} /* end of function qomx_UseEGLImage */


/*==========================================================================

         FUNCTION:      qomx_ComponentRoleEnum

         DESCRIPTION:
                        Refer to OMX_ComponentRoleEnum in OMX_Core.h
                        or the OMX IL specification for details on the 
                        ComponentRoleEnum method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component handle.
            @param[out] cRole       - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nIndex      - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_ComponentRoleEnum
(
   OMX_IN   OMX_HANDLETYPE             hCmpnt,
   OMX_OUT  OMX_U8                    *cRole,
   OMX_IN   OMX_U32                    nIndex
)
{
   OMX_ERRORTYPE        eRetVal  = OMX_ErrorNone;
   OMX_COMPONENTTYPE   *pComp    = ( OMX_COMPONENTTYPE * ) hCmpnt;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_MED( "h=0x%p, qomx_ComponentRoleEnum, nIndex = 0x%x",
      pComp, ( OMX_U32 ) nIndex );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( NULL == cRole )
   {
      QOMX_MSG_ERROR( "h=0x%p, Bad Parameters.", pComp );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else 
   {   
      /**---------------------------------------------------------------------
         Validate the component handle.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntValidateHandle( pComp, OMX_TRUE );

   }

   /**------------------------------------------------------------------------
      If the validations are successful, lock the component context and
      call appropriate function.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_CmpntStateTableType  *pStTable;
      QOMX_CmpntCtxType         *pCmpntCtx;
      /*--------------------------------------------------------------------*/

      pCmpntCtx = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      if( NULL != pStTable->ComponentRoleEnum )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->ComponentRoleEnum( pCmpntCtx, cRole, nIndex );

      }
      else
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "Incorrect state "
            "operation, eMainState = 0x%x.", pCmpntCtx->eMainState );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      /**---------------------------------------------------------------------
         Release LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntUnlockContext( hCmpnt );

   }

   return( eRetVal );

} /* end of function qomx_ComponentRoleEnum */


/*==========================================================================

         FUNCTION:      qomx_DeviceEventHandler

         DESCRIPTION:
                        This function is called when the device want to 
                        communicate to the OMX base class. All device events
                        are then funneld to appropriate states.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  nEventCode     -  Event code.
            @param[in]  nEventStatus   -  Event status.
            @param[in]  nPayloadLen    -  Payload length.
            @param[in]  pEvtData       -  Payload corresponding to this event.
            @param[in]  pClientData    -  Client Data passed as part of the 
                                          device open.
**//*    RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_DeviceEventHandler
(
   OMX_IN   OMX_U32                    nEventCode,
   OMX_IN   OMX_U32                    nEventStatus,
   OMX_IN   OMX_U32                    nPayloadLen,
   OMX_IN   OMX_PTR                    pEvtData,
   OMX_IN   OMX_PTR                    pClientData
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CmpntCtxType   *pCmpntCtx   = ( QOMX_CmpntCtxType * ) pClientData;
   QOMX_CommonRefType  *pCommonRef  = NULL;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_MED( "h=0x%p, qomx_DeviceEventHandler, nEventCode = 0x%x",
       pCmpntCtx, ( OMX_U32 ) nEventCode );

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( NULL == pCmpntCtx )
   {
      /**---------------------------------------------------------------------
         Compent context is invalid.
      ----------------------------------------------------------------------*/
      QOMX_MSG_ERROR( "Unexpected param. pClientData is NULL." );

   }
   else 
   {
      QOMX_CmpntStateTableType  *pStTable;
      /*--------------------------------------------------------------------*/

      pCommonRef = & ( pCmpntCtx->commonRef );

      QOMX_MSG_L_MED( pCommonRef, "nEventCode = 0x%x, nEventStatus = 0x%x",
         ( OMX_U32 ) nEventCode, ( OMX_U32 ) nEventStatus );

      /**---------------------------------------------------------------------
         Acquire LOCK.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLockContext( pCommonRef->hCmpnt );

      /**---------------------------------------------------------------------
         Get the component state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_CmpntCommon_GetStateTable(
                                    pCmpntCtx, pCmpntCtx->eMainState );

      if( NULL != pStTable->pfnEventHandler )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->pfnEventHandler( pCmpntCtx, nEventCode,
                                       nEventStatus, nPayloadLen, pEvtData );

      }
      else
      {
         /**------------------------------------------------------------------
            Callback is not expected in this state.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_ERROR( pCommonRef, "Unexpected callback "
             "in eMainState = 0x%x", pCmpntCtx->eMainState );

      }


      /**---------------------------------------------------------------------
         *************************
         **** IMPORTANT NOTE: ****
         *************************
         This function should unlock critical section only if it has not
         already been unlocked by some function in pfnEventHandler stack. 
         If event handler returns OMX_ERROR_CS_RELEASED, skip unlocking
         the context.
         e.g. For buffer done responses critical section will be unlocked
         right before issueing callbacks to IL client so locks should be
         assumed released for buffer done.
      ----------------------------------------------------------------------*/
      if( OMX_ERROR_CS_RELEASED != eRetVal )
      {
         QOMX_MSG_L_LOW( pCommonRef, "CS is NOT released inside state  "
            "handler. Unlock now. eRetVal = 0x%x", eRetVal );

         /**------------------------------------------------------------------
            Release LOCK.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntUnlockContext( pCmpntCtx->commonRef.hCmpnt );

      }
      else
      {
         QOMX_MSG_L_LOW( pCommonRef, "CS is released inside state machine "
            "handler. Skip unlock now." );

      }

   }

   return;
   
} /* end of function qomx_DeviceEventHandler */
