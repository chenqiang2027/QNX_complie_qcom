/*========================================================================

*//** @file qomxPortDisabledDepopulating.c

@par FILE SERVICES:
      Implementation file for Port state QOMX_StatePortDisabledDepopulating.

      This file contains the definitions for the port methods which are
      called when port state is QOMX_StatePortDisabledDepopulating. This
      state is assumed when port is processing disable command and buffers
      are being released.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxPortDisabledDepopulating.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
06/22/16   am     Fix compiler warnings for 64 bit OS environment.
10/23/13   dp     Add missing variable to messages.
08/05/10   yt     Refactoring of disable procedure for tunneling.
07/22/10   zm     Add component handle/port index in base class logging.
06/10/10   dm     Added return type in event handler.
05/10/10   dm     Allow port config changed on disabled ports.
03/26/10   spl    Modified to support interop-profile.
10/21/09   dm     Port state split.
07/24/09   dm     Changed order of buffer count decrement and callback.
07/21/09   dm     Handled buffer supplier settings.
06/16/09   dm     Initial Creation.

========================================================================== */

/*========================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxPortCommon.h"
#include "qomxPortUtils.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/**
 *
 * Forward declaration for the functions defined statically in this file.
 *
 */

static void    qomx_PortDisabledDepopulating_StateEntryHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
);

static void    qomx_PortDisabledDepopulating_StateExitHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
);

static OMX_ERRORTYPE    qomx_PortDisabledDepopulating_FreeBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN OMX_BUFFERHEADERTYPE           *pBufferHdr
);

static OMX_ERRORTYPE    qomx_PortDisabledDepopulating_DeviceEventHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEventCode,
   OMX_IN   OMX_U32                       nEventStatus,
   OMX_IN   OMX_U32                       nParamSize,
   OMX_IN   OMX_PTR                      *pParam
);


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_PortDisabledDepopulating_LoadStateTable

         DESCRIPTION:
                        This function will load the port state table
                        supported by the QOMX_StatePortDisabledDepopulating
                        state in the object of state table being passed.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable    - Pointer to the state primitive table
                                      object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortDisabledDepopulating_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType      *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      port is in QOMX_StatePortDisabledDepopulating state. NULL entry
      indicates that the specific function call is not allowed in this state,
      thus port utilities should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/
   pStTable->Enable           = NULL;
   pStTable->Disable          = NULL;
   pStTable->TunnelRequest    = NULL;
   pStTable->Populate         = NULL;
   pStTable->Unpopulate       = NULL;
   pStTable->Run              = NULL;
   pStTable->Stop             = NULL;
   pStTable->UseBuffer        = NULL;
   pStTable->AllocateBuffer   = NULL;
   pStTable->FreeBuffer       = qomx_PortDisabledDepopulating_FreeBuffer;
   pStTable->EmptyThisBuffer  = NULL;
   pStTable->FillThisBuffer   = NULL;
   pStTable->Flush            = NULL;
   pStTable->DeInit           = qomx_PortCommon_DeInit;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler
                     = qomx_PortDisabledDepopulating_DeviceEventHandler;

   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler
                     = qomx_PortDisabledDepopulating_StateEntryHandler;
   pStTable->pfnExitHandler
                     = qomx_PortDisabledDepopulating_StateExitHandler;

   return;

} /* end of function qomx_PortDisabledDepopulating_LoadStateTable */


/*==========================================================================

         FUNCTION:      qomx_PortDisabledDepopulating_StateEntryHandler

         DESCRIPTION:
*//**                   This function executes initial routines when port
                        moves in QOMX_StatePortEnabledPopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the Port context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_PortDisabledDepopulating_StateEntryHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
)
{
   OMX_ERRORTYPE  eRetVal;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Entering DisabledDepopulating"
      " State, nPortIndex = 0x%x, nEvent = 0x%x",
      pPortCtx->portDef.nPortIndex, nEvent );
   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pPortCtx->eState = QOMX_StatePortDisabledDepopulating;

   /**------------------------------------------------------------------------
      If no buffers to wait for, directly move to unpopulated state.
   -------------------------------------------------------------------------*/
   if( OMX_TRUE == qomx_PortCommon_CheckGuard( pPortCtx,
                                               QOMX_PORT_GUARD_UNPOPULATED ) )
   {
      QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
         "No buffers in queue, moving to unpopulated." );

      ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr, pPortCtx,
         QOMX_StatePortDisabledUnpopulated, 0 );

   }
   /**------------------------------------------------------------------------
      Otherwise, if this is a tunneling supplier port, free buffers and let
      peer component free headers.
   -------------------------------------------------------------------------*/
   else if( ( PORT_TUNNELING_DISABLED != pPortCtx->eTunneling )
         && ( PORT_TUNNELING_VENDOR != pPortCtx->eTunneling )
         && ( QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx ) ) )
   {
      QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
         "Port is tunneling supplier." );

      if( pPortCtx->bTunnelPeerAcceptsFreeBuffer )
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
            "Peer already accepts FreeBuffer calls." );

         eRetVal = qomx_PortCommon_FreeTunnelBuffers(pPortCtnr, pPortCtx);

         if( OMX_ErrorNone != eRetVal )
         {
            QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef,
               "FreeTunnelBuffers failed." );
         }

      }
      else
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
            "Port is awaiting peer to signal FreeBuffer acceptance." );
      }

   }
   /**------------------------------------------------------------------------
      If this is a tunneling non-supplier, signal peer for FreeBuffer
      acceptance.
   -------------------------------------------------------------------------*/
   else if( ( PORT_TUNNELING_DISABLED != pPortCtx->eTunneling )
         && ( PORT_TUNNELING_VENDOR != pPortCtx->eTunneling )
         && ( !QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx ) ) )
   {
      QDFC_ErrorType    eErrVal;
      /*--------------------------------------------------------------------*/

      eErrVal = qdfc_EnqueueArg6Function( pPortCtnr->pCommonRef->hDfc,
                  ( qfc_Arg6FpType ) ( qomx_PortCommon_SignalTunnelPeer ),
                  ( QDFC_ArgType ) pPortCtx->hTunneledComp,
                  ( QDFC_ArgType ) pPortCtx->nTunneledPort,
                  ( QDFC_ArgType ) OMX_PORTSTATUS_ACCEPTSFREEBUFFER,
                  ( QDFC_ArgType ) 0,
                  ( QDFC_ArgType ) 0,
                  ( QDFC_ArgType ) 0 );

      if( QDFC_ERROR_NONE != eErrVal )
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef,
            "DFC EnQueue error = %d. Event dropped", eErrVal );

      }

   }

   return;

} /* end of function qomx_PortDisabledDepopulating_StateEntryHandler */


/*==========================================================================

         FUNCTION:      qomx_PortDisabledDepopulating_StateExitHandler

         DESCRIPTION:
*//**                   This function executes initial routines when port
                        moves out of QOMX_StatePortEnabledPopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the Port context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_PortDisabledDepopulating_StateExitHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
)
{
   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Exiting DisabledDepopulating"
      " State, nPortIndex = 0x%x, nEvent = 0x%x",
      pPortCtx->portDef.nPortIndex, nEvent );

   return;

} /* end of function qomx_PortDisabledDepopulating_StateExitHandler */


/*==========================================================================

         FUNCTION:      qomx_PortDisabledDepopulating_FreeBuffer

         DESCRIPTION:
*//**                   This function processes free buffer request when port
                        is in QOMX_StatePortDisabledDepopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.
@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortDisabledDepopulating_FreeBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN OMX_BUFFERHEADERTYPE           *pBufferHdr
)
{
   OMX_ERRORTYPE  eRetVal;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
      "qomx_PortDisabledDepopulating_FreeBuffer nPortIndex = 0x%x, pBufferHdr"
      " = 0x%p", pPortCtx->portDef.nPortIndex, pBufferHdr );

   /**------------------------------------------------------------------------
      Free the buffer.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortCommon_FreeBuffer( pPortCtnr, pPortCtx, pBufferHdr );

   if( OMX_ErrorNone == eRetVal )
   {

      /**---------------------------------------------------------------------
         If all buffers are unpopulated and device is disable, transition
         to QOMX_StatePortDisabledUnpopulated state.
      ----------------------------------------------------------------------*/
      if( OMX_TRUE == qomx_PortCommon_CheckGuard(
                                 pPortCtx, QOMX_PORT_GUARD_UNPOPULATED ) )
      {

         /**------------------------------------------------------------------
            Complete state transition.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
            "Move to PortDisabledUnpopulated state nPortIndex = 0x%x",
            pPortCtx->portDef.nPortIndex );

         ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                           pPortCtx, QOMX_StatePortDisabledUnpopulated, 0 );

      }

   }

   return( eRetVal );

} /* end of function qomx_PortDisabledDepopulating_FreeBuffer */


/*==========================================================================

         FUNCTION:      qomx_PortDisabledDepopulating_DeviceEventHandler

         DESCRIPTION:
*//**                   This function processes events from device when port
                        is in QOMX_StatePortDisabledDepopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  nEventCode  - Event code.
            @param [in] nEventStatus- Status of the event.
            @param [in] nParamSize  - Size in bytes for the event related
                                      data which is pointed by the payload.
            @param [in] pParam      - Event related payload.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortDisabledDepopulating_DeviceEventHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEventCode,
   OMX_IN   OMX_U32                       nEventStatus,
   OMX_IN   OMX_U32                       nParamSize,
   OMX_IN   OMX_PTR                      *pParam
)
{
   OMX_ERRORTYPE  eRetVal = OMX_ErrorNone;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
      "qomx_PortDisabledDepopulating_DeviceEventHandler, nPortIndex = 0x%x,"
      " nEventCode = 0x%x", pPortCtx->portDef.nPortIndex, nEventCode );

   /**------------------------------------------------------------------------
      Check event code.
   -------------------------------------------------------------------------*/
   switch( nEventCode )
   {
   case MMI_RESP_DISABLE_PORT:
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "MMI_RESP_DISABLE_PORT"
            " event nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Handle disable command response.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_DisableResp(
                              pPortCtnr, pPortCtx, nEventStatus, OMX_FALSE );

      }

      break;

   case MMI_RESP_FLUSH:
      {
         QOMX_MSG_L_LOW( pPortCtnr->pCommonRef, "MMI_RESP_FLUSH"
            " event nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Call internal function to process this flush response.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_DisableFlushResp( pPortCtnr, pPortCtx );

      }

      break;

   case MMI_EVT_PORT_CONFIG_CHANGED:
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "MMI_EVT_PORT_CONFIG_CHANGED"
            " event nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Process config change event and update port definition.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_ConfigChange(
                                          pPortCtnr->pCommonRef, pPortCtx );

      }

      break;

   default:
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Unexpected parameters in"
            " device event: nEventCode = 0x%x, nPortIndex = 0x%x",
            nEventCode, pPortCtx->portDef.nPortIndex );

      }

      break;

   } /* end of switch( nEventCode ) */

   return( eRetVal );

} /* end of function qomx_PortDisabledDepopulating_DeviceEventHandler */


