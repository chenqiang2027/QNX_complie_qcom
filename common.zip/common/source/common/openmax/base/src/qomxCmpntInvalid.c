/*========================================================================

*//** @file qomxCmpntInvalid.c

@par FILE SERVICES:
      Component Invalid State Implementation File.

      This file implements all the methods which are applicable for
      OMX_StateInvalid state.

      Main functions are FreeBuffer and Deinit. Functions which are common
      for all states are implemented in the common functions table.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCmpntInvalid.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
07/02/14   dp     Check if the ports are created when entering state entry handler.
06/09/14   rz     Fix compilation warning
05/26/14   rz     Notify device invalid state
05/09/14   rz     Move port state to be appropriate to accept FreeBuffer
08/08/11   dm     Hardware critical error handling.
07/22/10   zm     Add component handle in each base class logging message.
10/30/09   dm     Return invalid state error on invalid function calls.
10/09/09   dm     Split component states.
08/18/09   dm     Removed state exit handler for invalid state.
06/03/09   dm     Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxPortCommon.h"
#include "qomxCmpntCommon.h"
#include "qomxPortUtils.h"
#include "qomxPortContext.h"

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 *
 * Forward declaration for the functions statically defined in this file.
 *
 */

static void    qomx_CmpntInvalid_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
);

static OMX_ERRORTYPE  qomx_CmpntInvalid_NotifyDevice
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);

static OMX_ERRORTYPE    qomx_CmpntInvalid_GetComponentVersion
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_OUT  OMX_STRING                 pComponentName,
   OMX_OUT  OMX_VERSIONTYPE           *pComponentVersion,
   OMX_OUT  OMX_VERSIONTYPE           *pSpecVersion,
   OMX_OUT  OMX_UUIDTYPE              *pComponentUUID
);

static OMX_ERRORTYPE    qomx_CmpntInvalid_SendCommand
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE            eCmd,
   OMX_IN   OMX_U32                    nParam,
   OMX_IN   OMX_PTR                    pCmdData
);

static OMX_ERRORTYPE    qomx_CmpntInvalid_GetParameter
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE              nIndex,
   OMX_OUT  OMX_PTR                    pCmpntParm
);

static OMX_ERRORTYPE    qomx_CmpntInvalid_SetParameter
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE              nIndex,
   OMX_IN   OMX_PTR                    pCmpntParm
);

static OMX_ERRORTYPE    qomx_CmpntInvalid_GetConfig
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE              nIndex,
   OMX_IN   OMX_PTR                    pCmpntCfg
);

static OMX_ERRORTYPE    qomx_CmpntInvalid_SetConfig
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE              nIndex,
   OMX_IN   OMX_PTR                    pCmpntCfg
);

static OMX_ERRORTYPE    qomx_CmpntInvalid_GetExtensionIndex
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_STRING                 cParameterName,
   OMX_OUT  OMX_INDEXTYPE             *pIndexType
);

static OMX_ERRORTYPE    qomx_CmpntInvalid_CmpntTunnelRequest
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN      OMX_U32                 nPort,
   OMX_IN      OMX_HANDLETYPE          hTunneledComp,
   OMX_IN      OMX_U32                 nTunneledPort,
   OMX_INOUT   OMX_TUNNELSETUPTYPE    *pTunnelSetup
);

static OMX_ERRORTYPE    qomx_CmpntInvalid_UseBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_OUT  OMX_BUFFERHEADERTYPE     **ppBuffer,
   OMX_IN   OMX_U32                    nPortIndex,
   OMX_IN   OMX_PTR                    pAppPrivate,
   OMX_IN   OMX_U32                    nSizeBytes,
   OMX_IN   OMX_U8                    *pBuffer
);

static OMX_ERRORTYPE    qomx_CmpntInvalid_AllocateBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_OUT  OMX_BUFFERHEADERTYPE     **ppBuffer,
   OMX_IN   OMX_U32                    nPortIndex,
   OMX_IN   OMX_PTR                    pAppPrivate,
   OMX_IN   OMX_U32                    nSizeBytes
);

static OMX_ERRORTYPE    qomx_CmpntInvalid_EmptyThisBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBuffer
);

static OMX_ERRORTYPE    qomx_CmpntInvalid_FillThisBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBuffer
);

static OMX_ERRORTYPE    qomx_CmpntInvalid_SetCallbacks
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_CALLBACKTYPE          *pCallbacks,
   OMX_IN   OMX_PTR                    pAppData
);

static OMX_ERRORTYPE    qomx_CmpntInvalid_UseEGLImage
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_OUT  OMX_BUFFERHEADERTYPE     **ppBufferHdr,
   OMX_IN   OMX_U32                    nPortIndex,
   OMX_IN   OMX_PTR                    pAppPrivate,
   OMX_IN   void                      *eglImage
);

static OMX_ERRORTYPE    qomx_CmpntInvalid_ComponentRoleEnum
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_OUT  OMX_U8                    *cRole,
   OMX_IN   OMX_U32                    nIndex
);

static void qomx_CmpntInvalid_TransitionPortState
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx
);

/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_LoadStateTable

         DESCRIPTION:
                        This function will load the component state table
                        supported by the Invalid state in the object of
                        state table being passed.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable - Pointer to the state primitive table
                                   object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntInvalid_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      component is in QOMX_StateInvalid state. NULL entry indicates that the
      specific function call is not allowed in this state, thus component API
      should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/
   pStTable->GetComponentVersion    = qomx_CmpntInvalid_GetComponentVersion;
   pStTable->SendCommand            = qomx_CmpntInvalid_SendCommand;
   pStTable->GetParameter           = qomx_CmpntInvalid_GetParameter;
   pStTable->SetParameter           = qomx_CmpntInvalid_SetParameter;
   pStTable->GetConfig              = qomx_CmpntInvalid_GetConfig;
   pStTable->SetConfig              = qomx_CmpntInvalid_SetConfig;
   pStTable->GetExtensionIndex      = qomx_CmpntInvalid_GetExtensionIndex;
   pStTable->GetState               = qomx_CmpntCommon_GetState;
   pStTable->ComponentTunnelRequest = qomx_CmpntInvalid_CmpntTunnelRequest;
   pStTable->UseBuffer              = qomx_CmpntInvalid_UseBuffer;
   pStTable->AllocateBuffer         = qomx_CmpntInvalid_AllocateBuffer;
   pStTable->FreeBuffer             = qomx_CmpntCommon_FreeBuffer;
   pStTable->EmptyThisBuffer        = qomx_CmpntInvalid_EmptyThisBuffer;
   pStTable->FillThisBuffer         = qomx_CmpntInvalid_FillThisBuffer;
   pStTable->SetCallbacks           = qomx_CmpntInvalid_SetCallbacks;
   pStTable->ComponentDeInit        = qomx_CmpntCommon_ComponentDeInit;
   pStTable->UseEGLImage            = qomx_CmpntInvalid_UseEGLImage;
   pStTable->ComponentRoleEnum      = qomx_CmpntInvalid_ComponentRoleEnum;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler        = NULL;

   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler        = qomx_CmpntInvalid_StateEntryHandler;
   pStTable->pfnExitHandler         = NULL;

   return;

} /* end of function qomx_CmpntInvalid_LoadStateTable */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_StateEntryHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateInvalid is entered. Entry into the state
                        performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void  qomx_CmpntInvalid_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
)
{
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ),
      "Entering Invalid State, nEvent = 0x%x", nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pCmpntCtx->eMainState   = QOMX_StateInvalid;
   pCmpntCtx->eOmxState    = OMX_StateInvalid;

   /**------------------------------------------------------------------------
      Transition all ports to a proper state to allow upcoming FreeBuffer cmd
      if the ports are created.
   -------------------------------------------------------------------------*/
   if ( NULL != pCmpntCtx->hPortCtnr )
   {
      qomx_CmpntInvalid_TransitionPortState( pCmpntCtx );
   }

   /**------------------------------------------------------------------------
      Notify MMI invalid state before callback to client
   -------------------------------------------------------------------------*/
   ( void )qomx_CmpntInvalid_NotifyDevice( pCmpntCtx );

   /**------------------------------------------------------------------------
      If invalid state transition is trigered by hardware error, report it
      to the client.
   -------------------------------------------------------------------------*/
   if( QOMX_EVENT_ERROR_FATAL_HARDWARE == nEvent )
   {
      ( void ) qomx_CmpntNotifyError(
                        & ( pCmpntCtx->commonRef ), OMX_ErrorHardware );

   }

   /**------------------------------------------------------------------------
      Callback to the application.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntNotifyError(
                        & ( pCmpntCtx->commonRef ), OMX_ErrorInvalidState );

   return;

} /* end of function qomx_CmpntInvalid_StateEntryHandler */

/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_NotifyDevice

         DESCRIPTION:
*//**                   This function is called to notify MMI the component
                        goes into invalid state to prepare for client's tear
                  down in invalid state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE     qomx_CmpntInvalid_NotifyDevice
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx
)
{
   OMX_U32              nStatus     = MMI_S_EFAIL;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntInvalid_NotifyDevice" );

   nStatus = pCommonRef->device.pfnCmd(
                              pCommonRef->hFd, MMI_CMD_ERROR_ABORT, NULL );

   if ( MMI_S_COMPLETE != nStatus )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "MMI_CMD_ERROR_ABORT returned failure status 0x%x",
                        nStatus );
   }

   return( OMX_ErrorNone );

} /* end of function qomx_CmpntInvalid_NotifyDevice */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_GetComponentVersion

         DESCRIPTION:
                        Refer to OMX_GetComponentVersion in OMX_Core.h
                        or the OMX IL specification for details on the
                        GetComponentVersion method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[out] pComponentName    - Refer OMX_Core.h / OMX IL spec.
            @param[out] pComponentVersion - Refer OMX_Core.h / OMX IL spec.
            @param[out] pSpecVersion      - Refer OMX_Core.h / OMX IL spec.
            @param[out] pComponentUUID    - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntInvalid_GetComponentVersion
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_OUT  OMX_STRING                 pComponentName,
   OMX_OUT  OMX_VERSIONTYPE           *pComponentVersion,
   OMX_OUT  OMX_VERSIONTYPE           *pSpecVersion,
   OMX_OUT  OMX_UUIDTYPE              *pComponentUUID
)
{
   QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntInvalid_GetComponentVersion" );

   return( OMX_ErrorInvalidState );

} /* end of function qomx_CmpntInvalid_GetComponentVersion */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_SendCommand

         DESCRIPTION:
*//**                   This function is called every time when Send command
                        is invoked in Executing state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  eCmd        - Command which is being invoked.
            @param[in]  nParam      - Parameter 1. Refer OMX Spec.
            @param[in]  pCmdData    - Command payload. Refer OMX Spec.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntInvalid_SendCommand
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE            eCmd,
   OMX_IN   OMX_U32                    nParam,
   OMX_IN   OMX_PTR                    pCmdData
)
{
   QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntInvalid_SendCommand, eCmd = 0x%x, nParam = 0x%x",
      eCmd, nParam );

   return( OMX_ErrorInvalidState );

} /* end of function qomx_CmpntInvalid_SendCommand */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_GetParameter

         DESCRIPTION:
                        Refer to OMX_GetParameter in OMX_Core.h
                        or the OMX IL specification for details on the
                        GetParameter method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nIndex      - Refer OMX_Core.h / OMX IL spec.
            @param[inout]
                        pCmpntParm  - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntInvalid_GetParameter
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE              nIndex,
   OMX_IN   OMX_PTR                    pCmpntParm
)
{
   QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntInvalid_GetParameter, nIndex = 0x%x",
      ( OMX_U32 ) nIndex );

   return( OMX_ErrorInvalidState );

} /* end of function qomx_CmpntInvalid_GetParameter */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_SetParameter

         DESCRIPTION:
                        Refer to OMX_SetParameter in OMX_Core.h
                        or the OMX IL specification for details on the
                        SetParameter method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nIndex      - Refer OMX_Core.h / OMX IL spec.
            @param[in]  pCmpntParm  - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntInvalid_SetParameter
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE              nIndex,
   OMX_OUT  OMX_PTR                    pCmpntParm
)
{
   QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntInvalid_SetParameter, nIndex = 0x%x",
      ( OMX_U32 ) nIndex );

   return( OMX_ErrorInvalidState );

} /* end of function qomx_CmpntInvalid_SetParameter */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_GetConfig

         DESCRIPTION:
                        Refer to OMX_GetConfig in OMX_Core.h
                        or the OMX IL specification for details on the
                        GetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nIndex      - Refer OMX_Core.h / OMX IL spec.
            @param[out] pCmpntCfg   - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntInvalid_GetConfig
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE              nIndex,
   OMX_OUT  OMX_PTR                    pCmpntCfg
)
{
   QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntInvalid_GetConfig, nIndex = 0x%x",
      ( OMX_U32 ) nIndex );

   return( OMX_ErrorInvalidState );

} /* end of function qomx_CmpntInvalid_GetConfig */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_SetConfig

         DESCRIPTION:
                        Refer to OMX_SetConfig in OMX_Core.h
                        or the OMX IL specification for details on the
                        SetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nIndex      - Refer OMX_Core.h / OMX IL spec.
            @param[in]  pCmpntCfg   - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntInvalid_SetConfig
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE              nIndex,
   OMX_IN   OMX_PTR                    pCmpntCfg
)
{
   QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntInvalid_SetConfig, nIndex = 0x%x",
      ( OMX_U32 ) nIndex );

   return( OMX_ErrorInvalidState );

} /* end of function qomx_CmpntInvalid_SetConfig */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_GetExtensionIndex

         DESCRIPTION:
                        Refer to OMX_GetExtensionIndex in OMX_Core.h
                        or the OMX IL specification for details on the
                        GetExtensionIndex method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  cParameterName - Refer OMX_Core.h / OMX IL spec.
            @param[out] pIndexType     - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntInvalid_GetExtensionIndex
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_STRING                 cParameterName,
   OMX_OUT  OMX_INDEXTYPE             *pIndexType
)
{
   QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntInvalid_GetExtensionIndex" );

   return( OMX_ErrorInvalidState );

} /* end of function qomx_CmpntInvalid_GetExtensionIndex */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_CmpntTunnelRequest

         DESCRIPTION:
                        Refer to OMX_ComponentTunnelRequest in OMX_Core.h
                        or the OMX IL specification for details on the
                        ComponentTunnelRequest method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nPort          - Refer OMX_Core.h / OMX IL spec.
            @param[in]  hTunneledComp  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nTunneledPort  - Refer OMX_Core.h / OMX IL spec.
            @param[out] pTunnelSetup   - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntInvalid_CmpntTunnelRequest
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN      OMX_U32                 nPort,
   OMX_IN      OMX_HANDLETYPE          hTunneledComp,
   OMX_IN      OMX_U32                 nTunneledPort,
   OMX_INOUT   OMX_TUNNELSETUPTYPE    *pTunnelSetup
)
{
   QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntInvalid_CmpntTunnelRequest, nPort = 0x%x,"
      "nTunneledPort = 0x%x", nPort, nTunneledPort );

   return( OMX_ErrorInvalidState );

} /* end of function qomx_CmpntInvalid_CmpntTunnelRequest */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_UseBuffer

         DESCRIPTION:
                        Refer to OMX_UseBuffer in OMX_Core.h
                        or the OMX IL specification for details on the
                        UseBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nPortIndex  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nSizeBytes  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  pBuffer     - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntInvalid_UseBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_OUT     OMX_BUFFERHEADERTYPE  **ppBufferHdr,
   OMX_IN      OMX_U32                 nPortIndex,
   OMX_IN      OMX_PTR                 pAppPrivate,
   OMX_IN      OMX_U32                 nSizeBytes,
   OMX_IN      OMX_U8                 *pBuffer
)
{
   QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ), "qomx_CmpntInvalid_UseBuffer"
      ", nPortIndex = 0x%x, nSizeBytes = %d", nPortIndex, nSizeBytes );

   return( OMX_ErrorInvalidState );

} /* end of function qomx_CmpntInvalid_UseBuffer */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_AllocateBuffer

         DESCRIPTION:
                        Refer to OMX_AllocateBuffer in OMX_Core.h
                        or the OMX IL specification for details on the
                        AllocateBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nPortIndex  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nSizeBytes  - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntInvalid_AllocateBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_OUT     OMX_BUFFERHEADERTYPE  **ppBufferHdr,
   OMX_IN      OMX_U32                 nPortIndex,
   OMX_IN      OMX_PTR                 pAppPrivate,
   OMX_IN      OMX_U32                 nSizeBytes
)
{
   QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntInvalid_AllocateBuffer, nPortIndex = 0x%x"
      " nSizeBytes = %d", nPortIndex, nSizeBytes );

   return( OMX_ErrorInvalidState );

} /* end of function qomx_CmpntInvalid_AllocateBuffer */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_EmptyThisBuffer

         DESCRIPTION:
                        Refer to OMX_EmptyThisBuffer in OMX_Core.h
                        or the OMX IL specification for details on the
                        EmptyThisBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntInvalid_EmptyThisBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBufferHdr
)
{
   QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntInvalid_EmptyThisBuffer" );

   return( OMX_ErrorInvalidState );

} /* end of function qomx_CmpntInvalid_EmptyThisBuffer */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_FillThisBuffer

         DESCRIPTION:
                        Refer to OMX_FillThisBuffer in OMX_Core.h
                        or the OMX IL specification for details on the
                        FillThisBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntInvalid_FillThisBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBufferHdr
)
{
   QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntInvalid_FillThisBuffer" );

   return( OMX_ErrorInvalidState );

} /* end of function qomx_CmpntInvalid_FillThisBuffer */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_UseEGLImage

         DESCRIPTION:
                        Refer to OMX_UseEGLImage in OMX_Core.h
                        or the OMX IL specification for details on the
                        UseEGLImage method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nPortIndex  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL spec.
            @param[out] eglImage    - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntInvalid_UseEGLImage
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_OUT  OMX_BUFFERHEADERTYPE     **ppBufferHdr,
   OMX_IN   OMX_U32                    nPortIndex,
   OMX_IN   OMX_PTR                    pAppPrivate,
   OMX_IN   void                      *eglImage
)
{
   QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntInvalid_UseEGLImage" );

   return( OMX_ErrorInvalidState );

} /* end of function qomx_CmpntInvalid_UseEGLImage */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_ComponentRoleEnum

         DESCRIPTION:
                        Refer to OMX_ComponentRoleEnum in OMX_Core.h
                        or the OMX IL specification for details on the
                        ComponentRoleEnum method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[out] cRole       - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nIndex      - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntInvalid_ComponentRoleEnum
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_OUT  OMX_U8                    *cRole,
   OMX_IN   OMX_U32                    nIndex
)
{
   QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntInvalid_ComponentRoleEnum" );

   return( OMX_ErrorInvalidState );

} /* end of function qomx_CmpntInvalid_ComponentRoleEnum */


/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_SetCallbacks

         DESCRIPTION:
                        Refer to OMX_SetCallBacks in OMX_Core.h
                        or the OMX IL specification for details on the
                        SetCallBacks method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  pCallbacks  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  pAppData    - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntInvalid_SetCallbacks
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_CALLBACKTYPE          *pCallbacks,
   OMX_IN   OMX_PTR                    pAppData
)
{
   QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntInvalid_SetCallbacks" );

   return( OMX_ErrorInvalidState );

} /* end of function qomx_CmpntInvalid_SetCallbacks */

/*==========================================================================

         FUNCTION:      qomx_CmpntInvalid_TransitionPortState

         DESCRIPTION:
                        When component transitioned to InvalidState,
                        tranisition the port to a proper state in order to accept
                        upcoming FreeBuffer cmd from client.


@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Component state machine context.

**//*    RETURN VALUE:
*//**       @return     None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void qomx_CmpntInvalid_TransitionPortState
(
   OMX_IN   QOMX_CmpntCtxType *pCmpntCtx
)
{
   QOMX_PortContainerType     *pPortCtnr = ( QOMX_PortContainerType * ) pCmpntCtx->hPortCtnr;
   OMX_U32                    i;
   QOMX_PortContextType       *pPortCtx;
   QOMX_PortStateType         eCurrState;


   for( i = 0; i < pPortCtnr->nNumPorts; i++ )
   {
      pPortCtx = & ( pPortCtnr->paPortCtx[ i ] );

      eCurrState = pPortCtx->eState;

      switch ( pPortCtx->eState )
      {
         case QOMX_StatePortEnabledStopping:
         case QOMX_StatePortEnabledRunning:
         case QOMX_StatePortEnabledPopulated:
         {
            ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                                 pPortCtx, QOMX_StatePortEnabledDepopulating, 0 );
         }
         break;

         default:
         break;
      }

      QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
            "Transitioned port state in Cmpnt InvalidState PortIndex 0x%x", pPortCtx->portDef.nPortIndex );
      QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
            "Transitioned port state from 0x%x to 0x%x", eCurrState, pPortCtx->eState );
   }

} /* end of function qomx_CmpntInvalid_TransitionPortState */
