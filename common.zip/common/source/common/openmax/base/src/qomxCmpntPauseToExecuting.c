/*========================================================================

*//** @file qomxCmpntPauseToExecuting.c 

@par FILE SERVICES:       
      Component PauseToExecuting State Implementation File.

      This file implements all the methods which are applicable for
      OMX_StatePauseToExecuting state.
      
      Main functions is Send Command. Functions which are common for all
      states are implemented in the common functions table.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2018 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCmpntPauseToExecuting.c#1 $

when       who     what, where, why
--------   ---     -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
08/08/11   dm     Hardware critical error handling.
07/22/10   zm      Add component handle in each base class logging message.
06/29/10   zm	   Allow ETB/FTB calls in PauseToExecuting state.
06/10/10   dm      Added return type in event handler.
03/26/10   spl    Modified to support interop-profile.
01/20/10   dm      Fix resource loss bug.
10/09/09   dm      Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxCmpntCommon.h"
#include "qomxPortUtils.h"

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 * 
 * Forward declaration for the functions statically defined in this file.
 * 
 */

static void    qomx_CmpntPauseToExecuting_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
);

static void    qomx_CmpntPauseToExecuting_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
   
);

static OMX_ERRORTYPE    qomx_CmpntPauseToExecuting_SendCommand
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE         eCmd,
   OMX_IN   OMX_U32                 nParam,
   OMX_IN   OMX_PTR                 pCmdData
);

static OMX_ERRORTYPE    qomx_CmpntPauseToExecuting_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
);

static void    qomx_CmpntPauseToExecuting_Resume
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);

static void    qomx_CmpntPauseToExecuting_ResumeResp
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nStatus
);

static void    qomx_CmpntPauseToExecuting_ResourcesLost
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_CmpntPauseToExecuting_LoadStateTable

         DESCRIPTION:
                        This function will load the component state table
                        supported by the PauseToExecuting state in the object
                        of state table being passed.
            
@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable - Pointer to the state primitive table
                                   object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntPauseToExecuting_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      component is in QOMX_StatePauseToExecuting state. NULL entry indicates
      that the specific function call is not allowed in this state, thus
      component API should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/
   pStTable->GetComponentVersion    = qomx_CmpntCommon_GetComponentVersion;
   pStTable->SendCommand            = qomx_CmpntPauseToExecuting_SendCommand;
   pStTable->GetParameter           = qomx_CmpntCommon_GetParameter;
   pStTable->SetParameter           = qomx_CmpntCommon_SetParameter;
   pStTable->GetConfig              = qomx_CmpntCommon_GetConfig;
   pStTable->SetConfig              = qomx_CmpntCommon_SetConfig;
   pStTable->GetExtensionIndex      = qomx_CmpntCommon_GetExtensionIndex;
   pStTable->GetState               = qomx_CmpntCommon_GetState;
   pStTable->ComponentTunnelRequest = qomx_CmpntCommon_TunnelRequest;
   pStTable->UseBuffer              = qomx_CmpntCommon_UseBuffer;
   pStTable->AllocateBuffer         = qomx_CmpntCommon_AllocateBuffer;
   pStTable->FreeBuffer             = qomx_CmpntCommon_FreeBuffer;
   pStTable->EmptyThisBuffer        = qomx_CmpntCommon_EmptyThisBuffer;
   pStTable->FillThisBuffer         = qomx_CmpntCommon_FillThisBuffer;
   pStTable->SetCallbacks           = NULL;
   pStTable->ComponentDeInit        = qomx_CmpntCommon_ComponentDeInit;
   pStTable->UseEGLImage            = NULL;
   pStTable->ComponentRoleEnum      = qomx_CmpntCommon_ComponentRoleEnum;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler
                        = qomx_CmpntPauseToExecuting_DeviceEventHandler;
   
   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler
                        = qomx_CmpntPauseToExecuting_StateEntryHandler;
   pStTable->pfnExitHandler
                        = qomx_CmpntPauseToExecuting_StateExitHandler;

   return;

} /* end of function qomx_CmpntPauseToExecuting_LoadStateTable */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntPauseToExecuting_StateEntryHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StatePauseToExecuting is entered. Entry into the
                        state performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntPauseToExecuting_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Entering PauseToExecuting State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Entering PauseToExecuting State, nEvent = 0x%x", nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pCmpntCtx->eMainState = QOMX_StatePauseToExecuting;

   /**------------------------------------------------------------------------
      Command device to resume.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntPauseToExecuting_Resume( pCmpntCtx );

   return;

} /* end of function qomx_CmpntPauseToExecuting_StateEntryHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntPauseToExecuting_StateExitHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StatePauseToExecuting is exited. Exit from this
                        state performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntPauseToExecuting_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent 
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Exiting PauseToExecuting State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Exiting PauseToExecuting State, nEvent = 0x%x", nEvent );

   return;   

} /* end of function qomx_CmpntPauseToExecuting_StateExitHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntPauseToExecuting_SendCommand

         DESCRIPTION:
*//**                   This function is called every time when Send command
                        is invoked in PauseToExecuting state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.
            @param[in]  eCmd        - Command which is being invoked.
            @param[in]  nParam      - Parameter 1. Refer OMX Spec.
            @param[in]  pCmdData    - Command payload. Refer OMX Spec.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntPauseToExecuting_SendCommand 
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE            eCmd,
   OMX_IN   OMX_U32                    nParam,
   OMX_IN   OMX_PTR                    pCmdData
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntPauseToExecuting_SendCommand,"
      " eCmd = 0x%x, nParam = 0x%x", eCmd, nParam );

   /**------------------------------------------------------------------------
      Check the command type.
   -------------------------------------------------------------------------*/
   switch( eCmd )
   {
      /**--------------------------------------------------------------------- 
         Port specific commands which are allowed in this state.
      ----------------------------------------------------------------------*/
      case OMX_CommandFlush:
         {
            QOMX_MSG_L_MED( pCommonRef, "Flush Port = 0x%x", nParam );

            /**---------------------------------------------------------------
               Send port flush request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortFlush( pCmpntCtx->hPortCtnr, nParam );

         }

         break;

      default:
         {
            /**---------------------------------------------------------------
               Call common routine to handle rest of the commands.
            ----------------------------------------------------------------*/
            eRetVal = qomx_CmpntCommon_SendCommand(
                                          pCmpntCtx, eCmd, nParam, pCmdData );

         }

         break;

   } /* end of switch( eCmd ) */

   return( eRetVal );

} /* end  of function qomx_CmpntPauseToExecuting_SendCommand */


/*==========================================================================

         FUNCTION:      qomx_CmpntPauseToExecuting_DeviceEventHandler

         DESCRIPTION:
*//**                   This function is called when the device want to 
                        communicate with the component when it is in 
                        PauseToExecuting state.
         
@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx      -  Context structure pointer.
            @param[in]  nEventCode     -  Event code.
            @param[in]  nEventStatus   -  Event status.
            @param[in]  nParamSize     -  Payload length.
            @param[in]  pParam         -  Payload corresponding to this event.

*//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None
                                                                        
===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntPauseToExecuting_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntPauseToExecuting_DeviceEventHandler"
      ", nEventCode = 0x%x, nEventStatus = 0x%x", nEventCode, nEventStatus );

   /**------------------------------------------------------------------------
      Finish moving to Executing state on successful pause response.
   -------------------------------------------------------------------------*/
   if( MMI_RESP_RESUME == nEventCode ) 
   {
      QOMX_MSG_L_HIGH( pCommonRef, "MMI_RESP_RESUME event." );

      /**---------------------------------------------------------------------
         Process the pause command status now.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntPauseToExecuting_ResumeResp( 
                                                pCmpntCtx, nEventStatus );

   }
   else if( MMI_EVT_RESOURCES_LOST == nEventCode )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "MMI_EVT_RESOURCES_LOST event." );

      /**---------------------------------------------------------------------
         Set resources lost status to permanent loss. This status need to 
         be overridden if resource loss message shows as temporary.
      ----------------------------------------------------------------------*/
      pCmpntCtx->eResState = QOMX_RESOURCES_PERMANENTLY_LOST;

      /**---------------------------------------------------------------------
         Validate event handler parameters.
      ----------------------------------------------------------------------*/
      if( ( NULL != pParam )
         && ( nParamSize == sizeof( MMI_ResourceLostMsgType ) ) )
      {
         MMI_ResourceLostMsgType *pResLostMsg
                     = ( MMI_ResourceLostMsgType * ) pParam;
         /*-----------------------------------------------------------------*/         

         /**------------------------------------------------------------------
            Set resource lost state to temporary if it is suspendable,
            and suspension policy allows it.
         -------------------------------------------------------------------*/
         if( ( OMX_TRUE == pResLostMsg->bSuspendable )
            && ( OMX_SuspensionEnabled == pCmpntCtx->ePolicy ) )
         {
            QOMX_MSG_L_HIGH( pCommonRef, "Temporary resource loss." );

            pCmpntCtx->eResState = QOMX_RESOURCES_TEMPORARILY_LOST;

         }

      }
      else
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Invalid resource lost params."
            " Assuming permanent loss." );

      }

      /**---------------------------------------------------------------------
         Process resources lost event now.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntPauseToExecuting_ResourcesLost( pCmpntCtx );

   }
   else
   {
      /**---------------------------------------------------------------------
         Pass this to common device handler routine.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntCommon_DeviceEventHandler( pCmpntCtx, 
                              nEventCode, nEventStatus, nParamSize, pParam );

   }

   return( eRetVal );

} /* end of function qomx_CmpntPauseToExecuting_DeviceEventHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntPauseToExecuting_Resume

         DESCRIPTION:
*//**                   This function will resume the device and move
                        component to Executing state based on the device
                        return code.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntPauseToExecuting_Resume
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   OMX_U32              nStatus     = MMI_S_EFAIL;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntPauseToExecuting_Resume" );

   /**------------------------------------------------------------------------
      Send resume command to MMI device.
   -------------------------------------------------------------------------*/
   nStatus = pCommonRef->device.pfnCmd( 
                                 pCommonRef->hFd, MMI_CMD_RESUME, NULL );

   QOMX_MSG_L_HIGH( pCommonRef, "MMI_CMD_RESUME status = 0x%x", nStatus );

   /**------------------------------------------------------------------------
      If device is processing the command asynchronously, wait for the
      callback, otherwise process the response.
   -------------------------------------------------------------------------*/
   if( MMI_S_PENDING != nStatus )
   {
      /**---------------------------------------------------------------------
         Process the pause command status now.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntPauseToExecuting_ResumeResp( pCmpntCtx, nStatus );

   }

   return;

} /* end of function qomx_CmpntPauseToExecuting_Resume */


/*==========================================================================

         FUNCTION:      qomx_CmpntPauseToExecuting_ResumeResp

         DESCRIPTION:
*//**                   This function processes the resume command response
                        received from the device.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   -  Context structure pointer.
            @param[in]  nStatus     -  Event / Response status.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
                                                                        
===========================================================================*/
static void    qomx_CmpntPauseToExecuting_ResumeResp
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nStatus
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_CmpntPauseToExecuting_ResumeResp" );

   if( MMI_S_COMPLETE == nStatus )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Resume successful." );

      /**---------------------------------------------------------------------
         Resume is successful. Move to destination state QOMX_StateExecuting.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, "Move to QOMX_StateExecuting." );

      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                                    QOMX_StateExecuting, QOMX_EVENT_UNKNOWN );

      /**---------------------------------------------------------------------
         Send state transition success callback.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
            "Send OMX_StateExecuting transition callback." );

      ( void ) qomx_CmpntCommon_StateTransitionCallback( 
                                    pCmpntCtx, OMX_StateExecuting );

   }
   else if( ( MMI_S_EFATAL == nStatus )
            || ( MMI_S_EFATALHW == nStatus ) )
   {
      QOMX_MSG_L_ERROR( 
         pCommonRef, "Critical error = %d during executing.", nStatus );

      /**---------------------------------------------------------------------
         Irrecoverable error. Move component to Invalid state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                  QOMX_StateInvalid, qomx_GetQOMXBaseEventCode( nStatus ) );

   }
   else
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Unexpected status in resume response,"
         " nStatus = 0x%x, Transition back to Pause state.", nStatus );

      /**---------------------------------------------------------------------
         Move back the component to Pause state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                                    QOMX_StatePause, QOMX_EVENT_UNKNOWN );

      /**---------------------------------------------------------------------
         Report hardware error for this command failure.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
         "Send OMX_ErrorHardware notification." );

      ( void ) qomx_CmpntNotifyError( 
                           & ( pCmpntCtx->commonRef ), OMX_ErrorHardware );

   }

   return;

} /* end of function qomx_CmpntPauseToExecuting_ResumeResp */


/*==========================================================================

         FUNCTION:      qomx_CmpntPauseToExecuting_ResourcesLost

         DESCRIPTION:
                        This function will process resources lost event from
                        device.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.

**//*    RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntPauseToExecuting_ResourcesLost
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_CmpntPauseToExecuting_ResourcesLost" );

   /**------------------------------------------------------------------------
      If the resources loss is temporary and it is resumable from the point
      it lost, move component to Pause state.
      Else start deinitialization process by moving component to Idle ->
      Loaded state.
   -------------------------------------------------------------------------*/
   if( QOMX_RESOURCES_TEMPORARILY_LOST == pCmpntCtx->eResState )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Pausing component now." );

      /**---------------------------------------------------------------------
         Set suspension status.
      ----------------------------------------------------------------------*/
      pCmpntCtx->eSuspension = OMX_Suspended;

      /**---------------------------------------------------------------------
         Device pauses itself while reporting resource lost. Move to Pause
         state now.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, "Move to QOMX_StatePause." );

      ( void ) qomx_CmpntCommon_DoStateTransition(
                  pCmpntCtx, QOMX_StatePause, QOMX_EVENT_UNKNOWN );

      /**---------------------------------------------------------------------
         Report suspension status to IL client.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
         "Send OMX_ErrorComponentSuspended notification." );

      ( void ) qomx_CmpntNotifyError( 
                  & ( pCmpntCtx->commonRef ), OMX_ErrorComponentSuspended );

   }
   else
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Stopping component now." );

      /**---------------------------------------------------------------------
         Report executing command failure.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
         "Send OMX_ErrorHardware notification." );

      ( void ) qomx_CmpntNotifyError( 
                  & ( pCmpntCtx->commonRef ), OMX_ErrorHardware );

      /**---------------------------------------------------------------------
         Report resources preempted error to IL client.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
         "Send OMX_ErrorResourcesPreempted notification." );

      ( void ) qomx_CmpntNotifyError( 
                  & ( pCmpntCtx->commonRef ), OMX_ErrorResourcesPreempted );

      /**---------------------------------------------------------------------
         Move to transition state ExecutingToIdle which will stop the 
         device.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
         "Move to QOMX_StateExecutingToIdle." );

      ( void ) qomx_CmpntCommon_DoStateTransition( 
                  pCmpntCtx, QOMX_StateExecutingToIdle, QOMX_EVENT_UNKNOWN );

   }

   return;

} /* end of function qomx_CmpntPauseToExecuting_ResourcesLost */
