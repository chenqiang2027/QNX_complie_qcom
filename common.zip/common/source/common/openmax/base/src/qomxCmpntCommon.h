#ifndef __QOMX_CMPNT_COMMON_H__
#define __QOMX_CMPNT_COMMON_H__

/*========================================================================

*//** @file qomxCmpntCommon.h 

@par FILE SERVICES:       
      Component Common Header File.

      This file contains the state machine omx il function handlers which are 
      common to all states being implemented. OMX privitive like 
      OMX_GetComponentVersion etc. does not change from state to state.
      
      Such states are captured in this header file alongwith the corresponding
      implementations.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2010 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCmpntCommon.h#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
06/10/10   dm     Added return type in event handler.
10/29/09   dm     Allow tunneling on disabled ports in any OMX state.
06/16/09   dm     Initial Creation.

========================================================================== */

/*======================================================================== 
 
                     INCLUDE FILES FOR MODULE 
 
========================================================================== */
#include "qomxCommon.h"
#include "qomxCmpntContext.h"
#include "qomxCmpntStateTable.h"

/*======================================================================== 

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Functions
** ----------------------------------------------------------------------- */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_GetComponentVersion

         DESCRIPTION:
                        Refer to OMX_GetComponentVersion in OMX_Core.h or the
                        OMX IL specification for details on the 
                        GetComponentVersion method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[out] pComponentName - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[out] pComponentVersion
                                       - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[out] pSpecVersion   - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[out] pComponentUUID - Refer OMX_Core.h or OMX IL
                                         specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_GetComponentVersion
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_OUT  OMX_STRING              pComponentName,
   OMX_OUT  OMX_VERSIONTYPE        *pComponentVersion,
   OMX_OUT  OMX_VERSIONTYPE        *pSpecVersion,
   OMX_OUT  OMX_UUIDTYPE           *pComponentUUID
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_GetExtensionIndex

         DESCRIPTION:
                        Refer to OMX_GetExtensionIndex in OMX_Core.h or the
                        OMX IL specification for details on the 
                        GetExtensionIndex method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  cParameterName - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[out] pIndexType     - Refer OMX_Core.h or OMX IL
                                         specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_GetExtensionIndex
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_STRING              cParameterName,
   OMX_OUT  OMX_INDEXTYPE          *pIndexType
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_ComponentRoleEnum

         DESCRIPTION:
                        Refer to OMX_ComponentRoleEnum in OMX_Core.h or the
                        OMX IL specification for details on the 
                        ComponentRoleEnum method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[out] cRole          - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[in]  nIndex         - Refer OMX_Core.h or OMX IL
                                         specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_ComponentRoleEnum
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
	OMX_OUT  OMX_U8                 *cRole,
	OMX_IN   OMX_U32                 nIndex
);


/*==========================================================================

         FUNCTION:      qomx_CmpntGetParameter

         DESCRIPTION:
                        Refer to OMX_GetParameter in OMX_Core.h or the
                        OMX IL specification for details on the 
                        GetParameter method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  nIndex         - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[out] pCmpntParm     - Refer OMX_Core.h or OMX IL
                                         specification.
**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_GetParameter
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE           nIndex,
   OMX_OUT  OMX_PTR                 pCmpntParm
);


/*==========================================================================

         FUNCTION:      qomx_CmpntSetParameter

         DESCRIPTION:
                        Refer to OMX_SetParameter in OMX_Core.h or the
                        OMX IL specification for details on the 
                        SetParameter method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  nIndex         - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[in]  pCmpntParm     - Refer OMX_Core.h or OMX IL
                                         specification.
**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_SetParameter
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE           nIndex,
   OMX_IN   OMX_PTR                 pCmpntParm
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_GetConfig

         DESCRIPTION:
                        Refer to OMX_GetConfig in OMX_Core.h or the
                        OMX IL specification for details on the 
                        GetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  nIndex         - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[out] pCmpntCfg      - Refer OMX_Core.h or OMX IL
                                         specification.
**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_GetConfig
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE           nIndex, 
   OMX_OUT  OMX_PTR                 pCmpntCfg
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_SetConfig

         DESCRIPTION:
                        Refer to OMX_SetConfig in OMX_Core.h or the
                        OMX IL specification for details on the 
                        SetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  nIndex         - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[in]  pCmpntCfg      - Refer OMX_Core.h or OMX IL
                                         specification.
**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_SetConfig
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE           nIndex, 
   OMX_IN   OMX_PTR                 pCmpntCfg
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_GetState

         DESCRIPTION:
                        Refer to OMX_GetState in OMX_Core.h or the
                        OMX IL specification for details on the 
                        GetState method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[out] pState         - Refer OMX_Core.h or OMX IL
                                         specification.
**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_GetState
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_OUT  OMX_STATETYPE          *pState
);

/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_UseBuffer

         DESCRIPTION:
                        Refer to OMX_UseBuffer in OMX_Core.h or the
                        OMX IL specification for details on the 
                        UseBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL specification.
            @param[in]  nPortIndex  - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL specification.
            @param[in]  nSizeBytes  - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pBuffer     - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_UseBuffer
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_OUT  OMX_BUFFERHEADERTYPE  **ppBufferHdr,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_IN   OMX_PTR                 pAppPrivate,
   OMX_IN   OMX_U32                 nSizeBytes,
   OMX_IN   OMX_U8                 *pBuffer
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_AllocateBuffer

         DESCRIPTION:
                        Refer to OMX_AllocateBuffer in OMX_Core.h or the
                        OMX IL specification for details on the 
                        AllocateBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL specification.
            @param[in]  nPortIndex  - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL specification.
            @param[in]  nSizeBytes  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_AllocateBuffer
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_OUT  OMX_BUFFERHEADERTYPE  **ppBufferHdr,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_IN   OMX_PTR                 pAppPrivate,
   OMX_IN   OMX_U32                 nSizeBytes
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_FreeBuffer

         DESCRIPTION:
                        Refer to OMX_FreeBuffer in OMX_Core.h or the
                        OMX IL specification for details on the 
                        FreeBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.
            @param[in]  nPortIndex  - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_FreeBuffer
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_EmptyThisBuffer

         DESCRIPTION:
                        Refer to OMX_EmptyThisBuffer in OMX_Core.h or the
                        OMX IL specification for details on the 
                        EmptyThisBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_EmptyThisBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBufferHdr
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_FillThisBuffer

         DESCRIPTION:
                        Refer to OMX_FillThisBuffer in OMX_Core.h or the
                        OMX IL specification for details on the 
                        FillThisBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_FillThisBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBufferHdr
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_ComponentDeInit

         DESCRIPTION:
                        Refer to OMX_ComponentDeInit in OMX_Core.h or the
                        OMX IL specification for details on the 
                        ComponentDeInit method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_ComponentDeInit
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_DeviceEventHandler

         DESCRIPTION:
                        Refer to OMX_ComponentDeInit in OMX_Core.h or the
                        OMX IL specification for details on the 
                        ComponentDeInit method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.
            @param [in] nEventCode  - Unique event code which came from
                                      the device.
            @param [in] nEventStatus- Status of the event.
            @param [in] nParamSize  - Size in bytes for the event related
                                      data which is pointed by the payload.
            @param [in] pParam      - Event related payload.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_DeviceEventHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_DoStateTransition

         DESCRIPTION:
                        This is a generic state transition routine which does
                        the common transition logic.
            
                        1) State management like calling entry and exit
                           functions.
                        2) Doing the actual transition.
                        3) Logging the transiton.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  eToState       - To state where the component state
                                         should transition to.
            @param[in]  nEvent         - Uniqueue event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntCommon_DoStateTransition
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   QOMX_CmpntStateType     eToState,
   OMX_IN   OMX_U8                  nEvent
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_StateTransitionCallback

         DESCRIPTION:
                        This function is called every time when a component
                        state transition callback is to be sent to the 
                        application.
            
@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  eOmxState      - OMX state where component just
                                         transitioned.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntCommon_StateTransitionCallback
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_STATETYPE           eOmxState
);


/*==========================================================================
     
         FUNCTION:      qomx_CmpntCommon_CommandStateSet

         DESCRIPTION:
*//**                   This function is called from the send command
                        functions which are implemented inside QOMX states
                        implementation files. This function executes common
                        state set methods which applies to all the states
                        in the same manner.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.
            @param[in]  nParam      - Parameter 1. Refer OMX Spec.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void     qomx_CmpntCommon_CommandStateSet
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_U32                    nParam
);


/*==========================================================================
     
         FUNCTION:      qomx_CmpntCommon_SendCommand

         DESCRIPTION:
*//**                   This function is called from the send command
                        functions which are implemented inside QOMX states
                        implementation files. This function should be called
                        only when command has to be executed in a common way.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.
            @param[in]  eCmd        - Command which is being invoked.
            @param[in]  nParam      - Parameter 1. Refer OMX Spec.
            @param[in]  pCmdData    - Command payload. Refer OMX Spec.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE     qomx_CmpntCommon_SendCommand
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE            eCmd,
   OMX_IN   OMX_U32                    nParam,
   OMX_IN   OMX_PTR                    pCmdData
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_TunnelRequest

         DESCRIPTION:
                        Refer to OMX_ComponentTunnelRequest in OMX_Core.h
                        or the OMX IL specification for details on the 
                        ComponentTunnelRequest method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  nPort          - Refer OMX_Core.h / OMX IL spec.
            @param[in]  hTunneledComp  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nTunneledPort  - Refer OMX_Core.h / OMX IL spec.
            @param[out] pTunnelSetup   - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_CmpntCommon_TunnelRequest
(
   OMX_IN      QOMX_CmpntCtxType   *pCmpntCtx,
   OMX_IN      OMX_U32              nPort,
   OMX_IN      OMX_HANDLETYPE       hTunneledComp,
   OMX_IN      OMX_U32              nTunneledPort,
   OMX_INOUT   OMX_TUNNELSETUPTYPE *pTunnelSetup
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_LoadStateTables

         DESCRIPTION:
                        This function will load all the component state tables
                        in the array of state primitive tables being passed.
                        Memory for this array is pre-allocated in component
                        initialization.
            
@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  paStTable      - Pointer to the base of array of state
                                         primitive table objects.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntCommon_LoadStateTables
(
   OMX_IN   QOMX_CmpntStateTableType     *paStTable
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_GetStateTable

         DESCRIPTION:
                        This function will return a component state machine
                        function table corresponding the QOMX state passed
                        as the parameter.
            
@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  eState         - QOMX State enumeration.

**//*     RETURN VALUE:
*//**       @return     Pointer to the state primitive table as appripriate.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
QOMX_CmpntStateTableType*  qomx_CmpntCommon_GetStateTable
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   QOMX_CmpntStateType     eState
);


#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */

#endif /* end of macro __QOMX_CMPNT_COMMON_H__ */
