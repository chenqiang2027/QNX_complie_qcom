/*========================================================================

*//** @file qomxPortUtils.c 

@par FILE SERVICES:       
      Port Interface Utility Methods File.
      
      This file contains the port interfaces which are used by component
      to pass port specific OMX calls to port state handler methods.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights 
    Reserved. QUALCOMM Proprietary. Export of this technology or software is 
    regulated by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxPortUtils.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
06/22/16   am     Fix compiler warnings for 64 bit OS environment.
03/13/14   rs     Add Timestamp values to debug logs for buffer operations
02/07/14   rs     Fix buffers with client value in ETB/FTB debug logs
12/13/13   rz     Send MMI handle for vendor-tunneling MarkBuffer and fix MarkBuffer
11/07/13   am     Fix mark buffer implementation.
09/30/13   am     Add msg for buffers tracking.
08/26/13   yzgao  Fix the wrong param in error msg
08/08/11   dm     Hardware critical error handling.
03/07/11   yt     Add cleanup mechanism for non-freed buffers during deinit.
11/22/10   zm     Use new QOMX_CMPNT_MALLOC and QOMX_CMPNT_FREEIF macros.
11/08/10   zm     Set vendor-tunneled port state to Populated after load
                  resource command succeeds, only if the port is enabled.
09/02/10   zm     Fix Klocwork errors.
08/28/10   zm     Added support for vendor tunneling.
07/22/10   zm     Add component handle/port index in base class logging.
07/15/10   yt     Init tunneling race condition flags.
06/10/10   dm     Added return type in event handler.
03/26/10   spl    Modified to support interop-profile.
11/25/09   dm     Corrected auto port detection behavior.
10/19/09   dm     Port state split.
08/11/09   dm     Handle zero buffer requirement for auto detect mode.
08/06/09   dm     Added setparameter checks for states.
07/28/09   dm     Refined setparameter handling.
07/21/09   dm     Added auto port detection event handling.
07/21/09   dm     Handled buffer supplier settings.
06/16/09   dm     Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxPortCommon.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 * 
 * Forward declaration for the functions defined statically in this file.
 * 
 */

static OMX_ERRORTYPE    qomx_PortDomainInit
(
   OMX_IN   QOMX_CmpntConfig       *pConfig,
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *paDomainCtx,
   OMX_IN   OMX_PORTDOMAINTYPE      eDomain
);

static OMX_ERRORTYPE    qomx_PortGroupInit
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *paGroupCtx,
   OMX_IN   QOMX_PortConfig        *pPortConfig,
   OMX_IN   OMX_DIRTYPE             eDir,
   OMX_IN   OMX_PORTDOMAINTYPE      eDomain
);

static OMX_ERRORTYPE    qomx_ValidateILPortConfig
(
   OMX_IN   QOMX_CommonRefType     *pCommonRef,
   OMX_IN   QOMX_CmpntConfig       *pConfig
);


/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_PortContainer_GetHandle

         DESCRIPTION:
                        This function is used to get port context handle for a
                        component. This function allocates and initializes an
                        array of input and output port based on configuration
                        described by the IL client.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pConfig     - Pointer to the object of IL component
                                      configuration.
            @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[out] pHPortCtnr  - Pointer to an object of OMX_HANDLETYPE
                                      type which will be assigned handle to
                                      the port container on successful
                                      return.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortContainer_GetHandle
(
   OMX_IN   QOMX_CmpntConfig    *pConfig,
   OMX_IN   QOMX_CommonRefType  *pCommonRef,
   OMX_OUT  OMX_HANDLETYPE      *pHPortCtnr
)
{
   OMX_ERRORTYPE              eRetVal     = OMX_ErrorNone;
   QOMX_PortContainerType    *pPortCtnr   = NULL;
   QOMX_PortContextType      *paPortCtx   = NULL;
   OMX_U8                    *pAllocBuf   = NULL;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortContainer_GetHandle" );

   /**------------------------------------------------------------------------
      IL config validation.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_ValidateILPortConfig( pCommonRef, pConfig );

   /**------------------------------------------------------------------------
      If IL Port Configuration validation is successful, create ports.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      OMX_U32  nTotalPorts = 0;
      OMX_U32  nAllocSize;
      OMX_U32  nPortCtnrSize;
      OMX_U32  nPortCtxSize;
      OMX_U32  nStTableSize;
      /*--------------------------------------------------------------------*/

      QOMX_MSG_L_HIGH( pCommonRef, "Port config validation success." );

      /**---------------------------------------------------------------------
         Get total of all audio, video, image, and other ports.
      ----------------------------------------------------------------------*/
      if( OMX_TRUE == pConfig->audioDomain.bConfigSet )
      {
         nTotalPorts += ( OMX_U32 ) pConfig->audioDomain.nNumInputPorts;
         nTotalPorts += ( OMX_U32 ) pConfig->audioDomain.nNumOutputPorts;

      }

      if( OMX_TRUE == pConfig->videoDomain.bConfigSet )
      {
         nTotalPorts += ( OMX_U32 ) pConfig->videoDomain.nNumInputPorts;
         nTotalPorts += ( OMX_U32 ) pConfig->videoDomain.nNumOutputPorts;

      }

      if( OMX_TRUE == pConfig->imageDomain.bConfigSet )
      {
         nTotalPorts += ( OMX_U32 ) pConfig->imageDomain.nNumInputPorts;
         nTotalPorts += ( OMX_U32 ) pConfig->imageDomain.nNumOutputPorts;

      }

      if( OMX_TRUE == pConfig->otherDomain.bConfigSet )
      {
         nTotalPorts += ( OMX_U32 ) pConfig->otherDomain.nNumInputPorts;
         nTotalPorts += ( OMX_U32 ) pConfig->otherDomain.nNumOutputPorts;

      }


      /**---------------------------------------------------------------------
         Calculate the total size which need to be allocated for port context
         handles + container handle.
      ----------------------------------------------------------------------*/
      nPortCtnrSize  = ( OMX_U32 ) sizeof( QOMX_PortContainerType );

      nPortCtxSize   = ( OMX_U32 ) sizeof( QOMX_PortContextType );
      nPortCtxSize  *= nTotalPorts;

      nStTableSize   = ( OMX_U32 ) sizeof( QOMX_PortStateTableType );
      nStTableSize  *= QOMX_StatePortMax;
      
      nAllocSize     = ( nPortCtnrSize + nPortCtxSize + nStTableSize );

      /**---------------------------------------------------------------------
         Allocate memory block.
      ----------------------------------------------------------------------*/
      pAllocBuf = ( OMX_U8 * ) QOMX_CMPNT_MALLOC( pCommonRef->pfnMalloc, 
                                          pCommonRef->hHeap, nAllocSize );

      if( NULL == pAllocBuf )
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Insufficient memory." );

         /**------------------------------------------------------------------
            Insufficient memory, return insufficient resources error.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorInsufficientResources;

      }
      else
      {
         QOMX_PortStateTableType   *pStTableBase;
         /*-----------------------------------------------------------------*/

         /**------------------------------------------------------------------
            Initialize allocated memory area with 0.
         -------------------------------------------------------------------*/
         QOMX_CMPNT_MEM_SET( pAllocBuf, 0, nAllocSize );

         /**------------------------------------------------------------------
            Get port container address.
         -------------------------------------------------------------------*/
         pPortCtnr = ( QOMX_PortContainerType * ) pAllocBuf;

         /**------------------------------------------------------------------
            Get base address of state primitive table array and load the 
            state tables.
         -------------------------------------------------------------------*/
         pStTableBase = ( QOMX_PortStateTableType * ) (
                                             pAllocBuf + nPortCtnrSize );

         ( void ) qomx_PortCommon_LoadStateTables( pStTableBase );

         /**------------------------------------------------------------------
            Get port contexts array start address.
         -------------------------------------------------------------------*/
         paPortCtx = ( QOMX_PortContextType * ) (
                                 pAllocBuf + nPortCtnrSize + nStTableSize );

         /**------------------------------------------------------------------
            Fill container data.
         -------------------------------------------------------------------*/
         pPortCtnr->paPortCtx    = paPortCtx;
         pPortCtnr->nNumPorts    = nTotalPorts;
         pPortCtnr->pCommonRef   = pCommonRef;
         pPortCtnr->hStateTables = ( OMX_HANDLETYPE ) pStTableBase;

      }

   }

   /**------------------------------------------------------------------------
      If memory is successfully allocated, initialize port contexts.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_MSG_L_MED( pCommonRef, "Memory initialization successful." );

      /**---------------------------------------------------------------------
         If audio port configuration is set, initialize audio ports.
      ----------------------------------------------------------------------*/
      if( OMX_TRUE == pConfig->audioDomain.bConfigSet )
      {
         QOMX_MSG_L_MED( pCommonRef, "Setting audio ports." );

         /**------------------------------------------------------------------
            Initialize audio domain ports.
         -------------------------------------------------------------------*/
         eRetVal = qomx_PortDomainInit( 
                        pConfig, pPortCtnr, paPortCtx, OMX_PortDomainAudio );

         /**------------------------------------------------------------------
               Move port array base to point to next set of ports.
         -------------------------------------------------------------------*/
         paPortCtx += ( pPortCtnr->audioDomain.nNumInputPorts );
         paPortCtx += ( pPortCtnr->audioDomain.nNumOutputPorts );

      }

      /**---------------------------------------------------------------------
         If video port configuration is set, initialize video ports.
      ----------------------------------------------------------------------*/
      if( ( OMX_ErrorNone == eRetVal )
         && ( OMX_TRUE == pConfig->videoDomain.bConfigSet ) )
      {
         QOMX_MSG_L_MED( pCommonRef, "Setting video ports." );

         /**------------------------------------------------------------------
            Initialize video domain ports.
         -------------------------------------------------------------------*/
         eRetVal = qomx_PortDomainInit(
                        pConfig, pPortCtnr, paPortCtx, OMX_PortDomainVideo );

         /**------------------------------------------------------------------
               Move port array base to point to next set of ports.
         -------------------------------------------------------------------*/
         paPortCtx += ( pPortCtnr->videoDomain.nNumInputPorts );
         paPortCtx += ( pPortCtnr->videoDomain.nNumOutputPorts );

      }

      /**---------------------------------------------------------------------
         If image port configuration is set, initialize image ports.
      ----------------------------------------------------------------------*/
      if( ( OMX_ErrorNone == eRetVal )
         && ( OMX_TRUE == pConfig->imageDomain.bConfigSet ) )
      {
         QOMX_MSG_L_MED( pCommonRef, "Setting image ports." );

         /**------------------------------------------------------------------
            Initialize video domain ports.
         -------------------------------------------------------------------*/
         eRetVal = qomx_PortDomainInit(
                        pConfig, pPortCtnr, paPortCtx, OMX_PortDomainImage );

         /**------------------------------------------------------------------
               Move port array base to point to next set of ports.
         -------------------------------------------------------------------*/
         paPortCtx += ( pPortCtnr->imageDomain.nNumInputPorts );
         paPortCtx += ( pPortCtnr->imageDomain.nNumOutputPorts );

      }

      /**---------------------------------------------------------------------
         If other port configuration is set, initialize other ports.
      ----------------------------------------------------------------------*/
      if( ( OMX_ErrorNone == eRetVal )
         && ( OMX_TRUE == pConfig->otherDomain.bConfigSet ) )
      {
         QOMX_MSG_L_MED( pCommonRef, "Setting other ports." );

         /**------------------------------------------------------------------
            Initialize video domain ports.
         -------------------------------------------------------------------*/
         eRetVal = qomx_PortDomainInit( 
                        pConfig, pPortCtnr, paPortCtx, OMX_PortDomainOther );

      }

      /**---------------------------------------------------------------------
         If all initializations are successful, set the handle and return to
         the caller.
      ----------------------------------------------------------------------*/
      if( OMX_ErrorNone == eRetVal )
      {
         ( *pHPortCtnr ) = ( OMX_HANDLETYPE ) pPortCtnr;

      }
      else
      {
         QOMX_MSG_L_ERROR( pCommonRef, 
            "Domain ports initialization failed." );

      }

   }

   /**---------------------------------------------------------------------
      Release allocated memories, if any error.
   ----------------------------------------------------------------------*/
   if( OMX_ErrorNone != eRetVal )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Releasing allocated memory." );

      QOMX_CMPNT_FREEIF( pCommonRef->pfnFree, pCommonRef->hHeap, pAllocBuf );

   }

   return( eRetVal );

} /* end of function qomx_PortGetContainerHandle */


/*==========================================================================

         FUNCTION:      qomx_PortContainer_DeInit

         DESCRIPTION:
                        This function deinitializes all the ports contained
                        within the port container handle.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortContainer_DeInit
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr
)
{
   QOMX_PortContainerType    *pPortCtnr
      = ( QOMX_PortContainerType * ) hPortCtnr;

   QOMX_PortStateTableType   *pStTable;
   QOMX_PortContextType      *pPortCtx;
   OMX_U32                    i;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "qomx_PortContainer_DeInit" );

   /**------------------------------------------------------------------------
      Deinit all the ports.
   -------------------------------------------------------------------------*/
   for( i = 0; i <  pPortCtnr->nNumPorts; i++ )
   {
      pPortCtx = & ( pPortCtnr->paPortCtx[ i ] );

      /**---------------------------------------------------------------------
         Get the port state table, and check if this state supports this
         function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_PortCommon_GetStateTable( pPortCtnr, pPortCtx->eState );

      if( NULL != pStTable->DeInit )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         ( void ) pStTable->DeInit( pPortCtnr, pPortCtx );

      }

   }

   return( OMX_ErrorNone );

} /* end of function qomx_PortFreeContextHandle */


/*==========================================================================

         FUNCTION:      qomx_PortContainer_FreeHandle

         DESCRIPTION:
                        This function releases the handle itself. This function 
                        executes only when buffer processings on all the ports 
                        are either carried out or flushed. After this call the 
                        handle is not valid for any further use.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container. Handle
                                      no longer remains valid for any further
                                      references.
            @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortContainer_FreeHandle
(
   OMX_IN   QOMX_CommonRefType  *pCommonRef,
   OMX_IN   OMX_HANDLETYPE       hPortCtnr
)
{
   QOMX_MSG_L_MED( pCommonRef, "qomx_PortContainer_FreeHandle" );

   /**------------------------------------------------------------------------
      Release container handle.
   -------------------------------------------------------------------------*/
   QOMX_CMPNT_FREEIF( pCommonRef->pfnFree, pCommonRef->hHeap, hPortCtnr );

   return( OMX_ErrorNone );

} /* end of function qomx_PortFreeContextHandle */


/*==========================================================================

         FUNCTION:      qomx_PortStartPopulating

         DESCRIPTION:
                        This function is called when component moves from 
                        Loaded to Idle state. This function moves all the
                        enabled ports to populating state so that they can
                        begin accepting / allocating buffers.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortStartPopulating
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr
)
{
   OMX_ERRORTYPE              eRetVal = OMX_ErrorNone;
   QOMX_PortContainerType    *pPortCtnr
      = ( QOMX_PortContainerType * ) hPortCtnr;
   
   QOMX_PortStateTableType   *pStTable;
   QOMX_PortContextType      *pPortCtx;
   OMX_U32                    i;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "qomx_PortStartPopulating" );

   /**------------------------------------------------------------------------
      Populate all the ports.
   -------------------------------------------------------------------------*/
   for( i = 0; ( i < pPortCtnr->nNumPorts )
               && ( OMX_ErrorNone == eRetVal ); i++ )
   {
      pPortCtx = & ( pPortCtnr->paPortCtx[ i ] );

      /**---------------------------------------------------------------------
         Get the port state table, and check if this state supports this
         function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_PortCommon_GetStateTable( 
                                       pPortCtnr, pPortCtx->eState );

      if( NULL != pStTable->Populate )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->Populate( pPortCtnr, pPortCtx );

      }

   }

   return( eRetVal );

} /* end of function qomx_PortStartPopulating */


/*==========================================================================

         FUNCTION:      qomx_PortUnpopulate

         DESCRIPTION:
                        This function is called when component is transitioned
                        to Loaded state. This function moves all the enabled
                        ports to unpopulated state.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortUnpopulate
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr
)
{
   OMX_ERRORTYPE              eRetVal = OMX_ErrorNone;
   QOMX_PortContainerType    *pPortCtnr
      = ( QOMX_PortContainerType * ) hPortCtnr;
   
   QOMX_PortStateTableType   *pStTable;
   QOMX_PortContextType      *pPortCtx;
   OMX_U32                    i;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "qomx_PortUnpopulate" );

   /**------------------------------------------------------------------------
      Unpopulate all the ports.
   -------------------------------------------------------------------------*/
   for( i = 0; ( i < pPortCtnr->nNumPorts )
               && ( OMX_ErrorNone == eRetVal ); i++ )
   {
      pPortCtx = & ( pPortCtnr->paPortCtx[ i ] );

      /**---------------------------------------------------------------------
         Get the port state table, and check if this state supports this
         function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_PortCommon_GetStateTable( 
                                       pPortCtnr, pPortCtx->eState );

      if( NULL != pStTable->Unpopulate )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->Unpopulate( pPortCtnr, pPortCtx );

      }

   }

   return( eRetVal );

} /* end of function qomx_PortUnpopulate */


/*==========================================================================

         FUNCTION:      qomx_PortStartBufferProcessing

         DESCRIPTION:
                        This function is called when component is transitioned
                        from Idle to Executing state. This function starts 
                        buffer processing on the enabled ports when tunneled.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortStartBufferProcessing
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr
)
{
   OMX_ERRORTYPE              eRetVal = OMX_ErrorNone;
   QOMX_PortContainerType    *pPortCtnr
      = ( QOMX_PortContainerType * ) hPortCtnr;

   QOMX_PortStateTableType   *pStTable;
   QOMX_PortContextType      *pPortCtx;
   OMX_U32                    i;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, 
      "qomx_PortStartBufferProcessing" );

   /**------------------------------------------------------------------------
      Run all the ports.
   -------------------------------------------------------------------------*/
   for( i = 0; ( i < pPortCtnr->nNumPorts )
               && ( OMX_ErrorNone == eRetVal ); i++ )
   {
      pPortCtx = & ( pPortCtnr->paPortCtx[ i ] );

      /**---------------------------------------------------------------------
         Get the port state table, and check if this state supports this
         function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_PortCommon_GetStateTable( 
                                       pPortCtnr, pPortCtx->eState );

      if( NULL != pStTable->Run )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->Run( pPortCtnr, pPortCtx );

      }

   }

   return( eRetVal );

} /* end of function qomx_PortStartBufferProcessing */


/*==========================================================================

         FUNCTION:      qomx_PortStopBufferProcessing

         DESCRIPTION:
                        This function is called when component is transitioned
                        from Executing / Pause to Idle state. This function 
                        stops buffer processing on the enabled ports when 
                        tunneled.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortStopBufferProcessing
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr
)
{
   OMX_ERRORTYPE              eRetVal = OMX_ErrorNone;
   QOMX_PortContainerType    *pPortCtnr
      = ( QOMX_PortContainerType * ) hPortCtnr;
   
   QOMX_PortStateTableType   *pStTable;
   QOMX_PortContextType      *pPortCtx;
   OMX_U32                    i;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, 
      "qomx_PortStopBufferProcessing" );

   /**------------------------------------------------------------------------
      Stop all the ports.
   -------------------------------------------------------------------------*/
   for( i = 0; ( i < pPortCtnr->nNumPorts )
               && ( OMX_ErrorNone == eRetVal ); i++ )
   {
      pPortCtx = & ( pPortCtnr->paPortCtx[ i ] );

      /**---------------------------------------------------------------------
         Get the port state table, and check if this state supports this
         function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_PortCommon_GetStateTable( 
                                       pPortCtnr, pPortCtx->eState );

      if( NULL != pStTable->Stop )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->Stop( pPortCtnr, pPortCtx );

      }

   }

   return( eRetVal );

} /* end of function qomx_PortStopBufferProcessing */


/*==========================================================================

         FUNCTION:      qomx_PortEnable

         DESCRIPTION:
                        Refer to OMX_SendCommand in OMX_Core.h or the OMX IL 
                        specification for details on the
                        OMX_CommandPortEnable command.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nPortIndex  - Index for the port which should be
                                      enabled.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortEnable
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr,
   OMX_IN   OMX_U32           nPortIndex
)
{
   OMX_ERRORTYPE              eRetVal = OMX_ErrorNone;
   QOMX_PortContainerType    *pPortCtnr
      = ( QOMX_PortContainerType * ) hPortCtnr;

   QOMX_PortStateTableType   *pStTable;
   QOMX_PortContextType      *pPortCtx;   
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, 
      "qomx_PortEnable, nPortIndex = 0x%x", nPortIndex );

   if( OMX_ALL == nPortIndex )
   {
      OMX_U32  i;
      /*--------------------------------------------------------------------*/

      QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Enable ALL" );

      /**---------------------------------------------------------------------
         Enable all the ports.
      ----------------------------------------------------------------------*/
      for( i = 0; i < pPortCtnr->nNumPorts; i++ )
      {
         pPortCtx = & ( pPortCtnr->paPortCtx[ i ] );

         /**------------------------------------------------------------------
            Get the port state table, and check if this state supports this
            function call.
         -------------------------------------------------------------------*/
         pStTable = qomx_PortCommon_GetStateTable( 
                                          pPortCtnr, pPortCtx->eState );

         if( NULL != pStTable->Enable )
         {
            /**---------------------------------------------------------------
               Call the state table function now.
            ----------------------------------------------------------------*/
            ( void ) pStTable->Enable( pPortCtnr, pPortCtx );
            
         }

      }

   }
   else 
   {
      /**---------------------------------------------------------------------
         Get the port context based on the given index.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_PortGetContext( pPortCtnr, nPortIndex, & pPortCtx );

      /**---------------------------------------------------------------------
         If current port state does not allow function execution, return an
         incorrect state operation.
      ----------------------------------------------------------------------*/
      if( OMX_ErrorNone == eRetVal )
      {
         /**------------------------------------------------------------------
            Get the port state table, and check if this state supports this
            function call.
         -------------------------------------------------------------------*/
         pStTable = qomx_PortCommon_GetStateTable( 
                                          pPortCtnr, pPortCtx->eState );

         if( NULL != pStTable->Enable )
         {
            /**---------------------------------------------------------------
               Call the state table function now.
            ----------------------------------------------------------------*/
            eRetVal = pStTable->Enable( pPortCtnr, pPortCtx );

         }
         else
         {
            QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Incorrect state"
               " operation, nPortIndex = 0x%x", nPortIndex );

            /**---------------------------------------------------------------
               Requested state transition is not allowed in this state.
            ----------------------------------------------------------------*/
            QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Send "
               "OMX_ErrorIncorrectStateOperation notification" );

            ( void ) qomx_CmpntNotifyError( pPortCtnr->pCommonRef, 
                                          OMX_ErrorIncorrectStateOperation );

         }

      }
      else
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Get port context failed,"
            " nPortIndex = 0x%x", nPortIndex );

      }

   }   

   return( eRetVal );

} /* end of function qomx_PortEnable */


/*==========================================================================

         FUNCTION:      qomx_PortDisable

         DESCRIPTION:
                        Refer to OMX_SendCommand in OMX_Core.h or the OMX IL 
                        specification for details on the
                        OMX_CommandPortDisable command.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nPortIndex  - Index for the port which should be
                                      disabled.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortDisable
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr,
   OMX_IN   OMX_U32           nPortIndex
)
{
   OMX_ERRORTYPE              eRetVal = OMX_ErrorNone;
   QOMX_PortContainerType    *pPortCtnr
      = ( QOMX_PortContainerType * ) hPortCtnr;

   QOMX_PortStateTableType   *pStTable;
   QOMX_PortContextType      *pPortCtx;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, 
      "qomx_PortDisable, nPortIndex = 0x%x", nPortIndex );

   if( OMX_ALL == nPortIndex )
   {
      OMX_U32  i;
      /*--------------------------------------------------------------------*/

      QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Disable ALL" );

      /**---------------------------------------------------------------------
         Disable all the ports.
      ----------------------------------------------------------------------*/
      for( i = 0; i < pPortCtnr->nNumPorts; i++ )
      {
         pPortCtx = & ( pPortCtnr->paPortCtx[ i ] );

         /**------------------------------------------------------------------
            Get the port state table, and check if this state supports this
            function call.
         -------------------------------------------------------------------*/
         pStTable = qomx_PortCommon_GetStateTable( 
                                          pPortCtnr, pPortCtx->eState );

         if( NULL != pStTable->Disable )
         {
            /**---------------------------------------------------------------
               Call the state table function now.
            ----------------------------------------------------------------*/
            ( void ) pStTable->Disable( pPortCtnr, pPortCtx );

         }

      }
      
   }
   else 
   {
      /**---------------------------------------------------------------------
         Get the port context based on the given index.
      ----------------------------------------------------------------------*/

      eRetVal = qomx_PortGetContext( pPortCtnr, nPortIndex, & pPortCtx );

      /**---------------------------------------------------------------------
         If current port state does not allow function execution, return an
         incorrect state operation.
      ----------------------------------------------------------------------*/
      if( OMX_ErrorNone == eRetVal )
      {
         /**------------------------------------------------------------------
            Get the port state table, and check if this state supports this
            function call.
         -------------------------------------------------------------------*/
         pStTable = qomx_PortCommon_GetStateTable( 
                                          pPortCtnr, pPortCtx->eState );

         if( NULL != pStTable->Disable )
         {
            /**---------------------------------------------------------------
               Call the state table function now.
            ----------------------------------------------------------------*/
            eRetVal = pStTable->Disable( pPortCtnr, pPortCtx );

         }
         else
         {
            QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Incorrect state"
               " operation, nPortIndex = 0x%x", nPortIndex );

            /**---------------------------------------------------------------
               Requested state transition is not allowed in this state.
            ----------------------------------------------------------------*/
            QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Send "
               "OMX_ErrorIncorrectStateOperation notification" );

            ( void ) qomx_CmpntNotifyError( pPortCtnr->pCommonRef, 
                                          OMX_ErrorIncorrectStateOperation );

         }
      
      }
      else
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Get port context failed,"
            " nPortIndex = 0x%x", nPortIndex );

      }

   }   

   return( eRetVal );

} /* end of function qomx_PortDisable */


/*==========================================================================

         FUNCTION:      qomx_PortGetParameter

         DESCRIPTION:
                        Refer to OMX_GetParameter in OMX_Core.h or the OMX IL 
                        specification for details on the GetParameter method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nParamIndex - Refer OMX_Core.h / OMX IL specification.
            @param[inout] pCmpntParm
                                    - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortGetParameter
(
   OMX_IN      OMX_HANDLETYPE    hPortCtnr,
   OMX_IN      OMX_INDEXTYPE     nParamIndex,
   OMX_INOUT   OMX_PTR           pCmpntParm
)
{
   OMX_ERRORTYPE           eRetVal;
   QOMX_PortContainerType *pPortCtnr = ( QOMX_PortContainerType * ) hPortCtnr;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pPortCtnr->pCommonRef, 
      "qomx_PortGetParameter, nParamIndex = 0x%x", nParamIndex );

   /**------------------------------------------------------------------------
      Get the port context based on the given index.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortCommon_GetParameter(
                                 pPortCtnr, nParamIndex, pCmpntParm );

   return( eRetVal );

} /* end of function qomx_PortGetParameter */


/*==========================================================================

         FUNCTION:      qomx_PortSetParameter

         DESCRIPTION:
                        Refer to OMX_GetParameter in OMX_Core.h or the OMX IL 
                        specification for details on the SetParameter method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nParamIndex - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pCmpntParm  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortSetParameter
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr,
   OMX_IN   OMX_INDEXTYPE     nParamIndex,
   OMX_IN   OMX_PTR           pCmpntParm
)
{
   OMX_ERRORTYPE           eRetVal;
   QOMX_PortContainerType *pPortCtnr = ( QOMX_PortContainerType * ) hPortCtnr;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pPortCtnr->pCommonRef, 
      "qomx_PortSetParameter, nParamIndex = 0x%x", nParamIndex );

   /**------------------------------------------------------------------------
      Get the port context based on the given index.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortCommon_SetParameter( 
                                    pPortCtnr, nParamIndex, pCmpntParm );

   return( eRetVal );

} /* end of function qomx_PortSetParameter */


/*==========================================================================

         FUNCTION:      qomx_PortGetConfig

         DESCRIPTION:
                        Refer to OMX_GetConfig in OMX_Core.h or the OMX IL 
                        specification for details on the GetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nCfgIndex   - Refer OMX_Core.h / OMX IL specification.
            @param[inout] pCmpntCfg - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortGetConfig
(
   OMX_IN      OMX_HANDLETYPE    hPortCtnr,
   OMX_IN      OMX_INDEXTYPE     nCfgIndex,
   OMX_INOUT   OMX_PTR           pCmpntCfg
)
{
   OMX_ERRORTYPE           eRetVal;
   QOMX_PortContainerType *pPortCtnr = ( QOMX_PortContainerType * ) hPortCtnr;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pPortCtnr->pCommonRef, 
      "qomx_PortGetConfig, nCfgIndex = 0x%x", nCfgIndex );

   /**------------------------------------------------------------------------
      Get the port context based on the given index.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortCommon_GetConfig( pPortCtnr, nCfgIndex, pCmpntCfg );

   return( eRetVal );

} /* end of function qomx_PortGetConfig */


/*==========================================================================

         FUNCTION:      qomx_PortSetConfig

         DESCRIPTION:
                        Refer to OMX_SetConfig in OMX_Core.h or the OMX IL 
                        specification for details on the SetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nCfgIndex   - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pCmpntCfg   - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortSetConfig
(
   OMX_IN      OMX_HANDLETYPE    hPortCtnr,
   OMX_IN      OMX_INDEXTYPE     nCfgIndex,
   OMX_INOUT   OMX_PTR           pCmpntCfg
)
{
   OMX_ERRORTYPE           eRetVal;
   QOMX_PortContainerType *pPortCtnr = ( QOMX_PortContainerType * ) hPortCtnr;
   /*-----------------------------------------------------------------------*/
   
   QOMX_MSG_L_LOW( pPortCtnr->pCommonRef, 
      "qomx_PortSetConfig, nCfgIndex = 0x%x", nCfgIndex );

   /**------------------------------------------------------------------------
      Get the port context based on the given index.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortCommon_SetConfig( pPortCtnr, nCfgIndex, pCmpntCfg );

   return( eRetVal );

} /* end of function qomx_PortSetConfig */


/*==========================================================================

         FUNCTION:      qomx_PortTunnelRequest

         DESCRIPTION:
                        Refer to OMX_ComponentTunnelRequest in OMX_Core.h
                        or the OMX IL specification for details on the 
                        ComponentTunnelRequest method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr      - Handle to the port container.
            @param[in]  nPort          - Refer OMX_Core.h / OMX IL spec.
            @param[in]  hTunneledComp  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nTunneledPort  - Refer OMX_Core.h / OMX IL spec.
            @param[out] pTunnelSetup   - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/

OMX_ERRORTYPE  qomx_PortTunnelRequest
(
   OMX_IN      OMX_HANDLETYPE          hPortCtnr,
   OMX_IN      OMX_U32                 nPort,
   OMX_IN      OMX_HANDLETYPE          hTunneledComp,
   OMX_IN      OMX_U32                 nTunneledPort,
   OMX_INOUT   OMX_TUNNELSETUPTYPE    *pTunnelSetup
)
{
   OMX_ERRORTYPE           eRetVal;
   QOMX_PortContextType   *pPortCtx;
   QOMX_PortContainerType *pPortCtnr = ( QOMX_PortContainerType * ) hPortCtnr;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "qomx_PortTunnelRequest,"
      " hTunneledComp = 0x%p, nTunneledPort = 0x%x", 
       hTunneledComp, nTunneledPort );

   /**------------------------------------------------------------------------
      Get the port context based on the given index.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortGetContext( pPortCtnr, nPort, & pPortCtx );

   /**------------------------------------------------------------------------
      If current port state does not allow function execution, return an
      incorrect state operation.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_PortStateTableType   *pStTable;
      /*--------------------------------------------------------------------*/

      /**---------------------------------------------------------------------
         Get the port state table, and check if this state supports
         this function call.
      ----------------------------------------------------------------------*/
      pStTable = qomx_PortCommon_GetStateTable( pPortCtnr, pPortCtx->eState );

      if( NULL != pStTable->TunnelRequest )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->TunnelRequest( pPortCtnr, pPortCtx,
                                 hTunneledComp, nTunneledPort, pTunnelSetup );

      }
      else
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Incorrect state"
               " operation, nPortIndex = 0x%x", nPort );

         /**------------------------------------------------------------------
            Operation is not supported in component's current state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

   }
   else
   {
      QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Get port context failed,"
            " nPortIndex = 0x%x", nPort );

   }
 
   return( eRetVal );

} /* end of function qomx_PortUseBuffer */


/*==========================================================================

         FUNCTION:      qomx_PortUseBuffer

         DESCRIPTION:
                        Refer to OMX_UseBuffer in OMX_Core.h or the OMX IL 
                        specification for details on the UseBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nPortIndex  - Index for the port on which method 
                                      need to be executed.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL specification.
            @param[in]  nSizeBytes  - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pBuffer     - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortUseBuffer
(
   OMX_IN   OMX_HANDLETYPE             hPortCtnr,
   OMX_IN   OMX_U32                    nPortIndex,
   OMX_OUT  OMX_BUFFERHEADERTYPE     **ppBufferHdr,
   OMX_IN   OMX_PTR                    pAppPrivate,
   OMX_IN   OMX_U32                    nSizeBytes,
   OMX_IN   OMX_U8                    *pBuffer
)
{
   OMX_ERRORTYPE           eRetVal;
   QOMX_PortContainerType *pPortCtnr = ( QOMX_PortContainerType * ) hPortCtnr;
   QOMX_PortContextType   *pPortCtx;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "qomx_PortUseBuffer,"
      " nPortIndex = 0x%x, nSizeBytes = 0x%x", nPortIndex, nSizeBytes );

   /**------------------------------------------------------------------------
      Get the port context based on the given index.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortGetContext( pPortCtnr, nPortIndex, & pPortCtx );

   /**------------------------------------------------------------------------
      Check buffer size, it should not be less than port buffer requirement.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_PortStateTableType   *pStTable;
      /*--------------------------------------------------------------------*/

      /**---------------------------------------------------------------------
         If current port state does not allow function execution, return
         an incorrect state operation.
      ----------------------------------------------------------------------*/
      pStTable = qomx_PortCommon_GetStateTable( 
                                    pPortCtnr, pPortCtx->eState );

      if( NULL != pStTable->UseBuffer )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->UseBuffer( pPortCtnr, pPortCtx,
                        ppBufferHdr, pAppPrivate, nSizeBytes, pBuffer );

      }
      else
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Incorrect state"
               " operation, nPortIndex = 0x%x", nPortIndex );

         /**------------------------------------------------------------------
            Incorrect state operation.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

   }

   return( eRetVal );

} /* end of function qomx_PortUseBuffer */


/*==========================================================================

         FUNCTION:      qomx_PortAllocateBuffer

         DESCRIPTION:
                        Refer to OMX_AllocateBuffer in OMX_Core.h or the OMX
                        IL specification for details on the AllocateBuffer
                        method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nPortIndex  - Index for the port on which method 
                                      need to be executed.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL specification.
            @param[in]  nSizeBytes  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortAllocateBuffer
(
   OMX_IN   OMX_HANDLETYPE             hPortCtnr,
   OMX_IN   OMX_U32                    nPortIndex,
   OMX_OUT  OMX_BUFFERHEADERTYPE     **ppBufferHdr,
   OMX_IN   OMX_PTR                    pAppPrivate,
   OMX_IN   OMX_U32                    nSizeBytes
)
{
   OMX_ERRORTYPE           eRetVal;
   QOMX_PortContainerType *pPortCtnr = ( QOMX_PortContainerType * ) hPortCtnr;
   QOMX_PortContextType   *pPortCtx;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "qomx_PortAllocateBuffer,"
      " nPortIndex = 0x%x, nSizeBytes = 0x%x", nPortIndex, nSizeBytes );

   /**------------------------------------------------------------------------
      Get the port context based on the given index.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortGetContext( pPortCtnr, nPortIndex, & pPortCtx );

   /**------------------------------------------------------------------------
      Check buffer size, it should not be less than port buffer requirement.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_PortStateTableType   *pStTable;
      /*--------------------------------------------------------------------*/

      /**---------------------------------------------------------------------
         If current port state does not allow function execution, return
         an incorrect state operation.
      ----------------------------------------------------------------------*/
      pStTable = qomx_PortCommon_GetStateTable(
                                       pPortCtnr, pPortCtx->eState );

      if( NULL != pStTable->AllocateBuffer )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->AllocateBuffer( pPortCtnr, pPortCtx,
                                 ppBufferHdr, pAppPrivate, nSizeBytes );

      }
      else
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Incorrect state"
            " operation, nPortIndex = 0x%x", nPortIndex );

         /**------------------------------------------------------------------
            Incorrect state operation.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

   }

   return( eRetVal );

} /* end of function qomx_PortAllocateBuffer */


/*==========================================================================

         FUNCTION:      qomx_PortFreeBuffer

         DESCRIPTION:
                        Refer to OMX_FreeBuffer in OMX_Core.h or the OMX IL
                        specification for details on the FreeBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nPortIndex  - Index for the port on which method 
                                      need to be executed.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortFreeBuffer
(
   OMX_IN   OMX_HANDLETYPE             hPortCtnr,
   OMX_IN   OMX_U32                    nPortIndex,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBufferHdr
)
{
   OMX_ERRORTYPE           eRetVal;
   QOMX_PortContainerType *pPortCtnr = ( QOMX_PortContainerType * ) hPortCtnr;
   QOMX_PortContextType   *pPortCtx;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "qomx_PortFreeBuffer, nPortIndex"
      "  = 0x%x, pBufferHdr = 0x%p", nPortIndex, pBufferHdr );

   /**------------------------------------------------------------------------
      Get the port context based on the given index.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortGetContext( pPortCtnr, nPortIndex, & pPortCtx );

   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_PortStateTableType   *pStTable;
      /*--------------------------------------------------------------------*/

      /**---------------------------------------------------------------------
         If current port state does not allow function execution, return
         an incorrect state operation.
      ----------------------------------------------------------------------*/
      pStTable = qomx_PortCommon_GetStateTable(
                                       pPortCtnr, pPortCtx->eState );

      if( NULL != pStTable->FreeBuffer )
      {
         /**------------------------------------------------------------------
            Call the state table function now.
         -------------------------------------------------------------------*/
         eRetVal = pStTable->FreeBuffer( pPortCtnr, pPortCtx, pBufferHdr );

      }
      else
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Incorrect state"
            " operation, nPortIndex = 0x%x", nPortIndex );

         /**------------------------------------------------------------------
            Incorrect state operation.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

   }

   return( eRetVal );

} /* end of function qomx_PortFreeBuffer */


/*==========================================================================

         FUNCTION:      qomx_PortEmptyThisBuffer

         DESCRIPTION:
                        Refer to OMX_EmptyThisBuffer in OMX_Core.h or the OMX
                        IL specification for details on the EmptyThisBuffer
                        method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortEmptyThisBuffer
(
   OMX_IN   OMX_HANDLETYPE          hPortCtnr,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr
)
{
   OMX_ERRORTYPE           eRetVal;
   QOMX_PortContainerType *pPortCtnr = ( QOMX_PortContainerType * ) hPortCtnr;
   QOMX_PortContextType   *pPortCtx;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pPortCtnr->pCommonRef, "qomx_PortEmptyThisBuffer,"
      " pBufferHdr = 0x%p", pBufferHdr );

   /**------------------------------------------------------------------------
      Get the port context based on the given index.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortGetContext(
                        pPortCtnr, pBufferHdr->nInputPortIndex, & pPortCtx );

   if( OMX_ErrorNone == eRetVal )
   {
      /**--------------------------------------------------------------------
         Check port direction. EmptyThisBuffer is allowed only on input
         ports.
      ----------------------------------------------------------------------*/
      if( OMX_DirInput != pPortCtx->portDef.eDir )
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "EmptyThisBuffer is allowed"
            " only on an input port, nPortIndex = 0x%x",
            pBufferHdr->nInputPortIndex );

         /**------------------------------------------------------------------
            Invalid port index.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorBadPortIndex;

      }
      else
      {
         QOMX_PortStateTableType   *pStTable;
         /*-----------------------------------------------------------------*/

         /**------------------------------------------------------------------
            If current port state does not allow function execution, return
            an incorrect state operation.
         -------------------------------------------------------------------*/
         pStTable = qomx_PortCommon_GetStateTable(
                                          pPortCtnr, pPortCtx->eState );

         if( NULL != pStTable->EmptyThisBuffer )
         {
            /**---------------------------------------------------------------
               Call the state table function now.
            ----------------------------------------------------------------*/
            eRetVal = pStTable->EmptyThisBuffer( 
                                       pPortCtnr, pPortCtx, pBufferHdr );

            if ( OMX_ErrorNone == eRetVal )
            {
               /**
               If this is not a tunneled component
               bufWithClient = nBufferCountActual - nBuffersWithDevice 
               or
               bufWithClient = nBuffersWithClient(ranges from 0 to -n) + nBufferCountActual(n)

               but for tunneled components, some buffers could be neither with device or client, 
               but instead with downstream components. So, the actual

               bufWithClient = nBuffersWithClient(ranges from 0 to -n) + nBufferCountActual(n)
               Then,
               buffersWithDownstreamComponent = 
                     nBufferCountActual - (buffers with device + buffers with client)
               */
               OMX_U32 bufWithClient = (pPortCtx->nBuffersWithClient + pPortCtx->portDef.nBufferCountActual);
               QOMX_STATS_MSG( pPortCtnr->pCommonRef, QOMX_MSG_PRIORITY_LOW, 
                  "ETB buffers with device = %d, buffers with client = %d, TimeStamp = %lld", 
                  pPortCtx->nBuffersWithDevice, bufWithClient, pBufferHdr->nTimeStamp );
            }
         }
         else
         {
            QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Incorrect state"
               " operation, nPortIndex = 0x%x",
               pBufferHdr->nInputPortIndex );

            /**---------------------------------------------------------------
               Incorrect state operation.
            ----------------------------------------------------------------*/
            eRetVal = OMX_ErrorIncorrectStateOperation;

         }

      }

   }

   return( eRetVal );

} /* end of function qomx_PortEmptyThisBuffer */


/*==========================================================================

         FUNCTION:      qomx_PortFillThisBuffer

         DESCRIPTION:
                        Refer to OMX_FillThisBuffer in OMX_Core.h or the OMX
                        IL specification for details on the FillThisBuffer
                        method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortFillThisBuffer
(
   OMX_IN   OMX_HANDLETYPE          hPortCtnr,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr
)
{
   OMX_ERRORTYPE           eRetVal;
   QOMX_PortContainerType *pPortCtnr = ( QOMX_PortContainerType * ) hPortCtnr;
   QOMX_PortContextType   *pPortCtx;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pPortCtnr->pCommonRef, "qomx_PortFillThisBuffer,"
      " pBufferHdr = 0x%p", pBufferHdr );

   /**------------------------------------------------------------------------
      Get the port context based on the given index.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortGetContext( 
                        pPortCtnr, pBufferHdr->nOutputPortIndex, & pPortCtx );

   if( OMX_ErrorNone == eRetVal )
   {
      /**--------------------------------------------------------------------
         Check port direction. FillThisBuffer is allowed only on output
         ports.
      ----------------------------------------------------------------------*/
      if( OMX_DirOutput != pPortCtx->portDef.eDir )
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "FillThisBuffer is allowed"
            " only on an output port, nPortIndex = 0x%x",
            pBufferHdr->nOutputPortIndex );

         /**------------------------------------------------------------------
            Invalid port index.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorBadPortIndex;

      }
      else
      {
         QOMX_PortStateTableType   *pStTable;
         /*-----------------------------------------------------------------*/

         /**------------------------------------------------------------------
            If current port state does not allow function execution, return
            an incorrect state operation.
         -------------------------------------------------------------------*/
         pStTable = qomx_PortCommon_GetStateTable(
                                          pPortCtnr, pPortCtx->eState );

         if( NULL != pStTable->FillThisBuffer )
         {
            /**---------------------------------------------------------------
               Call the state table function now.
            ----------------------------------------------------------------*/
            eRetVal = pStTable->FillThisBuffer( 
                                       pPortCtnr, pPortCtx, pBufferHdr );
            if ( OMX_ErrorNone == eRetVal )
            {
               OMX_U32 bufWithClient = (pPortCtx->nBuffersWithClient + pPortCtx->portDef.nBufferCountActual);
               QOMX_STATS_MSG( pPortCtnr->pCommonRef, QOMX_MSG_PRIORITY_LOW, 
                  "FTB buffers with device = %d, buffers with client = %d, TimeStamp = %lld", 
                  pPortCtx->nBuffersWithDevice, bufWithClient, pBufferHdr->nTimeStamp );
            }
         }
         else
         {
            QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Incorrect state"
               " operation, nPortIndex = 0x%x", 
               pBufferHdr->nOutputPortIndex );

            /**---------------------------------------------------------------
               Incorrect state operation.
            ----------------------------------------------------------------*/
            eRetVal = OMX_ErrorIncorrectStateOperation;

         }

      }

   }

   return( eRetVal );

} /* end of function qomx_PortFillThisBuffer */


/*==========================================================================

         FUNCTION:      qomx_PortFlush

         DESCRIPTION:
                        Refer to OMX_SendCommand in OMX_Core.h or the OMX
                        IL specification for details on the OMX_CommandFlush
                        command.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nPortIndex  - Index for the port on which method 
                                      need to be executed.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortFlush
(
   OMX_IN   OMX_HANDLETYPE          hPortCtnr,
   OMX_IN   OMX_U32                 nPortIndex
)
{
   OMX_ERRORTYPE              eRetVal = OMX_ErrorNone;
   QOMX_PortContainerType    *pPortCtnr
      = ( QOMX_PortContainerType * ) hPortCtnr;

   QOMX_PortStateTableType   *pStTable;
   QOMX_PortContextType      *pPortCtx;   
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "qomx_PortFlush, nPortIndex = 0x%x",
      nPortIndex );

   if( OMX_ALL == nPortIndex )
   {
      OMX_U32  i;
      /*--------------------------------------------------------------------*/

      QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Flush ALL" );

      /**---------------------------------------------------------------------
         Flush all the ports.
      ----------------------------------------------------------------------*/
      for( i = 0; i < pPortCtnr->nNumPorts; i++ )
      {
         pPortCtx = & ( pPortCtnr->paPortCtx[ i ] );

         /**------------------------------------------------------------------
            Get the port state table, and check if this state supports this
            function call.
         -------------------------------------------------------------------*/
         pStTable = qomx_PortCommon_GetStateTable( 
                                          pPortCtnr, pPortCtx->eState );

         if( NULL != pStTable->Flush )
         {
            /**---------------------------------------------------------------
               Call the state table function now.
            ----------------------------------------------------------------*/
            ( void ) pStTable->Flush( pPortCtnr, pPortCtx );

         }

      }

   }
   else 
   {
      /**---------------------------------------------------------------------
         Get the port context based on the given index.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_PortGetContext( pPortCtnr, nPortIndex, & pPortCtx );

      /**---------------------------------------------------------------------
         If current port state does not allow function execution, return an
         incorrect state operation.
      ----------------------------------------------------------------------*/
      if( OMX_ErrorNone == eRetVal )
      {
         /**------------------------------------------------------------------
            Get the port state table, and check if this state supports this
            function call.
         -------------------------------------------------------------------*/
         pStTable = qomx_PortCommon_GetStateTable( 
                                          pPortCtnr, pPortCtx->eState );

         if( NULL != pStTable->Flush )
         {
            /**---------------------------------------------------------------
               Call the state table function now.
            ----------------------------------------------------------------*/
            eRetVal = pStTable->Flush( pPortCtnr, pPortCtx );

         }
         else
         {
            QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Incorrect state"
               " operation, nPortIndex = 0x%x", nPortIndex );

            /**---------------------------------------------------------------
               Requested state transition is not allowed in this state.
            ----------------------------------------------------------------*/
            QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Send "
               "OMX_ErrorIncorrectStateOperation notification" );

            ( void ) qomx_CmpntNotifyError( pPortCtnr->pCommonRef, 
                                          OMX_ErrorIncorrectStateOperation );

         }
      
      }
      else
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Get port context failed,"
            " nPortIndex = 0x%x", nPortIndex );

      }

   }   

   return( eRetVal );

} /* end of function qomx_PortFlush */

/*==========================================================================

         FUNCTION:      qomx_VendorTunnel_PortMarkBufferCommand

         DESCRIPTION:
                        This function sends a mark buffer MMI command to 
                        device.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information
            @param[in]  nPortIndex  - Index for the port on which method 
                                      need to be executed.
            @param[in]  pMark       - Mark data and target component information.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE qomx_VendorTunnel_PortMarkBufferCommand
(
   QOMX_CommonRefType              *pCommonRef,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_IN   OMX_MARKTYPE           *pMark
)
{
   OMX_ERRORTYPE        eRetVal   = OMX_ErrorNone;
   OMX_U32                 nStatus   = MMI_S_EFAIL;

   MMI_VendorTunnelMarkBufferCmdType markBufCmd;

   markBufCmd.nPortIndex = nPortIndex;
   markBufCmd.markBuffer.hMarkTargetComponent = pCommonRef->hFd;
   markBufCmd.markBuffer.pMarkData = pMark->pMarkData;

   /**------------------------------------------------------------------------
      Send MMI mark buffer command to vendor tunneled device.
   -------------------------------------------------------------------------*/

   nStatus = pCommonRef->device.pfnCmd( 
        pCommonRef->hFd, MMI_CMD_VENDORTUNNEL_PORT_MARK_BUFFER, &markBufCmd );

   QOMX_MSG_L_HIGH( pCommonRef,
      "Vendor tunnel port mark buffer status = 0x%x.", nStatus );

   if( MMI_S_PENDING != nStatus )
   {
       eRetVal = qomx_GetOMXErrorCode( nStatus );

   }

   /**------------------------------------------------------------------------
      Move component to Invalid state on fatal error.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorInvalidState == eRetVal )
   {
      ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt, 
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

   }

   return eRetVal;

}  /* end of function qomx_VendorTunnel_PortMarkBufferCommand */

/*==========================================================================

         FUNCTION:      qomx_PortAddMarkBuffer

         DESCRIPTION:
                        This function sends a mark buffer MMI command to 
                        device.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information
            @param[in]  pPortCtx    - pointer to port context structure                                      
            @param[in]  pMark       - Mark data and target component information.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/

OMX_ERRORTYPE qomx_PortAddMarkBuffer 
    (
     OMX_IN QOMX_CommonRefType     *pCommonRef,
     OMX_IN QOMX_PortContextType   *pPortCtx,
     OMX_IN   OMX_MARKTYPE         *pMark 
    )
{
     OMX_ERRORTYPE        eRetVal   = OMX_ErrorNone;
     QOMX_MarkBufferList *pListEntry;
     QMM_ListLinkType     *link;
     QMM_ListErrorType    listError = QMM_LIST_ERROR_NONE;
    
    /* if no entry in empty list add free entry to it */
    if ( qmm_ListIsEmpty ( &pPortCtx->MarkBufEmptyList ) )
    {

       pListEntry = (QOMX_MarkBufferList *)QOMX_CMPNT_MALLOC( pCommonRef->pfnMalloc, pCommonRef->hHeap, sizeof(QOMX_MarkBufferList) );
       
       if ( pListEntry )
       {
          QOMX_CMPNT_MEM_SET( pListEntry, 0, sizeof(QOMX_MarkBufferList) );
              
          listError = qmm_ListPushRear ( &pPortCtx->MarkBufEmptyList, &(pListEntry->link) );
          if ( QMM_LIST_ERROR_NONE != listError )
          {
             QOMX_MSG_L_ERROR( pCommonRef, "Failed to push link to empty mark buffer list" );
             QOMX_CMPNT_FREEIF( pCommonRef->pfnFree, pCommonRef->hHeap, pListEntry );
             eRetVal = OMX_ErrorUndefined;
          }
       }
       else
       {
          QOMX_MSG_L_ERROR( pCommonRef, "failed to allocate memory for mark buffer list" );
          eRetVal = OMX_ErrorInsufficientResources;
       }
    }

    if ( OMX_ErrorNone == eRetVal )
    {
        listError = qmm_ListPopFront ( &pPortCtx->MarkBufEmptyList,  &link );

        if ( QMM_LIST_ERROR_NONE ==  listError )
         {
            pListEntry = ( QOMX_MarkBufferList * ) link;

            /**-----------------------------------------------------------
                              Copy Mark data.
            ------------------------------------------------------------*/
            QOMX_CMPNT_MEM_COPY( 
              & ( pListEntry->markBuffer ), pMark, sizeof( OMX_MARKTYPE ) );
        
            /* insert entry into full list */
            listError = qmm_ListPushRear( &pPortCtx->MarkBufFullList, link );

            if ( QMM_LIST_ERROR_NONE != listError )
            {
               QOMX_MSG_L_ERROR( pCommonRef, "Failed to push link to full mark buffer list, error = 0x%x", listError );
               eRetVal = OMX_ErrorUndefined;
            }
         }
         else
         {
            QOMX_MSG_L_ERROR( pCommonRef, "Failed to pop link from empty mark buffer list, error = 0x%x", listError );
            eRetVal = OMX_ErrorUndefined;
         }
    } 
    
    return eRetVal;
    
}  /* end of function qomx_PortAddMarkBuffer */


/*==========================================================================

         FUNCTION:      qomx_PortGetMarkBufferInfo

         DESCRIPTION:
                        This function sends a mark buffer MMI command to 
                        device.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtx    - pointer to port context structure                                      
            @param[in]  pMark       - Mark data and target component information.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/

OMX_ERRORTYPE qomx_PortGetMarkBufferInfo
    (
      OMX_IN QOMX_PortContextType  *pPortCtx,
      OMX_IN OMX_MARKTYPE          *pMark 
    )
{
     OMX_ERRORTYPE        eRetVal   = OMX_ErrorNone;
     QOMX_MarkBufferList *pListEntry;
     QMM_ListLinkType     *link;    
    
    if (1 != qmm_ListIsEmpty ( &pPortCtx->MarkBufFullList ) )
    {
        if ( QMM_LIST_ERROR_NONE != qmm_ListPopFront( &pPortCtx->MarkBufFullList, &link ) )
        {
           eRetVal = OMX_ErrorUndefined;
        }
        else
        {
           pListEntry = (QOMX_MarkBufferList *)link;
           
           QOMX_CMPNT_MEM_COPY( pMark, &pListEntry->markBuffer, sizeof(OMX_MARKTYPE) );
           
           QOMX_CMPNT_MEM_SET(&pListEntry->markBuffer, 0, sizeof(OMX_MARKTYPE));
           
           if ( QMM_LIST_ERROR_NONE != qmm_ListPushRear( &pPortCtx->MarkBufEmptyList, link ) )
           {
              eRetVal = OMX_ErrorUndefined;
           }
        }
    }
    
    return eRetVal;
    
} /* end of function qomx_PortGetMarkBufferInfo */

/*==========================================================================

         FUNCTION:      qomx_PortMarkBuffer

         DESCRIPTION:
                        Refer to OMX_SendCommand in OMX_Core.h or the OMX
                        IL specification for details on the OMX_CommandMarkBuffer
                        command.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nPortIndex  - Index for the port on which method 
                                      need to be executed.
            @param[in]  pMark       - Mark data and target component information.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortMarkBuffer
(
   OMX_IN   OMX_HANDLETYPE          hPortCtnr,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_IN   OMX_MARKTYPE           *pMark
)
{
   OMX_ERRORTYPE           eRetVal   = OMX_ErrorNone;
   QOMX_PortContainerType *pPortCtnr = ( QOMX_PortContainerType * ) hPortCtnr;
   QOMX_PortContextType   *pPortCtx;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "qomx_PortMarkBuffer,"
      " nPortIndex = 0x%x", nPortIndex );

   if( NULL == pMark ) 
   {
      QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Mark is NULL,"
         " nPortIndex = 0x%x", nPortIndex );

      /**---------------------------------------------------------------------
         Mark is NULL.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else
   {
      if( OMX_ALL == nPortIndex )
      {
         OMX_U32  i;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Mark ALL" );

         /**------------------------------------------------------------------
            Copy Mark data on all ports.
         -------------------------------------------------------------------*/
         for( i = 0; i < pPortCtnr->nNumPorts; i++ )
         {
            pPortCtx = & ( pPortCtnr->paPortCtx[ i ] );

            if ( PORT_TUNNELING_VENDOR == pPortCtx->eTunneling )
            {
                /**-----------------------------------------------------------
                   Send MMI mark buffer command to vendor tunneled device.
                ------------------------------------------------------------*/
                eRetVal = qomx_VendorTunnel_PortMarkBufferCommand(
                                pPortCtnr->pCommonRef, nPortIndex, pMark );

            }
            else
            {
                /**-----------------------------------------------------------
                   Add mark to port list.
                ------------------------------------------------------------*/
               eRetVal = qomx_PortAddMarkBuffer( pPortCtnr->pCommonRef, pPortCtx, pMark );
            }
         }
      }
      else 
      {
         /**------------------------------------------------------------------
            Get the port context based on the given index.
         -------------------------------------------------------------------*/
         eRetVal = qomx_PortGetContext( pPortCtnr, nPortIndex, & pPortCtx );

         if( OMX_ErrorNone == eRetVal )
         {
            if ( PORT_TUNNELING_VENDOR == pPortCtx->eTunneling )
            {
                /**-----------------------------------------------------------
                   Send MMI mark buffer command to vendor tunneled device.
                ------------------------------------------------------------*/
                eRetVal = qomx_VendorTunnel_PortMarkBufferCommand(
                                pPortCtnr->pCommonRef, nPortIndex, pMark );
            }
            else
            {
                /**-----------------------------------------------------------
                   Add mark to port list.
                ------------------------------------------------------------*/
                eRetVal = qomx_PortAddMarkBuffer( pPortCtnr->pCommonRef, pPortCtx, pMark);
            }
         }
         else
         {
            QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Get port context failed"
               ", nPortIndex = 0x%x", nPortIndex );
         }

      }

   }

   return ( eRetVal );

} /* end of function qomx_PortMarkBuffer */


/*==========================================================================

         FUNCTION:      qomx_PortDeviceEventHandler

         DESCRIPTION:
                        This function is used by the component to send port
                        specific events to the port event handler.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param [in] nEventCode  - Unique event code which came from
                                      the device.
            @param [in] nEventStatus- Status of the event.
            @param [in] nParamSize  - Size in bytes for the event related
                                      data which is pointed by the payload.
            @param [in] pParam      - Event related payload.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortDeviceEventHandler
(
   OMX_IN   OMX_HANDLETYPE          hPortCtnr,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
)
{
   OMX_ERRORTYPE              eRetVal           = OMX_ErrorNone;
   OMX_BOOL                   bValidPortEvent   = OMX_FALSE;
   OMX_U32                    nPortIndex        = 0;
   QOMX_PortContainerType    *pPortCtnr
      = ( QOMX_PortContainerType * ) hPortCtnr;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pPortCtnr->pCommonRef, "qomx_PortDeviceEventHandler,"
      " nEventCode = 0x%x, nEventStatus = 0x%x", nEventCode, nEventStatus );

   /**------------------------------------------------------------------------
      Check if this is port specific message.
   -------------------------------------------------------------------------*/
   switch( nEventCode ) 
   {
   case MMI_RESP_EMPTY_THIS_BUFFER:
      {
         MMI_BufferDoneMsgType *bufDoneMsg
                  = ( MMI_BufferDoneMsgType * )pParam;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_LOW( pPortCtnr->pCommonRef, "MMI_RESP_EMPTY_THIS_BUFFER,"
            " event." );

         /**------------------------------------------------------------------
            Validate buffer done message.
         -------------------------------------------------------------------*/
         if( ( NULL != bufDoneMsg ) 
            && ( nParamSize == sizeof( MMI_BufferDoneMsgType ) ) )
         {
            nPortIndex = bufDoneMsg->pBufferHdr->nInputPortIndex;
            bValidPortEvent = OMX_TRUE;

         }
         else
         {
            QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Invalid parameters in"
               "response." );

         }

      }

      break;

   case MMI_RESP_FILL_THIS_BUFFER:
      {
         MMI_BufferDoneMsgType *bufDoneMsg
                  = ( MMI_BufferDoneMsgType * )pParam;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_LOW( pPortCtnr->pCommonRef, "MMI_RESP_FILL_THIS_BUFFER,"
            " event." );

         /**------------------------------------------------------------------
            Validate buffer done message.
         -------------------------------------------------------------------*/
         if( ( NULL != bufDoneMsg ) 
            && ( nParamSize == sizeof( MMI_BufferDoneMsgType ) ) )
         {
            nPortIndex = bufDoneMsg->pBufferHdr->nOutputPortIndex;
            bValidPortEvent = OMX_TRUE;

         }
         else
         {
            QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Invalid parameters in"
               "response." );

         }

      }
    
      break;

   case MMI_EVT_VENDORTUNNEL_PORT_MARK_BUFFER:
	  {
	     QOMX_PortContextType *pPortCtx;
         MMI_VendorTunnelMarkBufferMsgType *pMarkBufMsg
                  = ( MMI_VendorTunnelMarkBufferMsgType * )pParam;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_LOW( pPortCtnr->pCommonRef,
            "VENDORTUNNEL_MARK_BUFFER response." );

         /**------------------------------------------------------------------
            Validate mark buffer message.
         -------------------------------------------------------------------*/
         if( ( NULL != pMarkBufMsg ) 
            && ( nParamSize == sizeof( MMI_VendorTunnelMarkBufferMsgType ) ) )
         {
            nPortIndex = pMarkBufMsg->nPortIndex;
			if( OMX_ErrorNone == qomx_PortGetContext( 
                                       pPortCtnr, nPortIndex, & pPortCtx ) )
			{
				if ( PORT_TUNNELING_VENDOR == pPortCtx->eTunneling )
				{
					bValidPortEvent = OMX_TRUE;

				}

			}

         }
         else
         {
            QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef,
               "Invalid VENDORTUNNEL_MARK_BUFFER event." );

         }

      }

	  break;

   case MMI_RESP_VENDORTUNNEL_PORT_MARK_BUFFER:
	  /* fall through */
   case MMI_EVT_VENDORTUNNEL_PORT_EOS:
	  {
	     QOMX_PortContextType *pPortCtx;
		 MMI_PortMsgType *portMsg = ( MMI_PortMsgType * )pParam;
		 /*-----------------------------------------------------------------*/

         /**------------------------------------------------------------------
            Validate message.
         -------------------------------------------------------------------*/
         if( ( NULL != portMsg ) 
            && ( nParamSize == sizeof( MMI_PortMsgType ) ) )
         {
            nPortIndex = portMsg->nPortIndex;

			if( OMX_ErrorNone == qomx_PortGetContext( 
                                       pPortCtnr, nPortIndex, & pPortCtx ) )
			{
				if ( PORT_TUNNELING_VENDOR == pPortCtx->eTunneling )
				{
					bValidPortEvent = OMX_TRUE;

				}

			}

         }
         else
         {
            QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef,
               "Invalid Port Message." );

         }
	  }
      
      break;

   case MMI_RESP_ENABLE_PORT:
      /* fall through */
   case MMI_RESP_DISABLE_PORT:
      /* fall through */
   case MMI_RESP_FLUSH:
      /* fall through */
   case MMI_EVT_PORT_CONFIG_CHANGED:
      /* fall through */
   case MMI_EVT_NEED_BUFFER:
      {
         MMI_PortMsgType *portMsg = ( MMI_PortMsgType * )pParam;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Port message." );

         /**------------------------------------------------------------------
            Validate message.
         -------------------------------------------------------------------*/
         if( ( NULL != portMsg ) 
            && ( nParamSize == sizeof( MMI_PortMsgType ) ) )
         {
            nPortIndex = portMsg->nPortIndex;
            bValidPortEvent = OMX_TRUE;

         }
         else
         {
            QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Invalid parameters in"
               " port Message." );

         }

      }

      break;

   default:
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Unknown event." );

      }
      
      break;

   } /* end of switch( nEventCode ) */


   /**------------------------------------------------------------------------
      Get the port context based on the index if a valid port index is 
      found.
   -------------------------------------------------------------------------*/
   if( OMX_TRUE == bValidPortEvent )
   {
      QOMX_PortStateTableType   *pStTable;
      QOMX_PortContextType      *pPortCtx;
      /*--------------------------------------------------------------------*/

      if( OMX_ErrorNone == qomx_PortGetContext( 
                                       pPortCtnr, nPortIndex, & pPortCtx ) )
      {
         /**------------------------------------------------------------------
            Get the port state table now and check if it handles events.
         -------------------------------------------------------------------*/
         pStTable = qomx_PortCommon_GetStateTable( 
                                          pPortCtnr, pPortCtx->eState );

         if( NULL != pStTable->pfnEventHandler )
         {
            /**---------------------------------------------------------------
               Call the state table function now.
            ----------------------------------------------------------------*/
            eRetVal = pStTable->pfnEventHandler( pPortCtnr, pPortCtx, 
                              nEventCode, nEventStatus, nParamSize, pParam );

         }
         else
         {
            QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Current port state does"
               "not handle events." );

         }

      }
      else
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Get port context failed,"
            " nPortIndex = 0x%x", nPortIndex );

      }

   }
   else
   {
      QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Invalid port event." );

   }

   return( eRetVal );

} /* end of function qomx_PortDeviceEventHandler */


/*==========================================================================

         FUNCTION:      qomx_PortGuardIsTrue

         DESCRIPTION:
                        This function is used to evaluate a guard condition.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  eGuard      - Guard which need to be checked.

**//*    RETURN VALUE:
*//**       @return     
                        OMX_TRUE   - When guard condition is satisfied.
                        OMX_FALSE  - otherwise.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_BOOL    qomx_PortGuardIsTrue
( 
   OMX_IN   OMX_HANDLETYPE          hPortCtnr,
   OMX_IN   QOMX_GuardType          eGuard
)
{
   OMX_BOOL                eRetVal   = OMX_FALSE;
   QOMX_PortContainerType *pPortCtnr = ( QOMX_PortContainerType * ) hPortCtnr;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
      "qomx_PortGuardIsTrue, eGuard = 0x%x", ( OMX_U32 ) eGuard );

   switch( eGuard )
   {
   case QOMX_GUARD_ALL_PORTS_UNPOPULATED:
      {
         QOMX_PortContextType   *pPortCtx;
         QMM_ListHandleType     *pHBufHdrQueue;
         QMM_ListSizeType        nQueueSize;
         OMX_U32                 i;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
            "QOMX_GUARD_ALL_PORTS_UNPOPULATED guard check" );

         /**------------------------------------------------------------------
            Set Default value to true. If any of the port is not unpopulated 
            yet, return false.
         -------------------------------------------------------------------*/
         eRetVal = OMX_TRUE;

         for( i = 0; i < ( pPortCtnr->nNumPorts ) &&
                                       ( OMX_TRUE == eRetVal ); i++ )
         {
            /**---------------------------------------------------------------
               Get buffer header list.
            ----------------------------------------------------------------*/
            pPortCtx       = & ( pPortCtnr->paPortCtx[ i ] );
            pHBufHdrQueue  = & ( pPortCtx->hBufHdrQueue );

            /**---------------------------------------------------------------
               Set value to False if queue size is Non-Zero.
            ----------------------------------------------------------------*/
            if( ( QMM_LIST_ERROR_NONE != qmm_ListSize( 
                                             pHBufHdrQueue, &nQueueSize ) )
               || ( 0 != nQueueSize ) )
            {
               QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
                  "Populated port exists." );

               eRetVal = OMX_FALSE;

            }

         }

      }

      break;

   case QOMX_GUARD_ALL_ENABLED_PORTS_POPULATED:
      {
         QOMX_PortContextType   *pPortCtx;
         OMX_U32                 i;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
            "QOMX_GUARD_ALL_ENABLED_PORTS_POPULATED guard check" );

         /**------------------------------------------------------------------
            Set Default value to true. If any of the port is not populated 
            yet, return false.
         -------------------------------------------------------------------*/
         eRetVal = OMX_TRUE;

         for( i = 0; i < ( pPortCtnr->nNumPorts ) &&
                                       ( OMX_TRUE == eRetVal ); i++ )
         {
            pPortCtx = & ( pPortCtnr->paPortCtx[ i ] );

            if ( ( PORT_TUNNELING_VENDOR == pPortCtx->eTunneling )
				&& ( QOMX_StatePortEnabledPopulating == pPortCtx->eState ) 
				&&  ( OMX_TRUE == pPortCtx->bVendorTunnelPeerLoadedToIdle ) )
			{
			   /**------------------------------------------------------------
			      For vendor-tunneled port, it will be populated after MMI
				  load resources command returns success. MMI load resources
				  command will be issued only if it has received loaded->idle 
				  acceptance signal from its peer port.
			   -------------------------------------------------------------*/
			   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
               "Vendor tunneled port will be populated after "
				   "MMI load resources command returns/responds success. "
				   "nPortIndex = %d.", 
				   pPortCtx->portDef.nPortIndex );

			}
            else if( ( QOMX_StatePortEnabledUnpopulated == pPortCtx->eState )
               || ( QOMX_StatePortEnabledPopulating == pPortCtx->eState ) )
            {
			   /**------------------------------------------------------------
                  Set value to False if port is enabled but unpopulated
                  or populating.
			   -------------------------------------------------------------*/
               QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
                  "Partially populated port exists." );

               eRetVal = OMX_FALSE;

            }

         }

      }

      break;

   case QOMX_GUARD_ALL_ENABLED_TUNNELED_PORTS_IDLE:
      {
         QOMX_PortContextType   *pPortCtx;
         OMX_U32                 i;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
            "QOMX_GUARD_ALL_ENABLED_PORTS_IDLE guard check." );

         /**------------------------------------------------------------------
            Set Default value to true. If any of the port is not populated 
            yet, return false.
         -------------------------------------------------------------------*/
         eRetVal = OMX_TRUE;

         for( i = 0; i < ( pPortCtnr->nNumPorts ) &&
                                       ( OMX_TRUE == eRetVal ); i++ )
         {
            /**---------------------------------------------------------------
               Get buffer header list.
            ----------------------------------------------------------------*/
            pPortCtx = & ( pPortCtnr->paPortCtx[ i ] );

            /**---------------------------------------------------------------
               Set value to False if port is enabled but unpopulated
               or populating.
            ----------------------------------------------------------------*/
            if( ( PORT_TUNNELING_VENDOR != pPortCtx->eTunneling )
				&& ( NULL != pPortCtx->hTunneledComp )
				&& ( 0 != pPortCtx->nBuffersWithClient ) )
            {
               QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
                  "Tunneled port buffers still outstanding, port not idle." );

               eRetVal = OMX_FALSE;

            }

         }

      }

      break;

   case QOMX_GUARD_ALL_ENABLED_VTPORTS_PEER_ACCEPTS_MMISTART:
	  {
		 QOMX_PortContextType   *pPortCtx;
         OMX_U32                 i;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
            "QOMX_GUARD_ALL_ENABLED_VTPORTS_PEER_ACCEPTS_MMISTART guard check.");

         /**------------------------------------------------------------------
            Set Default value to true. If any of the vendor tunneled ports has 
            not received peer acknowlegment yet for MMI START, return false.
         -------------------------------------------------------------------*/
         eRetVal = OMX_TRUE;

         for( i = 0; i < ( pPortCtnr->nNumPorts ) &&
                                       ( OMX_TRUE == eRetVal ); i++ )
         {
            pPortCtx = & ( pPortCtnr->paPortCtx[ i ] );

            /**---------------------------------------------------------------
               Set value to False if the vendor-tunneled port has not received
			   peer port acknowlegment for MMI START.
            ----------------------------------------------------------------*/
            if( ( PORT_TUNNELING_VENDOR == pPortCtx->eTunneling )
				&& ( QOMX_StatePortEnabledRunning == pPortCtx->eState ) 
				&& ( NULL != pPortCtx->hTunneledComp )
				&& ( OMX_FALSE == pPortCtx->bTunnelPeerAcceptsBufferExchange ) 
			  )
            {
               QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
                  "Vendor-tunneled peer port has not sent "
						"acknowlegment for MMI START." );

               eRetVal = OMX_FALSE;

            }

         }
		 
	  }

	  break;

   default:
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Unknown guard." );

      }

      break;

   }

   return( eRetVal );

} /* end of function qomx_PortGuardIsTrue */


/*==========================================================================

         FUNCTION:      qomx_PortDomainInit

         DESCRIPTION:
                        This function initializes the input and output ports
                        of a specific domain type.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pConfig     - Pointer to the object of IL component
                                      configuration.
            @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  paDomainCtx - Pointer to base of port domain array.
            @param[in]  eDomain     - Port group domain.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortDomainInit
(
   OMX_IN   QOMX_CmpntConfig       *pConfig,
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *paDomainCtx,
   OMX_IN   OMX_PORTDOMAINTYPE      eDomain
)
{
   OMX_ERRORTYPE           eRetVal           = OMX_ErrorNone;
   QOMX_PortContextType   *paDirBase         = paDomainCtx;
   QOMX_PortConfig        *pPortCtnrConfig   = NULL;
   QOMX_PortConfig        *pPortILConfig     = NULL;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "qomx_PortDomainInit" );

   /**------------------------------------------------------------------------
      Get the port array base for this domain.
   -------------------------------------------------------------------------*/
   switch( eDomain )
   {
   case OMX_PortDomainAudio:
      {
         pPortCtnrConfig = & ( pPortCtnr->audioDomain );
         pPortILConfig   = & ( pConfig->audioDomain );

      }

      break;

   case OMX_PortDomainVideo:
      {
         pPortCtnrConfig = & ( pPortCtnr->videoDomain );
         pPortILConfig   = & ( pConfig->videoDomain );

      }

      break;

   case OMX_PortDomainImage:
      {
         pPortCtnrConfig = & ( pPortCtnr->imageDomain );
         pPortILConfig   = & ( pConfig->imageDomain );

      }

      break;

   default:
      {
         pPortCtnrConfig = & ( pPortCtnr->otherDomain );
         pPortILConfig   = & ( pConfig->otherDomain );

      }

      break;

   } /* end of switch( eDomain ) */


   /**------------------------------------------------------------------------
      Copy port configuration in container memory.
   -------------------------------------------------------------------------*/
   QOMX_CMPNT_MEM_COPY( 
                  pPortCtnrConfig, pPortILConfig, sizeof( QOMX_PortConfig ) );

   /**------------------------------------------------------------------------
      Initialize input ports.
   -------------------------------------------------------------------------*/
   if( 0 != pPortCtnrConfig->nNumInputPorts )
   {
      QOMX_MSG_L_MED( pPortCtnr->pCommonRef, 
         "Initialize input ports." );

      eRetVal = qomx_PortGroupInit ( pPortCtnr, paDirBase, 
                           pPortCtnrConfig, OMX_DirInput, eDomain );

      /**---------------------------------------------------------------------
         Move port array base to point to next set of ports.
      ----------------------------------------------------------------------*/
      paDirBase += ( pPortCtnrConfig->nNumInputPorts );

   }

   /**------------------------------------------------------------------------
      Initialize input ports.
   -------------------------------------------------------------------------*/
   if( ( OMX_ErrorNone == eRetVal )
      && ( 0 != pPortCtnrConfig->nNumOutputPorts ) )
   {
      QOMX_MSG_L_MED( pPortCtnr->pCommonRef, 
         "Initialize output ports." );

      eRetVal = qomx_PortGroupInit ( pPortCtnr, paDirBase, 
                           pPortCtnrConfig, OMX_DirOutput, eDomain );

   }

   return( eRetVal );

} /* end of function qomx_PortDomainInit */


/*==========================================================================

         FUNCTION:      qomx_PortGroupInit

         DESCRIPTION:
                        This function gets parameters from the device and 
                        initializes a group of ports characterized by the 
                        direction and domain.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  paGroupCtx  - Pointer to base of port group array.
            @param[in]  pPortConfig - Pointer to the configuration object
                                      for this domain ports.
            @param[in]  eDir        - Domain for the given port group.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortGroupInit
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *paGroupCtx,
   OMX_IN   QOMX_PortConfig        *pPortConfig,
   OMX_IN   OMX_DIRTYPE             eDir,
   OMX_IN   OMX_PORTDOMAINTYPE      eDomain
)
{
   OMX_ERRORTYPE                    eRetVal  = OMX_ErrorNone;
   QOMX_PortContextType            *pPortCtx;
   OMX_PARAM_PORTDEFINITIONTYPE    *pPortDef;
   OMX_U32                          nPortBase;
   OMX_U8                           nPorts;
   OMX_U8                           i;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "qomx_PortGroupInit" );

   /**------------------------------------------------------------------------
      Get number of ports, and port base based on the direction.
   -------------------------------------------------------------------------*/
   if( OMX_DirInput == eDir )
   {
      nPortBase = pPortConfig->nPortStart;
      nPorts    = pPortConfig->nNumInputPorts;

   }
   else
   {
      nPortBase = pPortConfig->nPortStart + pPortConfig->nNumInputPorts;
      nPorts    = pPortConfig->nNumOutputPorts;

   }

   /**------------------------------------------------------------------------
      Retrieve port specific information from device and set in individual
      port context.
   -------------------------------------------------------------------------*/
   for( i = 0; i < nPorts; i++ )
   {
      /**---------------------------------------------------------------------
         Get port context.
      ----------------------------------------------------------------------*/
      pPortCtx = & ( paGroupCtx[ i ] );

      pPortCtx->portDef.nPortIndex = ( nPortBase + i );

      QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Refresh port definition for"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Get latest port definition from device and update.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_PortCommon_UpdatePortDefinition( 
                                          pPortCtnr->pCommonRef, pPortCtx );

      /**---------------------------------------------------------------------
         Set rest of the port definition properties now.
      ----------------------------------------------------------------------*/
      if( OMX_ErrorNone == eRetVal )
      {
         QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Set remaining port def."
            " now, nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         pPortDef        = & ( pPortCtx->portDef );

         QOMX_SET_STRUCT_OBJ( ( *pPortDef ), OMX_PARAM_PORTDEFINITIONTYPE );

         pPortDef->eDir               = eDir;
         pPortDef->bEnabled           = OMX_TRUE;
         pPortDef->bPopulated         = OMX_FALSE;
         pPortDef->eDomain            = eDomain;

         pPortCtx->nBuffersWithDevice = 0;
         pPortCtx->nBuffersWithClient = 0;
         pPortCtx->bAlterCmdFinished  = OMX_TRUE;
         pPortCtx->bAlterRespPending  = OMX_FALSE;
         pPortCtx->bAlterCmdPending   = OMX_FALSE;
         pPortCtx->eBufferSupplier    = OMX_BufferSupplyUnspecified;

         pPortCtx->hTunneledComp      = NULL;
         pPortCtx->nTunneledPort      = 0;
         pPortCtx->eTunneling         = PORT_TUNNELING_DISABLED;

         pPortCtx->bTunnelPeerIsQOMX                = OMX_FALSE;
         pPortCtx->bTunnelPeerAcceptsUseBuffer      = OMX_TRUE;
         pPortCtx->bTunnelPeerAcceptsBufferExchange = OMX_TRUE;
         pPortCtx->bTunnelPeerAcceptsFreeBuffer     = OMX_TRUE;
         pPortCtx->bVendorTunnelPeerLoadedToIdle    = OMX_TRUE;
         pPortCtx->bVendorTunnelPeerPortEnable      = OMX_TRUE;

         /**------------------------------------------------------------------
            All ports are default enabled with no buffers. State would move
            to populating / populated based on the buffer requirements when
            component transitions to Idle state.
         -------------------------------------------------------------------*/
         pPortCtx->eState            = QOMX_StatePortEnabledUnpopulated;

         /**------------------------------------------------------------------
            Initialize buffer queue.
         -------------------------------------------------------------------*/
         ( void ) qmm_ListInit( & ( pPortCtx->hBufHdrQueue ) );

         ( void ) qmm_ListInit( & ( pPortCtx->MarkBufEmptyList ) );

         ( void ) qmm_ListInit( & ( pPortCtx->MarkBufFullList ) );

      }

   }

   return( eRetVal );

} /* end of function qomx_PortGroupInit */


/*==========================================================================

         FUNCTION:      qomx_ValidateILPortConfig

         DESCRIPTION:
                        This function is used to validate port config data
                        passed to the port get handle function.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[in]  pConfig     - Pointer to the object of IL component
                                      configuration.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on successful validation.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_ValidateILPortConfig
(
   OMX_IN   QOMX_CommonRefType  *pCommonRef,
   OMX_IN   QOMX_CmpntConfig    *pConfig
)
{
   OMX_ERRORTYPE  eRetVal        = OMX_ErrorNone;
   OMX_U32        nMaxPortIndex  = 0;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_ValidateILPortConfig" );

   /**------------------------------------------------------------------------
      Check if ports for atleast one domain are specified.
   -------------------------------------------------------------------------*/
   if( ( OMX_FALSE == pConfig->audioDomain.bConfigSet )
      && ( OMX_FALSE == pConfig->videoDomain.bConfigSet )
      && ( OMX_FALSE == pConfig->imageDomain.bConfigSet )
      && ( OMX_FALSE == pConfig->otherDomain.bConfigSet ) )
   {
      QOMX_MSG_L_ERROR( pCommonRef,
         "All bConfigSet are set to OMX_FALSE." );

      /**------------------------------------------------------------------
         No domain specified.
      -------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }

   /**------------------------------------------------------------------------
      Audio domain port configuration validation. 
   -------------------------------------------------------------------------*/
   if( OMX_TRUE == pConfig->audioDomain.bConfigSet )
   {
      QOMX_MSG_L_MED( pCommonRef, "Validating audio domain config" );

      if( ( 0 == pConfig->audioDomain.nNumInputPorts ) 
         && ( 0 == pConfig->audioDomain.nNumOutputPorts ) )
      {
         QOMX_MSG_L_ERROR( pCommonRef, 
            "Input and output ports are set to 0." );

         /**------------------------------------------------------------------
            Both input and output ports are specified as 0.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorBadParameter;

      }
      else
      {
         /**------------------------------------------------------------------
            Set Maximum port index found in audio domain.
         -------------------------------------------------------------------*/
         nMaxPortIndex = ( pConfig->audioDomain.nPortStart )
                          + ( pConfig->audioDomain.nNumInputPorts )
                          + ( pConfig->audioDomain.nNumOutputPorts );

      }

   }


   /**------------------------------------------------------------------------
      Video domain port configuration validation.
   -------------------------------------------------------------------------*/
   if( ( OMX_ErrorNone == eRetVal )
       && ( OMX_TRUE == pConfig->videoDomain.bConfigSet ) )
   {
      QOMX_MSG_L_MED( pCommonRef, "Validating video domain config" );

      if( ( 0 == pConfig->videoDomain.nNumInputPorts ) 
         && ( 0 == pConfig->videoDomain.nNumOutputPorts ) )
      {
         QOMX_MSG_L_ERROR( pCommonRef, 
            "Input and output ports are set to 0." );

         /**------------------------------------------------------------------
            Both input and output ports are specified as 0.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorBadParameter;

      }
      else if( pConfig->videoDomain.nPortStart < nMaxPortIndex )
      {
         QOMX_MSG_L_ERROR( pCommonRef, 
            "Video domain port start overlaps with prev. domain." );

         /**------------------------------------------------------------------
            Bad port indexes found for video domain. Overlapping with audio
            port numbers.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorBadPortIndex;

      }
      else
      {
         /**------------------------------------------------------------------
            Set Maximum port index found in video domain.
         -------------------------------------------------------------------*/
         nMaxPortIndex = ( pConfig->videoDomain.nPortStart )
                          + ( pConfig->videoDomain.nNumInputPorts )
                          + ( pConfig->videoDomain.nNumOutputPorts );

      }

   }


   /**------------------------------------------------------------------------
      Image domain port configuration validation.
   -------------------------------------------------------------------------*/
   if( ( OMX_ErrorNone == eRetVal )
       && ( OMX_TRUE == pConfig->imageDomain.bConfigSet ) )
   {
      QOMX_MSG_L_MED( pCommonRef, "Validating image domain config" );

      if( ( 0 == pConfig->imageDomain.nNumInputPorts ) 
         && ( 0 == pConfig->imageDomain.nNumOutputPorts ) )
      {
         QOMX_MSG_L_ERROR( pCommonRef, 
            "Input and output ports are set to 0." );

         /**------------------------------------------------------------------
            Both input and output ports are specified as 0.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorBadParameter;

      }
      else if( pConfig->imageDomain.nPortStart < nMaxPortIndex )
      {
         QOMX_MSG_L_ERROR( pCommonRef, 
            "Image domain port start overlaps with prev. domain." );

         /**------------------------------------------------------------------
            Bad port indexes found for image domain. Overlapping with audio
            or video port numbers.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorBadPortIndex;

      }
      else
      {
         /**------------------------------------------------------------------
            Set Maximum port index found in image domain.
         -------------------------------------------------------------------*/
         nMaxPortIndex = ( pConfig->imageDomain.nPortStart )
                          + ( pConfig->imageDomain.nNumInputPorts )
                          + ( pConfig->imageDomain.nNumOutputPorts );

      }

   }


   /**------------------------------------------------------------------------
      Other domain port configuration validation.
   -------------------------------------------------------------------------*/
   if( ( OMX_ErrorNone == eRetVal )
       && ( OMX_TRUE == pConfig->otherDomain.bConfigSet ) )
   {
      QOMX_MSG_L_MED( pCommonRef, "Validating other domain config" );

      if( ( 0 == pConfig->otherDomain.nNumInputPorts ) 
         && ( 0 == pConfig->otherDomain.nNumOutputPorts ) )
      {
         QOMX_MSG_L_ERROR( pCommonRef, 
            "Input and output ports are set to 0." );

         /**------------------------------------------------------------------
            Both input and output ports are specified as 0.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorBadParameter;

      }
      else if( pConfig->otherDomain.nPortStart < nMaxPortIndex )
      {
         QOMX_MSG_L_ERROR( pCommonRef, 
            "Other domain port start overlaps with prev. domain." );

         /**------------------------------------------------------------------
            Bad port indexes found for image domain. Overlapping with audio,
            video or image port numbers.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorBadPortIndex;

      }

   }

   return( eRetVal );

} /* end of function qomx_ValidateILPortConfig */


/*==========================================================================
         FUNCTION:      qomx_VendorTunnel_SetEnabledPortsPopulated

         DESCRIPTION:
                        This function is used to transition enabled vendor 
                        tunneled port to EnabledPopulated after load 
                        resource command succeeds; and signal peer if the 
                        port is supplier.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of common
									           reference.
		      @param[in]  hPortCtnr   - Handle to port container.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on successful validation.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void	qomx_VendorTunnel_SetEnabledPortsPopulated
( 
   OMX_IN   QOMX_CommonRefType  *pCommonRef,
   OMX_IN   OMX_HANDLETYPE       hPortCtnr
)
{
   QOMX_PortContainerType *pPortCtnr = ( QOMX_PortContainerType * ) hPortCtnr;
   QOMX_PortContextType   *pPortCtx;
   QDFC_ErrorType		      eErrVal = QDFC_ERROR_NONE;
   OMX_U32				      i;	
   /*-----------------------------------------------------------------------*/

   for( i = 0; i < ( pPortCtnr->nNumPorts ); i++ )
   {
	   pPortCtx = & ( pPortCtnr->paPortCtx[ i ] );
	   
	   if ( PORT_TUNNELING_VENDOR == pPortCtx->eTunneling )
	   {
         if ( QOMX_StatePortEnabledPopulating == pPortCtx->eState )
         {
			   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Vendor tunneled port "
                  "transition to EnabledPopulated; nPortIndex = 0x%x.", 
                  pPortCtx->portDef.nPortIndex );

			   /**---------------------------------------------------------------
			      Complete port state transition.
			   ----------------------------------------------------------------*/
			   ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
				   		        pPortCtx, QOMX_StatePortEnabledPopulated, 0 );

         }

         if ( QOMX_StatePortEnabledPopulated == pPortCtx->eState )
         {
            /**---------------------------------------------------------------
			      If enable port command is being processed, send response now.
			   ----------------------------------------------------------------*/
			   if( OMX_TRUE == pPortCtx->bAlterRespPending )
			   {
				   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Enabled command "
                     "completed." );

				   pPortCtx->bAlterRespPending = OMX_FALSE;

				   ( void ) qomx_CmpntCmdComplete( pCommonRef, 
                                       OMX_CommandPortEnable,
                                       pPortCtx->portDef.nPortIndex, NULL );

			   }

            if ( QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx ) ) 
			   {
				   /**------------------------------------------------------------
				      If this is a vendor-tunneled buffer supplier port, signal
				      peer that the supplier port has finished Loaded->Idle 
				      transition.
			      -------------------------------------------------------------*/
				   eErrVal = qdfc_EnqueueArg6Function( 
						   pPortCtnr->pCommonRef->hDfc,
						   ( qfc_Arg6FpType ) ( qomx_PortCommon_SignalTunnelPeer ),
				    	   ( QDFC_ArgType ) pPortCtx->hTunneledComp,
						   ( QDFC_ArgType ) pPortCtx->nTunneledPort,
                     ( QDFC_ArgType ) OMX_PORTSTATUS_VTACCEPTSLOADEDTOIDLE,
						   ( QDFC_ArgType ) 0,
						   ( QDFC_ArgType ) 0,
						   ( QDFC_ArgType ) 0 );

			   }

			   if( QDFC_ERROR_NONE != eErrVal )
			   {
				   QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef,
                  "DFC EnQueue error = %d. Event dropped", eErrVal );

			   }

         }

		}

   }

} /* end of function qomx_VendorTunnel_SetEnabledPortsPopulated */


/*==========================================================================

         FUNCTION:      qomx_PortFreeStrayBuffers

         DESCRIPTION:
                        This function is called during component deinit and
                        aims to free any buffers and buffer headers that
                        IL client failed to free.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.

**//*    RETURN VALUE:
*//**       @return     None                        

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortFreeStrayBuffers
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr
)
{
   QOMX_PortContainerType    *pPortCtnr
      = ( QOMX_PortContainerType * ) hPortCtnr;
   
   QOMX_PortContextType      *pPortCtx;
   QMM_ListHandleType        *pHBufHdrQueue;
   QMM_ListLinkType          *pQueueLink = NULL;
   QOMX_PortBufferHdrLink    *pBufHdrLink;
   OMX_U32                    i;
   OMX_ERRORTYPE              eRetVal = OMX_ErrorNone;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "qomx_PortFreeStrayBuffers" );

   /**------------------------------------------------------------------------
      Iterate through all the ports and free any non-freed buffers.
   -------------------------------------------------------------------------*/
   for( i = 0; i <  pPortCtnr->nNumPorts; i++ )
   {
      pPortCtx = & ( pPortCtnr->paPortCtx[ i ] ); 
      pHBufHdrQueue = & ( pPortCtx->hBufHdrQueue );

      if( ! qmm_ListIsEmpty( pHBufHdrQueue ) )
      {
         /**------------------------------------------------------------------
            Port still has buffers that need freeing.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Port has stray buffers! "
                           "Will attempt cleanup now." );

         while( QMM_LIST_ERROR_NONE == 
                qmm_ListPeekFront( pHBufHdrQueue, & pQueueLink ) )
         {            
            /**---------------------------------------------------------------
               Free this buffer.
            ----------------------------------------------------------------*/
            pBufHdrLink = ( QOMX_PortBufferHdrLink * ) pQueueLink;

            eRetVal = qomx_PortCommon_FreeBuffer( pPortCtnr, pPortCtx, 
                                                  pBufHdrLink->pBufferHdr );

            if( OMX_ErrorNone != eRetVal )
            {
               QMM_ListLinkType          *pQueueLinkCur = NULL;

               QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, 
                                 "Failure during freeing." );

               /**------------------------------------------------------------
                  If failed and front element not removed, we need to keep 
                  moving by removing it ourself.
               -------------------------------------------------------------*/
               if( QMM_LIST_ERROR_NONE == qmm_ListPeekFront( pHBufHdrQueue, 
                                                           & pQueueLinkCur ) )
               {
                  if ( pQueueLinkCur == pQueueLink )
                  {
                     qmm_ListPopFront( pHBufHdrQueue, & pQueueLink );
                  }
               }
            }

         }
         
         if( ! qmm_ListIsEmpty( pHBufHdrQueue ) )
         {
            /**---------------------------------------------------------------
               This should not happen. We can only log an error at this point.
            ----------------------------------------------------------------*/
            QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, 
                              "Could not finish cleanup!" );
         }

      }

   }   
   
} /* end of function qomx_PortFreeStrayBuffers */
