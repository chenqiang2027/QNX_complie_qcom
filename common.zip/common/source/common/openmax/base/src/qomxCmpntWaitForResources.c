/*========================================================================

*//** @file qomxCmpntWaitForResources.c 

@par FILE SERVICES:       
      Component WaitForResources State Implementation File.

      This file implements all the methods which are applicable for
      WaitForResources state.
      
      Main function is Send Command. Functions which are common for all
      states are implemented in the common functions table.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2018 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCmpntWaitForResources.c#1 $ 
when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
08/08/11   dm     Hardware critical error handling.
07/22/10   zm     Add component handle in each base class logging message.
06/10/10   dm     Added return type in event handler.
10/29/09   dm     Allow tunneling on disabled ports in any OMX state.
10/29/09   dm     Disallow port commands in component transitional states.
09/30/09   dm     Split component states.
08/05/09   dm     Removed hack.
06/04/09   dm     Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxCmpntCommon.h"
#include "qomxPortUtils.h"

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/**
 * 
 * Forward declaration for the functions statically defined in this file.
 * 
 */

static void    qomx_CmpntWaitForResources_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
);

static void    qomx_CmpntWaitForResources_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
   
);

static OMX_ERRORTYPE    qomx_CmpntWaitForResources_SendCommand
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE         eCmd,
   OMX_IN   OMX_U32                 nParam,
   OMX_IN   OMX_PTR                 pCmdData
);

static OMX_ERRORTYPE    qomx_CmpntWaitForResources_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
);

static void    qomx_CmpntWaitForResources_ResourcesAvailable
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);

static OMX_ERRORTYPE    qomx_CmpntWaitForResources_SetStateLoaded
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_CmpntWaitForResources_LoadStateTable

         DESCRIPTION:
                        This function will load the component state table
                        supported by the WaitForResources state in the object
                        of state table being passed.
            
@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable - Pointer to the state primitive table
                                   object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntWaitForResources_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      component is in QOMX_StateWaitForResources state. NULL entry indicates
      that the specific function call is not allowed in this state, thus
      component API should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/   
   pStTable->GetComponentVersion    = qomx_CmpntCommon_GetComponentVersion;
   pStTable->SendCommand            = qomx_CmpntWaitForResources_SendCommand;
   pStTable->GetParameter           = qomx_CmpntCommon_GetParameter;
   pStTable->SetParameter           = qomx_CmpntCommon_SetParameter;
   pStTable->GetConfig              = qomx_CmpntCommon_GetConfig;
   pStTable->SetConfig              = qomx_CmpntCommon_SetConfig;
   pStTable->GetExtensionIndex      = qomx_CmpntCommon_GetExtensionIndex;
   pStTable->GetState               = qomx_CmpntCommon_GetState;
   pStTable->ComponentTunnelRequest = NULL;
   pStTable->UseBuffer              = NULL;
   pStTable->AllocateBuffer         = NULL;
   pStTable->FreeBuffer             = qomx_CmpntCommon_FreeBuffer;
   pStTable->EmptyThisBuffer        = NULL;
   pStTable->FillThisBuffer         = NULL;
   pStTable->SetCallbacks           = NULL;
   pStTable->ComponentDeInit        = qomx_CmpntCommon_ComponentDeInit;
   pStTable->UseEGLImage            = NULL;
   pStTable->ComponentRoleEnum      = qomx_CmpntCommon_ComponentRoleEnum;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler        
                        = qomx_CmpntWaitForResources_DeviceEventHandler;
   
   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler
                        = qomx_CmpntWaitForResources_StateEntryHandler;
   pStTable->pfnExitHandler
                        = qomx_CmpntWaitForResources_StateExitHandler;
   
   return;

} /* end of function qomx_CmpntWaitForResources_LoadStateTable */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntWaitForResources_StateEntryHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateWaitForResources is entered. Entry into the 
                        state performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntWaitForResources_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   OMX_U32              nStatus     = MMI_S_EFAIL;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pCommonRef, 
      "Entering WaitForResources State, nEvent = 0x%x", nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pCmpntCtx->eMainState = QOMX_StateWaitForResources;
   pCmpntCtx->eOmxState  = OMX_StateWaitForResources;

   /**------------------------------------------------------------------------
      Invoke state change callback.
   -------------------------------------------------------------------------*/
   QOMX_MSG_L_MED( pCommonRef, 
            "Send OMX_StateWaitForResources transition callback." );

   ( void ) qomx_CmpntCommon_StateTransitionCallback( 
                                       pCmpntCtx, OMX_StateWaitForResources );

   /**------------------------------------------------------------------------
      Acknowledge device about component waiting on resources. Device will
      give notification when required resources are available.
   -------------------------------------------------------------------------*/
   nStatus = pCommonRef->device.pfnCmd (
                        pCommonRef->hFd, MMI_CMD_WAIT_FOR_RESOURCES, NULL );
   
   QOMX_MSG_L_HIGH( pCommonRef,
      "MMI_CMD_WAIT_FOR_RESOURCES status = 0x%x", nStatus );

   /**------------------------------------------------------------------------
      If wait for resource command finished synchronously, notify client
      about availability of the resources and move to transitional state
      LoadedToIdle which will check ports population status, wait for
      buffers and load resources.
   -------------------------------------------------------------------------*/
   if( MMI_S_COMPLETE == nStatus )
   {
      QOMX_MSG_L_HIGH( pCommonRef,
         "Wait for resources finished synchronously" );

      /**---------------------------------------------------------------------
         Call internal function to process resources.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntWaitForResources_ResourcesAvailable( pCmpntCtx );

   }
   else if( MMI_S_PENDING != nStatus )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Unexpected status in wait for resources"
         " response, nStatus = 0x%x, Move to Invalid state.", nStatus );

      /**---------------------------------------------------------------------
         Resouce wait request failed, put component in invalid state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx,
                  QOMX_StateInvalid, qomx_GetQOMXBaseEventCode( nStatus ) );

   }

   return;

} /* end of function qomx_CmpntWaitForResources_StateEntryHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntWaitForResources_StateExitHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateWaitForResources is exited. Exit from this
                        state performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntWaitForResources_StateExitHandler
(   
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent 
)
{
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Exiting WaitForResources State, nEvent = 0x%x", nEvent );

   return;
   
} /* end of function qomx_CmpntWaitForResources_StateExitHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntWaitForResources_SendCommand

         DESCRIPTION:
*//**                   This function is called every time when Send command
                        is invoked in QOMX_StateWaitForResources state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.
            @param[in]  eCmd        - Command which is being invoked.
            @param[in]  nParam      - Parameter 1. Refer OMX Spec.
            @param[in]  pCmdData    - Command payload. Refer OMX Spec.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntWaitForResources_SendCommand 
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE            eCmd,
   OMX_IN   OMX_U32                    nParam,
   OMX_IN   OMX_PTR                    pCmdData
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/
   
   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntWaitForResources_SendCommand,"
      " eCmd = 0x%x, nParam = 0x%x", eCmd, nParam );

   /**------------------------------------------------------------------------
      Check the command type.
   -------------------------------------------------------------------------*/
   switch( eCmd ) 
   {
      /**--------------------------------------------------------------------- 
         Component specific commands which are allowed in this state
      ----------------------------------------------------------------------*/
      case OMX_CommandStateSet:
         {
            if( OMX_StateLoaded == nParam ) 
            {
               QOMX_MSG_L_MED( pCommonRef, "Set Loaded state." );

               /**------------------------------------------------------------
                  Call internal function to do steps to move to Loaded state.
               -------------------------------------------------------------*/
               eRetVal = qomx_CmpntWaitForResources_SetStateLoaded(
                                                               pCmpntCtx );

            }
            else 
            {
               /**------------------------------------------------------------
                  Call common routine to handle set state command.
               -------------------------------------------------------------*/
               ( void ) qomx_CmpntCommon_CommandStateSet( pCmpntCtx, nParam );

            }

         }

         break;

      /**---------------------------------------------------------------------
         Port specific commands which allowed.
      ----------------------------------------------------------------------*/
      case OMX_CommandPortDisable:
         {
            QOMX_MSG_L_MED( pCommonRef, "Disable Port = 0x%x", nParam );

            /**---------------------------------------------------------------
               Send port disable request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortDisable( pCmpntCtx->hPortCtnr, nParam );

         }

         break;

      case OMX_CommandPortEnable:
         {
            QOMX_MSG_L_MED( pCommonRef, "Enable Port = 0x%x", nParam );

            /**---------------------------------------------------------------
               Send port enable request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortEnable( pCmpntCtx->hPortCtnr, nParam );

         }

         break;

      default:
         {
            /**---------------------------------------------------------------
               Call common routine to handle rest of the commands.
            ----------------------------------------------------------------*/
            eRetVal = qomx_CmpntCommon_SendCommand(
                                          pCmpntCtx, eCmd, nParam, pCmdData );

         }

         break;

   } /* end of switch( eCmd ) */

   return( eRetVal );
   
} /* end  of function qomx_CmpntWaitForResources_SendCommand */


/*==========================================================================

         FUNCTION:      qomx_CmpntWaitForResources_DeviceEventHandler

         DESCRIPTION:
*//**                   This function is called when the device want to 
                        communicate with the component when it is in 
                        WaitForResources state.
         
@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx      -  Context structure pointer.
            @param[in]  nEventCode     -  Event code.
            @param[in]  nEventStatus   -  Event status.
            @param[in]  nParamSize     -  Payload length.
            @param[in]  pParam         -  Payload corresponding to this event.

*//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None
                                                                        
===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntWaitForResources_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_CmpntWaitForResources_DeviceEventHandler, nEventCode = 0x%x,"
         " nEventStatus = 0x%x", nEventCode, nEventStatus );

   /**------------------------------------------------------------------------
      If wait for resource command finished successfully, notify client
      about availability of the resources and move to transitional state
      LoadedToIdle which will check ports population status, wait for
      buffers and load resources.
   -------------------------------------------------------------------------*/
   if( MMI_RESP_WAIT_FOR_RESOURCES == nEventCode ) 
   {
      QOMX_MSG_L_HIGH( pCommonRef, 
         "MMI_RESP_WAIT_FOR_RESOURCES event." );

      if ( MMI_S_COMPLETE == nEventStatus )
      {
         QOMX_MSG_L_HIGH( pCommonRef, "Resources available." );

         /**------------------------------------------------------------------
            Call internal function to process resources.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntWaitForResources_ResourcesAvailable( pCmpntCtx );

      }
      else
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Unexpected status in wait for"
            "resources response, nStatus = 0x%x, Move to Invalid state.",
            nEventStatus );
         
         /**------------------------------------------------------------------
            Move component in Invalid state.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx,
                           QOMX_StateInvalid, qomx_GetQOMXBaseEventCode( nEventStatus ) );

      }

   }
   else
   {
      /**---------------------------------------------------------------------
         Pass this to common device handler routine.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntCommon_DeviceEventHandler( pCmpntCtx,
                              nEventCode, nEventStatus, nParamSize, pParam );

   }

   return( eRetVal );

} /* end of function qomx_CmpntWaitForResources_DeviceEventHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntWaitForResources_SetStateLoaded

         DESCRIPTION:
*//**                   This function will request device to release wait
                        on resources and move component to Loaded or 
                        IdleToLoaded state based on the device return code
                        and ports population.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntWaitForResources_SetStateLoaded
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   OMX_U32              nStatus     = MMI_S_EFAIL;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_CmpntWaitForResources_SetStateLoaded" );

   /**------------------------------------------------------------------------
      Release wait on resources.
   -------------------------------------------------------------------------*/
   nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                              MMI_CMD_RELEASE_WAIT_ON_RESOURCES, NULL );

   QOMX_MSG_L_HIGH( pCommonRef, 
      "MMI_CMD_RELEASE_WAIT_ON_RESOURCES status = 0x%x", nStatus );

   if( MMI_S_COMPLETE == nStatus )
   {
      /**---------------------------------------------------------------------
         Move to transitional state IdleToLoaded which will check ports
         population status, wait for buffer release and unload resources.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, "Move to QOMX_StateIdleToLoaded." );

      ( void ) qomx_CmpntCommon_DoStateTransition( 
                     pCmpntCtx, QOMX_StateIdleToLoaded, QOMX_EVENT_UNKNOWN );

   }
   else
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Unexpected status in release wait on"
         "resources response, nStatus = 0x%x, Move to Invalid state.",
         nStatus );

      /**---------------------------------------------------------------------
         Move component in Invalid state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx,
                  QOMX_StateInvalid, qomx_GetQOMXBaseEventCode( nStatus ) );

      /**---------------------------------------------------------------------
         Return Invalid state error.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorInvalidState;

   }

   return( eRetVal );

} /* end of function qomx_CmpntWaitForResources_SetStateLoaded */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntWaitForResources_ResourcesAvailable

         DESCRIPTION:
*//**                   This function is called when resource availability
                        is notified by device. It will notify client and 
                        move component to next state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntWaitForResources_ResourcesAvailable
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_CmpntWaitForResources_ResourcesAvailable" );

   /**------------------------------------------------------------------------
      Change resources status. Reservation might have failed before
      entering into WaitForResources state.
   -------------------------------------------------------------------------*/
   pCmpntCtx->eResState = QOMX_RESOURCES_UNRESERVED;

   /**------------------------------------------------------------------------
      Notify client about the resource availability.
   -------------------------------------------------------------------------*/
   QOMX_MSG_L_MED( pCommonRef, 
         "Send OMX_EventResourcesAcquired notification." );

   ( void ) qomx_CmpntNotifyEvent( & ( pCmpntCtx->commonRef ), 
                                    OMX_EventResourcesAcquired, 0, 0, NULL );   

   /**------------------------------------------------------------------------
      Move to transitional state LoadedToIdle which will check ports
      population status, wait for buffers and load resources.
   -------------------------------------------------------------------------*/
   QOMX_MSG_L_MED( pCommonRef, "Move to QOMX_StateLoadedToIdle." );

   ( void ) qomx_CmpntCommon_DoStateTransition( 
                     pCmpntCtx, QOMX_StateLoadedToIdle, QOMX_EVENT_UNKNOWN );

   return;

} /* end of function qomx_CmpntWaitForResources_ResourcesAvailable */
