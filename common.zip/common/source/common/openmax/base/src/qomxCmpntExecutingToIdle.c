/*========================================================================

*//** @file qomxCmpntExecutingToIdle.c 

@par FILE SERVICES:       
      Component ExecutingToIdle State Implementation File.

      This file implements all the methods which are applicable for
      ExecutingToIdle state.

      This state can be entered from either Executing or Pause state.      
      
      Main functions are Send Command, AllocateBuffer, UseBuffer and
      FreeBuffer. Functions which are common for all states are 
      implemented in the common functions table.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2018 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCmpntExecutingToIdle.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
08/08/11   dm     Hardware critical error handling.
07/22/10   zm     Add component handle in each base class logging message.
06/10/10   dm     Added return type in event handler.
03/26/10   spl    Modified to support interop-profile.
01/19/10   dm     Disallow empty/fill buffer commands in this state.
10/02/09   dm     Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxCmpntCommon.h"
#include "qomxPortUtils.h"

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 * 
 * Forward declaration for the functions statically defined in this file.
 * 
 */

static void    qomx_CmpntExecutingToIdle_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
);

static void    qomx_CmpntExecutingToIdle_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
   
);

static OMX_ERRORTYPE    qomx_CmpntExecutingToIdle_SendCommand
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE         eCmd,
   OMX_IN   OMX_U32                 nParam,
   OMX_IN   OMX_PTR                 pCmdData
);

static OMX_ERRORTYPE    qomx_CmpntExecutingToIdle_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
);

static void    qomx_CmpntExecutingToIdle_Stop
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);

static void    qomx_CmpntExecutingToIdle_StopResponse
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nStatus
);

static void    qomx_CmpntExecutingToIdle_ResourcesLost
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);

OMX_ERRORTYPE  qomx_CmpntExecutingToIdle_EmptyThisBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBufferHdr
);

OMX_ERRORTYPE  qomx_CmpntExecutingToIdle_FillThisBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBufferHdr
);

/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_CmpntExecutingToIdle_LoadStateTable

         DESCRIPTION:
                        This function will load the component state table
                        supported by the ExecutingToIdle state in the object of
                        state table being passed.
            
@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable    - Pointer to the state primitive table
                                      object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntExecutingToIdle_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      component is in QOMX_StateExecutingToIdle state. NULL entry indicates that
      the specific function call is not allowed in this state, thus component
      API should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/   
   pStTable->GetComponentVersion    = qomx_CmpntCommon_GetComponentVersion;
   pStTable->SendCommand            = qomx_CmpntExecutingToIdle_SendCommand;
   pStTable->GetParameter           = qomx_CmpntCommon_GetParameter;
   pStTable->SetParameter           = qomx_CmpntCommon_SetParameter;
   pStTable->GetConfig              = qomx_CmpntCommon_GetConfig;
   pStTable->SetConfig              = qomx_CmpntCommon_SetConfig;
   pStTable->GetExtensionIndex      = qomx_CmpntCommon_GetExtensionIndex;
   pStTable->GetState               = qomx_CmpntCommon_GetState;
   pStTable->ComponentTunnelRequest = qomx_CmpntCommon_TunnelRequest;
   pStTable->UseBuffer              = qomx_CmpntCommon_UseBuffer;
   pStTable->AllocateBuffer         = qomx_CmpntCommon_AllocateBuffer;
   pStTable->FreeBuffer             = qomx_CmpntCommon_FreeBuffer;
   pStTable->EmptyThisBuffer        = qomx_CmpntExecutingToIdle_EmptyThisBuffer;
   pStTable->FillThisBuffer         = qomx_CmpntExecutingToIdle_FillThisBuffer;
   pStTable->SetCallbacks           = NULL;
   pStTable->ComponentDeInit        = qomx_CmpntCommon_ComponentDeInit;
   pStTable->UseEGLImage            = NULL;
   pStTable->ComponentRoleEnum      = qomx_CmpntCommon_ComponentRoleEnum;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler     
                        = qomx_CmpntExecutingToIdle_DeviceEventHandler;
   
   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler     
                        = qomx_CmpntExecutingToIdle_StateEntryHandler;
   pStTable->pfnExitHandler      
                        = qomx_CmpntExecutingToIdle_StateExitHandler;

   return;

} /* end of function qomx_CmpntExecutingToIdle_LoadStateTable */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntExecutingToIdle_StateEntryHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateExecutingToIdle is entered. Entry into the
                        state performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntExecutingToIdle_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Entering ExecutingToIdle  State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Entering ExecutingToIdle State, nEvent = 0x%x", nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pCmpntCtx->eMainState = QOMX_StateExecutingToIdle;

   /**------------------------------------------------------------------------
      Command device to finish.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntExecutingToIdle_Stop( pCmpntCtx );

   return;

} /* end of function qomx_CmpntExecutingToIdle_StateEntryHandler */


/*==========================================================================

         FUNCTION:      qomx_CmpntExecutingToIdle_StateExitHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateExecutingToIdle is exited. Exit from this
                        state performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntExecutingToIdle_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Exiting ExecutingToIdle  State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Exiting ExecutingToIdle State, nEvent = 0x%x", nEvent );

   return;

} /* end of function qomx_CmpntExecutingToIdle_StateExitHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntExecutingToIdle_SendCommand

         DESCRIPTION:
*//**                   This function is called every time when Send command
                        is invoked in ExecutingToIdle state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.
            @param[in]  eCmd        - Command which is being invoked.
            @param[in]  nParam      - Parameter 1. Refer OMX Spec.
            @param[in]  pCmdData    - Command payload. Refer OMX Spec.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntExecutingToIdle_SendCommand
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE            eCmd,
   OMX_IN   OMX_U32                    nParam,
   OMX_IN   OMX_PTR                    pCmdData
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntExecutingToIdle_SendCommand,"
      " eCmd = 0x%x, nParam = 0x%x", eCmd, nParam );

   /**------------------------------------------------------------------------
      Check the command type.
   -------------------------------------------------------------------------*/
   switch( eCmd ) 
   {
      /**--------------------------------------------------------------------- 
         Port specific commands which are allowed in this state.
      ----------------------------------------------------------------------*/
      case OMX_CommandFlush:
         {
            QOMX_MSG_L_HIGH( pCommonRef, "Flush Port = 0x%x", nParam );

            /**---------------------------------------------------------------
               Send port flush request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortFlush( pCmpntCtx->hPortCtnr, nParam );

         }

         break;

      default:
         {
            /**---------------------------------------------------------------
               Call common routine to handle rest of the commands.
            ----------------------------------------------------------------*/
            eRetVal = qomx_CmpntCommon_SendCommand( 
                                          pCmpntCtx, eCmd, nParam, pCmdData );

         }

         break;

   } /* end of switch( eCmd ) */

   return( eRetVal );

} /* end of function qomx_CmpntExecutingToIdle_SendCommand */


/*==========================================================================

         FUNCTION:      qomx_CmpntExecutingToIdle_DeviceEventHandler

         DESCRIPTION:
*//**                   This function is called when the device want to 
                        communicate with the component when it is in 
                        ExecutingToIdle state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx      -  Context structure pointer.
            @param[in]  nEventCode     -  Event code.
            @param[in]  nEventStatus   -  Event status.
            @param[in]  nParamSize     -  Payload length.
            @param[in]  pParam         -  Payload corresponding to this event.

*//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None
                                                                        
===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntExecutingToIdle_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntExecutingToIdle_DeviceEventHandler,"
      " nEventCode = 0x%x, nEventStatus = 0x%x", nEventCode, nEventStatus );

   /**------------------------------------------------------------------------
      Finish moving to Idle state on successful stop response.
   -------------------------------------------------------------------------*/
   if( MMI_RESP_STOP == nEventCode ) 
   {
      QOMX_MSG_L_HIGH( pCommonRef, "MMI_RESP_STOP event." );

      /**---------------------------------------------------------------------
         Process the start command status now.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntExecutingToIdle_StopResponse( 
                                                pCmpntCtx, nEventStatus );

   }
   else if( MMI_EVT_RESOURCES_LOST == nEventCode )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "MMI_EVT_RESOURCES_LOST event." );

      /**---------------------------------------------------------------------
         Set resources state to lost.
      ----------------------------------------------------------------------*/
      pCmpntCtx->eResState = QOMX_RESOURCES_PERMANENTLY_LOST;

      /**---------------------------------------------------------------------
         Process resource loss.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntExecutingToIdle_ResourcesLost( pCmpntCtx );

   }
   else
   {
      /**---------------------------------------------------------------------
         Pass this to common device handler routine.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntCommon_DeviceEventHandler( pCmpntCtx, 
                              nEventCode, nEventStatus, nParamSize, pParam );

   }

   return( eRetVal );

} /* end of function qomx_CmpntExecutingToIdle_DeviceEventHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntExecutingToIdle_Stop

         DESCRIPTION:
*//**                   This function will stop the device and move component
                        to Idle state based on the device return code.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntExecutingToIdle_Stop
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   OMX_U32              nStatus     = MMI_S_EFAIL;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntExecutingToIdle_Stop" );

   /**------------------------------------------------------------------------
      Command ports to stop buffer processing.
   -------------------------------------------------------------------------*/
   QOMX_MSG_L_MED( pCommonRef, "Stop buffer processing." );

   ( void ) qomx_PortStopBufferProcessing( pCmpntCtx->hPortCtnr );

   /**------------------------------------------------------------------------
      Send start command to MMI device.
   -------------------------------------------------------------------------*/
   nStatus = pCommonRef->device.pfnCmd( 
                                 pCommonRef->hFd, MMI_CMD_STOP, NULL );

   QOMX_MSG_L_HIGH( pCommonRef, "MMI_CMD_STOP status = 0x%x", nStatus );

   /**------------------------------------------------------------------------
      If device is processing the command asynchronously, wait for the
      callback, otherwise process the response.
   -------------------------------------------------------------------------*/
   if( MMI_S_PENDING != nStatus )
   {
      /**---------------------------------------------------------------------
         Process the start command status now.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntExecutingToIdle_StopResponse( pCmpntCtx, nStatus );

   }

   return;

} /* end of function qomx_CmpntExecutingToIdle_Stop */


/*==========================================================================

         FUNCTION:      qomx_CmpntExecutingToIdle_StopResponse

         DESCRIPTION:
*//**                   This function processes the stop command response
                        received from the device.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   -  Context structure pointer.
            @param[in]  nStatus     -  Event / Response status.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
                                                                        
===========================================================================*/
static void    qomx_CmpntExecutingToIdle_StopResponse
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nStatus
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_CmpntExecutingToIdle_StopResponse" );

   if( MMI_S_COMPLETE == nStatus )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Stop successful." );

      pCmpntCtx->bDeviceStopped = OMX_TRUE;

      /**---------------------------------------------------------------------
         If this state is being entered because of the resource lost in
         Executing or Pause state, Report report lost and move the component
         to IdleToLoaded state so that client can start freeing the buffers.
      ----------------------------------------------------------------------*/
      if( QOMX_RESOURCES_PERMANENTLY_LOST == pCmpntCtx->eResState )
      {
         QOMX_MSG_L_HIGH( pCommonRef, "Processing resource lost happened"
            " in other state." );

         /**------------------------------------------------------------------
            Process resource loss.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntExecutingToIdle_ResourcesLost( pCmpntCtx );

      }
      else if( OMX_TRUE == qomx_GuardIsTrue( pCmpntCtx->commonRef.hCmpnt,
                                    QOMX_GUARD_ALL_ENABLED_TUNNELED_PORTS_IDLE ) )
      {
         /**------------------------------------------------------------------
            Stop is successful. Move to destination state QOMX_StateIdle.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_MED( pCommonRef, "Move to QOMX_StateIdle." );

         ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                                       QOMX_StateIdle, QOMX_EVENT_UNKNOWN );

         /**------------------------------------------------------------------
            Send state transition success callback.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_MED( pCommonRef, 
            "Send OMX_StateIdle transition callback." );

         ( void ) qomx_CmpntCommon_StateTransitionCallback( 
                                       pCmpntCtx, OMX_StateIdle );

      }

   }
   else
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Unexpected error during stop." );

      /**---------------------------------------------------------------------
         Move the component to Invalid state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                  QOMX_StateInvalid, qomx_GetQOMXBaseEventCode( nStatus ) );

   }

   return;

} /* end of function qomx_CmpntExecutingToIdle_StopResponse */


/*==========================================================================

         FUNCTION:      qomx_CmpntExecutingToIdle_ResourcesLost

         DESCRIPTION:
                        This function will process resources lost event from
                        device.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.

**//*    RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntExecutingToIdle_ResourcesLost
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, 
      "qomx_CmpntExecutingToIdle_ResourcesLost" );

   /**------------------------------------------------------------------------
      Finish state transition to Idle state and report resource lost so 
      that IL client can start freeing buffers.
   -------------------------------------------------------------------------*/
   QOMX_MSG_L_MED( pCommonRef, "Move to QOMX_StateIdle." );

   ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx,
                                 QOMX_StateIdle, QOMX_EVENT_UNKNOWN );

   /**------------------------------------------------------------------------
      Issue state transition success callback.
   -------------------------------------------------------------------------*/
   QOMX_MSG_L_MED( pCommonRef, 
            "Send OMX_StateIdle transition callback." );

   ( void ) qomx_CmpntCommon_StateTransitionCallback( 
                                 pCmpntCtx, OMX_StateIdle );

   /**------------------------------------------------------------------------
      Report resources lost error to IL client.
   -------------------------------------------------------------------------*/
   QOMX_MSG_L_MED( pCommonRef, 
         "Send OMX_ErrorResourcesLost notification." );

   ( void ) qomx_CmpntNotifyError( 
                        & ( pCmpntCtx->commonRef ), OMX_ErrorResourcesLost );

   /**------------------------------------------------------------------------
      Move to transitional state IdleToLoaded which will check ports
      population status, wait for buffer release and unload resources.
   -------------------------------------------------------------------------*/
   QOMX_MSG_L_MED( pCommonRef, "Move to QOMX_StateIdleToLoaded." );

   ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx,
                                 QOMX_StateIdleToLoaded, QOMX_EVENT_UNKNOWN );

   return;

} /* end of function qomx_CmpntExecutingToIdle_ResourcesLost */

/*==========================================================================

         FUNCTION:      qomx_CmpntExecutingToIdle_EmptyThisBuffer

         DESCRIPTION:
                        Refer to OMX_EmptyThisBuffer in OMX_Core.h or the
                        OMX IL specification for details on the 
                        EmptyThisBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntExecutingToIdle_EmptyThisBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBufferHdr
)
{
   OMX_ERRORTYPE  eRetVal;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );   
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pCommonRef, 
      "qomx_CmpntExecutingToIdle_EmptyThisBuffer called." );

   /**------------------------------------------------------------------------
      Call the appropriate port handler.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_CmpntCommon_EmptyThisBuffer( pCmpntCtx, pBufferHdr );

   if( OMX_TRUE == pCmpntCtx->bDeviceStopped && 
       OMX_TRUE == qomx_GuardIsTrue( pCmpntCtx->commonRef.hCmpnt,
                                    QOMX_GUARD_ALL_ENABLED_TUNNELED_PORTS_IDLE ) )
   {
      /**------------------------------------------------------------------
         Buffers returned. Move to destination state QOMX_StateIdle.
      -------------------------------------------------------------------*/
      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                                    QOMX_StateIdle, QOMX_EVENT_UNKNOWN );

      /**------------------------------------------------------------------
         Send state transition success callback.
      -------------------------------------------------------------------*/
      ( void ) qomx_CmpntCommon_StateTransitionCallback( 
                                    pCmpntCtx, OMX_StateIdle );

   }

   return( eRetVal );

} /* end of function qomx_CmpntCommon_EmptyThisBuffer */


/*==========================================================================

         FUNCTION:      qomx_CmpntExecutingToIdle_FillThisBuffer

         DESCRIPTION:
                        Refer to OMX_FillThisBuffer in OMX_Core.h or the
                        OMX IL specification for details on the 
                        FillThisBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntExecutingToIdle_FillThisBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBufferHdr
)
{
   OMX_ERRORTYPE  eRetVal;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );   
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pCommonRef, 
      "qomx_CmpntCommon_FillThisBuffer called." );

   /**------------------------------------------------------------------------
      Call the appropriate port handler.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_CmpntCommon_FillThisBuffer( pCmpntCtx, pBufferHdr );

   if( OMX_TRUE == pCmpntCtx->bDeviceStopped && 
       OMX_TRUE == qomx_GuardIsTrue( pCmpntCtx->commonRef.hCmpnt,
                                    QOMX_GUARD_ALL_ENABLED_TUNNELED_PORTS_IDLE ) )
   {
      /**------------------------------------------------------------------
         Buffers returned. Move to destination state QOMX_StateIdle.
      -------------------------------------------------------------------*/
      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                                    QOMX_StateIdle, QOMX_EVENT_UNKNOWN );

      /**------------------------------------------------------------------
         Send state transition success callback.
      -------------------------------------------------------------------*/
      ( void ) qomx_CmpntCommon_StateTransitionCallback( 
                                    pCmpntCtx, OMX_StateIdle );

   }

   return( eRetVal );

} /* end of function qomx_CmpntCommon_FillThisBuffer */
