/*========================================================================

*//** @file qomxPortEnabledDepopulating.c 

@par FILE SERVICES:
      Implementation file for Port state QOMX_StatePortEnabledDepopulating.

      This file contains the definitions for the port methods which are
      called when port state is QOMX_StatePortEnabledDepopulating. This state
      is assumed when port is transitioning to an unpopulated state and buffer
      freeing is in progress.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2018 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxPortEnabledDepopulating.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
07/15/10   yt     Initial Creation.

========================================================================== */

/*======================================================================== 
 
                     INCLUDE FILES FOR MODULE 
 
========================================================================== */
#include "qomxPortCommon.h"
#include "qomxPortUtils.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/**
 * 
 * Forward declaration for the functions defined statically in this file.
 * 
 */

static void    qomx_PortEnabledDepopulating_StateEntryHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
);

static void    qomx_PortEnabledDepopulating_StateExitHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
);

static OMX_ERRORTYPE    qomx_PortEnabledDepopulating_FreeBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN OMX_BUFFERHEADERTYPE           *pBufferHdr
);

static OMX_ERRORTYPE    qomx_PortEnabledDepopulating_DeviceEventHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEventCode,
   OMX_IN   OMX_U32                       nEventStatus,
   OMX_IN   OMX_U32                       nParamSize,
   OMX_IN   OMX_PTR                      *pParam
);


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledDepopulating_LoadStateTable

         DESCRIPTION:
                        This function will load the port state table supported
                        by the QOMX_StatePortEnabledDepopulating state in the 
                        object of state table being passed.
            
@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable    - Pointer to the state primitive table
                                      object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortEnabledDepopulating_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType      *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      port is in QOMX_StatePortEnabledDepopulating state. NULL entry indicates
      that the specific function call is not allowed in this state, thus
      port utilities should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/   
   pStTable->Enable           = NULL;
   pStTable->Disable          = qomx_PortCommon_Disable;
   pStTable->TunnelRequest    = NULL;
   pStTable->Populate         = NULL;
   pStTable->Unpopulate       = NULL;
   pStTable->Run              = NULL;
   pStTable->Stop             = NULL;
   pStTable->UseBuffer        = NULL;
   pStTable->AllocateBuffer   = NULL;
   pStTable->FreeBuffer       = qomx_PortEnabledDepopulating_FreeBuffer;
   pStTable->EmptyThisBuffer  = NULL;
   pStTable->FillThisBuffer   = NULL;
   pStTable->Flush            = NULL;
   pStTable->DeInit           = qomx_PortCommon_DeInit;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler  = qomx_PortEnabledDepopulating_DeviceEventHandler;
   
   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler  = qomx_PortEnabledDepopulating_StateEntryHandler;
   pStTable->pfnExitHandler   = qomx_PortEnabledDepopulating_StateExitHandler;
   
   return;

} /* end of function qomx_PortEnabledDepopulating_LoadStateTable */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledDepopulating_StateEntryHandler

         DESCRIPTION:
*//**                   This function executes initial routines when port
                        moves in QOMX_StatePortEnabledDepopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the Port context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_PortEnabledDepopulating_StateEntryHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
)
{   
   OMX_ERRORTYPE  eRetVal;         
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Entering EnabledDepopulating"
      " State, nPortIndex = 0x%x, nEvent = 0x%x",
      pPortCtx->portDef.nPortIndex, nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pPortCtx->eState = QOMX_StatePortEnabledDepopulating;


   /**------------------------------------------------------------------------
      If no buffers to wait for, directly move to unpopulated state.
   -------------------------------------------------------------------------*/
   if( OMX_TRUE == qomx_PortCommon_CheckGuard( pPortCtx, 
                                               QOMX_PORT_GUARD_UNPOPULATED ) )      
   {
      QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
         "No buffers in queue, moving to unpopulated." );

      ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr, pPortCtx,
         QOMX_StatePortEnabledUnpopulated, 0 );

   }
   /**------------------------------------------------------------------------
      Otherwise, if this is a tunneling supplier port, free buffers and let 
      peer component free headers.
   -------------------------------------------------------------------------*/
   else if( ( PORT_TUNNELING_DISABLED != pPortCtx->eTunneling )
         && ( PORT_TUNNELING_VENDOR != pPortCtx->eTunneling )
         && ( QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx ) ) )
   {            
      QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
         "Port is tunneling supplier. Freeing buffers now." );
      
      eRetVal = qomx_PortCommon_FreeTunnelBuffers(pPortCtnr, pPortCtx);
      
      if( OMX_ErrorNone != eRetVal )
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef,
            "FreeTunnelBuffers failed." );
      }      
      
   }

   return;

} /* end of function qomx_PortEnabledDepopulating_StateEntryHandler */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledDepopulating_StateExitHandler

         DESCRIPTION:
*//**                   This function executes initial routines when port
                        moves out of QOMX_StatePortEnabledDepopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the Port context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_PortEnabledDepopulating_StateExitHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
)
{   
   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Exiting EnabledDepopulating"
      " State, nPortIndex = 0x%x, nEvent = 0x%x",
      pPortCtx->portDef.nPortIndex, nEvent );

   return;

} /* end of function qomx_PortEnabledDepopulating_StateExitHandler */

/*==========================================================================

         FUNCTION:      qomx_PortEnabledDepopulating_DeviceEventHandler

         DESCRIPTION:
*//**                   This function processes events from device when port
                        is in one of the EnabledDepopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  nEventCode  - Event code.
            @param [in] nEventStatus- Status of the event.
            @param [in] nParamSize  - Size in bytes for the event related
                                      data which is pointed by the payload.
            @param [in] pParam      - Event related payload.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortEnabledDepopulating_DeviceEventHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEventCode,
   OMX_IN   OMX_U32                       nEventStatus,
   OMX_IN   OMX_U32                       nParamSize,
   OMX_IN   OMX_PTR                      *pParam
)
{
   OMX_ERRORTYPE  eRetVal = OMX_ErrorNone;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, 
      "qomx_PortEnabledDepopulating_DeviceEventHandler, nPortIndex = 0x%x,"
      " nEventCode = 0x%x", pPortCtx->portDef.nPortIndex, nEventCode ); 

   /**------------------------------------------------------------------------
      Check event code.
   -------------------------------------------------------------------------*/
   switch( nEventCode )
   {   
   case MMI_EVT_PORT_CONFIG_CHANGED:
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
            "Received port config changed event." );

         /**------------------------------------------------------------------
            Process config change event and update port definition.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_ConfigChange( 
                                          pPortCtnr->pCommonRef, pPortCtx );

      }

      break;

   default:
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef,
            "Unexpected event code in this state." );

      }

      break;

   } /* end of switch( nEventCode ) */

   return( eRetVal );

} /* end of function qomx_PortEnabledDepopulating_DeviceEventHandler */

/*==========================================================================

         FUNCTION:      qomx_PortEnabledDepopulating_FreeBuffer

         DESCRIPTION:
*//**                   This function processes free buffer request when port
                        is in QOMX_StatePortEnabledDepopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.
@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortEnabledDepopulating_FreeBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN OMX_BUFFERHEADERTYPE           *pBufferHdr
)
{
   OMX_ERRORTYPE  eRetVal;
   /*-----------------------------------------------------------------------*/
      
   QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
      "qomx_PortEnabledDepopulating_FreeBuffer, nPortIndex = 0x%x", 
      pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Free buffer now.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortCommon_FreeBuffer( pPortCtnr, pPortCtx, pBufferHdr );

   /**------------------------------------------------------------------------
      If free buffer successfully completed, Port is no longer populated
      completely.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {      
      
      /**------------------------------------------------------------------
         If all buffers are freed, move to unpopulated state.
      -------------------------------------------------------------------*/
      if( OMX_TRUE == qomx_PortCommon_CheckGuard( pPortCtx, 
                                               QOMX_PORT_GUARD_UNPOPULATED ) ) 
      {
         
         ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr, pPortCtx,
            QOMX_StatePortEnabledUnpopulated, 0 );

      }

   }

   return( eRetVal );

} /* end of function qomx_PortEnabledDepopulating_FreeBuffer */
