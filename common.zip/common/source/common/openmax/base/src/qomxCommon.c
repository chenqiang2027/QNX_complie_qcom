/*========================================================================

*//** @file qomxCommon.c

@par FILE SERVICES:
      Common Implementation File.

      This file contains the methods which are common to the all component
      states and port states. This includes accessor functions for port to
      component etc. This header file facilitates OpenMax data types to all
      the files within the component so that each individual file need not
      include openmax header files.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCommon.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
06/22/16   am     Fix compiler warnings for 64 bit OS environment.
01/28/13   dp     Add error code (fatal) for stream not supported.
08/08/11   dm     Hardware critical error handling.
09/02/10   zm     Fix Klocwork errors.
08/28/10   zm     Added support for vendor tunneling.
07/22/10   zm     Add component handle in each base class logging message.
07/16/10   dm     Remove redundant checks in handle validation.
06/22/10   dm     Add support for stream corruption error.
06/10/10   dm     Added return type in event handler.
03/26/10   spl    Modified to support interop-profile.
03/17/10   dm     Post all event callbacks to DFC queue.
03/11/10   dm     Add not ready error status.
02/25/10   dm     Release locks before calling FBD / EBD.
09/16/09   dm     Removed critical section exit and reentry on callback.
06/16/09   dm     Initial Creation.

========================================================================== */

/*========================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxCmpntContext.h"
#include "qomxCmpntCommon.h"
#include "qomxPortUtils.h"

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 *
 *  These typedefs declare prototype for EmptyBufferDone / FillBufferDone
 *  callback function.
 *  Note: Refer OMX_CALLBACKTYPE in 'OMX_Core.h' for details.
 *
 */
typedef OMX_ERRORTYPE ( * qomx_EmptyBufferDone )
(
   OMX_IN   OMX_HANDLETYPE          hCmpnt,
   OMX_IN   OMX_PTR                 pAppData,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBuffer
);

typedef OMX_ERRORTYPE ( * qomx_FillBufferDone )
(
   OMX_OUT  OMX_HANDLETYPE          hCmpnt,
   OMX_OUT  OMX_PTR                 pAppData,
   OMX_OUT  OMX_BUFFERHEADERTYPE   *pBuffer
);


/* -----------------------------------------------------------------------
** Functions
** ----------------------------------------------------------------------- */


/*==========================================================================

         FUNCTION:      qomx_GetOMXErrorCode

         DESCRIPTION:
                        This function returns an appropriate OMX error code
                        corresponding to a device error code.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  nDevErrorCode  - Device error code.

**//*    RETURN VALUE:
*//**       @return
                        OMX Error code - As appropriate.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_GetOMXErrorCode
(
   OMX_IN   int   nDevErrorCode
)
{
   OMX_ERRORTYPE  eRetVal = OMX_ErrorUndefined;
   /*-----------------------------------------------------------------------*/

   switch( nDevErrorCode )
   {
   case MMI_S_EBADPARAM:
      {
         eRetVal = OMX_ErrorBadParameter;

      }

      break;

   case MMI_S_EFAIL:
      {
         eRetVal = OMX_ErrorUndefined;

      }

      break;

   case MMI_S_EFATAL:
      {
         eRetVal = OMX_ErrorInvalidState;

      }

      break;

   case MMI_S_ENOSWRES:
      {
         eRetVal = OMX_ErrorInsufficientResources;

      }

      break;

   case MMI_S_ENOHWRES:
      {
         eRetVal = OMX_ErrorHardware;

      }

      break;

   case MMI_S_EBUFFREQ:
      {
         eRetVal = OMX_ErrorUnderflow;

      }

      break;

   case MMI_S_ENOREATMPT:
      /* fall through */
   case MMI_S_EINVALCMD:
      /* fall through */
   case MMI_S_EINVALSTATE:
      {
         eRetVal = OMX_ErrorIncorrectStateOperation;

      }

      break;

   case MMI_S_ETIMEOUT:
      {
         eRetVal = OMX_ErrorTimeout;

      }

      break;

   case MMI_S_ECMDQFULL:
      /* fall through */
   case MMI_S_ENOPREREQ:
      {
         eRetVal = OMX_ErrorNotReady;

      }

      break;

   case MMI_S_ENOTIMPL:
      {
         eRetVal = OMX_ErrorNotImplemented;

      }

      break;

   case MMI_S_ENOTSUPIDX:
      {
         eRetVal = OMX_ErrorUnsupportedIndex;

      }

      break;

   case MMI_S_ENOTSUPSET:
      {
         eRetVal = OMX_ErrorUnsupportedSetting;

      }

      break;

   case MMI_S_ENOMORE:
      {
         eRetVal = OMX_ErrorNoMore;

      }

      break;

   case MMI_S_ENOTREADY:
      {
         eRetVal = OMX_ErrorNotReady;

      }

      break;

   case MMI_S_ESTRMCORRUPT:
      {
         eRetVal = OMX_ErrorStreamCorrupt;

      }

      break;

   case MMI_S_EFATALHW:
      {
         eRetVal = OMX_ErrorHardware;

      }

      break;

   case MMI_S_ESTRMUNSUPPFATAL:
      {
         eRetVal = QOMX_ErrorStreamUnsupportedFatal;

      }

      break;

   default:
      {
         /**------------------------------------------------------------------
            Success case should be handled by the caller before calling this
            function. Return error.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorUndefined;

      }

      break;

   } /* switch( nDevErrorCode ) */

   return( eRetVal );

} /* end of function qomx_GetOMXErrorCode */


/*==========================================================================

         FUNCTION:      qomx_GetQOMXBaseEventCode

         DESCRIPTION:
                        This function returns an appropriate QOMX base class
                        event code corresponding to a device event code.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  nDevEventCode  - Device event code.

**//*    RETURN VALUE:
*//**       @return
                        QOMX Base class event code - As appropriate.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_U8   qomx_GetQOMXBaseEventCode
(
   OMX_IN   int   nDevEventCode
)
{
   OMX_U8  eRetVal = QOMX_EVENT_UNKNOWN;
   /*-----------------------------------------------------------------------*/

   switch( nDevEventCode )
   {
   case MMI_S_EFATAL:
      {
         eRetVal = QOMX_EVENT_ERROR_FATAL;

      }

      break;

   case MMI_S_EFATALHW:
      {
         eRetVal = QOMX_EVENT_ERROR_FATAL_HARDWARE;

      }

      break;

   default:
      {
         eRetVal = QOMX_EVENT_UNKNOWN;

      }

      break;

   } /* switch( nDevEventCode ) */

   return( eRetVal );

} /* end of function qomx_GetQOMXBaseEventCode */


/*==========================================================================

         FUNCTION:      qomx_CmpntFillBufferDone

         DESCRIPTION:
                        This function is used to send fill buffer done
                        response through the IL registered callback
                        FillBufferDone.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[in]  pBufferHdr  - Pointer to the buffer header associated
                                      with the fill buffer done response.

**//*    RETURN VALUE:
*//**       @return     OMX_ERROR_CS_RELEASED

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntFillBufferDone
(
   OMX_IN   QOMX_CommonRefType     *pCommonRef,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr
)
{
   OMX_ERRORTYPE        eRetVal;
   OMX_HANDLETYPE       hCmpnt;
   OMX_PTR              pAppData;
   qomx_FillBufferDone  pFnFBD;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntFillBufferDone,"
      " pBufferHdr = 0x%p",  pBufferHdr );

   /**------------------------------------------------------------------------
      *************************
      **** IMPORTANT NOTE: ****
      *************************
      This function releases critical section ( aquired during executing
      qomx_DeviceEventHandler function ) and sends callback to the client.
      Caller of this function must not perform any component context
      sensitive operation after the function returns. There is a possibility
      that DeInit / Other APIs may acquire the critical section and start
      updating the context. This may be result in operation on inconsistent
      / corrupted data .
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      After the critical section is unlocked, there is possiblity of DeInit
      API to hold the lock and release context. Hence, store callback
      function pointer, app data and component handle in local variables.
   -------------------------------------------------------------------------*/
   pFnFBD   = pCommonRef->clientCB.FillBufferDone;
   pAppData = pCommonRef->pAppData;
   hCmpnt   = pCommonRef->hCmpnt;

   /**------------------------------------------------------------------------
      Release LOCK. This critical section was acquired when event handler
      qomx_DeviceEventHandler is called from MMI.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntUnlockContext( hCmpnt );

   /**------------------------------------------------------------------------
      Send fill buffer done response now.
   -------------------------------------------------------------------------*/
   eRetVal = pFnFBD( hCmpnt, pAppData, pBufferHdr );

   if( OMX_ErrorNone != eRetVal )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "FillBufferDone returned an error, "
         "eRetVal = 0x%x", ( OMX_U32 ) eRetVal );

   }

   /**------------------------------------------------------------------------
      Return CS released error to the API handler. API handler must not
      attempt to unlock context again.
   -------------------------------------------------------------------------*/
   eRetVal = OMX_ERROR_CS_RELEASED;

   return( eRetVal );

} /* end of function qomx_CmpntFillBufferDone */


/*==========================================================================

         FUNCTION:      qomx_CmpntEmptyBufferDone

         DESCRIPTION:
                        This function is used to send empty buffer done
                        response through the IL registered callback
                        EmptyBufferDone.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[in]  pBufferHdr  - Pointer to the buffer header associated
                                      with the empty buffer done response.

**//*    RETURN VALUE:
*//**       @return     OMX_ERROR_CS_RELEASED

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntEmptyBufferDone
(
   OMX_IN   QOMX_CommonRefType     *pCommonRef,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr
)
{
   OMX_ERRORTYPE        eRetVal;
   OMX_HANDLETYPE       hCmpnt;
   OMX_PTR              pAppData;
   qomx_FillBufferDone  pFnEBD;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntEmptyBufferDone,"
      " pBufferHdr = 0x%p", pBufferHdr );

   /**------------------------------------------------------------------------
      *************************
      **** IMPORTANT NOTE: ****
      *************************
      This function releases critical section ( aquired during executing
      qomx_DeviceEventHandler function ) and sends callback to the client.
      Caller of this function must not perform any component context
      sensitive operation after the function returns. There is a possibility
      that DeInit / Other APIs may acquire the critical section and start
      updating the context. This may be result in operation on inconsistent
      / corrupted data .
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      After the critical section is unlocked, there is possiblity of DeInit
      API to hold the lock and release context. Hence, store callback
      function pointer, app data and component handle in local variables.
   -------------------------------------------------------------------------*/
   pFnEBD   = pCommonRef->clientCB.EmptyBufferDone;
   pAppData = pCommonRef->pAppData;
   hCmpnt   = pCommonRef->hCmpnt;

   /**------------------------------------------------------------------------
      Release LOCK. This critical section was acquired when event handler
      qomx_DeviceEventHandler is called from MMI.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntUnlockContext( hCmpnt );

   /**------------------------------------------------------------------------
      Send empty buffer done response now.
   -------------------------------------------------------------------------*/
   eRetVal = pFnEBD( hCmpnt, pAppData, pBufferHdr );

   if( OMX_ErrorNone != eRetVal )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "EmptyBufferDone returned an error, "
         "eRetVal = 0x%x", ( OMX_U32 ) eRetVal );

   }

   /**------------------------------------------------------------------------
      Return CS released error to the API handler. API handler must not
      attempt to unlock context again.
   -------------------------------------------------------------------------*/
   eRetVal = OMX_ERROR_CS_RELEASED;

   return( eRetVal );

} /* end of function qomx_CmpntEmptyBufferDone */


/*==========================================================================

         FUNCTION:      qomx_CmpntNotifyEvent

         DESCRIPTION:
                        This function is used to send a notification to the
                        application on an event.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[in]  eEvent      - Refer 'EventHandler' in OMX_Core.h or
                                      IL spec.
            @param[in]  nData1      - Refer 'EventHandler' in OMX_Core.h or
                                      IL spec.
            @param[in]  nData2      - Refer 'EventHandler' in OMX_Core.h or
                                      IL spec.
            @param[in]  pEventData  - Refer 'EventHandler' in OMX_Core.h or
                                      IL spec.

**//*    RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntNotifyEvent
(
   OMX_IN   QOMX_CommonRefType     *pCommonRef,
   OMX_IN   OMX_EVENTTYPE           eEvent,
   OMX_IN   OMX_U32                 nData1,
   OMX_IN   OMX_U32                 nData2,
   OMX_IN   OMX_PTR                 pEventData
)
{
   QDFC_ErrorType    eErrVal;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntNotifyEvent, eEvent = 0x%x,"
      "nData1 = 0x%x", ( OMX_U32 ) eEvent, ( OMX_U32 ) nData1 );

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntNotifyEvent, nData2 = 0x%x,"
      "pEventData = 0x%p", ( OMX_U32 ) nData2, pEventData );

   /**------------------------------------------------------------------------
      Push the event callback in DFC queue. This ensures that the event gets
      posted to IL client in different thread context so that API call in
      base class from callback context does not form deadlocks.
   -------------------------------------------------------------------------*/
   eErrVal = qdfc_EnqueueArg6Function( pCommonRef->hDfc,
                  ( qfc_Arg6FpType ) ( pCommonRef->clientCB.EventHandler ),
                  ( QDFC_ArgType ) ( pCommonRef->hCmpnt ),
                  ( QDFC_ArgType ) ( pCommonRef->pAppData ),
                  ( QDFC_ArgType ) eEvent,
                  ( QDFC_ArgType ) nData1,
                  ( QDFC_ArgType ) nData2,
                  ( QDFC_ArgType ) pEventData );

   if( QDFC_ERROR_NONE != eErrVal )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "QDFC enqueue error = 0x%x, Event"
         "dropped.", ( OMX_U32 ) eErrVal );

   }

   return;

} /* end of function qomx_CmpntNotifyEvent */


/*==========================================================================

         FUNCTION:      qomx_CmpntCmdComplete

         DESCRIPTION:
                        This function is used to send a command complete
                        notification to the application for the given
                        command.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[in]  nData1      - Refer 'EventHandler' in OMX_Core.h or
                                      IL spec.
            @param[in]  nData2      - Refer 'EventHandler' in OMX_Core.h or
                                      IL spec.
            @param[in]  pEventData  - Refer 'EventHandler' in OMX_Core.h or
                                      IL spec.

**//*    RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntCmdComplete
(
   OMX_IN   QOMX_CommonRefType     *pCommonRef,
   OMX_IN   OMX_U32                 nData1,
   OMX_IN   OMX_U32                 nData2,
   OMX_IN   OMX_PTR                 pEventData
)
{
   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntCmdComplete, nData1 = 0x%x,"
      "nData2 = 0x%x", ( OMX_U32 ) nData1, ( OMX_U32 ) nData2 );

   /**------------------------------------------------------------------------
      Send the error notification.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntNotifyEvent( pCommonRef,
                     OMX_EventCmdComplete, nData1, nData2, pEventData );

   return;

} /* end of function qomx_CmpntCmdComplete */


/*==========================================================================

         FUNCTION:      qomx_CmpntNotifyError

         DESCRIPTION:
                        This function is used to send a notification to the
                        application on an event.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[in]  eError      - Error code associated with this
                                      notification.

**//*    RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntNotifyError
(
   OMX_IN   QOMX_CommonRefType     *pCommonRef,
   OMX_IN   OMX_ERRORTYPE           eError
)
{
   QOMX_MSG_L_HIGH( pCommonRef,
      "qomx_CmpntNotifyError, eError = 0x%x", ( OMX_U32 ) eError );

   /**------------------------------------------------------------------------
      Some errors ( e.g. InvalidState ) might occur in GetHandle itself.
      Callback would not have set in this case. Check event handler value
      and send the error notification.
   -------------------------------------------------------------------------*/
   if( NULL != pCommonRef->clientCB.EventHandler )
   {
      ( void ) qomx_CmpntNotifyEvent(
                           pCommonRef, OMX_EventError, eError, 0, NULL );
   }

   return;

} /* end of function qomx_CmpntNotifyError */


/*==========================================================================

         FUNCTION:      qomx_CmpntStateSetInvalid

         DESCRIPTION:
                        This function is used to set the QOMX state of the
                        component to Invalid. This function should be called
                        only when an irrecoverable error is detected.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt   - Component Handle.
            @param[in]  nEvent   - Uniqueue event code.

**//*    RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntStateSetInvalid
(
   OMX_IN   OMX_HANDLETYPE    hCmpnt,
   OMX_IN   OMX_U8            nEvent
)
{
   QOMX_CmpntCtxType   *pCmpntCtx   = ( QOMX_CmpntCtxType * )
         ( ( OMX_COMPONENTTYPE * ) hCmpnt )->pComponentPrivate;

   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pCommonRef,
      "qomx_CmpntStateSetInvalid, nEvent = 0x%x", ( OMX_U32 ) nEvent );

   /**------------------------------------------------------------------------
      Move component in Invalid state.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntCommon_DoStateTransition(
                        pCmpntCtx, QOMX_StateInvalid, nEvent );

   return;

} /* end of function qomx_CmpntStateSetInvalid */


/*==========================================================================

         FUNCTION:      qomx_CmpntGetQOMXState

         DESCRIPTION:
                        This function is used to get the QOMX state of the
                        component.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component Handle.

**//*    RETURN VALUE:
*//**       @return     QOMX_CmpntStateType enum as appropriate.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
QOMX_CmpntStateType  qomx_CmpntGetQOMXState
(
   OMX_IN   OMX_HANDLETYPE          hCmpnt
)
{
   QOMX_CmpntCtxType   *pCmpntCtx = ( QOMX_CmpntCtxType * )
         ( ( OMX_COMPONENTTYPE * ) hCmpnt )->pComponentPrivate;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntGetQOMXState" );

   /**------------------------------------------------------------------------
      Return the QOMX state from the component context.
   -------------------------------------------------------------------------*/
   return( pCmpntCtx->eMainState );

} /* end of function qomx_CmpntGetQOMXState */


/*==========================================================================

         FUNCTION:      qomx_CmpntLockContext

         DESCRIPTION:
*//**                   This function is used to lock the component context.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  hCmpnt      - Component Handle.

**//*     RETURN VALUE:
*//**                   None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntLockContext
(
   OMX_IN   OMX_HANDLETYPE          hCmpnt
)
{
   QOMX_CmpntCtxType   *pCmpntCtx   = ( QOMX_CmpntCtxType * )
         ( ( OMX_COMPONENTTYPE * ) hCmpnt )->pComponentPrivate;

   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pCommonRef, "qomx_CmpntLockContext" );

   /**------------------------------------------------------------------------
      Lock the context.
   -------------------------------------------------------------------------*/
   ( void ) qomx_EnterCriticalSection( pCmpntCtx->hCritSection );

   QOMX_MSG_L_LOW( pCommonRef, "Component context is Locked." );

   return;

} /*  end of function qomx_CmpntLockContext */


/*==========================================================================

         FUNCTION:      qomx_CmpntUnlockContext

         DESCRIPTION:
*//**                   This function is used to unlock the component context.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  hCmpnt      - Component Handle.

**//*     RETURN VALUE:
*//**                   None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntUnlockContext
(
   OMX_IN   OMX_HANDLETYPE          hCmpnt
)
{
   QOMX_CmpntCtxType   *pCmpntCtx   = ( QOMX_CmpntCtxType * )
         ( ( OMX_COMPONENTTYPE * ) hCmpnt )->pComponentPrivate;

   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pCommonRef, "qomx_CmpntUnlockContext" );

   /**------------------------------------------------------------------------
      Unlock the context.
   -------------------------------------------------------------------------*/
   ( void ) qomx_LeaveCriticalSection( pCmpntCtx->hCritSection );

   QOMX_MSG_L_LOW( pCommonRef, "Component context is Unlocked." );

   return;

} /*  end of function qomx_CmpntUnlockContext */


/*==========================================================================

         FUNCTION:      qomx_GuardIsTrue

         DESCRIPTION:
                        This function checks a guard condition and returns
                        true or false based on the guard check result.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component Handle.
            @param[in]  eGuard      - Guard which need to be checked.

**//*     RETURN VALUE:
*//**       @return     Pointer to the state primitive table as appripriate.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_BOOL    qomx_GuardIsTrue
(
   OMX_IN   OMX_HANDLETYPE          hCmpnt,
   OMX_IN   QOMX_GuardType          eGuard
)
{
   OMX_BOOL             eRetVal     = OMX_FALSE;
   QOMX_CmpntCtxType   *pCmpntCtx   = ( QOMX_CmpntCtxType * )
         ( ( OMX_COMPONENTTYPE * ) hCmpnt )->pComponentPrivate;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( & ( pCmpntCtx->commonRef ), "qomx_GuardIsTrue." );

   /**------------------------------------------------------------------------
      Check guard.
   -------------------------------------------------------------------------*/
   switch( eGuard )
   {
   case QOMX_GUARD_ALL_PORTS_UNPOPULATED:
      /* fall through */
   case QOMX_GUARD_ALL_ENABLED_PORTS_POPULATED:
      /* fall through */
   case QOMX_GUARD_ALL_ENABLED_TUNNELED_PORTS_IDLE:
     /* fall through */
   case QOMX_GUARD_ALL_ENABLED_VTPORTS_PEER_ACCEPTS_MMISTART:
      {
         eRetVal = qomx_PortGuardIsTrue( pCmpntCtx->hPortCtnr, eGuard );

      }

      break;

   } /* end of switch( eGuard ) */

   return( eRetVal );

} /*  end of function qomx_GuardIsTrue */


/*==========================================================================

         FUNCTION:      qomx_CmpntValidateHandle

         DESCRIPTION:
                        This function checks for the validity of the component
                        handle passed to it.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pComp       - Pointer to the component context.
                        bCallback   - Whether callback validation is required.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on successful validation.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntValidateHandle
(
   OMX_IN   OMX_COMPONENTTYPE   *pComp,
   OMX_IN   OMX_BOOL             bCallback
)
{
   OMX_ERRORTYPE  eRetVal  = OMX_ErrorNone;
   /*-----------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Do a quick sanity check first.
   -------------------------------------------------------------------------*/
   if( NULL == pComp )
   {
      QOMX_MSG_ERROR( "NULL component handle." );

      /**---------------------------------------------------------------------
         Some function parameters are not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else if( ( NULL == pComp->pComponentPrivate )
            || ( pComp->nSize != sizeof( QOMX_CmpntCtxType ) ) )
   {
      QOMX_MSG_ERROR(
         "h=0x%p, Invalid base class object.", pComp );

      /**---------------------------------------------------------------------
         Component private member i.e. QOMX component context is not valid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorInvalidComponent;

   }
   else if( QOMX_CMPNT_VERSION_MISMATCH( pComp->nVersion ) )
   {
      QOMX_MSG_ERROR( "h=0x%p, Version mismatch.", pComp );

      /**---------------------------------------------------------------------
         Version mismatch detected.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorVersionMismatch;

   }
   else if( OMX_TRUE == bCallback )
   {
      QOMX_CmpntCtxType *pCmpntCtx
            = ( QOMX_CmpntCtxType * ) pComp->pComponentPrivate;
      /*--------------------------------------------------------------------*/

      /**---------------------------------------------------------------------
         Check one callback functions, rest all should be valid if this
         is valid.
      ----------------------------------------------------------------------*/
      if ( NULL == pCmpntCtx->commonRef.clientCB.EventHandler )
      {
         QOMX_MSG_L_ERROR( & ( pCmpntCtx->commonRef ),
            "Callback is not set." );

         /**------------------------------------------------------------------
            Callback function is invalid.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorNotReady;

      }

   }

   return( eRetVal );

} /* end of function qomx_CmpntValidateHandle */
