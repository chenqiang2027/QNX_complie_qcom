/*========================================================================

*//** @file qomxPortEnabledUnpopulated.c

@par FILE SERVICES:
      Implementation file for Port state QOMX_StatePortEnabledUnpopulated.

      This file contains the definitions for the port methods which are
      called when port state is QOMX_StatePortEnabledUnpopulated. This state
      is the initial state and is obtained when component is initially loaded
      or component is moved back to Loaded state while this port is enabled.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxPortEnabledUnpopulated.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
10/23/13   dp     Add missing variable to messages.
07/22/10   zm     Add component handle/port index in base class logging.
07/15/10   yt     Changes for tunneling and new EnabledDepopulating state.
06/10/10   dm     Added return type in event handler.
03/26/10   spl    Modified to support interop-profile.
10/20/09   dm     Port state split.
09/15/09   dm     Initial Creation.

========================================================================== */

/*========================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxPortCommon.h"
#include "qomxPortUtils.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/**
 *
 * Forward declaration for the functions defined statically in this file.
 *
 */

static void    qomx_PortEnabledUnpopulated_StateEntryHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
);

static void    qomx_PortEnabledUnpopulated_StateExitHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
);

static OMX_ERRORTYPE    qomx_PortEnabledUnpopulated_Populate
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
);

static OMX_ERRORTYPE    qomx_PortEnabledUnpopulated_DeviceEventHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEventCode,
   OMX_IN   OMX_U32                       nEventStatus,
   OMX_IN   OMX_U32                       nParamSize,
   OMX_IN   OMX_PTR                      *pParam
);

/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledUnpopulated_LoadStateTable

         DESCRIPTION:
                        This function will load the port state table supported
                        by the QOMX_StatePortEnabledUnpopulated state in the
                        object of state table being passed.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable    - Pointer to the state primitive table
                                      object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortEnabledUnpopulated_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType      *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      port is in QOMX_StatePortEnabledUnpopulated state. NULL entry indicates
      that the specific function call is not allowed in this state, thus port
      utilities should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/
   pStTable->Enable           = NULL;
   pStTable->Disable          = qomx_PortCommon_Disable;
   pStTable->TunnelRequest    = qomx_PortCommon_TunnelRequest;
   pStTable->Populate         = qomx_PortEnabledUnpopulated_Populate;
   pStTable->Unpopulate       = NULL;
   pStTable->Run              = NULL;
   pStTable->Stop             = NULL;
   pStTable->UseBuffer        = NULL;
   pStTable->AllocateBuffer   = NULL;
   pStTable->FreeBuffer       = NULL;
   pStTable->EmptyThisBuffer  = NULL;
   pStTable->FillThisBuffer   = NULL;
   pStTable->Flush            = NULL;
   pStTable->DeInit           = qomx_PortCommon_DeInit;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler
                  = qomx_PortEnabledUnpopulated_DeviceEventHandler;

   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler
                  = qomx_PortEnabledUnpopulated_StateEntryHandler;

   pStTable->pfnExitHandler
                  = qomx_PortEnabledUnpopulated_StateExitHandler;

   return;

} /* end of function qomx_PortEnabledUnpopulated_LoadStateTable */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledUnpopulated_StateEntryHandler

         DESCRIPTION:
*//**                   This function executes initial routines when port
                        moves in QOMX_StatePortEnabledUnpopulated state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the Port context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_PortEnabledUnpopulated_StateEntryHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
)
{
   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Entering EnabledUnpopulated"
      " State, nPortIndex = 0x%x, nEvent = 0x%x",
      pPortCtx->portDef.nPortIndex, nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pPortCtx->eState = QOMX_StatePortEnabledUnpopulated;

   /**------------------------------------------------------------------------
      Reset tunneling signal flags appropriately.
   -------------------------------------------------------------------------*/
   if( NULL != pPortCtx->hTunneledComp && pPortCtx->bTunnelPeerIsQOMX )
   {
      pPortCtx->bTunnelPeerAcceptsUseBuffer      = OMX_FALSE;
      pPortCtx->bTunnelPeerAcceptsBufferExchange = OMX_FALSE;
      pPortCtx->bTunnelPeerAcceptsFreeBuffer     = OMX_FALSE;
   }
   else
   {
      pPortCtx->bTunnelPeerAcceptsUseBuffer      = OMX_TRUE;
      pPortCtx->bTunnelPeerAcceptsBufferExchange = OMX_TRUE;
      pPortCtx->bTunnelPeerAcceptsFreeBuffer     = OMX_TRUE;
   }

   return;

} /* end of function qomx_PortEnabledUnpopulated_StateEntryHandler */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledUnpopulated_StateExitHandler

         DESCRIPTION:
*//**                   This function executes initial routines when port
                        moves out of QOMX_StatePortEnabledUnpopulated state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the Port context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_PortEnabledUnpopulated_StateExitHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
)
{
   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Exiting EnabledUnpopulated"
      " State, nPortIndex = 0x%x, nEvent = 0x%x",
      pPortCtx->portDef.nPortIndex, nEvent );

   return;

} /* end of function qomx_PortEnabledUnpopulated_StateExitHandler */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledUnpopulated_Populate

         DESCRIPTION:
                        This function will move the port state to populating
                        or populated based on the buffer requirement. After
                        moving to populating state, port will be ready to
                        accept / allocate the buffers.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortEnabledUnpopulated_Populate
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
)
{
   OMX_ERRORTYPE  eRetVal = OMX_ErrorNone;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
      "qomx_PortEnabledUnpopulated_Populate, nPortIndex = 0x%x",
      pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Check the port buffer requirement and set state appropriately. Zero
      buffer requirement would mean port state to be set to Populated.
      Auto detect port mode would have zero buffer requirement initially,
      and when the ports are detected, buffer requirements would be changed.
   -------------------------------------------------------------------------*/
   if( 0 == pPortCtx->portDef.nBufferCountActual )
   {
      QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Port buffer requirement is 0,"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Buffers should not be accumulated on this port when moving
         to Idle state.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Move to EnabledPopulated"
         " State, nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                           pPortCtx, QOMX_StatePortEnabledPopulated, 0 );

   }
   else
   {
      /**---------------------------------------------------------------------
         Port need buffers when moves to Idle state.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Move to EnabledPopulating"
         " State, nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                           pPortCtx, QOMX_StatePortEnabledPopulating, 0 );

   }

   return( eRetVal );

} /* end of function qomx_PortEnabledUnpopulated_Populate */

/*==========================================================================

         FUNCTION:      qomx_PortEnabledUnpopulated_DeviceEventHandler

         DESCRIPTION:
*//**                   This function processes events from device when port
                        is in one of the EnabledUnpopulated state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  nEventCode  - Event code.
            @param [in] nEventStatus- Status of the event.
            @param [in] nParamSize  - Size in bytes for the event related
                                      data which is pointed by the payload.
            @param [in] pParam      - Event related payload.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortEnabledUnpopulated_DeviceEventHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEventCode,
   OMX_IN   OMX_U32                       nEventStatus,
   OMX_IN   OMX_U32                       nParamSize,
   OMX_IN   OMX_PTR                      *pParam
)
{
   OMX_ERRORTYPE  eRetVal = OMX_ErrorNone;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
      "qomx_PortEnabledUnpopulated_DeviceEventHandler, nPortIndex = 0x%x,"
      " nEventCode = 0x%x", pPortCtx->portDef.nPortIndex, nEventCode );

   /**------------------------------------------------------------------------
      Check event code.
   -------------------------------------------------------------------------*/
   switch( nEventCode )
   {
   case MMI_RESP_ENABLE_PORT:
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "MMI_RESP_ENABLE_PORT"
            " event nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Handle enable command response.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_EnableResp(
                              pPortCtnr, pPortCtx, nEventStatus, OMX_FALSE );

      }

      break;

   case MMI_EVT_PORT_CONFIG_CHANGED:
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "MMI_EVT_PORT_CONFIG_CHANGED"
            " event nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Process config change event and update port definition.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_ConfigChange(
                                          pPortCtnr->pCommonRef, pPortCtx );

      }

      break;

   default:
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Unexpected parameters in"
            " device event: nEventCode = 0x%x, nPortIndex = 0x%x",
            nEventCode, pPortCtx->portDef.nPortIndex );

      }

      break;

   } /* end of switch( nEventCode ) */

   return( eRetVal );

} /* end of function qomx_PortEnabledUnpopulated_DeviceEventHandler */
