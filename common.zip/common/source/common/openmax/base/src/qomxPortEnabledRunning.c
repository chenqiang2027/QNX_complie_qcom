/*========================================================================

*//** @file qomxPortEnabledRunning.c

@par FILE SERVICES:
      Implementation file for Port state QOMX_StatePortEnabledRunning.

      This file contains the definitions for the port methods which are
      called when port state is QOMX_StatePortEnabledRunning. This state
      is assumed when port is enabled and all the required buffers are
      aquired. Buffer processing is carried out in this state.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxPortEnabledRunning.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
06/22/16   am     Fix compiler warnings for 64 bit OS environment.
12/13/13   rz     Fix pEventData in OMX_EventMark
11/28/13   rs     Decrement client buffer count only when ETB or FTP succeeds
                  in queueing the buffer to be in sync with device buffer count
10/23/13   dp     Add missing variable to messages.
08/22/13   rz     Add OMX_ErrorOverflow/Underflow event
03/20/13   am     Rename QOMX_CONFIG_TUNNELEDPORTSTATUSTYPE and associated variables
                  to QC omx extension for 1.1.2
08/08/11   dm     Hardware critical error handling.
09/02/10   zm     Fix Klocwork errors.
08/28/10   zm     Added support for vendor tunneling.
07/22/10   zm     Add component handle/port index in base class logging.
07/15/10   yt     Changes for starting tunnel data flow.
06/10/10   dm     Added return type in event handler.
03/26/10   spl    Modified to support interop-profile.
03/17/10   dm     Allow ETB / FTB asynchronous only.
01/18/09   dm     Disallow freebuffer in port running state.
11/25/09   dm     Corrected auto port detection behavior.
10/21/09   dm     Created file.

========================================================================== */

/*========================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxPortCommon.h"
#include "qomxPortUtils.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/**
 *
 * Forward declaration for the functions defined statically in this file.
 *
 */

static void  qomx_PortEnabledRunning_StateEntryHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
);

static void  qomx_PortEnabledRunning_StateExitHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
);

static OMX_ERRORTYPE    qomx_PortEnabledRunning_Stop
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
);

static OMX_ERRORTYPE    qomx_PortEnabledRunning_Disable
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
);

static OMX_ERRORTYPE    qomx_PortEnabledRunning_EmptyThisBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE         *pBufferHdr
);

static OMX_ERRORTYPE    qomx_PortEnabledRunning_FillThisBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE         *pBufferHdr
);

static OMX_ERRORTYPE    qomx_PortEnabledRunning_Flush
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
);

static OMX_ERRORTYPE    qomx_PortEnabledRunning_DeviceEventHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEventCode,
   OMX_IN   OMX_U32                       nEventStatus,
   OMX_IN   OMX_U32                       nParamSize,
   OMX_IN   OMX_PTR                      *pParam
);


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledRunning_LoadStateTable

         DESCRIPTION:
                        This function will load the port state table
                        supported by the QOMX_StatePortEnabledRunning state
                        in the object of state table being passed.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable    - Pointer to the state primitive table
                                      object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortEnabledRunning_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType      *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      port is in QOMX_StatePortEnabledRunning state. NULL entry indicates
      that the specific function call is not allowed in this state, thus
      port utilities should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/
   pStTable->Enable           = NULL;
   pStTable->Disable          = qomx_PortEnabledRunning_Disable;
   pStTable->TunnelRequest    = NULL;
   pStTable->Populate         = NULL;
   pStTable->Unpopulate       = NULL;
   pStTable->Run              = NULL;
   pStTable->Stop             = qomx_PortEnabledRunning_Stop;
   pStTable->UseBuffer        = NULL;
   pStTable->AllocateBuffer   = NULL;
   pStTable->FreeBuffer       = qomx_PortCommon_FreeBufferUnexpected;
   pStTable->EmptyThisBuffer  = qomx_PortEnabledRunning_EmptyThisBuffer;
   pStTable->FillThisBuffer   = qomx_PortEnabledRunning_FillThisBuffer;
   pStTable->Flush            = qomx_PortEnabledRunning_Flush;
   pStTable->DeInit           = qomx_PortCommon_DeInit;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler  = qomx_PortEnabledRunning_DeviceEventHandler;

   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler  = qomx_PortEnabledRunning_StateEntryHandler;
   pStTable->pfnExitHandler   = qomx_PortEnabledRunning_StateExitHandler;

   return;

} /* end of function qomx_PortEnabledRunning_LoadStateTable */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledRunning_StateEntryHandler

         DESCRIPTION:
*//**                   This function executes initial routines when port
                        moves in QOMX_StatePortEnabledPopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the Port context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_PortEnabledRunning_StateEntryHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
)
{
   OMX_ERRORTYPE  eRetVal;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Entering EnabledRunning"
      " State, nPortIndex = 0x%x, nEvent = 0x%x",
      pPortCtx->portDef.nPortIndex, nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pPortCtx->eState = QOMX_StatePortEnabledRunning;

   /**------------------------------------------------------------------------
      For non-vendor tunneling, start data flow by calling fill buffer if
      port is the buffer supplier.
   -------------------------------------------------------------------------*/
   if( ( PORT_TUNNELING_DISABLED != pPortCtx->eTunneling )
      && ( PORT_TUNNELING_VENDOR != pPortCtx->eTunneling )
      && ( QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx ) ) )
   {
      QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
         "Port is tunneling supplier." );

      if( pPortCtx->bTunnelPeerAcceptsBufferExchange )
      {
       QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
          "Peer already accepts buffer exchange." );

       eRetVal = qomx_PortCommon_StartTunneledDataFlow(pPortCtnr, pPortCtx);

         if( OMX_ErrorNone != eRetVal )
         {
            QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef,
               "StartTunneledDataFlow failed." );
         }

      }
      else
      {
       QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
          "Port is awaiting peer to signal buffer exchange acceptance." );

      }

   }
   /**------------------------------------------------------------------------
      If this is a tunneling non-supplier, signal peer for BufferExchange
      acceptance.
   -------------------------------------------------------------------------*/
   else if( ( PORT_TUNNELING_DISABLED != pPortCtx->eTunneling )
         && ( PORT_TUNNELING_VENDOR != pPortCtx->eTunneling )
         && ( !QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx ) ) )
   {
      QDFC_ErrorType    eErrVal;
      /*--------------------------------------------------------------------*/

      eErrVal = qdfc_EnqueueArg6Function( pPortCtnr->pCommonRef->hDfc,
                  ( qfc_Arg6FpType ) ( qomx_PortCommon_SignalTunnelPeer ),
                  ( QDFC_ArgType ) pPortCtx->hTunneledComp,
                  ( QDFC_ArgType ) pPortCtx->nTunneledPort,
                  ( QDFC_ArgType ) QOMX_PORTSTATUS_ACCEPTSUSEBUFFER |
                                   QOMX_PORTSTATUS_ACCEPTSBUFFEREXCHANGE,
                  ( QDFC_ArgType ) 0,
                  ( QDFC_ArgType ) 0,
                  ( QDFC_ArgType ) 0 );

      if( QDFC_ERROR_NONE != eErrVal )
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef,
            "DFC EnQueue error = %d. Event dropped", eErrVal );

      }

   }
   /**------------------------------------------------------------------------
      If this is a vendor tunneled port, signal peer for BufferExchange
      acceptance.
   -------------------------------------------------------------------------*/
   else if( PORT_TUNNELING_VENDOR == pPortCtx->eTunneling )
   {
      QDFC_ErrorType    eErrVal;
      /*--------------------------------------------------------------------*/

     if( OMX_FALSE == pPortCtx->bTunnelPeerAcceptsBufferExchange )
     {
       QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
          "Port is awaiting peer to signal MMI start acceptance." );
     }

     /**---------------------------------------------------------------------
       Signal peer for BufferExchange acceptance. Base class guarantees
       that both of vendor tunneled components have received idle to
       executing transition command, before sending MMI_CMD_START to either
       device.
     ----------------------------------------------------------------------*/
     eErrVal = qdfc_EnqueueArg6Function( pPortCtnr->pCommonRef->hDfc,
                  ( qfc_Arg6FpType ) ( qomx_PortCommon_SignalTunnelPeer ),
                  ( QDFC_ArgType ) pPortCtx->hTunneledComp,
                  ( QDFC_ArgType ) pPortCtx->nTunneledPort,
                  ( QDFC_ArgType ) OMX_PORTSTATUS_VTACCEPTSBUFFEREXCHANGE,
                  ( QDFC_ArgType ) 0,
                  ( QDFC_ArgType ) 0,
                  ( QDFC_ArgType ) 0 );

      if( QDFC_ERROR_NONE != eErrVal )
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef,
            "DFC EnQueue error = %d. Event dropped", eErrVal );

      }

   }

   return;

} /* end of function qomx_PortEnabledRunning_StateEntryHandler */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledRunning_StateExitHandler

         DESCRIPTION:
*//**                   This function executes initial routines when port
                        moves out of QOMX_StatePortEnabledPopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the Port context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_PortEnabledRunning_StateExitHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
)
{
   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Exiting EnabledRunning"
      " State, nPortIndex = 0x%x, nEvent = 0x%x",
      pPortCtx->portDef.nPortIndex, nEvent );

   return;

} /* end of function qomx_PortEnabledRunning_StateExitHandler */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledRunning_Disable

         DESCRIPTION:
*//**                   This function processes port disable request when the
                        port is in QOMX_StatePortEnabledRunning state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr      - Pointer to the port container.
            @param[in]  pPortCtx       - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortEnabledRunning_Disable
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
)
{
   OMX_U32           nStatus        = MMI_S_EFAIL;
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "qomx_PortEnabledRunning_Disable,"
      " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      If there are some buffers pending with device, do Flush on device and
      wait for device to complete Flush before sending Disable request.
      Otherwise do a normal disable.
   -------------------------------------------------------------------------*/
   if( 0 != pPortCtx->nBuffersWithDevice )
   {
      MMI_PortCmdType   portCmd;
      /*--------------------------------------------------------------------*/

      QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Flush the device port,"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Send flush command to device.
      ----------------------------------------------------------------------*/
      portCmd.nPortIndex = pPortCtx->portDef.nPortIndex;

      nStatus = pCommonRef->device.pfnCmd(
                                 pCommonRef->hFd, MMI_CMD_FLUSH, & portCmd );

      QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "MMI_CMD_FLUSH status = 0x%x,"
         " nPortIndex = 0x%x", nStatus, pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Check command status.
      ----------------------------------------------------------------------*/
      if( MMI_S_PENDING == nStatus )
      {
         QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Waiting for Flush callback,"
            " Move to DisabledDepopulating state, nPortIndex = 0x%x",
            pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Flush is in progress. Move to stopping state and wait for Flush
            to complete before sending Disable Port command to device.
         -------------------------------------------------------------------*/
         pPortCtx->portDef.bEnabled  = OMX_FALSE;
         pPortCtx->bAlterCmdPending  = OMX_TRUE;
         pPortCtx->bAlterCmdFinished = OMX_FALSE;

         ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                     pPortCtx, QOMX_StatePortDisabledStopping, 0 );

      }
      else if( MMI_S_COMPLETE == nStatus )
      {
         QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Flush done synchronously,"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Send disable port request to device now.
         -------------------------------------------------------------------*/
         eRetVal = qomx_PortCommon_Disable( pPortCtnr, pPortCtx );

      }
      else
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Unexpected status on Flush"
            " command, nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Move component in Invalid state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorInvalidState;

      }

   }
   else
   {
      /**---------------------------------------------------------------------
         Send disable port request to device now.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_PortCommon_Disable( pPortCtnr, pPortCtx );

   }

   /**------------------------------------------------------------------------
      Move component to Invalid state on fatal error.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorInvalidState == eRetVal )
   {
      QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Fatal error, Move to Invalid"
         " state, nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

   }

   return( eRetVal );

} /* end of function qomx_PortEnabledRunning_Disable */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledRunning_Stop

         DESCRIPTION:
                        This function will put the port in stopped state. Port
                        will stop buffer processing when tunneling after this
                        function call.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortEnabledRunning_Stop
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
)
{
   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "qomx_PortEnabledRunning_Stop,"
      " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------
      Move to EnabledStopping state.
   -------------------------------------------------------------------*/
   ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                        pPortCtx, QOMX_StatePortEnabledStopping, 0 );

   return( OMX_ErrorNone );

} /* end of function qomx_PortEnabledRunning_Stop */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledRunning_EmptyThisBuffer

         DESCRIPTION:
*//**                   This function processes empty this buffer request when
                        port is in QOMX_StatePortEnabledRunning state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.
@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortEnabledRunning_EmptyThisBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE         *pBufferHdr
)
{
   OMX_ERRORTYPE        eRetVal        = OMX_ErrorNone;
   OMX_U32              nStatus        = MMI_S_EFAIL;
   QMM_ListHandleType  *pHBufHdrQueue  = & ( pPortCtx->hBufHdrQueue );
   QOMX_CommonRefType  *pCommonRef     = pPortCtnr->pCommonRef;
   QMM_ListErrorType    eListRetVal;
   QMM_ListLinkType    *pQueueLink;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pCommonRef, "qomx_PortEnabledRunning_EmptyThisBuffer,"
      " nPortIndex = 0x%x, pBufferHdr = 0x%p", pPortCtx->portDef.nPortIndex,
       pBufferHdr );

   /**------------------------------------------------------------------------
      Search this buffer in queue.
   -------------------------------------------------------------------------*/
   eListRetVal = qmm_ListSearch(
                        pHBufHdrQueue, qomx_PortCommon_BufferHdrLinkCmp,
                        ( void * ) pBufferHdr, & pQueueLink );

   if( QMM_LIST_ERROR_NOT_PRESENT == eListRetVal )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Buffer header not found in list,"
         " nPortIndex = 0x%x, pBufferHdr = 0x%p",
         pPortCtx->portDef.nPortIndex, pBufferHdr );

      /**---------------------------------------------------------------------
         Link is not found in buffer queue, it may not be belonging to the
         current port, return bad parameter error.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else if( QMM_LIST_ERROR_PRESENT != eListRetVal )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Corruption detected in the list,"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Queue is corrupted, Component should move into an invalid state
         which is not recoverable now.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorInvalidState;

   }
   else
   {
      MMI_BufferCmdType    bufferCmd;
      /*--------------------------------------------------------------------*/

      /**---------------------------------------------------------------------
         Process buffer header.
      ----------------------------------------------------------------------*/
      ( void ) qomx_PortCommon_ProcessBufferHeader( pPortCtnr,
                        pPortCtx, pBufferHdr, MMI_CMD_EMPTY_THIS_BUFFER );

      /**---------------------------------------------------------------------
         Sent this command to the device.
      ----------------------------------------------------------------------*/
      bufferCmd.nPortIndex = pBufferHdr->nInputPortIndex;
      bufferCmd.pBufferHdr = pBufferHdr;

      nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                                    MMI_CMD_EMPTY_THIS_BUFFER, & bufferCmd );

      QOMX_MSG_L_LOW( pCommonRef, "MMI_CMD_EMPTY_THIS_BUFFER status = 0x%x,"
         " nPortIndex = 0x%x", nStatus, pPortCtx->portDef.nPortIndex );

      if( MMI_S_PENDING == nStatus )
      {
         /**------------------------------------------------------------------
            Request queued successfully, increment number of buffer being
            processed and decrement buffer count of client
         -------------------------------------------------------------------*/
         pPortCtx->nBuffersWithClient--;
         pPortCtx->nBuffersWithDevice++;

         QOMX_MSG_L_LOW( pCommonRef, "Client buffer count = %d,"
            " nPortIndex = 0x%x",
            pPortCtx->nBuffersWithClient, pPortCtx->portDef.nPortIndex );

         QOMX_MSG_L_LOW( pCommonRef, "Device buffer count = %d,"
            " nPortIndex = 0x%x",
            pPortCtx->nBuffersWithDevice, pPortCtx->portDef.nPortIndex );

      }
      else if( MMI_S_COMPLETE == nStatus )
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Execution not allowed synchronously"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Move the component to invalid state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorInvalidState;

      }
      else
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Error on EmptyThisBuffer command"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Get error code.
         -------------------------------------------------------------------*/
         eRetVal = qomx_GetOMXErrorCode( nStatus );

      }

   }

   /**------------------------------------------------------------------------
      Move component to Invalid state on fatal error.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorInvalidState == eRetVal )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Fatal error, Move to Invalid state"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

   }

   return( eRetVal );

} /* end of function qomx_PortEnabledRunning_EmptyThisBuffer */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledRunning_FillThisBuffer

         DESCRIPTION:
*//**                   This function processes fill this buffer request when
                        port is in QOMX_StatePortEnabledRunning state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortEnabledRunning_FillThisBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE         *pBufferHdr
)
{
   OMX_ERRORTYPE        eRetVal        = OMX_ErrorNone;
   OMX_U32              nStatus        = MMI_S_EFAIL;
   QMM_ListHandleType  *pHBufHdrQueue  = & ( pPortCtx->hBufHdrQueue );
   QOMX_CommonRefType  *pCommonRef     = pPortCtnr->pCommonRef;
   QMM_ListErrorType    eListRetVal;
   QMM_ListLinkType    *pQueueLink;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pCommonRef, "qomx_PortEnabledRunning_FillThisBuffer,"
      " nPortIndex = 0x%x, pBufferHdr = 0x%p", pPortCtx->portDef.nPortIndex,
      pBufferHdr );

   /**------------------------------------------------------------------------
      Search this buffer in queue.
   -------------------------------------------------------------------------*/
   eListRetVal = qmm_ListSearch(
                        pHBufHdrQueue, qomx_PortCommon_BufferHdrLinkCmp,
                        ( void * ) pBufferHdr, & pQueueLink );

   if( QMM_LIST_ERROR_NOT_PRESENT == eListRetVal )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Buffer header not found in list,"
         " nPortIndex = 0x%x, pBufferHdr = 0x%p",
         pPortCtx->portDef.nPortIndex, pBufferHdr );

      /**---------------------------------------------------------------------
         Link is not found in buffer queue, it may not be belonging to the
         current port, return bad parameter error.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else if( QMM_LIST_ERROR_PRESENT != eListRetVal )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Corruption detected in the list,"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Queue is corrupted, Component should move into an invalid state
         which is not recoverable now.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorInvalidState;

   }
   else
   {
      MMI_BufferCmdType    bufferCmd;
      /*--------------------------------------------------------------------*/

      /**---------------------------------------------------------------------
         Process buffer header.
      ----------------------------------------------------------------------*/
      ( void ) qomx_PortCommon_ProcessBufferHeader( pPortCtnr,
                        pPortCtx, pBufferHdr, MMI_CMD_FILL_THIS_BUFFER );

      /**---------------------------------------------------------------------
         Sent this command to the device.
      ----------------------------------------------------------------------*/
      bufferCmd.nPortIndex = pBufferHdr->nOutputPortIndex;
      bufferCmd.pBufferHdr = pBufferHdr;

      nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                                    MMI_CMD_FILL_THIS_BUFFER, & bufferCmd );

      QOMX_MSG_L_LOW( pCommonRef, "MMI_CMD_FILL_THIS_BUFFER status = 0x%x,"
         " nPortIndex = 0x%x", nStatus, pPortCtx->portDef.nPortIndex );

      if( MMI_S_PENDING == nStatus )
      {
         /**------------------------------------------------------------------
            Request queued successfully, increment number of buffer being
            processed and decrement buffer count of client
         -------------------------------------------------------------------*/
         pPortCtx->nBuffersWithClient--;
         pPortCtx->nBuffersWithDevice++;

         QOMX_MSG_L_LOW( pCommonRef, "Client buffer count = %d,"
            " nPortIndex = 0x%x",
            pPortCtx->nBuffersWithClient, pPortCtx->portDef.nPortIndex );

         QOMX_MSG_L_LOW( pCommonRef, "Device buffer count = %d,"
            " nPortIndex = 0x%x",
            pPortCtx->nBuffersWithDevice, pPortCtx->portDef.nPortIndex );

      }
      else if( MMI_S_COMPLETE == nStatus )
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Execution not allowed synchronously"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Move the component to invalid state.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorInvalidState;

      }
      else
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Error on FillThisBuffer command"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Get error code.
         -------------------------------------------------------------------*/
         eRetVal = qomx_GetOMXErrorCode( nStatus );

      }

   }

   /**------------------------------------------------------------------------
      Move component to Invalid state on fatal error.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorInvalidState == eRetVal )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Fatal error, Move to Invalid state"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

   }

   return( eRetVal );

} /* end of function qomx_PortEnabledRunning_FillThisBuffer */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledRunning_Flush

         DESCRIPTION:
*//**                   This function processes flush request when port is in
                        QOMX_StatePortEnabledRunning state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortEnabledRunning_Flush
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   MMI_PortCmdType      portCmd;
   OMX_U32              nStatus;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortEnabledRunning_Flush,"
      " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Send flush command to device.
   -------------------------------------------------------------------------*/
   portCmd.nPortIndex = pPortCtx->portDef.nPortIndex;

   nStatus = pCommonRef->device.pfnCmd(
                                 pCommonRef->hFd, MMI_CMD_FLUSH, & portCmd );

   QOMX_MSG_L_HIGH( pCommonRef, "MMI_CMD_FLUSH status = 0x%x,"
      " nPortIndex = 0x%x", nStatus, pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Check command status.
   -------------------------------------------------------------------------*/
   if( MMI_S_PENDING == nStatus )
   {
      QOMX_MSG_L_MED( pCommonRef, "Waiting for Flush callback,"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Request queued successfully. No action to take.
      ----------------------------------------------------------------------*/

   }
   else if( MMI_S_COMPLETE == nStatus )
   {
      QOMX_MSG_L_MED( pCommonRef, "Flush done synchronously, Send"
         " OMX_CommandFlush notification, nPortIndex = 0x%x",
         pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Send flush done notification.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntCmdComplete( pCommonRef,
                  OMX_CommandFlush, pPortCtx->portDef.nPortIndex, NULL );

   }
   else
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Unexpected status for Flush command"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Move component in Invalid state.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorInvalidState;

   }

   /**------------------------------------------------------------------------
      Move component to Invalid state on fatal error.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorInvalidState == eRetVal )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Fatal error, Move to Invalid state"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

   }

   return( eRetVal );

} /* end of function qomx_PortEnabledRunning_Flush */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledRunning_DeviceEventHandler

         DESCRIPTION:
*//**                   This function processes events from device when port
                        is in QOMX_StatePortEnabledRunning state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  nEventCode  - Event code.
            @param [in] nEventStatus- Status of the event.
            @param [in] nParamSize  - Size in bytes for the event related
                                      data which is pointed by the payload.
            @param [in] pParam      - Event related payload.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortEnabledRunning_DeviceEventHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEventCode,
   OMX_IN   OMX_U32                       nEventStatus,
   OMX_IN   OMX_U32                       nParamSize,
   OMX_IN   OMX_PTR                      *pParam
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pCommonRef, "qomx_PortEnabledRunning_DeviceEventHandler,"
      " nPortIndex = 0x%x, nEventCode = 0x%x",
      pPortCtx->portDef.nPortIndex, nEventCode );

   /**------------------------------------------------------------------------
      Check event code.
   -------------------------------------------------------------------------*/
   switch( nEventCode )
   {
   case MMI_RESP_EMPTY_THIS_BUFFER:
      {
         MMI_BufferDoneMsgType *bufMsg = ( MMI_BufferDoneMsgType * ) pParam;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_LOW( pCommonRef, "MMI_RESP_EMPTY_THIS_BUFFER event,"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Process empty this buffer response.
         -------------------------------------------------------------------*/
         eRetVal = qomx_PortCommon_EmptyThisBufferResp( pPortCtnr,
                              pPortCtx, bufMsg->pBufferHdr, nEventStatus );

      }

      break;

   case MMI_RESP_FILL_THIS_BUFFER:
      {
         MMI_BufferDoneMsgType *bufMsg = ( MMI_BufferDoneMsgType * ) pParam;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_LOW( pCommonRef, "MMI_RESP_FILL_THIS_BUFFER event,"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Process fill this buffer response.
         -------------------------------------------------------------------*/
         eRetVal = qomx_PortCommon_FillThisBufferResp( pPortCtnr,
                              pPortCtx, bufMsg->pBufferHdr, nEventStatus );

      }

      break;

   case MMI_RESP_FLUSH:
      {
         QOMX_MSG_L_HIGH( pCommonRef, "MMI_RESP_FLUSH event,"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         if( MMI_S_COMPLETE == nEventStatus )
         {
            QOMX_MSG_L_MED( pCommonRef, "Send OMX_CommandFlush notification,"
               " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

            /**---------------------------------------------------------------
               Send flush done notification.
            ----------------------------------------------------------------*/
            ( void ) qomx_CmpntCmdComplete( pCommonRef, OMX_CommandFlush,
                                 pPortCtx->portDef.nPortIndex, NULL );

         }
         else
         {
            QOMX_MSG_L_MED( pCommonRef, "Unexpected error on flush command,"
               " Move to Invalid state, nPortIndex = 0x%x",
               pPortCtx->portDef.nPortIndex );

            /**---------------------------------------------------------------
               Move component to Invalid state.
            ----------------------------------------------------------------*/
            ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                 qomx_GetQOMXBaseEventCode( nEventStatus ) );
         }

      }

      break;

   case MMI_RESP_VENDORTUNNEL_PORT_MARK_BUFFER:
     {
       QOMX_MSG_L_HIGH( pCommonRef,
          "Received VENDORTUNNEL_PORT_MARK_BUFFER response." );

         if( MMI_S_COMPLETE == nEventStatus )
       {
         /**---------------------------------------------------------------
            Send mark buffer response notification to application.
         ----------------------------------------------------------------*/
         ( void ) qomx_CmpntCmdComplete(
                              pPortCtnr->pCommonRef, OMX_CommandMarkBuffer,
                              pPortCtx->portDef.nPortIndex, NULL );

       }
       else
       {
         QOMX_MSG_L_HIGH( pCommonRef,
            "Unexpected error on mark buffer response in vendor tunneling.");

            /**---------------------------------------------------------------
               Move component to Invalid state.
            ----------------------------------------------------------------*/
            ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                 qomx_GetQOMXBaseEventCode( nEventStatus ) );

       }

     }

     break;

   case MMI_EVT_PORT_CONFIG_CHANGED:
      {
         QOMX_MSG_L_HIGH( pCommonRef, "MMI_EVT_PORT_CONFIG_CHANGED"
            " event nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Process config change event and update port definition.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_ConfigChange( pCommonRef, pPortCtx );

      }

      break;

   case MMI_EVT_NEED_BUFFER:
      {
         if ( OMX_DirInput == pPortCtx->portDef.eDir )
         {
            /**------------------------------------------------------------------
               Send underflow error notification.
            -------------------------------------------------------------------*/
            QOMX_MSG_L_HIGH( pCommonRef, "MMI_EVT_NEED_BUFFER"
               " event, Send OMX_ErrorUnderflow notification, nPortIndex = 0x%x",
               pPortCtx->portDef.nPortIndex );

            ( void ) qomx_CmpntNotifyEvent( pCommonRef,
                           OMX_EventError, OMX_ErrorUnderflow,
                           pPortCtx->portDef.nPortIndex, NULL );
         }
         else if ( OMX_DirOutput == pPortCtx->portDef.eDir )
         {
            /**------------------------------------------------------------------
               Send overflow error notification.
            -------------------------------------------------------------------*/
            QOMX_MSG_L_HIGH( pCommonRef, "MMI_EVT_NEED_BUFFER"
               " event, Send OMX_ErrorOverflow notification, nPortIndex = 0x%x",
               pPortCtx->portDef.nPortIndex );

            ( void ) qomx_CmpntNotifyEvent( pCommonRef,
                           OMX_EventError, OMX_ErrorOverflow,
                           pPortCtx->portDef.nPortIndex, NULL );
         }
      }

      break;

   case MMI_EVT_VENDORTUNNEL_PORT_EOS:
      {
         QOMX_MSG_L_HIGH( pCommonRef, "MMI_EVT_VENDORTUNNEL_PORT_EOS event,"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
             Send EOS event only if the port is setup for vendor tunneling,
          and is either an output port, or the component is a sink.
         -------------------------------------------------------------------*/
         if ( ( PORT_TUNNELING_VENDOR == pPortCtx->eTunneling )
            && ( ( OMX_DirOutput == pPortCtx->portDef.eDir )
               || ( OMX_TRUE == QOMX_COMPONENT_IS_SINK( pPortCtnr ) ) ) )
         {
            QOMX_MSG_L_HIGH( pCommonRef, "Send VENDORTUNNEL_PORT_EOS"
               " notification, nPortIndex = 0x%x",
               pPortCtx->portDef.nPortIndex );

            /**---------------------------------------------------------------
               Send EOS notification to the application.
            ----------------------------------------------------------------*/
            ( void ) qomx_CmpntNotifyEvent( pCommonRef,
                           OMX_EventBufferFlag, pPortCtx->portDef.nPortIndex,
                           OMX_BUFFERFLAG_EOS, NULL );

         }

      }

      break;

   case MMI_EVT_VENDORTUNNEL_PORT_MARK_BUFFER:
     {
        MMI_VendorTunnelMarkBufferMsgType *pMarkBufMsg =
                  ( MMI_VendorTunnelMarkBufferMsgType * ) pParam;

       QOMX_MSG_L_HIGH( pCommonRef,
          "Received need VENDORTUNNEL_PORT_MARK_BUFFER event." );

       /**------------------------------------------------------------------
            Send mark buffer notification to the application.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntNotifyEvent( pCommonRef, OMX_EventMark,
                  0, 0,  pMarkBufMsg->markBuffer.pMarkData );

     }

     break;

   default:
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Unexpected parameters in"
            " device event: nEventCode = 0x%x, nPortIndex = 0x%x",
            nEventCode, pPortCtx->portDef.nPortIndex );

      }

      break;

   } /* end of switch( nEventCode ) */

   return( eRetVal );

} /* end of function qomx_PortEnabledRunning_DeviceEventHandler */
