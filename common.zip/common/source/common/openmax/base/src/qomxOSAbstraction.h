#ifndef __H_QOMX_OS_ABSTRACTION_H__
#define __H_QOMX_OS_ABSTRACTION_H__

/*========================================================================

*//** @file qomxOSAbstraction.h 

@par FILE SERVICES:
      OS Abstraction Header File.

      This file contains OS abstraction interfaces.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2009-2016 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxOSAbstraction.h#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
06/22/16   am     Fix compiler warnings for 64 bit OS environment.
11/22/10   zm     Change qomx_OSHeapGetHandle signature to use it as default
                  MMI GetHeapHandle routine.
08/08/09   dm     Memory functions abstracted.
04/18/09   srk    Created file.

========================================================================== */

/*======================================================================== 
 
                     INCLUDE FILES FOR MODULE 
 
========================================================================== */
#include <OMX_Types.h>
#include <OMX_Core.h>

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */


/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Functions
** ----------------------------------------------------------------------- */


/*==========================================================================

         FUNCTION:      qomx_CreateCriticalSection

         DESCRIPTION:
*//**
                        This function implements the method for creating the
                        critical section and aquiring the required resources.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[out] pHCrtSec - This parameter will hold the pointer to
                                   just created critical section context
                                   upon exit.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
===========================================================================*/
void  qomx_CreateCriticalSection
(
   OMX_OUT  OMX_HANDLETYPE      *pHCrtSec
);


/*==========================================================================

         FUNCTION:      qomx_ReleaseCriticalSection

         DESCRIPTION:
*//**
                        This function implements the method for releasing the
                        critical section and releasing all the resources
                        associated with this.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  hCrtSec  - Handle to the critical section context.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
===========================================================================*/
void  qomx_ReleaseCriticalSection
(
   OMX_IN   OMX_HANDLETYPE       hCrtSec
);


/*==========================================================================

         FUNCTION:      qomx_EnterCriticalSection

         DESCRIPTION:
*//**
                        This function implements the method to enter a
                        critical section. This function blocks if another
                        thread is inside the critical section until the other
                        thread leaves the critical section.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  hCrtSec  - Handle to the critical section context.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
===========================================================================*/
void  qomx_EnterCriticalSection
(
   OMX_IN   OMX_HANDLETYPE       hCrtSec
);


/*==========================================================================

         FUNCTION:      qomx_LeaveCriticalSection

         DESCRIPTION:
*//**
                        This function implements the method to leave a
                        critical section.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  hCrtSec  - Handle to the critical section context.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
===========================================================================*/
void  qomx_LeaveCriticalSection
(
   OMX_IN   OMX_HANDLETYPE       hCrtSec
);


/*==========================================================================

         FUNCTION:      qomx_OSHeapGetHandle

         DESCRIPTION:
*//**
                        This function instantiate the OS specific memory 
                        module which is used for memory management for the
                        current component.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[out] pHHeap - Handle to the heap area would be filled here.

*//*     RETURN VALUE:
*//**       @return     MMI_S_COMPLETE  - on successful validation.
                        Other error codes - As appropriate on failures.

@par     SIDE EFFECTS:
                        None
===========================================================================*/
OMX_U32  qomx_OSHeapGetHandle
(
   OMX_OUT  OMX_HANDLETYPE         *pHHeap
);


/*==========================================================================

         FUNCTION:      qomx_OSHeapReleaseHandle

         DESCRIPTION:
*//**
                        This function calls appropriate deinit function
                        to release OS specific memory module which is used for
                        memory management for the current component.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  hHeap - Handle to the heap area.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
===========================================================================*/
void  qomx_OSHeapReleaseHandle
(
   OMX_IN   OMX_HANDLETYPE             hHeap
);


/*==========================================================================

         FUNCTION:      qomx_OSMalloc

         DESCRIPTION:
*//**
                        This function calls appropriate memory allocation 
                        routine from the given heap area to allocate requested
                        number of bytes.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  hHeap - Handle to the heap area.
            @param[in]  nSize - Number of bytes to be allocated.

*//*     RETURN VALUE:
*//**       @return     Pointer to the allocated memory area.

@par     SIDE EFFECTS:
                        None
===========================================================================*/
void *   qomx_OSMalloc
(
   OMX_IN   OMX_HANDLETYPE       hHeap,
   OMX_IN   OMX_U32              nSize
);


/*==========================================================================

         FUNCTION:      qomx_OSFree

         DESCRIPTION:
*//**
                        This function calls appropriate free allocation 
                        routine from the given heap area to release previously
                        allocated memory.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  hHeap - Handle to the heap area.
            @param[in]  pMem  - Pointer to the memory location to be freed.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
===========================================================================*/
void  qomx_OSFree
(
   OMX_IN   OMX_HANDLETYPE       hHeap,
   OMX_IN   void                *pMem
);


/*==========================================================================

         FUNCTION:      qomx_GetTime

         DESCRIPTION:
*//**
                        This function calls appropriate get time routine on
                        the given OS Abstraction layer.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[out] pTime - Pointer to a OMX_U64 integer which will be 
                                assigned time in MS on return.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
===========================================================================*/
void  qomx_GetTime
(
   OMX_U64       *pTime
);


#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */


#endif /* __H_QOMX_OS_ABSTRACTION_H__ */
