/*========================================================================

*//** @file qomxCmpntCommon.c

@par FILE SERVICES:
      Component Common Implementation File.

      This file contains the state machine omx il function handlers which are
      common to all states being implemented. OMX privitive like
      OMX_GetComponentVersion etc. does not change from state to state.

      Such states are captured in this header file alongwith the corresponding
      implementations.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCmpntCommon.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
06/22/16   am     Fix compiler warnings for 64 bit OS environment.
01/28/13   dp     Generate notification in case of fatal error.
08/08/11   dm     Hardware critical error handling.
03/07/11   yt     Add cleanup mechanism for non-freed buffers during deinit.
09/13/10   dm     Adding component name and handle in logging messages.
08/28/10   zm     Added support for vendor tunneling.
08/05/10   yt     Added support for QOMX tunnel index.
07/22/10   zm     Add component handle in each base class logging message.
07/16/10   dm     Allow GetComponentVersion for optional parameters as NULL.
06/10/10   dm     Added return type in event handler.
03/26/10   spl    Modified to support interop-profile.
03/18/10   spl    Added support for Port Throughput extension.
11/25/09   dm     Corrected auto port detection behavior.
11/24/09   dm     Added support for device extension indexes.
10/30/09   dm     Defined macro for structure size and version validation.
10/29/09   dm     Allow tunneling on disabled ports in any OMX state.
10/29/09   dm     Disallow port commands in component transitional states.
10/09/09   dm     Split component states.
08/06/09   dm     Added extension specific generic event.
07/28/09   dm     Refined setparameter handling.
07/21/09   dm     Freebuffer offloaded to device during abnormal init.
06/16/09   dm     Initial Creation.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxCmpntCommon.h"
#include "qomxPortUtils.h"

/*=========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/**
 *
 *  These are the component state primitive table load functions defined in
 *  the respective state handler implementation file.
 *
 */

void  qomx_CmpntInvalid_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
);

void  qomx_CmpntLoaded_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
);

void  qomx_CmpntIdle_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
);

void  qomx_CmpntExecuting_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
);

void  qomx_CmpntPause_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
);

void  qomx_CmpntWaitForResources_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
);

void  qomx_CmpntLoadedToIdle_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
);

void  qomx_CmpntIdleToLoaded_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
);

void  qomx_CmpntIdleToExecuting_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
);

void  qomx_CmpntIdleToPause_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
);

void  qomx_CmpntExecutingToIdle_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
);

void  qomx_CmpntExecutingToPause_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
);

void  qomx_CmpntPauseToExecuting_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
);

/* -----------------------------------------------------------------------
** Functions
** ----------------------------------------------------------------------- */

/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_GetComponentVersion

         DESCRIPTION:
                        Refer to OMX_GetComponentVersion in OMX_Core.h or the
                        OMX IL specification for details on the
                        GetComponentVersion method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[out] pComponentName - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[out] pComponentVersion
                                       - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[out] pSpecVersion   - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[out] pComponentUUID - Refer OMX_Core.h or OMX IL
                                         specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_GetComponentVersion
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_OUT  OMX_STRING              pComponentName,
   OMX_OUT  OMX_VERSIONTYPE        *pComponentVersion,
   OMX_OUT  OMX_VERSIONTYPE        *pSpecVersion,
   OMX_OUT  OMX_UUIDTYPE           *pComponentUUID
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntCommon_GetComponentVersion" );

   /**------------------------------------------------------------------------
      Copy component name, UUID from the component context.
      Assign component version and spec version from the common macros.
   -------------------------------------------------------------------------*/
   if( NULL != pComponentName )
   {
      QOMX_CMPNT_MEM_COPY( pComponentName, & ( pCommonRef->acCmpntName[ 0 ] ),
            sizeof( pCommonRef->acCmpntName ) );

   }

   if( NULL != pComponentUUID )
   {
      QOMX_CMPNT_MEM_COPY( pComponentUUID, & ( pCommonRef->cmpntUUID[ 0 ] ),
            sizeof( pCommonRef->cmpntUUID ) );

   }

   if( NULL != pComponentVersion )
   {
      SET_QOMX_CMPNT_VERSION( ( *pComponentVersion ) );

   }

   if( NULL != pSpecVersion )
   {
      SET_QOMX_SPEC_VERSION( ( *pSpecVersion ) );

   }

   return( OMX_ErrorNone );

} /* end of function qomx_CmpntCommon_GetComponentVersion */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_GetExtensionIndex

         DESCRIPTION:
                        Refer to OMX_GetExtensionIndex in OMX_Core.h or the
                        OMX IL specification for details on the
                        GetExtensionIndex method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  cParameterName - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[out] pIndexType     - Refer OMX_Core.h or OMX IL
                                         specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_GetExtensionIndex
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_STRING              cParameterName,
   OMX_OUT  OMX_INDEXTYPE          *pIndexType
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntCommon_GetExtensionIndex" );

   /**------------------------------------------------------------------------
      Compare parameter strings with extension strings in base class.
   -------------------------------------------------------------------------*/
   if( 0 == QOMX_CMPNT_STR_CMP( cParameterName,
                           QOMX_PARAM_NAME_QUALCOMM_TUNNEL ) )
   {
      QOMX_MSG_L_MED( pCommonRef,
         "Vendor tunnel device extension queried." );

      /**---------------------------------------------------------------------
         Set qualcomm tunnel enabled value (the tunnel is between two
       qualcomm components).
      ----------------------------------------------------------------------*/
      ( *pIndexType ) = ( OMX_INDEXTYPE ) QOMX_PARAM_INDEX_QUALCOMM_TUNNEL;

   }
   else if( 0 == QOMX_CMPNT_STR_CMP( cParameterName,
                           QOMX_PARAM_NAME_PORT_THROUGHPUT ) )
   {
      QOMX_MSG_L_MED( pCommonRef,
         "Port throughput extension queried." );

      /**---------------------------------------------------------------------
         Set port throughput value.
      ----------------------------------------------------------------------*/
      ( *pIndexType ) = ( OMX_INDEXTYPE ) QOMX_IndexParamPortThroughput;

   }
   else if( 0 == QOMX_CMPNT_STR_CMP( cParameterName,
                           QOMX_CONFIG_NAME_DEBUG_MSG ) )
   {
      QOMX_MSG_L_MED( pCommonRef,
         "Debug message name extension queried." );

      /**---------------------------------------------------------------------
         Set port throughput value.
      ----------------------------------------------------------------------*/
      ( *pIndexType ) = ( OMX_INDEXTYPE ) QOMX_IndexConfigDebugMsg;

   }
   else
   {
      OMX_U32                    nStatus     = MMI_S_EFAIL;
      MMI_GetExtensionCmdType    getExtCmd;
      /*--------------------------------------------------------------------*/

      /**---------------------------------------------------------------------
         It may be an extension supported by the device. Pass this command
         to device. Device need to check and return Index corresponding
         to this string or failure as applicable.
      ----------------------------------------------------------------------*/
      getExtCmd.cParamName = cParameterName;
      getExtCmd.pIndex     = pIndexType;

      nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                           MMI_CMD_GET_EXTENSION_INDEX, & getExtCmd );

      QOMX_MSG_L_MED( pCommonRef,
         "Get extension index status = 0x%x.", nStatus );

      if( MMI_S_COMPLETE != nStatus )
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Get extension failed." );

         /**------------------------------------------------------------------
            Get OpenMax failure code for this.
         -------------------------------------------------------------------*/
         eRetVal = qomx_GetOMXErrorCode( nStatus );

      }
      else if( ( ((OMX_U32 ) ( * pIndexType )) >= ((OMX_U32 ) QOMX_IndexParamStartUnused) )
               && ( ((OMX_U32 )( * pIndexType )) <=  ((OMX_U32 )QOMX_IndexConfigMax )) )
      {
         QOMX_MSG_L_ERROR( pCommonRef, "MMI ext index value conflicts with "
            "base class reserved extension indexes." );

         /**------------------------------------------------------------------
            MMI must not return index within the base class reserved range.
            Move component to invalid state.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

         eRetVal = OMX_ErrorInvalidState;

      }

   }

   return( eRetVal );

} /* end of function qomx_CmpntCommon_GetExtensionIndex */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_ComponentRoleEnum

         DESCRIPTION:
                        Refer to OMX_ComponentRoleEnum in OMX_Core.h or the
                        OMX IL specification for details on the
                        ComponentRoleEnum method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[out] cRole          - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[in]  nIndex         - Refer OMX_Core.h or OMX IL
                                         specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_ComponentRoleEnum
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_OUT  OMX_U8                 *cRole,
   OMX_IN   OMX_U32                 nIndex
)
{
   QOMX_MSG_L_MED( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntCommon_ComponentRoleEnum" );

   /*TODO: to be implemented */

   return( OMX_ErrorNone);

} /* end of function qomx_CmpntCommon_ComponentRoleEnum */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_GetParameter

         DESCRIPTION:
                        Refer to OMX_GetParameter in OMX_Core.h or the
                        OMX IL specification for details on the
                        GetParameter method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  nIndex         - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[out] pCmpntParm     - Refer OMX_Core.h or OMX IL
                                         specification.
**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_GetParameter
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE           nIndex,
   OMX_OUT  OMX_PTR                 pCmpntParm
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pCommonRef, "qomx_CmpntCommon_GetParameter,"
      " nIndex = 0x%x", ( OMX_U32 ) nIndex );


   switch( nIndex )
   {
   case OMX_IndexParamPriorityMgmt:
      {
         OMX_PRIORITYMGMTTYPE *pPriMgmt = ( OMX_PRIORITYMGMTTYPE * ) pCmpntParm;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_HIGH( pCommonRef,
            "OMX_IndexParamPriorityMgmt index." );

         /**------------------------------------------------------------------
            Validate parameters and set policy type.
         -------------------------------------------------------------------*/
         QOMX_IF_VALID_STRUCT_OBJ( pCommonRef,
               pPriMgmt, OMX_PRIORITYMGMTTYPE, eRetVal )
         {
            /**---------------------------------------------------------------
               Fill priority management type now.
            ----------------------------------------------------------------*/
            pPriMgmt->nGroupID       = pCmpntCtx->nGroupID;
            pPriMgmt->nGroupPriority = pCmpntCtx->nGroupPri;

         }

      }

      break;

   case OMX_IndexParamSuspensionPolicy:
      {
         OMX_PARAM_SUSPENSIONPOLICYTYPE *pPolicy
                  = ( OMX_PARAM_SUSPENSIONPOLICYTYPE * ) pCmpntParm;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_HIGH( pCommonRef,
            "OMX_IndexParamSuspensionPolicy index." );

         /**------------------------------------------------------------------
            Validate parameters and set policy type.
         -------------------------------------------------------------------*/
         QOMX_IF_VALID_STRUCT_OBJ( pCommonRef,
               pPolicy, OMX_PARAM_SUSPENSIONPOLICYTYPE, eRetVal )
         {
            /**---------------------------------------------------------------
               Fill policy type now.
            ----------------------------------------------------------------*/
            pPolicy->ePolicy = pCmpntCtx->ePolicy;

         }

      }

      break;

   case OMX_IndexParamComponentSuspended:
      {
         OMX_PARAM_SUSPENSIONTYPE *pSuspension
                  = ( OMX_PARAM_SUSPENSIONTYPE * ) pCmpntParm;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_HIGH( pCommonRef,
            "OMX_IndexParamComponentSuspended index." );

         /**------------------------------------------------------------------
            Validate parameters and set policy type.
         -------------------------------------------------------------------*/
         QOMX_IF_VALID_STRUCT_OBJ( pCommonRef,
               pSuspension, OMX_PARAM_SUSPENSIONTYPE, eRetVal )
         {
            /**---------------------------------------------------------------
               Fill suspension status now.
            ----------------------------------------------------------------*/
            pSuspension->eType = pCmpntCtx->eSuspension;

         }

      }

      break;

   default:
      {
         /**------------------------------------------------------------------
            Send to port if it handles this call.
         -------------------------------------------------------------------*/
         eRetVal = qomx_PortGetParameter(
                                 pCmpntCtx->hPortCtnr, nIndex, pCmpntParm );

      }

      break;

   } /* end of switch( nParamIndex ) */

   return( eRetVal );

} /* end of function qomx_CmpntCommon_GetParameter */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_SetParameter

         DESCRIPTION:
                        Refer to OMX_SetParameter in OMX_Core.h or the
                        OMX IL specification for details on the
                        SetParameter method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  nIndex         - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[in]  pCmpntParm     - Refer OMX_Core.h or OMX IL
                                         specification.
**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_SetParameter
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE           nIndex,
   OMX_IN   OMX_PTR                 pCmpntParm
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pCommonRef, "qomx_CmpntCommon_SetParameter,"
      " nIndex = 0x%x", ( OMX_U32 ) nIndex );


   switch( nIndex )
   {
   case OMX_IndexParamPriorityMgmt:
      {
         OMX_PRIORITYMGMTTYPE *pPriMgmt = ( OMX_PRIORITYMGMTTYPE * ) pCmpntParm;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_HIGH( pCommonRef,
            "OMX_IndexParamPriorityMgmt index." );

         /**------------------------------------------------------------------
            Validate parameters and set policy type.
         -------------------------------------------------------------------*/
         QOMX_IF_VALID_STRUCT_OBJ( pCommonRef,
               pPriMgmt, OMX_PRIORITYMGMTTYPE, eRetVal )
         {
            /**---------------------------------------------------------------
               Fill priority management type now.
            ----------------------------------------------------------------*/
            pCmpntCtx->nGroupID  = pPriMgmt->nGroupID;
            pCmpntCtx->nGroupPri = pPriMgmt->nGroupPriority;

         }

      }

      break;

   case OMX_IndexParamSuspensionPolicy:
      {
         OMX_PARAM_SUSPENSIONPOLICYTYPE *pPolicy
                  = ( OMX_PARAM_SUSPENSIONPOLICYTYPE * ) pCmpntParm;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_HIGH( pCommonRef,
            "OMX_IndexParamSuspensionPolicy index." );

         /**------------------------------------------------------------------
            Suspension setting is allowed only when component is in Loaded
            state.
         -------------------------------------------------------------------*/
         if( QOMX_StateLoaded == pCmpntCtx->eMainState )
         {
            /**---------------------------------------------------------------
               Validate parameters and set policy type.
            ----------------------------------------------------------------*/
            QOMX_IF_VALID_STRUCT_OBJ( pCommonRef,
                  pPolicy, OMX_PARAM_SUSPENSIONPOLICYTYPE, eRetVal )
            {
               QOMX_MSG_L_HIGH( pCommonRef, "Suspension policy = 0x%x",
                  ( OMX_U32 ) pPolicy->ePolicy );

               if( ( OMX_SuspensionDisabled == pPolicy->ePolicy )
                     || ( OMX_SuspensionEnabled == pPolicy->ePolicy ) )
               {
                  /**---------------------------------------------------------
                     Set policy type now.
                  ----------------------------------------------------------*/
                  pCmpntCtx->ePolicy = pPolicy->ePolicy;

               }
               else
               {
                  QOMX_MSG_L_ERROR( pCommonRef, "Bad parameters." );

                  /**---------------------------------------------------------
                     Bad parameter.
                  ----------------------------------------------------------*/
                  eRetVal = OMX_ErrorBadParameter;

               }

            }

         }
         else
         {
            QOMX_MSG_L_ERROR( pCommonRef, "Set suspension policy not allowed "
               "in eMainState = 0x%x", ( OMX_U32 ) pCmpntCtx->eMainState );

            /**---------------------------------------------------------------
               Setting not allowed in current component state.
            ----------------------------------------------------------------*/
            eRetVal = OMX_ErrorIncorrectStateOperation;

         }

      }

      break;

   case OMX_IndexParamComponentSuspended:
      {
         QOMX_MSG_L_ERROR( pCommonRef,
            "Get only index. Set is not allowed" );

         /**------------------------------------------------------------------
            This is get only property, setting is not allowed.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorBadParameter;

      }

      break;

   default:
      {
         /**------------------------------------------------------------------
            Send to port if it handles this call.
         -------------------------------------------------------------------*/
         eRetVal = qomx_PortSetParameter(
                                 pCmpntCtx->hPortCtnr, nIndex, pCmpntParm );

      }

      break;

   } /* switch( nParamIndex ) */

   return( eRetVal );

} /* end of function qomx_CmpntCommon_SetParameter */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_GetConfig

         DESCRIPTION:
                        Refer to OMX_GetConfig in OMX_Core.h or the
                        OMX IL specification for details on the
                        GetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  nIndex         - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[out] pCmpntCfg      - Refer OMX_Core.h or OMX IL
                                         specification.
**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_GetConfig
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE           nIndex,
   OMX_OUT  OMX_PTR                 pCmpntCfg
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pCommonRef, "qomx_CmpntCommon_GetConfig,"
      " nIndex = 0x%x", ( OMX_U32 ) nIndex );


   switch( (OMX_U32 ) nIndex )
   {
   case QOMX_IndexConfigDebugMsg:
      {
         QOMX_ConfigDebugMsg *pConfigMsg
                  = ( QOMX_ConfigDebugMsg * ) pCmpntCfg;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_HIGH( pCommonRef,
            "QOMX_IndexConfigDebugMsg index." );

         /**------------------------------------------------------------------
            Validate parameters.
         -------------------------------------------------------------------*/
         QOMX_IF_VALID_STRUCT_OBJ( pCommonRef,
            pConfigMsg, QOMX_ConfigDebugMsg, eRetVal )
         {
            /**---------------------------------------------------------------
               Check message level.
            ----------------------------------------------------------------*/
            if( QOMX_DEBUG_MSG_LEVEL_ENABLE_ALL &
                  pCommonRef->debugMsgProp.nDebugMsgLevelFlags )
            {
               pConfigMsg->eDebugMsgLevel = QOMX_DebugMsgLevelEnableAll;

            }
            else if( QOMX_DEBUG_MSG_LEVEL_MEDIUM &
                     pCommonRef->debugMsgProp.nDebugMsgLevelFlags )
            {
               pConfigMsg->eDebugMsgLevel = QOMX_DebugMsgLevelMedium;

            }
            else if( QOMX_DEBUG_MSG_LEVEL_HIGH &
                     pCommonRef->debugMsgProp.nDebugMsgLevelFlags )
            {
               pConfigMsg->eDebugMsgLevel = QOMX_DebugMsgLevelHigh;

            }
            else if( QOMX_DEBUG_MSG_LEVEL_CRITICAL ==
                     pCommonRef->debugMsgProp.nDebugMsgLevelFlags )
            {
               pConfigMsg->eDebugMsgLevel = QOMX_DebugMsgLevelCritical;

            }
            else
            {
               pConfigMsg->eDebugMsgLevel = QOMX_DebugMsgLevelDisableAll;

            }

            /**---------------------------------------------------------------
               Check component name setting.
            ----------------------------------------------------------------*/
            if( QOMX_DEBUG_MSG_COMPONENT_NAME &
                  pCommonRef->debugMsgProp.nDebugMsgLevelFlags )
            {
               pConfigMsg->bEnableCompName = OMX_TRUE;

               QOMX_CMPNT_MEM_COPY( & ( pConfigMsg->acCustomName[ 0 ] ),
                  & ( pCommonRef->debugMsgProp.acCustomName[ 0 ] ),
                  sizeof( pConfigMsg->acCustomName ) );

            }
            else
            {
               pConfigMsg->bEnableCompName = OMX_FALSE;

            }

         }

      }

      break;

   default:
      {
         /**------------------------------------------------------------------
            Send to port if it handles this call.
         -------------------------------------------------------------------*/
         eRetVal = qomx_PortGetConfig(
                                 pCmpntCtx->hPortCtnr, nIndex, pCmpntCfg );

      }

      break;

   } /* switch( nParamIndex ) */

   return( eRetVal );

} /* end of function qomx_CmpntCommon_GetConfig */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_SetConfig

         DESCRIPTION:
                        Refer to OMX_SetConfig in OMX_Core.h or the
                        OMX IL specification for details on the
                        SetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  nIndex         - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[in]  pCmpntCfg      - Refer OMX_Core.h or OMX IL
                                         specification.
**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_SetConfig
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE           nIndex,
   OMX_IN   OMX_PTR                 pCmpntCfg
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pCommonRef, "qomx_CmpntCommon_SetConfig,"
      " nIndex = 0x%x", ( OMX_U32 ) nIndex );


   switch( (OMX_U32 )nIndex )
   {
   case QOMX_IndexConfigDebugMsg:
      {
         QOMX_ConfigDebugMsg *pConfigMsg
                  = ( QOMX_ConfigDebugMsg * ) pCmpntCfg;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_HIGH( pCommonRef,
            "QOMX_IndexConfigDebugMsg index." );

         /**------------------------------------------------------------------
            Validate parameters.
         -------------------------------------------------------------------*/
         QOMX_IF_VALID_STRUCT_OBJ( pCommonRef,
            pConfigMsg, QOMX_ConfigDebugMsg, eRetVal )
         {
            QOMX_DebugMsgPropType *pMsgProp = & ( pCommonRef->debugMsgProp );
            /*--------------------------------------------------------------*/

            /**---------------------------------------------------------------
               Check message level.
            ----------------------------------------------------------------*/
            if( QOMX_DebugMsgLevelEnableAll == pConfigMsg->eDebugMsgLevel )
            {
               pCommonRef->debugMsgProp.nDebugMsgLevelFlags
                  = QOMX_DEBUG_MSG_LEVEL_ENABLE_ALL;

            }
            else if( QOMX_DebugMsgLevelMedium == pConfigMsg->eDebugMsgLevel )
            {
               pCommonRef->debugMsgProp.nDebugMsgLevelFlags
                  = QOMX_DEBUG_MSG_LEVEL_MEDIUM;

            }
            else if( QOMX_DebugMsgLevelHigh == pConfigMsg->eDebugMsgLevel )
            {
               pCommonRef->debugMsgProp.nDebugMsgLevelFlags
                  = QOMX_DEBUG_MSG_LEVEL_HIGH;

            }
            else if( QOMX_DebugMsgLevelCritical == pConfigMsg->eDebugMsgLevel )
            {
               pCommonRef->debugMsgProp.nDebugMsgLevelFlags
                  = QOMX_DEBUG_MSG_LEVEL_CRITICAL;

            }
            else
            {
               pCommonRef->debugMsgProp.nDebugMsgLevelFlags
                  = QOMX_DEBUG_MSG_LEVEL_DISABLE_ALL;
            }


            /**---------------------------------------------------------------
               Check component name setting.
            ----------------------------------------------------------------*/
            if( OMX_TRUE == pConfigMsg->bEnableCompName )
            {
               /**------------------------------------------------------------
                  Set bitflag for component name.
               -------------------------------------------------------------*/
               pCommonRef->debugMsgProp.nDebugMsgLevelFlags
                  |= QOMX_DEBUG_MSG_COMPONENT_NAME;

            }

            /**---------------------------------------------------------------
               If source component name has valid values, set it.
               Else set real component name.
            ----------------------------------------------------------------*/
            if( ( OMX_TRUE == pConfigMsg->bEnableCompName )
               && ( '\0' != pConfigMsg->acCustomName[ 0 ] ) )
            {
               /**------------------------------------------------------------
                  Copy 127 characters from source and terminate with NULL.
               -------------------------------------------------------------*/
               QOMX_CMPNT_MEM_SET( & ( pMsgProp->acCustomName[ 0 ] ), 0,
                  sizeof( & ( pMsgProp->acCustomName[ 0 ] ) ) );

               QOMX_CMPNT_MEM_COPY( & ( pMsgProp->acCustomName[ 0 ] ),
                  & ( pConfigMsg->acCustomName[ 0 ] ),
                  ( sizeof( pMsgProp->acCustomName ) - 1 ) );

            }
            else
            {
               /**------------------------------------------------------------
                  Copy real component name for printing.
               -------------------------------------------------------------*/
               QOMX_CMPNT_MEM_COPY( & ( pMsgProp->acCustomName[ 0 ] ),
                  & ( pCommonRef->acCmpntName[ 0 ] ),
                  sizeof( pMsgProp->acCustomName ) );

            }

         }

      }

      break;

   default:
      {
         /**------------------------------------------------------------------
            Send to port if it handles this call.
         -------------------------------------------------------------------*/
         eRetVal = qomx_PortSetConfig(
                              pCmpntCtx->hPortCtnr, nIndex, pCmpntCfg );

         break;
      }

   } /* switch( nParamIndex ) */

   return( eRetVal );

} /* end of function qomx_CmpntCommon_SetConfig */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_GetState

         DESCRIPTION:
                        Refer to OMX_GetState in OMX_Core.h or the
                        OMX IL specification for details on the
                        GetState method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[out] pState         - Refer OMX_Core.h or OMX IL
                                         specification.
**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_GetState
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_OUT  OMX_STATETYPE          *pState
)
{
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), "qomx_CmpntCommon_GetState,"
      "eOmxState = 0x%x", ( OMX_U32 ) pCmpntCtx->eOmxState );

   /**------------------------------------------------------------------------
      Assign the OMX state to the return parameter.
   -------------------------------------------------------------------------*/
   ( *pState ) = pCmpntCtx->eOmxState;

   return( OMX_ErrorNone );

} /* end of function qomx_CmpntCommon_GetState */

/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_UseBuffer

         DESCRIPTION:
                        Refer to OMX_UseBuffer in OMX_Core.h or the
                        OMX IL specification for details on the
                        UseBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL specification.
            @param[in]  nPortIndex  - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL specification.
            @param[in]  nSizeBytes  - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pBuffer     - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_UseBuffer
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_OUT  OMX_BUFFERHEADERTYPE  **ppBufferHdr,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_IN   OMX_PTR                 pAppPrivate,
   OMX_IN   OMX_U32                 nSizeBytes,
   OMX_IN   OMX_U8                 *pBuffer
)
{
   OMX_ERRORTYPE  eRetVal;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( & ( pCmpntCtx->commonRef ), "qomx_CmpntCommon_UseBuffer,"
      " nPortIndex = 0x%x, nSizeBytes = %d", nPortIndex, nSizeBytes );

   /**------------------------------------------------------------------------
      Call the appropriate port handler.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortUseBuffer( pCmpntCtx->hPortCtnr, nPortIndex,
                        ppBufferHdr, pAppPrivate, nSizeBytes, pBuffer );

   return( eRetVal );

} /* end of function qomx_CmpntCommon_UseBuffer */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_AllocateBuffer

         DESCRIPTION:
                        Refer to OMX_AllocateBuffer in OMX_Core.h or the
                        OMX IL specification for details on the
                        AllocateBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL specification.
            @param[in]  nPortIndex  - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL specification.
            @param[in]  nSizeBytes  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_AllocateBuffer
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_OUT  OMX_BUFFERHEADERTYPE  **ppBufferHdr,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_IN   OMX_PTR                 pAppPrivate,
   OMX_IN   OMX_U32                 nSizeBytes
)
{
   OMX_ERRORTYPE  eRetVal;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntCommon_AllocateBuffer, nPortIndex = 0x%x,"
         " nSizeBytes = %d", nPortIndex, nSizeBytes );

   /**------------------------------------------------------------------------
      Call the appropriate port handler.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortAllocateBuffer( pCmpntCtx->hPortCtnr, nPortIndex,
                        ppBufferHdr, pAppPrivate, nSizeBytes );

   return( eRetVal );

} /* end of function qomx_CmpntCommon_AllocateBuffer */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_FreeBuffer

         DESCRIPTION:
                        Refer to OMX_FreeBuffer in OMX_Core.h or the
                        OMX IL specification for details on the
                        FreeBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.
            @param[in]  nPortIndex  - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_FreeBuffer
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr
)
{
   OMX_ERRORTYPE  eRetVal;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( & ( pCmpntCtx->commonRef ), "qomx_CmpntCommon_FreeBuffer,"
      " nPortIndex = 0x%x", nPortIndex );

   /**------------------------------------------------------------------------
      Call the appropriate port handler.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortFreeBuffer(
                        pCmpntCtx->hPortCtnr, nPortIndex, pBufferHdr );

   return( eRetVal );

} /* end of function qomx_CmpntCommon_FreeBuffer */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_EmptyThisBuffer

         DESCRIPTION:
                        Refer to OMX_EmptyThisBuffer in OMX_Core.h or the
                        OMX IL specification for details on the
                        EmptyThisBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_EmptyThisBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBufferHdr
)
{
   OMX_ERRORTYPE  eRetVal;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntCommon_EmptyThisBuffer" );

   /**------------------------------------------------------------------------
      Call the appropriate port handler.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortEmptyThisBuffer( pCmpntCtx->hPortCtnr, pBufferHdr );

   return( eRetVal );

} /* end of function qomx_CmpntCommon_EmptyThisBuffer */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_FillThisBuffer

         DESCRIPTION:
                        Refer to OMX_FillThisBuffer in OMX_Core.h or the
                        OMX IL specification for details on the
                        FillThisBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_FillThisBuffer
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE      *pBufferHdr
)
{
   OMX_ERRORTYPE  eRetVal;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntCommon_FillThisBuffer" );

   /**------------------------------------------------------------------------
      Call the appropriate port handler.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortFillThisBuffer( pCmpntCtx->hPortCtnr, pBufferHdr );

   return( eRetVal );

} /* end of function qomx_CmpntCommon_FillThisBuffer */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_ComponentDeInit

         DESCRIPTION:
                        Refer to OMX_ComponentDeInit in OMX_Core.h or the
                        OMX IL specification for details on the
                        ComponentDeInit method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_ComponentDeInit
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
)
{
   QOMX_CommonRefType  *pCommonRef = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pCommonRef, "qomx_CmpntCommon_ComponentDeInit" );

   /**------------------------------------------------------------------------
      Before closing the device, if there are any buffers that are not freed
      by IL client, we need to free them. Per spec, all buffers should have
      been freed at this point. We are acting only defensively.
   -------------------------------------------------------------------------*/
   qomx_PortFreeStrayBuffers( pCmpntCtx->hPortCtnr );

   /**------------------------------------------------------------------------
      Close the device.
   -------------------------------------------------------------------------*/
   QOMX_MSG_L_HIGH( pCommonRef,
      "Close device, hFd = 0x%p", pCommonRef->hFd );

   ( void ) pCommonRef->device.pfnClose( pCommonRef->hFd );

   /**------------------------------------------------------------------------
      De-Init all the ports and related data structures.
   -------------------------------------------------------------------------*/
   QOMX_MSG_L_HIGH( pCommonRef, "Deinit port container." );

   ( void ) qomx_PortContainer_DeInit( pCmpntCtx->hPortCtnr );

   /**------------------------------------------------------------------------
      Release all the port handles
   -------------------------------------------------------------------------*/
   QOMX_MSG_L_HIGH( pCommonRef, "Free port container handler." );

   ( void ) qomx_PortContainer_FreeHandle( pCommonRef, pCmpntCtx->hPortCtnr );


   return( OMX_ErrorNone );

} /* end of function qomx_CmpntCommon_ComponentDeInit */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_DeviceEventHandler

         DESCRIPTION:
                        Common event handler for all state implementations.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.
            @param [in] nEventCode  - Unique event code which came from
                                      the device.
            @param [in] nEventStatus- Status of the event.
            @param [in] nParamSize  - Size in bytes for the event related
                                      data which is pointed by the payload.
            @param [in] pParam      - Event related payload.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntCommon_DeviceEventHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pCommonRef, "qomx_CmpntCommon_DeviceEventHandler,"
      " nEventCode = 0x%x; nEventStatus = 0x%x.", nEventCode, nEventStatus );

   /**------------------------------------------------------------------------
      If extension specific event is received, pass it to IL client.
   -------------------------------------------------------------------------*/
   switch( nEventCode )
   {
   case MMI_EVT_QOMX_EXT_SPECIFIC:
      {
         MMI_ExtSpecificMsgType *pMsg
                  = ( MMI_ExtSpecificMsgType * ) pParam;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_HIGH( pCommonRef, "MMI Extension specific event." );

         /**------------------------------------------------------------------
            Validate parameters now.
         -------------------------------------------------------------------*/
         if( ( NULL != pMsg )
            && ( nParamSize == sizeof( MMI_ExtSpecificMsgType ) ) )
         {
            /**---------------------------------------------------------------
               Send this event to client now.
            ----------------------------------------------------------------*/
            ( void ) qomx_CmpntNotifyEvent( pCommonRef, pMsg->eEvent,
                              pMsg->nData1, pMsg->nData2, pMsg->pEventData );

         }
         else
         {
            QOMX_MSG_L_ERROR(
               pCommonRef, "Event dropped. Validation failed." );

         }

      }

      break;

   case MMI_EVT_PORT_DETECTION:
      {
         QOMX_MSG_L_HIGH( pCommonRef, "MMI_EVT_PORT_DETECTION event." );

         if( MMI_S_COMPLETE == nEventStatus )
         {
            QOMX_MSG_L_HIGH( pCommonRef, "Port format detected." );

            /**---------------------------------------------------------------
               Send port detection notification to the application.
            ----------------------------------------------------------------*/
            ( void ) qomx_CmpntNotifyEvent( pCommonRef,
                                    OMX_EventPortFormatDetected, 0, 0, NULL );

         }
         else
         {
            QOMX_MSG_L_ERROR( pCommonRef, "Port format not detected." );

            /**---------------------------------------------------------------
               Port format is not detected, report error.
            ----------------------------------------------------------------*/
            ( void ) qomx_CmpntNotifyError( pCommonRef,
                                    OMX_ErrorFormatNotDetected );

         }

      }

      break;

   case MMI_EVT_FATAL_ERROR:
      {
         OMX_ERRORTYPE eRetVal = qomx_GetOMXErrorCode( nEventStatus );
         /*-----------------------------------------------------------------*/
         QOMX_MSG_L_ERROR( pCommonRef, "MMI_EVT_FATAL_ERROR event, nEventStatus = 0x%x.", nEventStatus );

         /**------------------------------------------------------------------
            Irrecoverable fatal error, report error.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntNotifyError( pCommonRef, eRetVal );

         /**------------------------------------------------------------------
            Irrecoverable error. Move component to Invalid state.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx,
                                    QOMX_StateInvalid, QOMX_EVENT_UNKNOWN );

      }

      break;


   case MMI_EVT_HARDWARE_ERROR:
      {
         QOMX_MSG_L_ERROR( pCommonRef, "MMI_EVT_HARDWARE_ERROR event." );

         /**------------------------------------------------------------------
            Irrecoverable hardware error, report error.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntNotifyError( pCommonRef, OMX_ErrorHardware );

         /**------------------------------------------------------------------
            Irrecoverable error. Move component to Invalid state.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx,
                                    QOMX_StateInvalid, QOMX_EVENT_UNKNOWN );

      }

      break;

   default:
      {
         /**------------------------------------------------------------------
            Component may not be handling this event, pass it to port.
         -------------------------------------------------------------------*/
         eRetVal = qomx_PortDeviceEventHandler( pCmpntCtx->hPortCtnr,
                              nEventCode, nEventStatus, nParamSize, pParam );

      }

      break;

   } /* end of switch( nEventCode )  */

   return( eRetVal );

} /* end of function qomx_CmpntCommon_DeviceEventHandler */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_DoStateTransition

         DESCRIPTION:
                        This is a generic state transition routine which does
                        the common transition logic.

                        1) State management like calling entry and exit
                           functions.
                        2) Doing the actual transition.
                        3) Logging the transiton.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  eToState       - To state where the component state
                                         should transition to.
            @param[in]  nEvent         - Uniqueue event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntCommon_DoStateTransition
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   QOMX_CmpntStateType     eToState,
   OMX_IN   OMX_U8                  nEvent
)
{
   QOMX_CommonRefType        *pCommonRef  = & ( pCmpntCtx->commonRef );
   QOMX_CmpntStateTableType  *pStTable    = NULL;
   OMX_U64                    nTime       = 0;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntCommon_DoStateTransition,"
      " eToState = 0x%x, nEvent = 0x%x", ( OMX_U32 ) eToState, nEvent );

   QOMX_MSG_L_MED( pCommonRef, "Transition component from 0x%x to 0x%x",
      ( OMX_U32 ) pCmpntCtx->eMainState, ( OMX_U32 ) eToState );

   /**------------------------------------------------------------------------
      If switching from a steady state, setup variable required to measure
      the time it takes a component to change states.
   -------------------------------------------------------------------------*/
   switch (pCmpntCtx->eMainState)
   {
   case QOMX_StateInvalid:
      /* fall through */
   case QOMX_StateLoaded:
      /* fall through */
   case QOMX_StateIdle:
      /* fall through */
   case QOMX_StateExecuting:
      /* fall through */
   case QOMX_StatePause:
      /* fall through */
   case QOMX_StateWaitForResources:

      /**---------------------------------------------------------------------
         Get current system time.
      ----------------------------------------------------------------------*/
      ( void ) qomx_GetTime( & ( pCmpntCtx->nStateTransTime ) );

      break;

   default:

      break;

   }

   /**------------------------------------------------------------------------
      Invoke exit state handler for the current state which will do all event
      agnostic execution.
   -------------------------------------------------------------------------*/
   pStTable = qomx_CmpntCommon_GetStateTable(
                                       pCmpntCtx, pCmpntCtx->eMainState );

   if( NULL != pStTable->pfnExitHandler )
   {
      ( void ) pStTable->pfnExitHandler( pCmpntCtx, nEvent );

   }
   else
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Exit handler not defined"
         " for eMainState = 0x%x", ( OMX_U32 ) pCmpntCtx->eMainState );

   }

   /**------------------------------------------------------------------------
      Invoke entry state handler for the new state which will do all event
      agnostic execution.
   -------------------------------------------------------------------------*/
   pStTable = qomx_CmpntCommon_GetStateTable( pCmpntCtx, eToState );

   if( NULL != pStTable->pfnEntryHandler )
   {
      ( void ) pStTable->pfnEntryHandler( pCmpntCtx, nEvent );

   }
   else
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Entry handler not defined"
         " for eToState = 0x%x", ( OMX_U32 ) eToState );

   }


   /**------------------------------------------------------------------------
      If switching to a steady state, log the time it took to transition.
   -------------------------------------------------------------------------*/
   switch (eToState)
   {
   case QOMX_StateInvalid:
      /* fall through */
   case QOMX_StateLoaded:
      /* fall through */
   case QOMX_StateIdle:
      /* fall through */
   case QOMX_StateExecuting:
      /* fall through */
   case QOMX_StatePause:
      /* fall through */
   case QOMX_StateWaitForResources:

      /**---------------------------------------------------------------------
         Get current system time.
      ----------------------------------------------------------------------*/
      ( void ) qomx_GetTime( & nTime );

      /**---------------------------------------------------------------------
         Calculate latency time.
      ----------------------------------------------------------------------*/
      nTime = nTime - pCmpntCtx->nStateTransTime;

      QOMX_MSG_L_MED( pCommonRef, "State transition latency time = %lld ms,"
         " destination state = 0x%x", nTime, ( OMX_U32 ) eToState );

      break;

   default:

      break;

   }


   return;

} /* end of function qomx_CmpntCommon_DoStateTransition */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_StateTransitionCallback

         DESCRIPTION:
                        This function is called every time when a component
                        state transition callback is to be sent to the
                        application.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  eOmxState      - OMX state where component just
                                         transitioned.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntCommon_StateTransitionCallback
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_STATETYPE           eOmxState
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntCommon_StateTransitionCallback,"
      " eOmxState = 0x%x", ( OMX_U32 ) eOmxState );

   /**------------------------------------------------------------------------
      Send state change event notification.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntCmdComplete(
               pCommonRef, OMX_CommandStateSet, eOmxState, NULL );

   return;

} /* end of function qomx_CmpntCommon_StateTransitionCallback */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_CommandStateSet

         DESCRIPTION:
*//**                   This function is called from the send command
                        functions which are implemented inside QOMX states
                        implementation files. This function executes common
                        state set methods which applies to all the states
                        in the same manner.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.
            @param[in]  nParam      - Parameter 1. Refer OMX Spec.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void     qomx_CmpntCommon_CommandStateSet
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_U32                    nParam
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntCommon_CommandStateSet,"
      " nParam = 0x%x", nParam );

   if( pCmpntCtx->eOmxState == ( ( OMX_STATETYPE ) nParam ) )
   {
      QOMX_MSG_L_ERROR( pCommonRef,
         "Same state error, eState = 0x%x", nParam );

      /**---------------------------------------------------------------------
         An attempt to move to the same state is made when component is
         already in requested state, report SameState error.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntNotifyError(
                           & ( pCmpntCtx->commonRef ), OMX_ErrorSameState );

   }
   else if( OMX_StateInvalid == nParam )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Set to invalid state." );

      /**---------------------------------------------------------------------
         Move to Invalid state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntCommon_DoStateTransition(
                           pCmpntCtx, QOMX_StateInvalid, QOMX_EVENT_UNKNOWN );

   }
   else
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Incorrect state transition." );

      /**---------------------------------------------------------------------
         Requested state transition is not allowed in this state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntNotifyError(
                           pCommonRef, OMX_ErrorIncorrectStateTransition );

   }

   return;

} /* end of function qomx_CmpntCommon_CommandStateSet */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_SendCommand

         DESCRIPTION:
*//**                   This function is called from the send command
                        functions which are implemented inside QOMX states
                        implementation files. This function should be called
                        only when command has to be executed in a common way.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.
            @param[in]  eCmd        - Command which is being invoked.
            @param[in]  nParam      - Parameter 1. Refer OMX Spec.
            @param[in]  pCmdData    - Command payload. Refer OMX Spec.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE     qomx_CmpntCommon_SendCommand
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE            eCmd,
   OMX_IN   OMX_U32                    nParam,
   OMX_IN   OMX_PTR                    pCmdData
)
{
   OMX_ERRORTYPE        eRetVal = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntCommon_SendCommand,"
      " eCmd = 0x%x, nParam = 0x%x", ( OMX_U32 ) eCmd, nParam );

   /**------------------------------------------------------------------------
      Check the command type.
   -------------------------------------------------------------------------*/
   switch( eCmd )
   {
      /**---------------------------------------------------------------------
         Component specific commands which are allowed.
      ----------------------------------------------------------------------*/
      case OMX_CommandStateSet:
         {
            /**---------------------------------------------------------------
               Call common routine to handle set state command.
            ----------------------------------------------------------------*/
            ( void ) qomx_CmpntCommon_CommandStateSet( pCmpntCtx, nParam );

         }

         break;

      default:
         {
            QOMX_MSG_L_ERROR( pCommonRef, "Incorrect state operation." );

            /**---------------------------------------------------------------
               Requested command is not allowed in this state.
            ----------------------------------------------------------------*/
            ( void ) qomx_CmpntNotifyError(
                              pCommonRef, OMX_ErrorIncorrectStateOperation );

         }

         break;

   } /* end of switch( eCmd ) */

   return( eRetVal );

} /* end of function qomx_CmpntCommon_SendCommand */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_TunnelRequest

         DESCRIPTION:
                        Refer to OMX_ComponentTunnelRequest in OMX_Core.h
                        or the OMX IL specification for details on the
                        ComponentTunnelRequest method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  nPort          - Refer OMX_Core.h / OMX IL spec.
            @param[in]  hTunneledComp  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nTunneledPort  - Refer OMX_Core.h / OMX IL spec.
            @param[inout] pTunnelSetup - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_CmpntCommon_TunnelRequest
(
   OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN      OMX_U32                 nPort,
   OMX_IN      OMX_HANDLETYPE          hTunneledComp,
   OMX_IN      OMX_U32                 nTunneledPort,
   OMX_INOUT   OMX_TUNNELSETUPTYPE    *pTunnelSetup
)
{
   OMX_ERRORTYPE  eRetVal;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( & ( pCmpntCtx->commonRef ),
      "qomx_CmpntCommon_TunnelRequest, nPort = 0x%x,"
         "nTunneledPort = 0x%x", nPort, nTunneledPort );

   /**------------------------------------------------------------------------
      Call the appropriate port handler.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortTunnelRequest( pCmpntCtx->hPortCtnr, nPort,
                              hTunneledComp, nTunneledPort, pTunnelSetup );

   return( eRetVal );

} /* end of function qomx_CmpntLoaded_TunnelRequest */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_LoadStateTables

         DESCRIPTION:
                        This function will load all the component state tables
                        in the array of state primitive tables being passed.
                        Memory for this array is pre-allocated in component
                        initialization.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  paStTable      - Pointer to the base of array of state
                                         primitive table objects.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntCommon_LoadStateTables
(
   OMX_IN   QOMX_CmpntStateTableType  *paStTable
)
{
   /**------------------------------------------------------------------------
      Load All the state tables in respective indexes.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntInvalid_LoadStateTable(
                           & ( paStTable[ QOMX_StateInvalid ] ) );

   ( void ) qomx_CmpntLoaded_LoadStateTable(
                           & ( paStTable[ QOMX_StateLoaded ] ) );

   ( void ) qomx_CmpntIdle_LoadStateTable(
                           & ( paStTable[ QOMX_StateIdle ] ) );

   ( void ) qomx_CmpntExecuting_LoadStateTable(
                           & ( paStTable[ QOMX_StateExecuting ] ) );

   ( void ) qomx_CmpntPause_LoadStateTable(
                           & ( paStTable[ QOMX_StatePause ] ) );

   ( void ) qomx_CmpntWaitForResources_LoadStateTable(
                           & ( paStTable[ QOMX_StateWaitForResources ] ) );

   ( void ) qomx_CmpntLoadedToIdle_LoadStateTable(
                           & ( paStTable[ QOMX_StateLoadedToIdle ] ) );

   ( void ) qomx_CmpntIdleToLoaded_LoadStateTable(
                           & ( paStTable[ QOMX_StateIdleToLoaded ] ) );

   ( void ) qomx_CmpntIdleToExecuting_LoadStateTable(
                           & ( paStTable[ QOMX_StateIdleToExecuting ] ) );

   ( void ) qomx_CmpntIdleToPause_LoadStateTable(
                           & ( paStTable[ QOMX_StateIdleToPause ] ) );

   ( void ) qomx_CmpntExecutingToIdle_LoadStateTable(
                           & ( paStTable[ QOMX_StateExecutingToIdle ] ) );

   ( void ) qomx_CmpntExecutingToPause_LoadStateTable(
                           & ( paStTable[ QOMX_StateExecutingToPause ] ) );

   ( void ) qomx_CmpntPauseToExecuting_LoadStateTable(
                           & ( paStTable[ QOMX_StatePauseToExecuting ] ) );

   return;

} /* end of function qomx_CmpntCommon_LoadStateTables */


/*==========================================================================

         FUNCTION:      qomx_CmpntCommon_GetStateTable

         DESCRIPTION:
                        This function will return a component state machine
                        function table corresponding the QOMX state passed
                        as the parameter.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  eState         - QOMX State enumeration.

**//*     RETURN VALUE:
*//**       @return     Pointer to the state primitive table as appripriate.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
QOMX_CmpntStateTableType*  qomx_CmpntCommon_GetStateTable
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   QOMX_CmpntStateType     eState
)
{
   QOMX_CmpntStateTableType  *pStTable = NULL;
   QOMX_CmpntStateTableType  *paStTable
               = ( QOMX_CmpntStateTableType * ) ( pCmpntCtx->hStateTables );
   /*-----------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Check state and fill appropriate state table.
   -------------------------------------------------------------------------*/
   switch( eState )
   {
   case QOMX_StateLoaded:
      {
         pStTable = & ( paStTable[ QOMX_StateLoaded ] );
      }

      break;

   case QOMX_StateIdle:
      {
         pStTable = & ( paStTable[ QOMX_StateIdle ] );
      }

      break;

   case QOMX_StateExecuting:
      {
         pStTable = & ( paStTable[ QOMX_StateExecuting ] );
      }

      break;

   case QOMX_StatePause:
      {
         pStTable = & ( paStTable[ QOMX_StatePause ] );
      }

      break;

   case QOMX_StateWaitForResources:
      {
         pStTable = & ( paStTable[ QOMX_StateWaitForResources ] );
      }

      break;

   case QOMX_StateLoadedToIdle:
      {
         pStTable = & ( paStTable[ QOMX_StateLoadedToIdle ] );
      }

      break;

   case QOMX_StateIdleToLoaded:
      {
         pStTable = & ( paStTable[ QOMX_StateIdleToLoaded ] );
      }

      break;

   case QOMX_StateIdleToExecuting:
      {
         pStTable = & ( paStTable[ QOMX_StateIdleToExecuting ] );
      }

      break;

   case QOMX_StateIdleToPause:
      {
         pStTable = & ( paStTable[ QOMX_StateIdleToPause ] );
      }

      break;

   case QOMX_StateExecutingToIdle:
      {
         pStTable = & ( paStTable[ QOMX_StateExecutingToIdle ] );
      }

      break;

   case QOMX_StateExecutingToPause:
      {
         pStTable = & ( paStTable[ QOMX_StateExecutingToPause ] );
      }

      break;

   case QOMX_StatePauseToExecuting:
      {
         pStTable = & ( paStTable[ QOMX_StatePauseToExecuting ] );
      }

      break;

   case QOMX_StateInvalid:
      /* fall through */
   default:
      {
         pStTable = & ( paStTable[ QOMX_StateInvalid ] );
      }

      break;

   } /* end of switch( eState ) */

   return(  pStTable );

} /* end of function qomx_CmpntCommon_GetStateTable */

