#ifndef __OMX_PORT_UTILS_H__
#define __OMX_PORT_UTILS_H__

/*========================================================================

*//** @file qomxPortUtils.h 

@par FILE SERVICES:
      Port Interface Utility File.
      
      This file contains the port interfaces which are used by component
      to pass port specific OMX calls to port state handler methods.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxPortUtils.h#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
03/07/11   yt     Add cleanup mechanism for non-freed buffers during deinit.
11/08/10   zm     Set vendor-tunneled port state to Populated after load
                  resource command succeeds, only if the port is enabled.
08/28/10   zm     Added support for vendor tunneling.
06/10/10   dm     Added return type in event handler.
08/06/09   dm     Added setparameter checks for states.
06/16/09   dm     Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */


/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Functions
** ----------------------------------------------------------------------- */

/*==========================================================================
     
         FUNCTION:      qomx_PortContainer_GetHandle

         DESCRIPTION:
                        This function is used to get port context handle for a
                        component. This function allocates and initializes an
                        array of input and output port based on configuration
                        described by the IL client.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pConfig     - Pointer to the object of IL component
                                      configuration.
            @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[out] pHPortCtnr  - Pointer to an object of OMX_HANDLETYPE
                                      type which will be assigned handle to
                                      the port container on successful
                                      return.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortContainer_GetHandle
(
   OMX_IN   QOMX_CmpntConfig    *pConfig,
   OMX_IN   QOMX_CommonRefType  *pCommonRef,
   OMX_OUT  OMX_HANDLETYPE      *pHPortCtnr
);


/*==========================================================================
     
         FUNCTION:      qomx_PortContainer_DeInit

         DESCRIPTION:
                        This function deinitializes all the ports contained
                        within the port container handle.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortContainer_DeInit
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr
);


/*==========================================================================
     
         FUNCTION:      qomx_PortContainer_FreeHandle

         DESCRIPTION:
                        This function releases the handle itself. This function 
                        executes only when buffer processings on all the ports 
                        are either carried out or flushed. After this call the 
                        handle is not valid for any further use.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container. Handle
                                      no longer remains valid for any further
                                      references.
            @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortContainer_FreeHandle
(
   OMX_IN   QOMX_CommonRefType  *pCommonRef,
   OMX_IN   OMX_HANDLETYPE       hPortCtnr
);


/*==========================================================================

         FUNCTION:      qomx_PortStartPopulating

         DESCRIPTION:
                        This function is called when component moves from 
                        Loaded to Idle state. This function moves all the
                        enabled ports to populating state so that they can
                        begin accepting / allocating buffers.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortStartPopulating
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr
);


/*==========================================================================

         FUNCTION:      qomx_PortUnpopulate

         DESCRIPTION:
                        This function is called when component is transitioned
                        to Loaded state. This function moves all the enabled
                        ports to unpopulated state.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortUnpopulate
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr
);


/*==========================================================================

         FUNCTION:      qomx_PortStartBufferProcessing

         DESCRIPTION:
                        This function is called when component is transitioned
                        from Idle to Executing state. This function starts 
                        buffer processing on the enabled ports when tunneled.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortStartBufferProcessing
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr
);


/*==========================================================================

         FUNCTION:      qomx_PortStopBufferProcessing

         DESCRIPTION:
                        This function is called when component is transitioned
                        from Executing / Pause to Idle state. This function 
                        stops buffer processing on the enabled ports when 
                        tunneled.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortStopBufferProcessing
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr
);


/*==========================================================================
     
         FUNCTION:      qomx_PortEnable

         DESCRIPTION:
                        Refer to OMX_SendCommand in OMX_Core.h or the OMX IL 
                        specification for details on the
                        OMX_CommandPortEnable command.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nPortIndex  - Index for the port which should be
                                      enabled.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortEnable
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr,
   OMX_IN   OMX_U32           nPortIndex
);


/*==========================================================================
     
         FUNCTION:      qomx_PortDisable

         DESCRIPTION:
                        Refer to OMX_SendCommand in OMX_Core.h or the OMX IL 
                        specification for details on the
                        OMX_CommandPortDisable command.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nPortIndex  - Index for the port which should be
                                      disabled.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortDisable
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr,
   OMX_IN   OMX_U32           nPortIndex
);


/*==========================================================================
     
         FUNCTION:      qomx_PortGetParameter

         DESCRIPTION:
                        Refer to OMX_GetParameter in OMX_Core.h or the OMX IL 
                        specification for details on the GetParameter method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nParamIndex - Refer OMX_Core.h / OMX IL specification.
            @param[inout] pCmpntParm
                                    - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortGetParameter
(
   OMX_IN      OMX_HANDLETYPE    hPortCtnr,
   OMX_IN      OMX_INDEXTYPE     nParamIndex,
   OMX_INOUT   OMX_PTR           pCmpntParm
);


/*==========================================================================
     
         FUNCTION:      qomx_PortSetParameter

         DESCRIPTION:
                        Refer to OMX_GetParameter in OMX_Core.h or the OMX IL 
                        specification for details on the SetParameter method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nParamIndex - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pCmpntParm  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortSetParameter
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr,
   OMX_IN   OMX_INDEXTYPE     nParamIndex,
   OMX_IN   OMX_PTR           pCmpntParm
);


/*==========================================================================
     
         FUNCTION:      qomx_PortGetConfig

         DESCRIPTION:
                        Refer to OMX_GetConfig in OMX_Core.h or the OMX IL 
                        specification for details on the GetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nCfgIndex   - Refer OMX_Core.h / OMX IL specification.
            @param[inout] pCmpntCfg - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortGetConfig
(
   OMX_IN      OMX_HANDLETYPE    hPortCtnr,
   OMX_IN      OMX_INDEXTYPE     nCfgIndex,
   OMX_INOUT   OMX_PTR           pCmpntCfg
);


/*==========================================================================
     
         FUNCTION:      qomx_PortSetConfig

         DESCRIPTION:
                        Refer to OMX_SetConfig in OMX_Core.h or the OMX IL 
                        specification for details on the SetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nCfgIndex   - Index for the port on which method 
                                      need to be executed.
            @param[in]  pCmpntCfg   - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortSetConfig
(
   OMX_IN      OMX_HANDLETYPE    hPortCtnr,
   OMX_IN      OMX_INDEXTYPE     nCfgIndex,
   OMX_INOUT   OMX_PTR           pCmpntCfg
);

/*==========================================================================

         FUNCTION:      qomx_PortTunnelRequest

         DESCRIPTION:
                        Refer to OMX_ComponentTunnelRequest in OMX_Core.h
                        or the OMX IL specification for details on the 
                        ComponentTunnelRequest method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr      - Handle to the port container.
            @param[in]  nPort          - Refer OMX_Core.h / OMX IL spec.
            @param[in]  hTunneledComp  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nTunneledPort  - Refer OMX_Core.h / OMX IL spec.
            @param[out] pTunnelSetup   - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/

OMX_ERRORTYPE  qomx_PortTunnelRequest
(
   OMX_IN      OMX_HANDLETYPE             hPortCtnr,
   OMX_IN      OMX_U32                    nPort,
   OMX_IN      OMX_HANDLETYPE             hTunneledComp,
   OMX_IN      OMX_U32                    nTunneledPort,
   OMX_INOUT   OMX_TUNNELSETUPTYPE       *pTunnelSetup
);


/*==========================================================================
     
         FUNCTION:      qomx_PortUseBuffer

         DESCRIPTION:
                        Refer to OMX_UseBuffer in OMX_Core.h or the OMX IL 
                        specification for details on the UseBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nPortIndex  - Index for the port on which method 
                                      need to be executed.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL specification.
            @param[in]  nSizeBytes  - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pBuffer     - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortUseBuffer
(
   OMX_IN   OMX_HANDLETYPE          hPortCtnr,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_OUT  OMX_BUFFERHEADERTYPE  **ppBufferHdr,
   OMX_IN   OMX_PTR                 pAppPrivate,
   OMX_IN   OMX_U32                 nSizeBytes,
   OMX_IN   OMX_U8                 *pBuffer
);


/*==========================================================================
     
         FUNCTION:      qomx_PortAllocateBuffer

         DESCRIPTION:
                        Refer to OMX_AllocateBuffer in OMX_Core.h or the OMX
                        IL specification for details on the AllocateBuffer
                        method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nPortIndex  - Index for the port on which method 
                                      need to be executed.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL specification.
            @param[in]  nSizeBytes  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortAllocateBuffer
(
   OMX_IN   OMX_HANDLETYPE          hPortCtnr,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_OUT  OMX_BUFFERHEADERTYPE  **ppBufferHdr,
   OMX_IN   OMX_PTR                 pAppPrivate,
   OMX_IN   OMX_U32                 nSizeBytes
);


/*==========================================================================
     
         FUNCTION:      qomx_PortFreeBuffer

         DESCRIPTION:
                        Refer to OMX_FreeBuffer in OMX_Core.h or the OMX IL
                        specification for details on the FreeBuffer method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nPortIndex  - Index for the port on which method 
                                      need to be executed.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortFreeBuffer
(
   OMX_IN   OMX_HANDLETYPE          hPortCtnr,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr
);


/*==========================================================================
     
         FUNCTION:      qomx_PortEmptyThisBuffer

         DESCRIPTION:
                        Refer to OMX_EmptyThisBuffer in OMX_Core.h or the OMX
                        IL specification for details on the EmptyThisBuffer
                        method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortEmptyThisBuffer
(
   OMX_IN   OMX_HANDLETYPE          hPortCtnr,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr
);


/*==========================================================================
     
         FUNCTION:      qomx_PortFillThisBuffer

         DESCRIPTION:
                        Refer to OMX_FillThisBuffer in OMX_Core.h or the OMX
                        IL specification for details on the FillThisBuffer
                        method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortFillThisBuffer
(
   OMX_IN   OMX_HANDLETYPE          hPortCtnr,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr
);


/*==========================================================================
     
         FUNCTION:      qomx_PortFlush

         DESCRIPTION:
                        Refer to OMX_SendCommand in OMX_Core.h or the OMX
                        IL specification for details on the OMX_CommandFlush
                        command.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nPortIndex  - Index for the port on which method 
                                      need to be executed.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortFlush
(
   OMX_IN   OMX_HANDLETYPE          hPortCtnr,
   OMX_IN   OMX_U32                 nPortIndex
);


/*==========================================================================

         FUNCTION:      qomx_VendorTunnel_PortMarkBufferCommand

         DESCRIPTION:
                        This function sends a mark buffer MMI command to 
						device for vendor tunneled port.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information
            @param[in]  nPortIndex  - Index for the port on which method 
                                      need to be executed.
            @param[in]  pMark       - Mark data and target component 
									  information.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE qomx_VendorTunnel_PortMarkBufferCommand
(
   QOMX_CommonRefType			   *pCommonRef,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_IN   OMX_MARKTYPE           *pMark
);


/*==========================================================================
     
         FUNCTION:      qomx_PortMarkBuffer

         DESCRIPTION:
                        Refer to OMX_SendCommand in OMX_Core.h or the OMX
                        IL specification for details on the OMX_CommandMarkBuffer
                        command.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  nPortIndex  - Index for the port on which method 
                                      need to be executed.
            @param[in]  pMark       - Mark data and target component information.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortMarkBuffer
(
   OMX_IN   OMX_HANDLETYPE          hPortCtnr,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_IN   OMX_MARKTYPE           *pMark
);


/*==========================================================================
     
         FUNCTION:      qomx_PortDeviceEventHandler

         DESCRIPTION:
                        This function is used by the component to send port
                        specific events to the port event handler.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param [in] nEventCode  - Unique event code which came from
                                      the device.
            @param [in] nEventStatus- Status of the event.
            @param [in] nParamSize  - Size in bytes for the event related
                                      data which is pointed by the payload.
            @param [in] pParam      - Event related payload.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortDeviceEventHandler
(
   OMX_IN   OMX_HANDLETYPE          hPortCtnr,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
);


/*==========================================================================
     
         FUNCTION:      qomx_PortGuardIsTrue

         DESCRIPTION:
                        This function is used to evaluate a guard condition.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.
            @param[in]  eGuard      - Guard which need to be checked.

**//*    RETURN VALUE:
*//**       @return     
                        OMX_TRUE   - When guard condition is satisfied.
                        OMX_FALSE  - otherwise.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_BOOL    qomx_PortGuardIsTrue
( 
   OMX_IN   OMX_HANDLETYPE          hPortCtnr,
   OMX_IN   QOMX_GuardType          eGuard
);


/*==========================================================================

         FUNCTION:      qomx_VendorTunnel_SetEnabledPortsPopulated

         DESCRIPTION:
                        This function is used to transition enabled vendor 
                        tunneled port to EnabledPopulated after load 
                        resource command succeeds; and signal peer if the 
                        port is supplier.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of common
									           reference.
		      @param[in]  hPortCtnr   - Handle to port container.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on successful validation.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void	qomx_VendorTunnel_SetEnabledPortsPopulated
( 
   OMX_IN   QOMX_CommonRefType	   *pCommonRef,
   OMX_IN   OMX_HANDLETYPE          hPortCtnr
);


/*==========================================================================

         FUNCTION:      qomx_PortFreeStrayBuffers

         DESCRIPTION:
                        This function is called during component deinit and
                        aims to free any buffers and buffer headers that
                        IL client failed to free.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hPortCtnr   - Handle to the port container.

**//*    RETURN VALUE:
*//**       @return     None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortFreeStrayBuffers
(
   OMX_IN   OMX_HANDLETYPE    hPortCtnr
);

#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */


#endif /* end of macro __OMX_PORT_UTILS_H__ */
