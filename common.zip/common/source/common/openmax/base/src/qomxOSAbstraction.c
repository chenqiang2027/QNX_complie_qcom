/*========================================================================

*//** @file qomxOSAbstraction.c 

@par FILE SERVICES:       
      OS Abstraction Implementation File.

      This file contains implmentation for OS abstraction interfaces.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2016 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxOSAbstraction.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
06/22/16   am     Fix compiler warnings for 64 bit OS environment.
11/22/10   zm     Change qomx_OSHeapGetHandle signature to use it as default
                  MMI GetHeapHandle routine.
11/12/10   zm     Use MMOSAL malloc/free.
10/22/09   dm     Changed file to use MMOSAL.
08/08/09   dm     Memory functions abstracted.
07/13/09   dm     Initial Creation.

========================================================================== */

/*======================================================================== 
 
                     INCLUDE FILES FOR MODULE 
 
========================================================================== */
#include "qomxOSAbstraction.h"
#include "MMMalloc.h"
#include "MMCriticalSection.h"
#include "MMTimer.h"
#include "qomxUtils.h"
#include "mmiDeviceApi.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Functions
** ----------------------------------------------------------------------- */


/*==========================================================================

         FUNCTION:      qomx_CreateCriticalSection

         DESCRIPTION:
*//**
                        This function implements the method for creating the
                        critical section and aquiring the required resources.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[out] pHCrtSec - This parameter will hold the pointer to
                                   just created critical section context
                                   upon exit.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
===========================================================================*/
void  qomx_CreateCriticalSection
(
   OMX_OUT  OMX_HANDLETYPE      *pHCrtSec
)
{
   /**------------------------------------------------------------------------
      Create video critical section.
   -------------------------------------------------------------------------*/
   ( void ) MM_CriticalSection_Create( ( MM_HANDLE * ) pHCrtSec );

   return;

} /* end of function qomx_CreateCriticalSection */


/*==========================================================================

         FUNCTION:      qomx_ReleaseCriticalSection

         DESCRIPTION:
*//**
                        This function implements the method for releasing the
                        critical section and releasing all the resources
                        associated with this.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  hCrtSec  - Handle to the critical section context.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
===========================================================================*/
void  qomx_ReleaseCriticalSection
(
   OMX_IN   OMX_HANDLETYPE       hCrtSec
)
{
   /**------------------------------------------------------------------------
      Release video critical section.
   -------------------------------------------------------------------------*/
   ( void ) MM_CriticalSection_Release( ( MM_HANDLE ) hCrtSec );

   return;

} /* end of function qomx_ReleaseCriticalSection */


/*==========================================================================

         FUNCTION:      qomx_EnterCriticalSection

         DESCRIPTION:
*//**
                        This function implements the method to enter a
                        critical section. This function blocks if another
                        thread is inside the critical section until the other
                        thread leaves the critical section.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  hCrtSec  - Handle to the critical section context.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
===========================================================================*/
void  qomx_EnterCriticalSection
(
   OMX_IN   OMX_HANDLETYPE       hCrtSec
)
{
   /**------------------------------------------------------------------------
      Lock video critical section.
   -------------------------------------------------------------------------*/
   ( void ) MM_CriticalSection_Enter( ( MM_HANDLE ) hCrtSec );

   return;

} /* end of function qomx_EnterCriticalSection */


/*==========================================================================

         FUNCTION:      qomx_LeaveCriticalSection

         DESCRIPTION:
*//**
                        This function implements the method to leave a
                        critical section.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  hCrtSec  - Handle to the critical section context.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
===========================================================================*/
void  qomx_LeaveCriticalSection
(
   OMX_IN   OMX_HANDLETYPE       hCrtSec
)
{
   /**------------------------------------------------------------------------
      Unlock video critical section.
   -------------------------------------------------------------------------*/
   ( void ) MM_CriticalSection_Leave( ( MM_HANDLE ) hCrtSec );
   
   return;

} /* end of function qomx_LeaveCriticalSection */


/*==========================================================================

         FUNCTION:      qomx_OSHeapGetHandle

         DESCRIPTION:
*//**
                        This function calls appropriate instantiation function
                        to create OS specific memory module which is used for
                        memory management for the current component.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[out] pHHeap - Handle to the heap area would be filled here.

*//*     RETURN VALUE:
*//**       @return     MMI_S_COMPLETE  - on successful validation.
                        Other error codes - As appropriate on failures.

@par     SIDE EFFECTS:
                        None
===========================================================================*/
OMX_U32  qomx_OSHeapGetHandle
(
   OMX_OUT  OMX_HANDLETYPE         *pHHeap
)
{
   /**------------------------------------------------------------------------
      Call appropriate function to instantiate heap memory. Since Win32 and
      AMSS do not have designated memory modules, set this to NULL.
   -------------------------------------------------------------------------*/
   ( * pHHeap ) = NULL;
 
   return( MMI_S_COMPLETE );

} /* end of function qomx_OSHeapGetHandle */


/*==========================================================================

         FUNCTION:      qomx_OSHeapReleaseHandle

         DESCRIPTION:
*//**
                        This function calls appropriate deinit function
                        to release OS specific memory module which is used for
                        memory management for the current component.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  hHeap - Handle to the heap area.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
===========================================================================*/
void  qomx_OSHeapReleaseHandle
(
   OMX_IN   OMX_HANDLETYPE       hHeap
)
{
   /**------------------------------------------------------------------------
      Call appropriate function to release heap memory region. Since Win32
      and AMSS do not have designated memory modules, do nothing.
   -------------------------------------------------------------------------*/

   return;

} /* end of function qomx_OSHeapReleaseHandle */


/*==========================================================================

         FUNCTION:      qomx_OSMalloc

         DESCRIPTION:
*//**
                        This function calls appropriate memory allocation 
                        routine from the given heap area to allocate requested
                        number of bytes.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  hHeap - Handle to the heap area.
            @param[in]  nSize - Number of bytes to be allocated.

*//*     RETURN VALUE:
*//**       @return     Pointer to the allocated memory area.

@par     SIDE EFFECTS:
                        None
===========================================================================*/
void *   qomx_OSMalloc
(
   OMX_IN   OMX_HANDLETYPE       hHeap,
   OMX_IN   OMX_U32              nSize
)
{
   void    *pMem;
   /*-----------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Call appropriate function to allocate memory from the given memory
      region. Since Win32 and AMSS do not have designated memory modules,
      call normal malloc() routine.
   -------------------------------------------------------------------------*/
   pMem = ( void * ) MM_Malloc( nSize );
   
   return( pMem );

} /* end of function qomx_OSMalloc */


/*==========================================================================

         FUNCTION:      qomx_OSFree

         DESCRIPTION:
*//**
                        This function calls appropriate free allocation 
                        routine from the given heap area to release previously
                        allocated memory.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  hHeap - Handle to the heap area.
            @param[in]  pMem  - Pointer to the memory location to be freed.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
===========================================================================*/
void  qomx_OSFree
(
   OMX_IN   OMX_HANDLETYPE       hHeap,
   OMX_IN   void                *pMem
)
{
   /**------------------------------------------------------------------------
      Call appropriate function to release memory from the given memory
      region. Since Win32 and AMSS do not have designated memory modules,
      call normal free() routine.
   -------------------------------------------------------------------------*/
   ( void ) MM_Free( pMem );
   
   return;

} /* end of function qomx_OSFree */


/*==========================================================================

         FUNCTION:      qomx_GetTime

         DESCRIPTION:
*//**
                        This function calls appropriate get time routine on
                        the given OS Abstraction layer.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[out] pTime - Pointer to a OMX_U64 integer which will be 
                                assigned time in MS on return.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
===========================================================================*/
void  qomx_GetTime
(
   OMX_U64       *pTime
)
{
   /**------------------------------------------------------------------------
      Call appropriate function to get time.
   -------------------------------------------------------------------------*/
   ( void ) MM_Time_GetTimeEx( pTime );

   return;

} /* end of function qomx_GetTime */
