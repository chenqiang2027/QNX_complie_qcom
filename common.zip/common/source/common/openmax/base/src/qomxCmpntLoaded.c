/*========================================================================

*//** @file qomxCmpntLoaded.c 

@par FILE SERVICES:       
      Component Loaded State Implementation File.

      This file implements all the methods which are applicable for
      OMX_StateLoaded state.
      
      Main functions are Send Command and set call backs. Functions which are 
      common for all states are implemented in the common functions table.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2018 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCmpntLoaded.c#1 $ 
when       who    what, where, why
--------   ---    -------------------------------------------------------  
04/05/18   rz     Fix print fmt check errors
12/13/13   rz     Support MarkBuffer in Loaded state
08/11/10   zm     Reset resource state after Loaded transition finishes.				  
07/22/10   zm     Add component handle in each base class logging message.
03/26/10   spl    Modified to support interop-profile.
03/17/10   dm     Allow Idle state transition in resource lost state too.
02/11/10   dm     Block Idle state transition if resources were lost.
10/30/09   dm     Fixed compilation warning.
10/29/09   dm     Allow tunneling on disabled ports in any OMX state.
10/29/09   dm     Disallow port commands in component transitional states.
09/30/09   dm     Split component states.
04/11/09   srk    Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxCmpntCommon.h"
#include "qomxPortUtils.h"

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 * 
 * Forward declaration for the functions statically defined in this file.
 * 
 */

static void    qomx_CmpntLoaded_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
);

static void    qomx_CmpntLoaded_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
   
);

static OMX_ERRORTYPE    qomx_CmpntLoaded_SendCommand
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE         eCmd,
   OMX_IN   OMX_U32                 nParam,
   OMX_IN   OMX_PTR                 pCmdData
);

static OMX_ERRORTYPE    qomx_CmpntLoaded_SetCallbacks
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_CALLBACKTYPE       *pCallbacks,
   OMX_IN   OMX_PTR                 pAppData
);

static OMX_ERRORTYPE    qomx_CmpntLoaded_SetStateIdle
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_CmpntLoaded_LoadStateTable

         DESCRIPTION:
                        This function will load the component state table
                        supported by the Loaded state in the object of
                        state table being passed.
            
@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable - Pointer to the state primitive table
                                   object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntLoaded_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      component is in QOMX_StateLoaded state. NULL entry indicates that the
      specific function call is not allowed in this state, thus component API
      should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/   
   pStTable->GetComponentVersion    = qomx_CmpntCommon_GetComponentVersion;
   pStTable->SendCommand            = qomx_CmpntLoaded_SendCommand;
   pStTable->GetParameter           = qomx_CmpntCommon_GetParameter;
   pStTable->SetParameter           = qomx_CmpntCommon_SetParameter;
   pStTable->GetConfig              = qomx_CmpntCommon_GetConfig;
   pStTable->SetConfig              = qomx_CmpntCommon_SetConfig;
   pStTable->GetExtensionIndex      = qomx_CmpntCommon_GetExtensionIndex;
   pStTable->GetState               = qomx_CmpntCommon_GetState;
   pStTable->ComponentTunnelRequest = qomx_CmpntCommon_TunnelRequest;
   pStTable->UseBuffer              = NULL;
   pStTable->AllocateBuffer         = NULL;
   pStTable->FreeBuffer             = NULL;
   pStTable->EmptyThisBuffer        = NULL;
   pStTable->FillThisBuffer         = NULL;
   pStTable->SetCallbacks           = qomx_CmpntLoaded_SetCallbacks;
   pStTable->ComponentDeInit        = qomx_CmpntCommon_ComponentDeInit;
   pStTable->UseEGLImage            = NULL;
   pStTable->ComponentRoleEnum      = qomx_CmpntCommon_ComponentRoleEnum;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler        = qomx_CmpntCommon_DeviceEventHandler;
   
   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler        = qomx_CmpntLoaded_StateEntryHandler;
   pStTable->pfnExitHandler         = qomx_CmpntLoaded_StateExitHandler;

   return;

} /* end of function qomx_CmpntLoaded_LoadStateTable */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntLoaded_StateEntryHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateLoaded is entered. Entry into the state
                        performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntLoaded_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Entering Loaded State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Entering Loaded State, nEvent = 0x%x", nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pCmpntCtx->eMainState = QOMX_StateLoaded;
   pCmpntCtx->eOmxState  = OMX_StateLoaded;

   /**------------------------------------------------------------------------
      Reset the resource state.
   -------------------------------------------------------------------------*/
   pCmpntCtx->eResState = QOMX_RESOURCES_UNRESERVED;

   return;

} /* end of function qomx_CmpntLoaded_StateEntryHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntLoaded_StateExitHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateLoaded is exited. Exit from this state
                        performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntLoaded_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Exiting Loaded State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Exiting Loaded State, nEvent = 0x%x", nEvent );

   return;
   
} /* end of function qomx_CmpntLoaded_StateExitHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntLoaded_SendCommand

         DESCRIPTION:
*//**                   This function is called every time when Send command
                        is invoked in Loaded state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.
            @param[in]  eCmd        - Command which is being invoked.
            @param[in]  nParam      - Parameter 1. Refer OMX Spec.
            @param[in]  pCmdData    - Command payload. Refer OMX Spec.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntLoaded_SendCommand
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE            eCmd,
   OMX_IN   OMX_U32                    nParam,
   OMX_IN   OMX_PTR                    pCmdData
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntLoaded_SendCommand,"
      " eCmd = 0x%x, nParam = 0x%x", eCmd, nParam );

   /**------------------------------------------------------------------------
      Check the command type.
   -------------------------------------------------------------------------*/
   switch( eCmd )
   {
      /**---------------------------------------------------------------------  
         Component specific commands which are allowed in this state.
      ----------------------------------------------------------------------*/
      case OMX_CommandStateSet:
         {
            if( OMX_StateIdle == nParam ) 
            {
               QOMX_MSG_L_MED( pCommonRef, "Set Idle state." );

               /**------------------------------------------------------------
                  Call internal function to do steps to move to Loaded state.
               -------------------------------------------------------------*/
               eRetVal = qomx_CmpntLoaded_SetStateIdle( pCmpntCtx );

            }
            else if( OMX_StateWaitForResources == nParam )
            {
               QOMX_MSG_L_MED( pCommonRef, "Set WFR state." );

               /**------------------------------------------------------------
                  Move to WaitForResources state.
               -------------------------------------------------------------*/
               ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                           QOMX_StateWaitForResources, QOMX_EVENT_UNKNOWN );

            }
            else 
            {
               /**------------------------------------------------------------
                  Call common routine to handle set state command.
               -------------------------------------------------------------*/
               ( void ) qomx_CmpntCommon_CommandStateSet( pCmpntCtx, nParam );

            }

         }

         break;

      /**---------------------------------------------------------------------
         Port specific commands which allowed.
      ----------------------------------------------------------------------*/
      case OMX_CommandPortDisable:
         {
            QOMX_MSG_L_MED( pCommonRef, "Disable Port = 0x%x", nParam );

            /**---------------------------------------------------------------
               Send port disable request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortDisable( pCmpntCtx->hPortCtnr, nParam );

         }

         break;

      case OMX_CommandPortEnable:
         {
            QOMX_MSG_L_MED( pCommonRef, "Enable Port = 0x%x", nParam );

            /**---------------------------------------------------------------
               Send port enable request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortEnable( pCmpntCtx->hPortCtnr, nParam );

         }

         break;

      case OMX_CommandMarkBuffer:
         {
            OMX_MARKTYPE  *pMark = ( OMX_MARKTYPE * ) pCmdData;
            /*--------------------------------------------------------------*/

            QOMX_MSG_L_MED( pCommonRef, "Mark Port = 0x%x", nParam );

            /**---------------------------------------------------------------
               Send mark buffer request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortMarkBuffer( 
                                 pCmpntCtx->hPortCtnr, nParam, pMark );

         }

         break;

      default:
         {
            /**---------------------------------------------------------------
               Call common routine to handle rest of the commands.
            ----------------------------------------------------------------*/
            eRetVal = qomx_CmpntCommon_SendCommand(
                                          pCmpntCtx, eCmd, nParam, pCmdData );

         }

         break;

   } /* end of switch( eCmd ) */

   return( eRetVal );

} /* end of function qomx_CmpntLoaded_SendCommand */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntStateSetCallBacks

         DESCRIPTION:
*//**                   This function is the equivalent of OMX_SetCallbacks
                        macro. Please refer to OMX IL spec for more details.
                        This method is a registration function to get
                        application provided event callbacks to be registered
                        in OMX layer.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.
            @param[in]  pCallbacks  - Pointer to the callback structure.
            @param[in]  pAppData    - Unique app data pointer.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntLoaded_SetCallbacks
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_CALLBACKTYPE          *pCallbacks, 
   OMX_IN   OMX_PTR                    pAppData
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pCommonRef, "qomx_CmpntLoaded_SetCallbacks" );

   /**------------------------------------------------------------------------
      Set callbacks if all of these are valid.
   -------------------------------------------------------------------------*/
   if ( ( NULL == pCallbacks->EmptyBufferDone )
      || ( NULL == pCallbacks->EventHandler )
      || ( NULL == pCallbacks->FillBufferDone ) )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "NULL callback pointer." );

      /**---------------------------------------------------------------------
         Some callback function pointers are invalid.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else
   {
      /**---------------------------------------------------------------------
         Copy callback function pointers in component context.
      ----------------------------------------------------------------------*/
      ( & ( pCmpntCtx->commonRef ) )->clientCB = ( *pCallbacks );
      ( & ( pCmpntCtx->commonRef ) )->pAppData = pAppData;

   }

   return( eRetVal );

} /* end of function qomx_CmpntLoaded_SetCallbacks */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntLoaded_SetStateIdle

         DESCRIPTION:
*//**                   This function will move the component to transitional
                        state LoadedToIdle which checks the port population
                        status, waits for the buffers and load the resources.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntLoaded_SetStateIdle
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntLoaded_SetStateIdle" );

   /**------------------------------------------------------------------------
      Move the component to transitional state LoadedToIdle which will
      check ports population status, wait for buffers and load resources.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntCommon_DoStateTransition( 
                  pCmpntCtx, QOMX_StateLoadedToIdle, QOMX_EVENT_UNKNOWN );


   return( eRetVal );

} /* end of function qomx_CmpntLoaded_SetStateIdle */

