#ifndef __QOMX_CMPNT_CONTEXT_H__
#define __QOMX_CMPNT_CONTEXT_H__

/*========================================================================

*//** @file qomxCmpntContext.h

@par FILE SERVICES:       
      Component Context Header File.
      
      This file contains the component contexts which maintains the component
      state machine and other component characterstics.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2016 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCmpntContext.h#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
06/22/16   am     Fix compiler warnings for 64 bit OS environment.
02/27/12   sk     Fixed KW compiler warnings
09/13/10   dm     Adding component name and handle in logging messages.
07/22/10   zm     Add utility function for logging.
03/26/10   spl    Modified to support interop-profile.
06/12/09   dm     Initial creation.

========================================================================== */

/*======================================================================== 
 
                     INCLUDE FILES FOR MODULE 
 
========================================================================== */
#include "qomxCommon.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */


/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 * 
 *  This typedef enumerates static resources reservation state. Resources are 
 *  reserved through underlying device's load resource command and are used
 *  by the device for realization of the functionality.
 *
 */

typedef enum
{
   QOMX_RESOURCES_UNRESERVED = 0,         /**< 
                                          * Resource reservation is not done
                                          * yet. This is either the initial
                                          * state when component is loaded,
                                          * or when component moves back to
                                          * Loaded state after releasing
                                          * the resources.
                                          */

   QOMX_RESOURCES_RESERVING,              /**< 
                                          * Device is in process of reserving
                                          * the resources required for the
                                          * realization of the functionality.
                                          */

   QOMX_RESOURCES_RESERVED,               /**< 
                                          * All the resources required for the
                                          * realization of the functionality
                                          * have been reserved.
                                          */

   QOMX_RESOURCES_RESERVATION_FAILED,     /**< 
                                          * Resources reservation request has
                                          * failed. Thus resources could not
                                          * be reserved.
                                          */

   QOMX_RESOURCES_TEMPORARILY_LOST,       /**< 
                                          * Some of resources are preempted or
                                          * lost and thus execution is halted.
                                          * This loss is recoverable from the 
                                          * point it lost.
                                          * This state is obtained when device
                                          * sends resource lost event with 
                                          * suspendable flag set to false.
                                          */

   QOMX_RESOURCES_PERMANENTLY_LOST,       /**< 
                                          * Some of resources are preempted or
                                          * lost and thus execution is halted.
                                          * This loss is a permanent loss and
                                          * session can not be resumed.
                                          * This state is obtained when device
                                          * sends resource lost event with
                                          * suspendable flag set to true.
                                          */

   QOMX_RESOURCES_RELEASING               /**< 
                                          * Resources are being released. This
                                          * state is obtained when component
                                          * moves back to Loaded state.
                                          */

} QOMX_ResourcesStateType;



/**
 * 
 * Following stucture holds the entire OMX IL context. This is the only
 * piece of memory which someone will need to look at to find the snapshot of
 * the IL.
 * 
 */

typedef struct
{  
   /**------------------------------------------------------------------------
      Device and application references data.
   -------------------------------------------------------------------------*/

   QOMX_CommonRefType         commonRef;     /**<
                                             * Common references object which
                                             * holds information about the 
                                             * underlying device and the 
                                             * application.
                                             */

   /**------------------------------------------------------------------------
      Component states.
   -------------------------------------------------------------------------*/
   
   OMX_STATETYPE              eOmxState;     /**< 
                                             * Current OMX state of the
                                             * component. The reason why this
                                             * is called out separately is
                                             * because the current OMX state
                                             * can be harder to deduce if the
                                             * IL is in some transitional
                                             * state.
                                             */

   QOMX_CmpntStateType        eMainState;    /**<
                                             * Current internal state of the
                                             * component machine. It will match
                                             * with OMX state if the state is a
                                             * non-transitional stable state
                                             * called out by IL.
                                             */

   /**------------------------------------------------------------------------
      Component state primitive tables.
   -------------------------------------------------------------------------*/
   
   OMX_HANDLETYPE             hStateTables;  /**<
                                             * Handle to the component states
                                             * primitive tables. State tables
                                             * are loaded during component
                                             * initialization.
                                             */

   /**------------------------------------------------------------------------
      Port information.
   -------------------------------------------------------------------------*/

   OMX_HANDLETYPE             hPortCtnr;     /**<
                                             * An opaque handle to the port
                                             * context. Refer to port state
                                             * machine implementations.
                                             */

   /**------------------------------------------------------------------------
      Resources information.
   -------------------------------------------------------------------------*/

   QOMX_ResourcesStateType    eResState;     /**
                                             * Current resource reservation 
                                             * state.
                                             */

   /**------------------------------------------------------------------------
      Component parameters which can be set by IL client and consumed by the
      base state machine.
   -------------------------------------------------------------------------*/

   OMX_U32                    nGroupPri;     /**< 
                                             * Priority of the component group 
                                             */

   OMX_U32                    nGroupID;      /**< 
                                             * ID of the component group 
                                             */

   OMX_SUSPENSIONPOLICYTYPE   ePolicy;       /**<
                                             * Refer to OMX specification.
                                             * Specifies how the component
                                             * will behave when a
                                             * temporary resource is lost.
                                             */
   
   OMX_SUSPENSIONTYPE         eSuspension;   /**<
                                             * This holds the component
                                             * suspension status.
                                             */

   /**------------------------------------------------------------------------
      OS specific information.
   -------------------------------------------------------------------------*/
   
   OMX_HANDLETYPE             hCritSection;  /**<
                                             * Handle to the OS specific 
                                             * critical section context which
                                             * is created during component
                                             * initialization.
                                             */

   OMX_U64                    nStateTransTime;/**<
                                             * State transiontion start time.
                                             * Used to measure how long it takes
                                             * for a component to transition 
                                             * between OMX states.
                                             */

   OMX_BOOL                   bDeviceStopped; /**<
                                              * The MMI device has sent the STOP
                                              * response.
                                              */
} QOMX_CmpntCtxType;


/**
 * 
 * Following function gets the component handle from the QOMX_CmpntCtxType
 * structure; this is used for QOMX base class logging.
 * 
 */

/* OBSOLETE: Defined but not used
 *
static OMX_HANDLETYPE qomx_CmpntContext_GetComponentHandle
(
  OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
)
{
  OMX_HANDLETYPE hCmpnt = NULL;
  
  if (NULL != pCmpntCtx)
  {
    hCmpnt = pCmpntCtx->commonRef.hCmpnt;
  }

	return hCmpnt;
}
*/

#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */


#endif /* end of macro __QOMX_CMPNT_CONTEXT_H__ */
