/*========================================================================

*//** @file qomxPortCommon.c

@par FILE SERVICES:
      Methods common to all port states.

      This file contains the definitions for the methods which are common
      for all port states and used by these states same way.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxPortCommon.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
06/22/16   am     Fix compiler warnings for 64 bit OS environment.
10/30/15   rz     Initialize pointer value to fix compilation
06/10/14   dp     Fix double send command complete for disable port.
05/21/14   am     Fix log msg.
03/30/14   am     Fix Klockworks warning.
03/13/14   rs     Add Timestamp values to debug logs for buffer operations and also add more logs
02/07/14   rs     Add back EBD/FBD debug logs
12/16/13   rz     Fix MarkBuffer structure and free MarkBufFullList
12/13/13   rz     Fix MarkBuffer implementation
11/25/13   hc     Fix logic for error reporting during deinit
11/07/13   am     Fix mark buffer implementation.
08/26/13   yzgao  Fix the typo in error msg
07/04/13   dp     Remove KW warning Inconsistent Case Labels.
06/25/13   rz     Move port state at stopping with ETBD/FTBD error status
04/19/13   dp     Send EOS event in base class after delivering buffer with EOS flag.
03/20/13   am     Rename QOMX_CONFIG_TUNNELEDPORTSTATUSTYPE and associated variables
                  to QC omx extension for 1.1.2
02/27/12   sk     Fixed KW compiler warnings
10/19/11   zm     Add dummy flush command handling.
08/08/11   dm     Hardware critical error handling.
05/16/11   zm     Revert 1.y related change in qomx_SetParmBufferSupplier.
02/01/11   zm     Inform device to cancel VT mode if VT setup fails.
02/01/11   zm     Use memset() instead of {0} to initialize structures.
01/31/11   zm     Add support for canceling vendor tunnel mode.
01/28/11   zm     If a buffer returned unprocessed from device, do not
                  process its buffer header.
01/25/11   zm     Remove buffer count check in qomx_SetParmPortDefinition.
11/22/10   zm     Use new QOMX_CMPNT_FREEIF macro.
01/18/11   zm     Remove buffer count check in qomx_SetParmPortDefinition.
12/10/10   zm     Disallow supplier override before tunnel is setup.
12/02/10   zm     Add buffer supplier negotiation during tunnel setup.
11/12/10   zm     Fix a Klockwork error.
10/28/10   zm     Change CLEAR_BUFFER failure message from ERROR to HIGH.
09/13/10   dm     Adding component name and handle in logging messages.
08/28/10   zm     Added support for vendor tunneling.
08/24/10   dm     Add platform private data for allocated buffers.
07/22/10   zm     Add component handle/port index in base class logging.
07/15/10   yt     Added support for standard tunneling.
07/12/10   dm     Reset flag after sending callback.
06/17/10   dm     Allow port settings changed event in all states.
06/10/10   dm     Added return type in event handler.
06/01/10   dm     Fixed error cases buffer count.
05/06/10   dm     Allow all extension indexes.
04/22/10   dm     Allow OMX_ALL on SetParameter call.
04/08/10   dm     Return buffer to client on an error.
03/26/10   spl    Modified to support interop-profile.
03/18/10   spl    Added support for Port Throughput extension.
02/18/10   sl     Fixed tunneling shutdown code (bufferes are now freed)
11/25/09   dm     Corrected auto port detection behavior.
11/24/09   dm     Added support for device extension indexes.
10/30/09   dm     Defined macro for structure size and version validation.
10/30/09   dm     Move component state when buffer count reaches zero.
10/23/09   dm     Update port definition after setting domain definition.
10/16/09   dm     Port state split.
10/13/09   dm     Added error codes for unsupported setting and index.
08/17/09   dm     Removed size and version check from common setparam.
08/11/09   dm     Let device handle OMX_IndexParamContentURI size.
08/06/09   dm     Added setparameter checks for states.
07/28/09   dm     Refined setparameter handling.
07/27/09   dm     Fixed bug when port is enabled in loaded state.
07/21/09   dm     Allow SetParm only on disabled port or in Loaded state.
07/21/09   dm     Handled buffer supplier settings.
07/01/09   dm     Corrected set port definition handling.
06/16/09   dm     Initial Creation.

========================================================================== */

/*========================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxPortCommon.h"
#include "qomxPortUtils.h"
#include "qomxCmpntContext.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* 1 second */
#define BITRATE_DURATION               ( 1000L )

/* 17 ms (assumes 30FPS = (1000 / 30) / 2) */
#define BITRATE_HALFFRAME_DURATION     ( 17LL )

#define BITRATE_THRESHOLD           \
      ( ( BITRATE_DURATION - BITRATE_HALFFRAME_DURATION ) )

#define MS_PER_SEC                     ( 1000 )

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 *
 * Following stucture declares a common pattern that is followed by all the
 * data structures defined in OMX Types which are associated with Get / Set
 * Parameter / Config for Ports.
 *
 */

typedef struct
{
   OMX_U32              nSize;               /**<
                                             * Object size in bytes.
                                             */

   OMX_VERSIONTYPE      nVersion;            /**<
                                             * Object version.
                                             */

   OMX_U32              nPortIndex;          /**<
                                             * Port number on which this
                                             * setting is applied.
                                             */

} QOMX_PortParamPattern;


/**
 *
 *  These are the port state primitive table load functions defined in
 *  the respective state handler implementation file.
 *
 */

void  qomx_PortEnabledUnpopulated_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType   *pStTable
);

void  qomx_PortEnabledPopulating_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType   *pStTable
);

void  qomx_PortEnabledDepopulating_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType   *pStTable
);

void  qomx_PortEnabledPopulated_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType   *pStTable
);

void  qomx_PortEnabledRunning_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType   *pStTable
);

void  qomx_PortEnabledStopping_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType   *pStTable
);

void  qomx_PortDisabledDepopulating_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType   *pStTable
);

void  qomx_PortDisabledUnpopulated_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType   *pStTable
);

void  qomx_PortDisabledStopping_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType   *pStTable
);

static OMX_ERRORTYPE    qomx_GetParmDomainInit
(
   OMX_IN   QOMX_PortContainerType    *pPortCtnr,
   OMX_IN   OMX_INDEXTYPE              nParamIndex,
   OMX_OUT  OMX_PTR                    pCmpntParm
);

static OMX_ERRORTYPE    qomx_GetParmPortDefinition
(
   OMX_IN   QOMX_PortContainerType    *pPortCtnr,
   OMX_OUT  OMX_PTR                    pCmpntParm
);

static OMX_ERRORTYPE    qomx_GetParmBufferSupplier
(
   OMX_IN   QOMX_PortContainerType    *pPortCtnr,
   OMX_OUT  OMX_PTR                    pCmpntParm
);

static OMX_ERRORTYPE    qomx_GetParmPortThroughput
(
   OMX_IN   QOMX_PortContainerType    *pPortCtnr,
   OMX_OUT  OMX_PTR                    pCmpntParm
);

static OMX_ERRORTYPE    qomx_SetParmBufferSupplier
(
   OMX_IN   QOMX_CommonRefType        *pCommonRef,
   OMX_IN   QOMX_PortContextType      *pPortCtx,
   OMX_IN   OMX_PTR                    pCmpntParm
);

static OMX_ERRORTYPE    qomx_SetParmPortDefinition
(
   OMX_IN   QOMX_CommonRefType        *pCommonRef,
   OMX_IN   QOMX_PortContextType      *pPortCtx,
   OMX_IN   OMX_PTR                    pCmpntParm
);

static OMX_ERRORTYPE    qomx_SetParameterIsLegal
(
   OMX_IN      QOMX_PortContainerType *pPortCtnr,
   OMX_IN      OMX_INDEXTYPE           nParamIndex,
   OMX_IN      OMX_PTR                 pCmpntParm,
   OMX_OUT     QOMX_PortContextType  **ppPortCtx
);

static OMX_ERRORTYPE  qomx_PortCommon_ProcessTunnelPeerStatus
(
   OMX_IN      QOMX_PortContainerType              *pPortCtnr,
   OMX_IN      QOMX_CONFIG_TUNNELEDPORTSTATUSTYPE   *pTunneledPortStatus
);

static OMX_ERRORTYPE  qomx_PortCommon_ProcessVendorTunnelPeerStatus
(
   OMX_IN      QOMX_PortContainerType              *pPortCtnr,
   OMX_IN      QOMX_PortContextType                *pPortCtx,
   OMX_IN      OMX_U32                             nPortStatus
);

static void  qomx_PortCommon_BufferRejected
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr
);

static OMX_ERRORTYPE    qomx_PortCommon_TunnelNegotiateBuffers
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_HANDLETYPE                         hTunneledComp,
   OMX_U32                                nTunneledPort
);

static OMX_ERRORTYPE qomx_TunnelNegotiateBufferSupplier
(
   OMX_IN      QOMX_CommonRefType        *pCommonRef,
   OMX_IN      QOMX_PortContextType      *pPortCtx,
   OMX_IN      OMX_HANDLETYPE             hTunneledComp,
   OMX_IN      OMX_U32                    nTunneledPort,
   OMX_INOUT   OMX_TUNNELSETUPTYPE       *pTunnelSetup
);

static OMX_ERRORTYPE qomx_GetDeviceBufSupplierPref
(
   OMX_IN      QOMX_CommonRefType        *pCommonRef,
   OMX_IN      OMX_U32                    nPortIndex,
   OMX_OUT     OMX_BUFFERSUPPLIERTYPE    *peBufferSupplier
);

static OMX_ERRORTYPE qomx_SetDeviceBufSupplierPref
(
   OMX_IN      QOMX_CommonRefType        *pCommonRef,
   OMX_IN      OMX_U32                    nPortIndex,
   OMX_IN      OMX_BUFFERSUPPLIERTYPE     eBufferSupplier
);

static void qomx_TunnelSetSupplier
(
   OMX_INOUT   OMX_BUFFERSUPPLIERTYPE    *peSupPrefInputPort,
   OMX_INOUT   OMX_BUFFERSUPPLIERTYPE    *peSupPrefOutputPort
);

static OMX_ERRORTYPE qomx_CancelDeviceVendorTunnelMode
(
   OMX_IN      QOMX_CommonRefType        *pCommonRef,
   OMX_IN      QOMX_PortContextType      *pPortCtx
);

static void qomx_PortCommon_GetTotalRates
(
   QOMX_PortContextType *pPortCtx,
   OMX_U32              *pTotalByteRate,
   double               *pTotalPacketRate
);


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_BufferHdrLinkCmp

         DESCRIPTION:
*//**                   This function compares the data embedded in one queue
                        link against the given value.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pElement    - Pointer to queue element i.e. link
                                      of type QOMX_PortBufferHdrLink.
            @param[in]  pCmpValue   - Pointer to buffer header of type
                                      OMX_BUFFERHEADERTYPE against which
                                      data associated with the link need
                                      to be compared.

**//*     RETURN VALUE:
*//**       @return     QMM_LIST_ERROR_PRESENT     - If comparsion is
                                                     successful.
                        QMM_LIST_ERROR_NOT_PRESENT - Otherwise.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
QMM_ListErrorType   qomx_PortCommon_BufferHdrLinkCmp
(
   void     *pElement,
   void     *pCmpValue
)
{
   QMM_ListErrorType       eRetVal = QMM_LIST_ERROR_NOT_PRESENT;

   QOMX_PortBufferHdrLink *pBufferHdrInfo
         = ( QOMX_PortBufferHdrLink * ) pElement;

   OMX_BUFFERHEADERTYPE   *pBufferHdr
         = ( OMX_BUFFERHEADERTYPE * ) pCmpValue;
   /*-----------------------------------------------------------------------*/


   /**------------------------------------------------------------------------
      Compares the data embedded in one queue link against the given value.
   -------------------------------------------------------------------------*/
   if( ( NULL != pBufferHdrInfo ) && ( NULL != pBufferHdr )
      && ( pBufferHdr == ( pBufferHdrInfo->pBufferHdr ) ) )
   {
      eRetVal = QMM_LIST_ERROR_PRESENT;

   }

   return( eRetVal );

} /* end of function qomx_PortCommon_BufferHdrLinkCmp */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_DoStateTransition

         DESCRIPTION:
*//**                   This function is generic state transition routine
                        which performs the common transition logic.

                        1) State management like calling entry and exit
                           functions.
                        2) Doing the actual transition.
                        3) Logging the transiton.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the container object.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  eToState    - New port state.
            @param[in]  nEvent      - Uniqueue event code.

**//*     RETURN VALUE:
*//**       @return     None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void    qomx_PortCommon_DoStateTransition
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx,
   OMX_IN   QOMX_PortStateType      eToState,
   OMX_IN   OMX_U8                  nEvent
)
{
   QOMX_PortStateTableType   *pStTable;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "qomx_PortCommon_DoStateTransition,"
      " eToState = 0x%x, nEvent = 0x%x", ( OMX_U32 ) eToState, nEvent );

   if( pPortCtx->eState != eToState )
   {
      /**---------------------------------------------------------------------
         Invoke exit state handler for the current state which will do all
         event agnostic execution. If port is not initialized already,
         current state does not exist.
      ----------------------------------------------------------------------*/
      pStTable = qomx_PortCommon_GetStateTable( pPortCtnr, pPortCtx->eState );

      if( NULL != pStTable->pfnExitHandler )
      {
         ( void ) pStTable->pfnExitHandler( pPortCtnr, pPortCtx, nEvent );

      }
      else
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Exit handler not defined"
            " for port eState = 0x%x", ( OMX_U32 ) pPortCtx->eState );

      }

      /**---------------------------------------------------------------------
         Invoke entry state handler for the current state which will do all
         event agnostic execution.
      ----------------------------------------------------------------------*/
      pStTable = qomx_PortCommon_GetStateTable( pPortCtnr, eToState );

      if( NULL != pStTable->pfnEntryHandler )
      {
         ( void ) pStTable->pfnEntryHandler( pPortCtnr, pPortCtx, nEvent );

      }
      else
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Entry handler not defined"
            " for port eToState = 0x%x", ( OMX_U32 ) eToState );

      }

   }
   else
   {
      QOMX_MSG_L_MED( pPortCtnr->pCommonRef, "Same State. nPortIndex = 0x%x",
         pPortCtx->portDef.nPortIndex );

   }

   return;

} /* end of function qomx_PortCommon_DoStateTransition */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_CheckGuard

         DESCRIPTION:
*//**                   This function checks the port population status.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  ePortGuard  - Port guard to be checked.

**//*     RETURN VALUE:
*//**       @return     OMX_TRUE    - if port guard condition is satisfied.
                        OMX_FALSE   - otherwise.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_BOOL   qomx_PortCommon_CheckGuard
(
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   QOMX_PortGuardType            ePortGuard
)
{
   OMX_BOOL             bResult        = OMX_FALSE;
   QMM_ListHandleType  *pHBufHdrQueue  = & ( pPortCtx->hBufHdrQueue );
   QMM_ListSizeType     nQueueSize;
   /*-----------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Get queue size,
   -------------------------------------------------------------------------*/
   ( void ) qmm_ListSize( pHBufHdrQueue, &nQueueSize );

   /**------------------------------------------------------------------------
      If queue size is 0, then port is unpopulated. If queue size is equal to
      actual required port buffer count, port is populated.
   -------------------------------------------------------------------------*/
   if( ( pPortCtx->portDef.nBufferCountActual == nQueueSize )
      && ( QOMX_PORT_GUARD_POPULATED == ePortGuard ) )
   {
      bResult = OMX_TRUE;

   }
   else if( ( 0 == nQueueSize )
          && ( QOMX_PORT_GUARD_UNPOPULATED == ePortGuard ) )
   {
      bResult = OMX_TRUE;

   }
   /**------------------------------------------------------------------------
      For vendor tunneled port, buffer management is done in device; ignore
     the guard check, and always returns true, such that
     MMI_CMD_LOAD_RESOURCES or MMI_CMD_RELEASE_RESOURCES can be sent to MMI
     for buffer allocation/deallocation and resource loading/release and
     MMI_CMD_ENABLE_PORT or MMI_CMD_DISABLE_PORT can be sent to MMI.
   -------------------------------------------------------------------------*/
   else if ( PORT_TUNNELING_VENDOR == pPortCtx->eTunneling )
   {
     bResult = OMX_TRUE;

   }

   return( bResult );

} /* end of function qomx_PortCommon_CheckGuard */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_GetParameter

         DESCRIPTION:
                        Refer to OMX_GetParameter in OMX_Core.h or the OMX IL
                        specification for details on the GetParameter method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  nParamIndex - Refer OMX_Core.h / OMX IL specification.
            @param[inout] pCmpntParm
                                    - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_GetParameter
(
   OMX_IN      QOMX_PortContainerType       *pPortCtnr,
   OMX_IN      OMX_INDEXTYPE                 nParamIndex,
   OMX_INOUT   OMX_PTR                       pCmpntParm
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortCommon_GetParameter,"
      " nParamIndex = 0x%x", ( OMX_U32 ) nParamIndex );

   /**------------------------------------------------------------------------
      Check parameter index and send it to Device if it can not be handled
      here.
   -------------------------------------------------------------------------*/
   switch( ((OMX_S32)nParamIndex) )
   {
   case (OMX_S32)OMX_IndexParamAudioInit:
      /* fall through */
   case (OMX_S32)OMX_IndexParamVideoInit:
      /* fall through */
   case (OMX_S32)OMX_IndexParamImageInit:
      /* fall through */
   case (OMX_S32)OMX_IndexParamOtherInit:
      {
         /**------------------------------------------------------------------
            Call internal function to handle get domain configuration.
         -------------------------------------------------------------------*/
         eRetVal = qomx_GetParmDomainInit(
                                    pPortCtnr, nParamIndex, pCmpntParm );

      }

      break;

   case (OMX_S32)OMX_IndexParamPortDefinition:
      {
         /**------------------------------------------------------------------
            Call internal function to handle get domain definition.
         -------------------------------------------------------------------*/
         eRetVal = qomx_GetParmPortDefinition( pPortCtnr, pCmpntParm );

      }

      break;

   case (OMX_S32)OMX_IndexParamCompBufferSupplier:
      {
         /**------------------------------------------------------------------
            Call internal function to handle get buffer supplier info.
         -------------------------------------------------------------------*/
         eRetVal = qomx_GetParmBufferSupplier( pPortCtnr, pCmpntParm );

      }

      break;

   case (OMX_S32)QOMX_PARAM_INDEX_PORT_THROUGHPUT:
     {
         /**------------------------------------------------------------------
            Call internal function to handle get port throughput.
         -------------------------------------------------------------------*/
         eRetVal = qomx_GetParmPortThroughput( pPortCtnr, pCmpntParm );

      }

      break;

   default:
      {

         OMX_U32              nStatus     = MMI_S_EFAIL;
         MMI_OmxParamCmdType  omxParamCmd;
         /*-----------------------------------------------------------------*/

         /**------------------------------------------------------------------
            Device might handle this parameter, Pass this to device now.
         -------------------------------------------------------------------*/
         omxParamCmd.nParamIndex  = nParamIndex;
         omxParamCmd.pParamStruct = pCmpntParm;

         nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                     MMI_CMD_GET_STD_OMX_PARAM, ( void * ) & omxParamCmd );

         QOMX_MSG_L_HIGH( pCommonRef, "MMI_CMD_GET_STD_OMX_PARAM"
            " status = 0x%x", nStatus );

         if( MMI_S_COMPLETE != nStatus )
         {
            QOMX_MSG_L_ERROR( pCommonRef, "MMI_CMD_GET_STD_OMX_PARAM"
               " failed." );

            eRetVal = qomx_GetOMXErrorCode( nStatus );

         }

         /**------------------------------------------------------------------
            Move component to Invalid state on fatal error.
         -------------------------------------------------------------------*/
         if( OMX_ErrorInvalidState == eRetVal )
         {
            ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

         }

      }

      break;

   } /* end of switch( nParamIndex ) */

   return( eRetVal );

} /* end of function qomx_PortCommon_GetParameter */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_SetParameter

         DESCRIPTION:
                        Refer to OMX_SetParameter in OMX_Core.h or the OMX IL
                        specification for details on the SetParameter method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  nParamIndex - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pCmpntParm  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_SetParameter
(
   OMX_IN      QOMX_PortContainerType       *pPortCtnr,
   OMX_IN      OMX_INDEXTYPE                 nParamIndex,
   OMX_IN      OMX_PTR                       pCmpntParm
)
{
   OMX_ERRORTYPE           eRetVal        = OMX_ErrorNone;
   QOMX_CommonRefType     *pCommonRef     = pPortCtnr->pCommonRef;
   QOMX_PortContextType   *pPortCtx       = NULL;
   OMX_BOOL                bSendToDevice  = OMX_FALSE;
   OMX_BOOL                bIgnoreStatus  = OMX_FALSE;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortCommon_SetParameter,"
      " nParamIndex = 0x%x", ( OMX_U32 ) nParamIndex );

   /**------------------------------------------------------------------------
      Validate parameter operation.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_SetParameterIsLegal( pPortCtnr,
                                 nParamIndex, pCmpntParm, & pPortCtx );

   /**------------------------------------------------------------------------
      Handle parameter index if operation is found to be legal.
   -------------------------------------------------------------------------*/
   if ( OMX_ErrorNone == eRetVal )
   {
      switch( nParamIndex )
      {
      case OMX_IndexParamPortDefinition:
         {
            /**---------------------------------------------------------------
               Call internal function to handle get domain definition.
            ----------------------------------------------------------------*/
            eRetVal = qomx_SetParmPortDefinition(
                                          pCommonRef, pPortCtx, pCmpntParm );

         }

         break;

      case OMX_IndexParamCompBufferSupplier:
         {
            /**---------------------------------------------------------------
               Call internal function to handle set buffer supplier info.
            ----------------------------------------------------------------*/
            eRetVal = qomx_SetParmBufferSupplier(
                                 pCommonRef, pPortCtx, pCmpntParm );

            /**---------------------------------------------------------------
               Forward this parameter to the MMI Device. This is just for
               information purposes only, so ignore any error code returned
               by the device for this parameter (the device might not support
               the parameter).
            ----------------------------------------------------------------*/
            bSendToDevice = OMX_TRUE;
            bIgnoreStatus = OMX_TRUE;

         }

         break;

      default:
         {
            /**---------------------------------------------------------------
               Forward this parameter to the MMI Device.
            ----------------------------------------------------------------*/
            bSendToDevice = OMX_TRUE;

         }

         break;

      } /* end of switch( nParamIndex ) */


      /**---------------------------------------------------------------------
         Send this command to device now.
      ----------------------------------------------------------------------*/
      if( ( OMX_ErrorNone == eRetVal ) && ( OMX_TRUE == bSendToDevice ) )
      {
         OMX_U32              nStatus     = MMI_S_EFAIL;
         MMI_OmxParamCmdType  omxParamCmd;
         /*-----------------------------------------------------------------*/

         /**------------------------------------------------------------------
            Device might handle this parameter, Pass this to device now.
         -------------------------------------------------------------------*/
         omxParamCmd.nParamIndex  = nParamIndex;
         omxParamCmd.pParamStruct = pCmpntParm;

         /**------------------------------------------------------------------
            Send this command to device.
         -------------------------------------------------------------------*/
         nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                     MMI_CMD_SET_STD_OMX_PARAM, ( void * ) & omxParamCmd );

         QOMX_MSG_L_HIGH( pCommonRef, "MMI_CMD_SET_STD_OMX_PARAM"
            " status = 0x%x", nStatus );

         if( ( MMI_S_COMPLETE != nStatus ) && ( OMX_FALSE == bIgnoreStatus ) )
         {
            QOMX_MSG_L_ERROR( pCommonRef, "MMI_CMD_SET_STD_OMX_PARAM failed." );

            eRetVal = qomx_GetOMXErrorCode( nStatus );

         }

         /**------------------------------------------------------------------
            Move component to Invalid state on fatal error.
         -------------------------------------------------------------------*/
         if( OMX_ErrorInvalidState == eRetVal )
         {
            ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

         }

      }

      /**---------------------------------------------------------------------
         Above settings might result in port definition to change in MMI,
         Get latest port definitions from the device and update it in port
         context.
      ----------------------------------------------------------------------*/
      if( ( OMX_ErrorNone == eRetVal ) && ( NULL != pPortCtx ) )
      {
         QOMX_MSG_L_MED( pCommonRef, "Refresh port definition for"
            "nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         eRetVal = qomx_PortCommon_UpdatePortDefinition(
                                                pCommonRef, pPortCtx );

      }

   }

   return( eRetVal );

} /* end of function qomx_PortCommon_SetParameter */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_GetConfig

         DESCRIPTION:
                        Refer to OMX_GetConfig in OMX_Core.h or the OMX IL
                        specification for details on the GetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  nCfgIndex   - Refer OMX_Core.h / OMX IL specification.
            @param[inout] pCmpntCfg - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_GetConfig
(
   OMX_IN      QOMX_PortContainerType       *pPortCtnr,
   OMX_IN      OMX_INDEXTYPE                 nCfgIndex,
   OMX_INOUT   OMX_PTR                       pCmpntCfg
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortCommon_GetConfig,"
      " nCfgIndex = 0x%x", ( OMX_U32 ) nCfgIndex );

   /**------------------------------------------------------------------------
      Check parameter index and send it to Device if it can not be handled
      here.
   -------------------------------------------------------------------------*/
   switch( nCfgIndex )
   {
   default:
      {
         OMX_U32              nStatus     = MMI_S_EFAIL;
         MMI_OmxParamCmdType  omxParamCmd;
         /*-----------------------------------------------------------------*/

         /**------------------------------------------------------------------
            Device might handle this parameter, Pass this to device now.
         -------------------------------------------------------------------*/
         omxParamCmd.nParamIndex  = nCfgIndex;
         omxParamCmd.pParamStruct = pCmpntCfg;

         nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                     MMI_CMD_GET_STD_OMX_PARAM, ( void * ) & omxParamCmd );

         QOMX_MSG_L_HIGH( pCommonRef, "MMI_CMD_GET_STD_OMX_PARAM"
            " status = 0x%x", nStatus );

         if( MMI_S_COMPLETE != nStatus )
         {
            QOMX_MSG_L_ERROR( pCommonRef, "MMI_CMD_GET_STD_OMX_PARAM failed." );

            eRetVal = qomx_GetOMXErrorCode( nStatus );

         }

         /**------------------------------------------------------------------
            Move component to Invalid state on fatal error.
         -------------------------------------------------------------------*/
         if( OMX_ErrorInvalidState == eRetVal )
         {
            ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

         }

      }

      break;

   } /* end of switch( nParamIndex ) */

   return( eRetVal );

} /* end of function qomx_PortCommon_GetConfig */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_SetConfig

         DESCRIPTION:
                        Refer to OMX_SetConfig in OMX_Core.h or the OMX IL
                        specification for details on the SetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  nCfgIndex   - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pCmpntCfg   - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_SetConfig
(
   OMX_IN      QOMX_PortContainerType       *pPortCtnr,
   OMX_IN      OMX_INDEXTYPE                 nCfgIndex,
   OMX_IN      OMX_PTR                       pCmpntCfg
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortCommon_SetConfig,"
      " nCfgIndex = 0x%x", ( OMX_U32 ) nCfgIndex );

   /**------------------------------------------------------------------------
      Handle parameter index if operation is found to be legal.
   -------------------------------------------------------------------------*/
   switch( ((OMX_U32)nCfgIndex) )
   {

   case QOMX_IndexConfigTunneledPortStatus:

      /**---------------------------------------------------------------------
         This index provides a handshake mechanism against race conditions
         that would otherwise take place during tunneling state transitions.
      ----------------------------------------------------------------------*/

     (void) qomx_PortCommon_ProcessTunnelPeerStatus( pPortCtnr,
                          ( QOMX_CONFIG_TUNNELEDPORTSTATUSTYPE * ) pCmpntCfg );


      break;

   default:
      {
         QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
         OMX_U32              nStatus     = MMI_S_EFAIL;
         MMI_OmxParamCmdType  omxParamCmd;
         /*-----------------------------------------------------------------*/

         /**------------------------------------------------------------------
            Device might handle this parameter, Pass this to device now.
         -------------------------------------------------------------------*/
         omxParamCmd.nParamIndex  = nCfgIndex;
         omxParamCmd.pParamStruct = pCmpntCfg;

         /**------------------------------------------------------------------
            Send this command to device.
         -------------------------------------------------------------------*/
         nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                     MMI_CMD_SET_STD_OMX_PARAM, ( void * ) & omxParamCmd );

         QOMX_MSG_L_HIGH( pCommonRef, "MMI_CMD_SET_STD_OMX_PARAM"
            " status = 0x%x", nStatus );

         if( MMI_S_COMPLETE != nStatus )
         {
            QOMX_MSG_L_ERROR( pCommonRef, "MMI_CMD_SET_STD_OMX_PARAM failed." );

            eRetVal = qomx_GetOMXErrorCode( nStatus );

         }

         /**------------------------------------------------------------------
            Move component to Invalid state on fatal error.
         -------------------------------------------------------------------*/
         if( OMX_ErrorInvalidState == eRetVal )
         {
            ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

         }

      }

      break;

   } /* end of switch( nParamIndex ) */

   return( eRetVal );

} /* end of function qomx_PortCommon_SetConfig */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_Enable

         DESCRIPTION:
*//**                   This function processes port enable request.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr      - Pointer to the port container.
            @param[in]  pPortCtx       - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_Enable
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   OMX_U32              nStatus     = MMI_S_EFAIL;
   MMI_PortCmdType      portCmd;
   MMI_VendorTunnelPortCmdData portCmdData = { OMX_FALSE, OMX_FALSE };
   QOMX_CmpntStateType  eCmpntState;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortCommon_Enable,"
      " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

   if ( PORT_TUNNELING_VENDOR == pPortCtx->eTunneling )
   {
     /**---------------------------------------------------------------------
         If its peer port has not received port enable command, transition to
       EnabledPopulating for vendor tunneled port and return.
      ----------------------------------------------------------------------*/
     if( OMX_FALSE == pPortCtx->bVendorTunnelPeerPortEnable )
     {
       pPortCtx->bAlterCmdPending = OMX_TRUE;

       ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                          pPortCtx, QOMX_StatePortEnabledPopulating, 0 );

       return ( OMX_ErrorNone );

     }

     /**---------------------------------------------------------------------
         Get current component state.
      ----------------------------------------------------------------------*/
      eCmpntState = qomx_CmpntGetQOMXState( pCommonRef->hCmpnt );

     /**---------------------------------------------------------------------
       if component state is not Loaded or WFR and the vendor tunneled peer
       port has receivd port enable command and the port is buffer supplier,
       instruct the MMI to allocate buffer, in addition to enable the port.
     ----------------------------------------------------------------------*/
     if( ( QOMX_StateLoaded != eCmpntState )
         && ( QOMX_StateWaitForResources != eCmpntState )
       && QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx ) )
     {
         portCmdData.bAllocateBuffer = OMX_TRUE;

     }

   }

   /**------------------------------------------------------------------------
      Send enable command to device.
   -------------------------------------------------------------------------*/
   portCmd.nPortIndex = pPortCtx->portDef.nPortIndex;
   portCmd.pCmdData = & portCmdData;

   nStatus = pCommonRef->device.pfnCmd(
                           pCommonRef->hFd, MMI_CMD_ENABLE_PORT, & portCmd );

   QOMX_MSG_L_HIGH( pCommonRef,
      "MMI_CMD_ENABLE_PORT status = 0x%x", nStatus );

   /**------------------------------------------------------------------------
      Handle enable command response.
   -------------------------------------------------------------------------*/
   ( void ) qomx_PortCommon_EnableResp(
                           pPortCtnr, pPortCtx, nStatus, OMX_TRUE );

   /**------------------------------------------------------------------------
      For vendor tunneling, signal the peer vendor-tunneled port if it is
     buffer supplier.
   -------------------------------------------------------------------------*/
   if ( ( PORT_TUNNELING_VENDOR == pPortCtx->eTunneling )
      && QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx ) )
   {
      QDFC_ErrorType    eErrVal;
     /*--------------------------------------------------------------------*/

     eErrVal = qdfc_EnqueueArg6Function( pPortCtnr->pCommonRef->hDfc,
               ( qfc_Arg6FpType ) ( qomx_PortCommon_SignalTunnelPeer ),
               ( QDFC_ArgType ) pPortCtx->hTunneledComp,
               ( QDFC_ArgType ) pPortCtx->nTunneledPort,
               ( QDFC_ArgType ) OMX_PORTSTATUS_VTACCEPTSPORTENABLE,
               ( QDFC_ArgType ) 0,
               ( QDFC_ArgType ) 0,
               ( QDFC_ArgType ) 0 );

     if( QDFC_ERROR_NONE != eErrVal )
     {
          QOMX_MSG_L_ERROR( pCommonRef,
             "DFC EnQueue error = %d. Event dropped", eErrVal );

     }

   }

   return( OMX_ErrorNone );

} /* end of function qomx_PortCommon_Enable */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_Disable

         DESCRIPTION:
*//**                   This function processes port disable request.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr      - Pointer to the port container.
            @param[in]  pPortCtx       - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_Disable
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   OMX_U32              nStatus     = MMI_S_EFAIL;
   MMI_PortCmdType      portCmd;
   MMI_VendorTunnelPortCmdData portCmdData = { OMX_FALSE, OMX_FALSE };
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortCommon_Disable,"
      " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Set free buffer flag to true, if it is a vendor tunneled port and
     its component state is not Loaded or WFR.
   -------------------------------------------------------------------------*/
   if ( pPortCtx->eTunneling == PORT_TUNNELING_VENDOR)
   {
     QOMX_CmpntStateType eCmpntState =
            qomx_CmpntGetQOMXState( pPortCtnr->pCommonRef->hCmpnt );

     if( ( QOMX_StateLoaded != eCmpntState )
         && ( QOMX_StateWaitForResources != eCmpntState )
       && QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx ) )
     {
        portCmdData.bFreeBuffer = OMX_TRUE;

     }

   }

   /**------------------------------------------------------------------------
      Send disable command to device.
   -------------------------------------------------------------------------*/
   portCmd.nPortIndex = pPortCtx->portDef.nPortIndex;
   portCmd.pCmdData = & portCmdData;

   nStatus = pCommonRef->device.pfnCmd(
                           pCommonRef->hFd, MMI_CMD_DISABLE_PORT, & portCmd );

   QOMX_MSG_L_HIGH( pCommonRef,
      "MMI_CMD_DISABLE_PORT status = 0x%x", nStatus );

   /**------------------------------------------------------------------------
      Handle disable command response.
   -------------------------------------------------------------------------*/
   ( void ) qomx_PortCommon_DisableResp(
                           pPortCtnr, pPortCtx, nStatus, OMX_TRUE );

   /**------------------------------------------------------------------------
      Move to disabled stoppping state unless port is already there.
   -------------------------------------------------------------------------*/
   if ( ( QOMX_StatePortDisabledStopping != pPortCtx->eState ) &&
        ( QOMX_StatePortDisabledUnpopulated != pPortCtx->eState ) )
   {
      ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                                pPortCtx, QOMX_StatePortDisabledStopping, 0 );
   }

   return( OMX_ErrorNone );

} /* end of function qomx_PortCommon_Disable */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_DummyFlush

         DESCRIPTION:
*//**                   This function is a dummy funtion created to handle
                        port flush request in port state table for states
                        EnabledPopulated and DisabledUnpopulated (when
                        component state is Idle) where flush might be legal,
                        but should not take any action.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_DummyFlush
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;

   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortCommon_DummyFlush,"
      " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
         Send flush done notification.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntCmdComplete( pCommonRef,
               OMX_CommandFlush, pPortCtx->portDef.nPortIndex, NULL );

   return( OMX_ErrorNone );
}


/*==========================================================================

         FUNCTION:      qomx_PortCommon_DeInit

         DESCRIPTION:
*//**                   This function processes deinit request.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_DeInit
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
)
{
   QOMX_CommonRefType  *pCommonRef     = pPortCtnr->pCommonRef;
   QMM_ListHandleType  *pHBufHdrQueue  = & ( pPortCtx->hBufHdrQueue );
   QMM_ListSizeType     nQueueSize;
   OMX_U32              totalByteRate;
   double               totalPacketRate;
   OMX_ERRORTYPE        errSts = OMX_ErrorNone;
   QMM_ListErrorType    listError;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortCommon_DeInit,"
      " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Cumulative average bitrate calculation.
      Need at least 2 buffers to calculate the cumulative average bitrate.
   -------------------------------------------------------------------------*/
   ( void ) qomx_PortCommon_GetTotalRates(
                  pPortCtx, & totalByteRate, & totalPacketRate );

   QOMX_MSG_L_MED( pCommonRef, "nPortIndex = 0x%x, Total Byte Rate = %u",
         pPortCtx->portDef.nPortIndex, totalByteRate );

   QOMX_MSG_L_MED( pCommonRef, "nPortIndex = 0x%x, Total Packet Rate = %0.2f",
         pPortCtx->portDef.nPortIndex, totalPacketRate );

   /**------------------------------------------------------------------------
      Get the list size.
   -------------------------------------------------------------------------*/
   if( QMM_LIST_ERROR_NONE != qmm_ListSize( pHBufHdrQueue, & nQueueSize ) )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Irrecoverable list error." );

      /**---------------------------------------------------------------------
         Irrecoverable error, Move component to Invalid state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntStateSetInvalid(
                        pPortCtnr->pCommonRef->hCmpnt, QOMX_EVENT_UNKNOWN );

   }
   else
   {
      QMM_ListLinkType    *pQueueLink;
      QMM_ListSizeType     i;
      /*--------------------------------------------------------------------*/

      if( 0 != nQueueSize )
      {
         QOMX_MSG_L_ERROR( pCommonRef,
            "%d Buffer(s) not freed by client.", nQueueSize );
      }

      /**---------------------------------------------------------------------
         Pop the queue links; free headers & associated buffers if those
         were allocated by the device.
      ----------------------------------------------------------------------*/
      for( i = 0; i < nQueueSize; i++ )
      {
         ( void ) qmm_ListPopFront( pHBufHdrQueue, & pQueueLink );

         /**------------------------------------------------------------------
            Free buffer header.
         -------------------------------------------------------------------*/
         QOMX_CMPNT_FREEIF( pCommonRef->pfnFree, pCommonRef->hHeap, pQueueLink );

      }

      /**---------------------------------------------------------------------
         Deinitialize the queue.
      ----------------------------------------------------------------------*/
      listError = qmm_ListDeInit( pHBufHdrQueue );
      if( QMM_LIST_ERROR_NONE != listError )
      {
         QOMX_MSG_L_ERROR( pCommonRef, "qmm_ListDeInit failed for pHBufHdrQueue, err = 0x%x", listError );
         errSts = OMX_ErrorUndefined;
      }

      listError = qmm_ListSize(&pPortCtx->MarkBufEmptyList, &nQueueSize);

      if( QMM_LIST_ERROR_NONE == listError )
      {
         for( i = 0; i < nQueueSize; i++ )
         {
            QOMX_MarkBufferList *pListEntry;

            listError = qmm_ListPopFront( &pPortCtx->MarkBufEmptyList, & pQueueLink );

            if( QMM_LIST_ERROR_NONE == listError )
            {
                /* free the link structure */
                pListEntry = (QOMX_MarkBufferList *) pQueueLink;
                QOMX_CMPNT_FREEIF( pCommonRef->pfnFree, pCommonRef->hHeap, pListEntry );
            }
            else
            {
               QOMX_MSG_L_ERROR( pCommonRef, "qmm_ListPopFront returned error = 0x%x for idx = %d", listError, i );
               errSts = OMX_ErrorUndefined;
            }
         }
     }
     else
     {
        QOMX_MSG_L_ERROR( pCommonRef, "qmm_ListSize returned error = 0x%x", listError );
        errSts = OMX_ErrorUndefined;
     }

     listError = qmm_ListDeInit( &pPortCtx->MarkBufEmptyList );

     if( QMM_LIST_ERROR_NONE != listError)
     {
        QOMX_MSG_L_ERROR( pCommonRef, "qmm_ListDeInit returned error = 0x%x for MarkBufEmptyList", listError );
        errSts = OMX_ErrorUndefined;
     }

     listError = qmm_ListSize(&pPortCtx->MarkBufFullList, &nQueueSize);

     if( QMM_LIST_ERROR_NONE == listError)
     {
        for( i = 0; i < nQueueSize; i++ )
        {
           QOMX_MarkBufferList *pListEntry;

           listError = qmm_ListPopFront( &pPortCtx->MarkBufFullList, & pQueueLink );

           if( QMM_LIST_ERROR_NONE == listError )
           {
              /* free the link structure */
              pListEntry = (QOMX_MarkBufferList *) pQueueLink;
              QOMX_CMPNT_FREEIF( pCommonRef->pfnFree, pCommonRef->hHeap, pListEntry );
           }
           else
           {
              QOMX_MSG_L_ERROR( pCommonRef, "qmm_ListPopFront returned error = 0x%x for idx = %d", listError, i );
              errSts = OMX_ErrorUndefined;
           }
        }
     }
     else
     {
        QOMX_MSG_L_ERROR( pCommonRef, "qmm_ListSize returned error = 0x%x", listError );
        errSts = OMX_ErrorUndefined;
     }

     listError = qmm_ListDeInit( &pPortCtx->MarkBufFullList );

     if( QMM_LIST_ERROR_NONE != listError)
     {
        QOMX_MSG_L_ERROR( pCommonRef, "qmm_ListDeInit returned error = 0x%x for MarkBufEmptyList", listError );
        errSts = OMX_ErrorUndefined;
     }
   }

   return( errSts );

} /* end of function qomx_PortCommon_DeInit */


/*==========================================================================

         FUNCTION:      qomx_PortGetContext

         DESCRIPTION:
*//**                   This function is used to retrieve port context from
                        container at given port index.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the container object.
            @param[in]  nPortIndex  - Index for the port which should be
                                      enabled.
            @param[out] ppPortCtx   - Pointer to an object of Port Context
                                      which will be filled with appropriate
                                      context upon successful return.
**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortGetContext
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   OMX_U32                       nPortIndex,
   OMX_OUT  QOMX_PortContextType        **ppPortCtx
)
{
   OMX_ERRORTYPE  eRetVal           = OMX_ErrorNone;
   OMX_U32        portCtxIndex      = 0;
   OMX_U32        audioDomainOffset;
   OMX_U32        videoDomainOffset;
   OMX_U32        imageDomainOffset;
   OMX_U32        otherDomainOffset;
   OMX_U32        audioDomainMaxIndex;
   OMX_U32        videoDomainMaxIndex;
   OMX_U32        imageDomainMaxIndex;
   OMX_U32        otherDomainMaxIndex;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
      "qomx_PortGetContext, nPortIndex = 0x%x", nPortIndex );

   /**------------------------------------------------------------------------
      Get audio, video, image and other domain offsets in contexts array.
   -------------------------------------------------------------------------*/
   audioDomainOffset    = 0;

   videoDomainOffset    = audioDomainOffset
                           + pPortCtnr->audioDomain.nNumInputPorts
                           + pPortCtnr->audioDomain.nNumOutputPorts;

   imageDomainOffset    = videoDomainOffset
                           + pPortCtnr->videoDomain.nNumInputPorts
                           + pPortCtnr->videoDomain.nNumOutputPorts;

   otherDomainOffset    = imageDomainOffset
                           + pPortCtnr->imageDomain.nNumInputPorts
                           + pPortCtnr->imageDomain.nNumOutputPorts;

   /**------------------------------------------------------------------------
      Get audio, video, image and other domain max indexes.
   -------------------------------------------------------------------------*/
   audioDomainMaxIndex  = pPortCtnr->audioDomain.nPortStart
                           + pPortCtnr->audioDomain.nNumInputPorts
                           + pPortCtnr->audioDomain.nNumOutputPorts;

   videoDomainMaxIndex  = pPortCtnr->videoDomain.nPortStart
                           + pPortCtnr->videoDomain.nNumInputPorts
                           + pPortCtnr->videoDomain.nNumOutputPorts;

   imageDomainMaxIndex  = pPortCtnr->imageDomain.nPortStart
                           + pPortCtnr->imageDomain.nNumInputPorts
                           + pPortCtnr->imageDomain.nNumOutputPorts;

   otherDomainMaxIndex  = pPortCtnr->otherDomain.nPortStart
                           + pPortCtnr->otherDomain.nNumInputPorts
                           + pPortCtnr->otherDomain.nNumOutputPorts;

   /**------------------------------------------------------------------------
      Find if passed port index is valid and falls in any of the domain.
   -------------------------------------------------------------------------*/
   if( ( nPortIndex >= pPortCtnr->audioDomain.nPortStart )
      && ( nPortIndex < audioDomainMaxIndex ) )
   {
      /**---------------------------------------------------------------------
         Audio domain index.
      ----------------------------------------------------------------------*/
      portCtxIndex
         = audioDomainOffset + nPortIndex - pPortCtnr->audioDomain.nPortStart;

   }
   else if( ( nPortIndex >= pPortCtnr->videoDomain.nPortStart )
         && ( nPortIndex < videoDomainMaxIndex ) )
   {
      /**---------------------------------------------------------------------
         Video domain index.
      ----------------------------------------------------------------------*/
      portCtxIndex
         = videoDomainOffset + nPortIndex - pPortCtnr->videoDomain.nPortStart;

   }
   else if( ( nPortIndex >= pPortCtnr->imageDomain.nPortStart )
         && ( nPortIndex < imageDomainMaxIndex ) )
   {
      /**---------------------------------------------------------------------
         Image domain index.
      ----------------------------------------------------------------------*/
      portCtxIndex
         = imageDomainOffset + nPortIndex - pPortCtnr->imageDomain.nPortStart;

   }
   else if( ( nPortIndex >= pPortCtnr->otherDomain.nPortStart )
         && ( nPortIndex < otherDomainMaxIndex ) )
   {
      /**---------------------------------------------------------------------
         Other domain index.
      ----------------------------------------------------------------------*/
      portCtxIndex
         = otherDomainOffset + nPortIndex - pPortCtnr->otherDomain.nPortStart;

   }
   else
   {
      QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef,
         "Invalid port index, nPortIndex = 0x%x", nPortIndex );

      /**---------------------------------------------------------------------
         Bad port index.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadPortIndex;

   }

   /**------------------------------------------------------------------------
      Fill the given port context address memory with appropriate port
      context address.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      ( *ppPortCtx ) = & ( pPortCtnr->paPortCtx[ portCtxIndex ] );

   }

   return( eRetVal );

} /* end of function qomx_PortGetContext */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_LoadStateTables

         DESCRIPTION:
                        This function will load all the port state tables
                        in the array of state primitive tables being passed.
                        Memory for this array is pre-allocated in port
                        initialization.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  paStTable   - Pointer to the base of array of state
                                      primitive table objects.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortCommon_LoadStateTables
(
   OMX_IN   QOMX_PortStateTableType   *paStTable
)
{
   /**------------------------------------------------------------------------
      Load All the state tables in respective indexes.
   -------------------------------------------------------------------------*/
   ( void ) qomx_PortEnabledUnpopulated_LoadStateTable(
                     & ( paStTable[ QOMX_StatePortEnabledUnpopulated ] ) );

   ( void ) qomx_PortEnabledPopulating_LoadStateTable(
                     & ( paStTable[ QOMX_StatePortEnabledPopulating ] ) );

   ( void ) qomx_PortEnabledDepopulating_LoadStateTable(
                     & ( paStTable[ QOMX_StatePortEnabledDepopulating ] ) );

   ( void ) qomx_PortEnabledPopulated_LoadStateTable(
                     & ( paStTable[ QOMX_StatePortEnabledPopulated ] ) );

   ( void ) qomx_PortEnabledRunning_LoadStateTable(
                     & ( paStTable[ QOMX_StatePortEnabledRunning ] ) );

   ( void ) qomx_PortEnabledStopping_LoadStateTable(
                     & ( paStTable[ QOMX_StatePortEnabledStopping ] ) );

   ( void ) qomx_PortDisabledDepopulating_LoadStateTable(
                     & ( paStTable[ QOMX_StatePortDisabledDepopulating ] ) );

   ( void ) qomx_PortDisabledUnpopulated_LoadStateTable(
                     & ( paStTable[ QOMX_StatePortDisabledUnpopulated ] ) );

   ( void ) qomx_PortDisabledStopping_LoadStateTable(
                     & ( paStTable[ QOMX_StatePortDisabledStopping ] ) );

   return;

}  /* end of function qomx_PortCommon_LoadStateTables */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_GetStateTable

         DESCRIPTION:
*//**                   This function is used to get function table for
                        port's current state which contains pointers to the
                        functions which should be called for the state
                        operations.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the container object.
            @param[in]  eState      - Current port state.

**//*     RETURN VALUE:
*//**       @return     Pointer to an object holding function table.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
QOMX_PortStateTableType*   qomx_PortCommon_GetStateTable
(
   OMX_IN   QOMX_PortContainerType    *pPortCtnr,
   OMX_IN   QOMX_PortStateType         eState
)
{
   QOMX_PortStateTableType   *pStTable = NULL;
   QOMX_PortStateTableType   *paStTable
      = ( QOMX_PortStateTableType * ) ( pPortCtnr->hStateTables );
   /*-----------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Check port state and return appropriate function table.
   -------------------------------------------------------------------------*/
   switch( eState )
   {
   case QOMX_StatePortEnabledPopulating:
      {
         pStTable = & ( paStTable[ QOMX_StatePortEnabledPopulating ] );

      }

      break;

   case QOMX_StatePortEnabledDepopulating:
      {
         pStTable = & ( paStTable[ QOMX_StatePortEnabledDepopulating ] );

      }

      break;

   case QOMX_StatePortEnabledPopulated:
      {
         pStTable = & ( paStTable[ QOMX_StatePortEnabledPopulated ] );

      }

      break;

   case QOMX_StatePortEnabledRunning:
      {
         pStTable = & ( paStTable[ QOMX_StatePortEnabledRunning ] );

      }

      break;

   case QOMX_StatePortEnabledStopping:
      {
         pStTable = & ( paStTable[ QOMX_StatePortEnabledStopping ] );

      }

      break;

   case QOMX_StatePortDisabledDepopulating:
      {
         pStTable = & ( paStTable[ QOMX_StatePortDisabledDepopulating ] );

      }

      break;

   case QOMX_StatePortDisabledUnpopulated:
      {
         pStTable = & ( paStTable[ QOMX_StatePortDisabledUnpopulated ] );

      }

      break;

   case QOMX_StatePortDisabledStopping:
      {
         pStTable = & ( paStTable[ QOMX_StatePortDisabledStopping ] );

      }

      break;

   case QOMX_StatePortEnabledUnpopulated:
      /* fall through */
   default:
      {
         pStTable = & ( paStTable[ QOMX_StatePortEnabledUnpopulated ] );

      }

      break;

   } /* end of switch( eState ) */

   return( pStTable );

} /* end of function qomx_PortCommon_GetStateTable */


/*==========================================================================

         FUNCTION:      qomx_GetParmDomainInit

         DESCRIPTION:
                        This function will return the domain configuration in
                        the structure passed to it.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  nParamIndex - Refer OMX_Core.h / OMX IL specification.
            @param[out] pCmpntParm  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_GetParmDomainInit
(
   OMX_IN   QOMX_PortContainerType          *pPortCtnr,
   OMX_IN   OMX_INDEXTYPE                    nParamIndex,
   OMX_OUT  OMX_PTR                          pCmpntParm
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   OMX_PORT_PARAM_TYPE *pPortParam  = ( OMX_PORT_PARAM_TYPE * ) pCmpntParm;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
      "qomx_GetParmDomainInit, nParamIndex = 0x%x", nParamIndex );

   /**------------------------------------------------------------------------
      Validate size and version.
   -------------------------------------------------------------------------*/
   QOMX_IF_VALID_STRUCT_OBJ(
         pPortCtnr->pCommonRef, pPortParam, OMX_PORT_PARAM_TYPE, eRetVal )
   {
      QOMX_PortConfig  *pPortConfig;
      /*--------------------------------------------------------------------*/

      /**---------------------------------------------------------------------
         Check parameter index and set domain specific configuration address.
      ----------------------------------------------------------------------*/
      if( OMX_IndexParamAudioInit == nParamIndex )
      {
         pPortConfig = & ( pPortCtnr->audioDomain );

      }
      else if( OMX_IndexParamVideoInit == nParamIndex )
      {
         pPortConfig = & ( pPortCtnr->videoDomain );

      }
      else if( OMX_IndexParamImageInit == nParamIndex )
      {
         pPortConfig = & ( pPortCtnr->imageDomain );

      }
      else
      {
         pPortConfig = & ( pPortCtnr->otherDomain );

      }

      /**---------------------------------------------------------------------
         Fill port parameter structure now.
      ----------------------------------------------------------------------*/
      pPortParam->nPorts = pPortConfig->nNumInputPorts
                           + pPortConfig->nNumOutputPorts;

      pPortParam->nStartPortNumber = pPortConfig->nPortStart;

   }

   return( eRetVal );

} /* end of function qomx_GetParmDomainInit */


/*==========================================================================

         FUNCTION:      qomx_GetParmPortDefinition

         DESCRIPTION:
                        This function will fill the port definition object
                        passed to it.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[out] pCmpntParm  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_GetParmPortDefinition
(
   OMX_IN   QOMX_PortContainerType    *pPortCtnr,
   OMX_OUT  OMX_PTR                    pCmpntParm
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;

   OMX_PARAM_PORTDEFINITIONTYPE *pPortDef
      = ( OMX_PARAM_PORTDEFINITIONTYPE * ) pCmpntParm;;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_GetParmPortDefinition" );

   /**------------------------------------------------------------------------
      Validate size and version.
   -------------------------------------------------------------------------*/
   QOMX_IF_VALID_STRUCT_OBJ(
            pCommonRef, pPortDef, OMX_PARAM_PORTDEFINITIONTYPE, eRetVal )
   {
      QOMX_PortContextType   *pPortCtx;
      /*--------------------------------------------------------------------*/

      /**---------------------------------------------------------------------
         Get port context now.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_PortGetContext(
                           pPortCtnr, pPortDef->nPortIndex, & pPortCtx );

      if( OMX_ErrorNone == eRetVal )
      {
         QOMX_MSG_L_MED( pCommonRef, "Refresh port defintion for,"
            " nPortIndex = 0x%x.", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Get latest port definition from the device and update it in
            port context.
         -------------------------------------------------------------------*/
         eRetVal = qomx_PortCommon_UpdatePortDefinition(
                                          pCommonRef, pPortCtx );

      }

      /**---------------------------------------------------------------------
         Fill port definition in memory passed from IL client.
      ----------------------------------------------------------------------*/
      if( OMX_ErrorNone == eRetVal )
      {
         QOMX_CMPNT_MEM_COPY( pPortDef,
            & ( pPortCtx->portDef ), sizeof( OMX_PARAM_PORTDEFINITIONTYPE ) );

      }

   }

   return( eRetVal );

} /* end of function qomx_GetParmPortDefinition */


/*==========================================================================

         FUNCTION:      qomx_GetParmBufferSupplier

         DESCRIPTION:
                        This function will fill the buffer supplier object
                        passed to it.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[out] pCmpntParm  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_GetParmBufferSupplier
(
   OMX_IN   QOMX_PortContainerType    *pPortCtnr,
   OMX_OUT  OMX_PTR                    pCmpntParm
)
{
   OMX_ERRORTYPE           eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType     *pCommonRef  = pPortCtnr->pCommonRef;
   QOMX_PortContextType   *pPortCtx    = NULL;

   OMX_PARAM_BUFFERSUPPLIERTYPE *pBufSup
      = ( OMX_PARAM_BUFFERSUPPLIERTYPE * ) pCmpntParm;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_GetParmBufferSupplier" );

   /**------------------------------------------------------------------------
      Validate size and version.
   -------------------------------------------------------------------------*/
   QOMX_IF_VALID_STRUCT_OBJ(
         pCommonRef, pBufSup, OMX_PARAM_BUFFERSUPPLIERTYPE, eRetVal )
   {
      /**---------------------------------------------------------------------
         Get port context now.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_PortGetContext(
                           pPortCtnr, pBufSup->nPortIndex, & pPortCtx );

   }

   /**------------------------------------------------------------------------
      Fill buffer supplier definition now.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_MSG_L_MED( pCommonRef, "nPortIndex = 0x%x, Buffer supplier = 0x%x",
            pPortCtx->portDef.nPortIndex,
            ( OMX_U32 ) pPortCtx->eBufferSupplier );

      pBufSup->eBufferSupplier = pPortCtx->eBufferSupplier;

   }

   return( eRetVal );

} /* end of function qomx_GetParmBufferSupplier */

/*==========================================================================

         FUNCTION:      qomx_GetParmPortThroughput

         DESCRIPTION:
                        This function will fill the port throughput object
                        passed to it.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[out] pCmpntParm  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_GetParmPortThroughput
(
   OMX_IN   QOMX_PortContainerType    *pPortCtnr,
   OMX_OUT  OMX_PTR                    pCmpntParm
)
{
   OMX_ERRORTYPE           eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType     *pCommonRef  = pPortCtnr->pCommonRef;
   QOMX_PortContextType   *pPortCtx    = NULL;

   QOMX_ParamPortThroughput  *pPortThPut
      = ( QOMX_ParamPortThroughput * ) pCmpntParm;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_GetParmPortThroughput" );

   /**------------------------------------------------------------------------
      Validate size and version.
   -------------------------------------------------------------------------*/
   QOMX_IF_VALID_STRUCT_OBJ(
         pCommonRef, pPortThPut, QOMX_ParamPortThroughput, eRetVal )
   {
      /**---------------------------------------------------------------------
         Get port context now.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_PortGetContext(
                        pPortCtnr, pPortThPut->nPortIndex, & pPortCtx );

   }

   if( OMX_ErrorNone == eRetVal )
   {
      OMX_U32  totalByteRate = 0;
      double   totalPacketRate = 0;

      QOMX_MSG_L_MED( pCommonRef, "qomx_GetParmPortThroughput,"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Calculate the total packet and byte rates.
      ----------------------------------------------------------------------*/
      ( void ) qomx_PortCommon_GetTotalRates(
                           pPortCtx, & totalByteRate, & totalPacketRate );

      /**---------------------------------------------------------------------
         Fill buffer supplier definition now.
      ----------------------------------------------------------------------*/
      pPortThPut->nCurrentByteRate     = pPortCtx->nCurrentAverageDataRate;
      pPortThPut->nTotalByteRate       = totalByteRate;
      pPortThPut->nCurrentPacketRate   = pPortCtx->nCurrentAveragePacketRate;
      pPortThPut->nTotalBytes          = pPortCtx->nRateDataTotal;
      pPortThPut->nTotalPackets        = pPortCtx->nRatePacketsTotal;
      pPortThPut->nTotalPacketRate
               = ( OMX_U32 )( totalPacketRate * 65536.0 );

   }

   return( eRetVal );

} /* end of function qomx_GetParmPortThroughput */


/*==========================================================================

         FUNCTION:      qomx_SetParmBufferSupplier

         DESCRIPTION:
                        This function will set the buffer supplier type.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to common reference container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pCmpntParm  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_SetParmBufferSupplier
(
   OMX_IN   QOMX_CommonRefType        *pCommonRef,
   OMX_IN   QOMX_PortContextType      *pPortCtx,
   OMX_OUT  OMX_PTR                    pCmpntParm
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;

   OMX_PARAM_BUFFERSUPPLIERTYPE *pBufSup
      = ( OMX_PARAM_BUFFERSUPPLIERTYPE * ) pCmpntParm;;
   /*-----------------------------------------------------------------------*/

   if ( NULL == pPortCtx )
   {
       QOMX_MSG_L_ERROR( pCommonRef, "qomx_SetParmBufferSupplier,"
          " pPortCtx is NULL" );

      return OMX_ErrorBadParameter;
   }

   QOMX_MSG_L_MED( pCommonRef, "qomx_SetParmBufferSupplier,"
      " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

#ifdef OMX_SPEC_1_Y
   /**------------------------------------------------------------------------
      This function can be called in supplier negotiation during tunnel
      setup or in supplier override after tunnel is setup - in both cases,
      pPortCtx->hTunneledComp is set and should not be NULL.
   -------------------------------------------------------------------------*/
   if( NULL == pPortCtx->hTunneledComp )
   {
      eRetVal = OMX_ErrorIncorrectStateOperation;

   }

   if( OMX_ErrorNone == eRetVal )
   {
#endif
      /**---------------------------------------------------------------------
         Validate size and version.
      ----------------------------------------------------------------------*/
      QOMX_IF_VALID_STRUCT_OBJ(
               pCommonRef, pBufSup, OMX_PARAM_BUFFERSUPPLIERTYPE, eRetVal )
      {
         if( ( OMX_BufferSupplyUnspecified != pBufSup->eBufferSupplier )
            && ( OMX_BufferSupplyInput != pBufSup->eBufferSupplier )
            && ( OMX_BufferSupplyOutput != pBufSup->eBufferSupplier ) )
         {
            QOMX_MSG_L_ERROR( pCommonRef, "Unsupported buffer supplier setting,"
               " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

            /**---------------------------------------------------------------
               Attempt to set an invalid buffer supplier.
            ----------------------------------------------------------------*/
            eRetVal = OMX_ErrorUnsupportedSetting;

         }

      }

      if( OMX_ErrorNone == eRetVal )
      {
         /**------------------------------------------------------------------
            If it is an input port, inform the tunneled output port about
            the buffer supplier change.
         -------------------------------------------------------------------*/
#ifdef OMX_SPEC_1_Y
         if( OMX_DirInput == pPortCtx->portDef.eDir )
#else
         if( ( NULL != pPortCtx->hTunneledComp )
            && ( OMX_DirInput == pPortCtx->portDef.eDir ) )
#endif
         {
            OMX_PARAM_BUFFERSUPPLIERTYPE  bufSup;
            /*--------------------------------------------------------------*/

            QOMX_MSG_L_HIGH( pCommonRef, "Set buffer supplier,"
               " nPortIndex = 0x%x, nTunneledPort = 0x%x",
               pPortCtx->portDef.nPortIndex, pPortCtx->nTunneledPort );

            /**---------------------------------------------------------------
               Set buffer supplier.
            ----------------------------------------------------------------*/
            QOMX_SET_STRUCT_OBJ( bufSup, OMX_PARAM_BUFFERSUPPLIERTYPE );

            bufSup.nPortIndex       = pPortCtx->nTunneledPort;
            bufSup.eBufferSupplier  = pBufSup->eBufferSupplier;

            eRetVal = OMX_SetParameter( pPortCtx->hTunneledComp,
                              OMX_IndexParamCompBufferSupplier, & bufSup );

         }


         /**------------------------------------------------------------------
            Set buffer supplier type in port context now. For tunneling,
            it would be done only when buffer supplier setting on tunneled
            output port is successful.
         -------------------------------------------------------------------*/
         if( OMX_ErrorNone == eRetVal )
         {
            QOMX_MSG_L_HIGH( pCommonRef, "nPortIndex = 0x%x,"
               " eBufferSupplier = 0x%x", pPortCtx->portDef.nPortIndex,
               ( OMX_U32 ) pBufSup->eBufferSupplier );

            /**---------------------------------------------------------------
               Set buffer supplier type now.
            ----------------------------------------------------------------*/
            pPortCtx->eBufferSupplier = pBufSup->eBufferSupplier;

         }
         else
         {
            QOMX_MSG_L_ERROR( pCommonRef, "nPortIndex = 0x%x, Set buffer"
               " supplier failed.", pPortCtx->portDef.nPortIndex );

         }

      }

#ifdef OMX_SPEC_1_Y
   }
#endif

   return( eRetVal );

} /* end of function qomx_SetParmBufferSupplier */

/*==========================================================================

         FUNCTION:      qomx_SetParmPortDefinition

         DESCRIPTION:
                        This function will set the port definition sent from
                        IL client via SetParameter call.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the common reference container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pCmpntParm  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_SetParmPortDefinition
(
   OMX_IN   QOMX_CommonRefType        *pCommonRef,
   OMX_IN   QOMX_PortContextType      *pPortCtx,
   OMX_IN   OMX_PTR                    pCmpntParm
)
{
   OMX_ERRORTYPE                    eRetVal     = OMX_ErrorNone;
   OMX_U32                          nStatus     = MMI_S_EFAIL;
   OMX_PARAM_PORTDEFINITIONTYPE    *pCurPortDef;
   OMX_PARAM_PORTDEFINITIONTYPE    *pNewPortDef
      = ( OMX_PARAM_PORTDEFINITIONTYPE * ) pCmpntParm;
   if (NULL == pPortCtx)
   {
       QOMX_MSG_L_ERROR( pCommonRef, "qomx_SetParmPortDefinition,"
          " pPortCtx is NULL" );

       return OMX_ErrorBadParameter;
   }

   pCurPortDef = & ( pPortCtx->portDef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_SetParmPortDefinition,"
      " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Validate size and version.
   -------------------------------------------------------------------------*/
   QOMX_IF_VALID_STRUCT_OBJ(
            pCommonRef, pNewPortDef, OMX_PARAM_PORTDEFINITIONTYPE, eRetVal )
   {
      /**---------------------------------------------------------------------
         If domain specific parameters are being set, pass it to device.
      ----------------------------------------------------------------------*/

      int   nCmp;
      /*--------------------------------------------------------------------*/

      /**---------------------------------------------------------------------
         Compare port format.
      ----------------------------------------------------------------------*/
      nCmp = QOMX_CMPNT_MEM_CMP( & ( pNewPortDef->format ),
                  & ( pCurPortDef->format ), sizeof( pCurPortDef->format ) );

      if( 0 != nCmp )
      {
         MMI_ParamDomainDefType  domainDef;
         MMI_CustomParamCmdType  customCmd;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_HIGH( pCommonRef, "nPortIndex = 0x%x, Set domain"
            "definition.", pCurPortDef->nPortIndex );

         /**------------------------------------------------------------------
            Set domain definition parameters.
         -------------------------------------------------------------------*/
         domainDef.nPortIndex    = pCurPortDef->nPortIndex;

         QOMX_CMPNT_MEM_COPY( & ( domainDef.format ),
                  & ( pNewPortDef->format ), sizeof( domainDef.format ) );

         /**------------------------------------------------------------------
            Set custom command parameters.
         -------------------------------------------------------------------*/
         customCmd.nParamIndex   = MMI_IndexDomainDef;
         customCmd.pParamStruct  = & domainDef;

         /**------------------------------------------------------------------
            Send this command to device.
         -------------------------------------------------------------------*/
         nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                                    MMI_CMD_SET_CUSTOM_PARAM, & customCmd );

         QOMX_MSG_L_HIGH( pCommonRef, "MMI_CMD_SET_CUSTOM_PARAM"
            " status = 0x%x", nStatus );

         if( MMI_S_COMPLETE != nStatus )
         {
            QOMX_MSG_L_ERROR( pCommonRef, "nPortIndex = 0x%x,"
               " MMI_CMD_SET_CUSTOM_PARAM domain def failed.",
               pCurPortDef->nPortIndex );

            /**---------------------------------------------------------------
               Get OpenMax failure code for this.
            ----------------------------------------------------------------*/
            eRetVal = qomx_GetOMXErrorCode( nStatus );

         }

         /**------------------------------------------------------------------
            Above settings might result in port definition to change in MMI,
            Get latest port definitions from the device and update it in port
            context.
         -------------------------------------------------------------------*/
         if( OMX_ErrorNone == eRetVal )
         {
            QOMX_MSG_L_MED( pCommonRef, "Refresh port definition for"
               "nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

            eRetVal = qomx_PortCommon_UpdatePortDefinition(
                                                   pCommonRef, pPortCtx );

         }

      }

   }


   /**------------------------------------------------------------------------
      If buffer requirements are being set, pass it to device.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      if( pNewPortDef->nBufferCountActual != pCurPortDef->nBufferCountActual )
      {

         MMI_ParamBuffersReqType bufferReq   = { 0 };
         MMI_CustomParamCmdType  customCmd;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_HIGH( pCommonRef, "nPortIndex = 0x%x, Set buffer count",
            pCurPortDef->nPortIndex );

         /**------------------------------------------------------------------
            Set buffer requirement parameters. Pick only Writable fields
            from the new port definition i.e. nBufferCountActual. If IL
            client is trying to set read only fields nBufferSize etc.,
            ignore those. Editing read only fields is not allowed.
         -------------------------------------------------------------------*/
         bufferReq.nCount     = pNewPortDef->nBufferCountActual;

         bufferReq.nPortIndex = pCurPortDef->nPortIndex;
         bufferReq.nMinCount  = pCurPortDef->nBufferCountMin;
         bufferReq.nDataSize  = pCurPortDef->nBufferSize;
         bufferReq.nAlignment = pCurPortDef->nBufferAlignment;
         bufferReq.bBuffersContiguous
                              = pCurPortDef->bBuffersContiguous;

         /**------------------------------------------------------------------
            Set custom command parameters.
         -------------------------------------------------------------------*/
         customCmd.nParamIndex   = MMI_IndexBuffersReq;
         customCmd.pParamStruct  = & bufferReq;

         /**------------------------------------------------------------------
            Send command to device.
         -------------------------------------------------------------------*/
         nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                                    MMI_CMD_SET_CUSTOM_PARAM, & customCmd );

         QOMX_MSG_L_HIGH( pCommonRef, "MMI_CMD_SET_CUSTOM_PARAM"
            " status = 0x%x", nStatus );

         if( MMI_S_COMPLETE != nStatus )
         {
            QOMX_MSG_L_ERROR( pCommonRef, "nPortIndex = 0x%x,"
               " MMI_CMD_SET_CUSTOM_PARAM buffer req failed.",
               pCurPortDef->nPortIndex );

            /**---------------------------------------------------------------
               Get OpenMax failure code for this.
            ----------------------------------------------------------------*/
            eRetVal = qomx_GetOMXErrorCode( nStatus );

         }

         /**------------------------------------------------------------------
            If successful, save the new count locally as well.
         -------------------------------------------------------------------*/
         if( OMX_ErrorNone == eRetVal )
         {
            pCurPortDef->nBufferCountActual = pNewPortDef->nBufferCountActual;
         }

      }

   }

   if( OMX_ErrorInvalidState == eRetVal )
   {
      /**---------------------------------------------------------------------
         Irrecoverable error, Move component to Invalid state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

   }

   return( eRetVal );

} /* end of function qomx_SetParmPortDefinition */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_ProcessBufferHeader

         DESCRIPTION:
*//**                   This function checks the buffer header for marks
                        and flags and send the appropriate notifications
                        to the application.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the component's port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Buffer header which may contain mark.
            @param[in]  nCmd        - Command code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortCommon_ProcessBufferHeader
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE         *pBufferHdr,
   OMX_IN   OMX_U32                       nCmd
)
{
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pCommonRef, "qomx_PortCommon_ProcessBufferHeader,"
      " nPortIndex = 0x%x, pBufferHdr = 0x%p",
      pPortCtx->portDef.nPortIndex,  pBufferHdr );


   if ( MMI_CMD_EMPTY_THIS_BUFFER == nCmd || MMI_RESP_FILL_THIS_BUFFER == nCmd )
   {
      OMX_TICKS   bitrateDuration   = 0;
      OMX_U64     msTime            = 0;

      ( void ) qomx_GetTime( & msTime );

      if (pPortCtx->nRatePacketsTotal == 0)
      {
         pPortCtx->nRateFirstTS = msTime;
         pPortCtx->nRateLastTS  = msTime;

      }

      bitrateDuration = msTime - pPortCtx->nRateLastTS;

      if( bitrateDuration >= BITRATE_THRESHOLD )
      {
         double   averagePacketRate;

         /**------------------------------------------------------------------
            Calculate average data and packet rates for the last sampling
            period. Current data is ignored for this calculation period, and
            applied to the next calculation period.
         -------------------------------------------------------------------*/
         pPortCtx->nCurrentAverageDataRate = ( OMX_U32 )(
               ( pPortCtx->nRateData * MS_PER_SEC ) / bitrateDuration );

         /**------------------------------------------------------------------
            Calculate average packet rate for the last sampling period.
         -------------------------------------------------------------------*/
         averagePacketRate
            =  ( ( double ) pPortCtx->nRatePackets * ( double )MS_PER_SEC )
               / ( double ) bitrateDuration;

         /**------------------------------------------------------------------
            Convert to Q16 format.
         -------------------------------------------------------------------*/
         pPortCtx->nCurrentAveragePacketRate
            = ( OMX_U32 )( averagePacketRate * 65536.0 );

         /**------------------------------------------------------------------
            Update the last packet time, and reset the byte and packet rate
            data.
         -------------------------------------------------------------------*/
         pPortCtx->nRateLastTS  = msTime;
         pPortCtx->nRateData    = 0;
         pPortCtx->nRatePackets = 0;

      }

      /**---------------------------------------------------------------------
         Update the byte and packet rate data, current data is counted
         towards the next calculation period.
      ----------------------------------------------------------------------*/
      pPortCtx->nRateData      += pBufferHdr->nFilledLen;
      pPortCtx->nRateDataTotal += pBufferHdr->nFilledLen;

      pPortCtx->nRatePackets++;
      pPortCtx->nRatePacketsTotal++;

   }

   if ( MMI_CMD_EMPTY_THIS_BUFFER == nCmd )
   {
      QOMX_MSG_L_LOW( pCommonRef, "nPortIndex = 0x%x, EMPTY_THIS_BUFFER,"
         " pBufferHdr = 0x%p",
         pBufferHdr->nInputPortIndex, pBufferHdr );

      QOMX_MSG_L_LOW( pCommonRef, "EMPTY_THIS_BUFFER,"
         " nFilledLen = %u, nTimeStamp = %lld",
         pBufferHdr->nFilledLen, pBufferHdr->nTimeStamp );

      if ( !qmm_ListIsEmpty( &pPortCtx->MarkBufFullList ) )
      {
         (void) qomx_PortCommon_CopyMark( pPortCtnr, pPortCtx, pBufferHdr);
      }
   }
   else if ( MMI_CMD_FILL_THIS_BUFFER == nCmd )
   {

      QOMX_MSG_L_LOW( pCommonRef, "nPortIndex = 0x%x, FILL_THIS_BUFFER,"
         " pBufferHdr = 0x%p",
         pBufferHdr->nOutputPortIndex, pBufferHdr );

      QOMX_MSG_L_LOW( pCommonRef, "FILL_THIS_BUFFER,"
         " nFilledLen = %u, nTimeStamp = %lld",
         pBufferHdr->nFilledLen, pBufferHdr->nTimeStamp );

      /**---------------------------------------------------------------------
         Clear the MarkBuffer header
      ----------------------------------------------------------------------*/
      pBufferHdr->hMarkTargetComponent = NULL;
      pBufferHdr->pMarkData            = NULL;
   }
   else if ( MMI_RESP_EMPTY_THIS_BUFFER == nCmd )
   {

      QOMX_MSG_L_LOW( pCommonRef, "nPortIndex = 0x%x, EMPTY_BUFFER_DONE,"
         " pBufferHdr = 0x%p",
         pPortCtx->portDef.nPortIndex, pBufferHdr );

      QOMX_MSG_L_LOW( pCommonRef, "EMPTY_BUFFER_DONE,"
         " nFilledLen = %u, nTimeStamp = %lld",
         pBufferHdr->nFilledLen, pBufferHdr->nTimeStamp );

      /**---------------------------------------------------------------------
         Check for the marked component.
      ----------------------------------------------------------------------*/
      if ( pBufferHdr->hMarkTargetComponent == pCommonRef->hCmpnt )
      {
         QOMX_MSG_L_MED( pCommonRef, "Marked component detected" );

         /**------------------------------------------------------------------
            Send mark event to the application.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_MED( pCommonRef,
            "Send OMX_EventMark notification" );

         ( void ) qomx_CmpntNotifyEvent( pCommonRef,
                     OMX_EventMark, 0, 0, pBufferHdr->pMarkData );

      }

      /**---------------------------------------------------------------------
         Check for EOS buffer flag. Send EOS notification to IL client if
         this is a sink component.
      ----------------------------------------------------------------------*/
      if ( ( ( pBufferHdr->nFlags & OMX_BUFFERFLAG_EOS ) > 0 )
         && ( OMX_TRUE == QOMX_COMPONENT_IS_SINK( pPortCtnr ) ) )
      {
         QOMX_MSG_L_HIGH( pCommonRef, "Sink component. EOS detected,"
            " nPortIndex = 0x%x", pBufferHdr->nInputPortIndex );

         /**------------------------------------------------------------------
            Send EOS notification to the application.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_MED( pCommonRef,
            "Send OMX_EventBufferFlag notification" );

         ( void ) qomx_CmpntNotifyEvent( pCommonRef, OMX_EventBufferFlag,
                     pBufferHdr->nInputPortIndex, OMX_BUFFERFLAG_EOS, NULL );

      }

   }
   else if ( MMI_RESP_FILL_THIS_BUFFER == nCmd )
   {
      QOMX_MSG_L_LOW( pCommonRef, "nPortIndex = 0x%x, FILL_BUFFER_DONE,"
         " pBufferHdr = 0x%p",
         pPortCtx->portDef.nPortIndex, pBufferHdr );

      QOMX_MSG_L_LOW( pCommonRef, "FILL_BUFFER_DONE,"
         " nFilledLen = %u, nTimeStamp = %lld",
         pBufferHdr->nFilledLen, pBufferHdr->nTimeStamp );

      /**---------------------------------------------------------------------
         Check for EOS buffer flag. Send EOS notification to IL client.
      ----------------------------------------------------------------------*/
      if( ( pBufferHdr->nFlags & OMX_BUFFERFLAG_EOS ) > 0 )
      {
         QOMX_MSG_L_HIGH( pCommonRef, "EOS detected on output port,"
            " nPortIndex = 0x%x", pBufferHdr->nOutputPortIndex );

         /**------------------------------------------------------------------
            Send EOS notification to the application.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_MED( pCommonRef,
            "Send OMX_EventBufferFlag notification" );

         ( void ) qomx_CmpntNotifyEvent( pCommonRef, OMX_EventBufferFlag,
                     pBufferHdr->nOutputPortIndex, OMX_BUFFERFLAG_EOS, NULL );

      }

   }
   return;

} /* end of function qomx_PortCommon_ProcessBufferHeader */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_FreeBuffer

         DESCRIPTION:
*//**                   This function processes free buffer request.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.
@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_FreeBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN OMX_BUFFERHEADERTYPE           *pBufferHdr
)
{
   OMX_U32              nStatus        = MMI_S_EFAIL;
   OMX_ERRORTYPE        eRetVal        = OMX_ErrorNone;
   QMM_ListHandleType  *pHBufHdrQueue  = &(pPortCtx->hBufHdrQueue);
   QOMX_CommonRefType  *pCommonRef     = pPortCtnr->pCommonRef;
   QMM_ListErrorType    eListRetVal;
   QMM_ListLinkType    *pQueueLink;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortCommon_FreeBuffer,"
      " nPortIndex = 0x%x, pBufferHdr = 0x%p",
      pPortCtx->portDef.nPortIndex, pBufferHdr );

   /**------------------------------------------------------------------------
      Search this buffer in queue.
   -------------------------------------------------------------------------*/
   eListRetVal = qmm_ListSearch(
                     pHBufHdrQueue, qomx_PortCommon_BufferHdrLinkCmp,
                     ( void * ) pBufferHdr, & pQueueLink );

   if( QMM_LIST_ERROR_NOT_PRESENT == eListRetVal )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Buffer header not found in list."
         "Invalid pBufferHdr = 0x%p", pBufferHdr );

      /**---------------------------------------------------------------------
         Link is not found in the buffer queue, it may not be belonging to
         current port, return bad parameter error.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else if ( QMM_LIST_ERROR_PRESENT != eListRetVal )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Corruption detected in the list."
         "nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Queue is corrupted, Component should move into an invalid state
         which is not recoverable now.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorInvalidState;

   }
   else
   {
      QOMX_PortBufferHdrLink *pBufHdrLink;
      OMX_BUFFERHEADERTYPE   *pBufferHdr;
      OMX_U8*                 pBufferAddr;
      OMX_U32                 nCmdType;
      OMX_PTR                 pBufCmd;
      MMI_FreeBufferCmdType   freeBufCmd;
      MMI_ClearBufferCmdType  clearBufCmd;
      /*--------------------------------------------------------------------*/

      /**---------------------------------------------------------------------
         Pop this buffer header from queue.
      ----------------------------------------------------------------------*/
      ( void ) qmm_ListPopElement( pHBufHdrQueue, pQueueLink );

      pBufHdrLink = ( QOMX_PortBufferHdrLink * ) pQueueLink;

      /**---------------------------------------------------------------------
        Save buffer address to a local variable for later logging use and
        prepare the MMI device free/clear buffer command, while the header
        is still valid.
      ----------------------------------------------------------------------*/
      pBufferHdr = pBufHdrLink->pBufferHdr;
      pBufferAddr = pBufferHdr->pBuffer;

      if( OMX_TRUE == pBufHdrLink->bDeviceIsBufferAllocator )
      {
         freeBufCmd.nPortIndex   = pPortCtx->portDef.nPortIndex;
         freeBufCmd.pBuffer      = pBufferHdr->pBuffer;
         freeBufCmd.pPlatformPvt = pBufferHdr->pPlatformPrivate;
         nCmdType                = MMI_CMD_FREE_BUFFER;
         pBufCmd                 = & freeBufCmd;

     }
     else
     {
         clearBufCmd.nPortIndex   = pPortCtx->portDef.nPortIndex;
         clearBufCmd.pBuffer      = pBufferHdr->pBuffer;
         clearBufCmd.pPlatformPvt = pBufferHdr->pPlatformPrivate;
         nCmdType                 = MMI_CMD_CLEAR_BUFFER;
         pBufCmd                  = & clearBufCmd;

      }

      /**---------------------------------------------------------------------
         Free buffer header. Since the tunneled peer can own the buffer
         header, we need to free the header before freeing the buffer.
      ----------------------------------------------------------------------*/
      if( OMX_TRUE == pBufHdrLink->bPortIsHeaderAllocator )
      {
         QOMX_MSG_L_HIGH( pCommonRef, "Freeing buffer header. nPortIndex"
            " = 0x%x, pBufferHdr = 0x%p", pPortCtx->portDef.nPortIndex, pBufferHdr );

         QOMX_CMPNT_FREEIF( pCommonRef->pfnFree, pCommonRef->hHeap,
                  pBufferHdr );

      }
      else if( NULL != pPortCtx->hTunneledComp )
      {
         QOMX_MSG_L_HIGH( pCommonRef, "FreeBuffer on tunneled port."
               " nTunneledPort = 0x%x, pBufferHdr = 0x%p",
               pPortCtx->nTunneledPort,  pBufferHdr );

         /**------------------------------------------------------------------
            Tunneled component allocated the header.  Call OMX_FreeBuffer on
            the Tunneled component.
         -------------------------------------------------------------------*/
         eRetVal = OMX_FreeBuffer( pPortCtx->hTunneledComp,
                           pPortCtx->nTunneledPort, pBufferHdr );

      }

      /**---------------------------------------------------------------------
         If device allocated the buffer, call free on device;
         If the buffer was passed to device via a UseBuffer call, call clear
         buffer on device, so that device should no longer reference it.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_HIGH( pCommonRef, "Free/Clear Buffer on device. hFd = 0x%p, "
               "nCmd = 0x%x", pCommonRef->hFd, nCmdType );

      QOMX_MSG_L_HIGH( pCommonRef, "pBuffer = 0x%p", pBufferAddr );

      nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                              nCmdType, pBufCmd );

      QOMX_MSG_L_HIGH( pCommonRef, "nCmd = 0x%x, status = 0x%x",
                     nCmdType, nStatus );

      if( MMI_S_COMPLETE != nStatus )
      {
         if ( nCmdType == MMI_CMD_FREE_BUFFER )
         {
            QOMX_MSG_L_ERROR( pCommonRef, "MMI_CMD_FREE_BUFFER failed. "
                  "pBuffer = 0x%p", pBufferAddr );

         }
         else if ( nCmdType == MMI_CMD_CLEAR_BUFFER )
         {
            QOMX_MSG_L_HIGH( pCommonRef, "MMI_CMD_CLEAR_BUFFER failed. "
                  "pBuffer = 0x%p", pBufferAddr );

         }

      }

      /**---------------------------------------------------------------------
         Free buffer header link.
      ----------------------------------------------------------------------*/
      QOMX_CMPNT_FREEIF( pCommonRef->pfnFree, pCommonRef->hHeap, pBufHdrLink );

      /**---------------------------------------------------------------------
         Reset port population flag.
      ----------------------------------------------------------------------*/
      pPortCtx->portDef.bPopulated = OMX_FALSE;

   }

   if( OMX_ErrorInvalidState == eRetVal )
   {
      /**---------------------------------------------------------------------
         Irrecoverable error, Move component to Invalid state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

   }

   return( eRetVal );

} /* end of function qomx_PortCommon_FreeBuffer */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_ConfigChange

         DESCRIPTION:
*//**                   This function processes the port configuration changed
                        event received from the device.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortCommon_ConfigChange
(
   OMX_IN   QOMX_CommonRefType           *pCommonRef,
   OMX_IN   QOMX_PortContextType         *pPortCtx
)
{
   QOMX_MSG_L_MED( pCommonRef, "qomx_PortCommon_ConfigChange,"
      " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Update the port definition now.
   -------------------------------------------------------------------------*/
   QOMX_MSG_L_MED( pCommonRef, "Refresh port definition for"
      " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

   ( void ) qomx_PortCommon_UpdatePortDefinition( pCommonRef, pPortCtx );

   /**------------------------------------------------------------------------
      Send port config changed done notification.
   -------------------------------------------------------------------------*/
   QOMX_MSG_L_MED( pCommonRef,
            "Send OMX_EventPortSettingsChanged notification" );

   ( void ) qomx_CmpntNotifyEvent(
                              pCommonRef, OMX_EventPortSettingsChanged,
                              pPortCtx->portDef.nPortIndex, 0, NULL );

   return;

} /* end of function qomx_PortCommon_ConfigChange */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_UpdatePortDefinition

         DESCRIPTION:
                        This function will update the port definition with
                        latest information retrieved from device.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_UpdatePortDefinition
(
   OMX_IN   QOMX_CommonRefType           *pCommonRef,
   OMX_IN   QOMX_PortContextType         *pPortCtx
)
{
   OMX_ERRORTYPE              eRetVal     = OMX_ErrorNone;
   OMX_U32                    nStatus     = MMI_S_EFAIL;
   MMI_ParamDomainDefType     domainDef;
   MMI_ParamBuffersReqType    bufferReq;
   MMI_CustomParamCmdType     customCmd;

   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortCommon_UpdatePortDefinition,"
      " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Get buffer requirements.
   -------------------------------------------------------------------------*/
   bufferReq.nPortIndex    = pPortCtx->portDef.nPortIndex;
   customCmd.nParamIndex   = MMI_IndexBuffersReq;
   customCmd.pParamStruct  = & bufferReq;

   /**------------------------------------------------------------------------
      Send this command to device.
   -------------------------------------------------------------------------*/
   nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                              MMI_CMD_GET_CUSTOM_PARAM, & customCmd );

   QOMX_MSG_L_HIGH( pCommonRef,
            "MMI_CMD_GET_CUSTOM_PARAM buffer req status = 0x%x", nStatus );

   /**------------------------------------------------------------------------
      Get domain definition, if buffer requirement is retrieved successfully.
   -------------------------------------------------------------------------*/
   if( MMI_S_COMPLETE == nStatus )
   {
      /**---------------------------------------------------------------------
         Get buffer requirements.
      ----------------------------------------------------------------------*/
      domainDef.nPortIndex    = pPortCtx->portDef.nPortIndex;
      customCmd.nParamIndex   = MMI_IndexDomainDef;
      customCmd.pParamStruct  = & domainDef;

      /**---------------------------------------------------------------------
         Send this command to device.
      ----------------------------------------------------------------------*/
      nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                                 MMI_CMD_GET_CUSTOM_PARAM, & customCmd );


      QOMX_MSG_L_HIGH( pCommonRef,
            "MMI_CMD_GET_CUSTOM_PARAM domain def status = 0x%x", nStatus );

   }

   /**------------------------------------------------------------------------
      If above properties are fetched successfully, update port definition.
      Else since get param should not fail. Move component to invalid state
      on such failure.
   -------------------------------------------------------------------------*/
   if( MMI_S_COMPLETE == nStatus )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "nPortIndex = 0x%x, nBufferCountActual"
         " = %u", pPortCtx->portDef.nPortIndex, bufferReq.nCount );
      QOMX_MSG_L_HIGH( pCommonRef, "nPortIndex = 0x%x, nMinCount = %u",
         pPortCtx->portDef.nPortIndex, bufferReq.nMinCount );
      QOMX_MSG_L_HIGH( pCommonRef, "nPortIndex = 0x%x, nDataSize = %u",
         pPortCtx->portDef.nPortIndex, bufferReq.nDataSize );

      /**---------------------------------------------------------------------
         Update the port definition in port context now.
      ----------------------------------------------------------------------*/
      pPortCtx->portDef.nBufferCountActual   = bufferReq.nCount;
      pPortCtx->portDef.nBufferCountMin      = bufferReq.nMinCount;
      pPortCtx->portDef.nBufferSize          = bufferReq.nDataSize;
      pPortCtx->portDef.nBufferAlignment     = bufferReq.nAlignment;
      pPortCtx->portDef.bBuffersContiguous   = bufferReq.bBuffersContiguous;

      /**---------------------------------------------------------------------
         Update port definition in port context.
      ----------------------------------------------------------------------*/
      QOMX_CMPNT_MEM_COPY( & pPortCtx->portDef.format,
                  & domainDef.format, sizeof( pPortCtx->portDef.format ) );

   }
   else
   {
      QOMX_MSG_L_ERROR( pCommonRef, "nPortIndex = 0x%x, Unexpected failure on"
         " MMI_CMD_GET_CUSTOM_PARAM.", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Set Invalid state error.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorInvalidState;

      /**---------------------------------------------------------------------
         Irrecoverable error, Move component to Invalid state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

   }

   return( eRetVal );

} /* end of function qomx_PortCommon_UpdatePortDefinition */


/*==========================================================================

         FUNCTION:      qomx_SetParameterIsLegal

         DESCRIPTION:
                        This function checks if SetParameter is a legal call
                        in the current component or port state, for the given
                        port index.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  nParamIndex - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pCmpntParm  - Refer OMX_Core.h / OMX IL specification.
            @param[out] ppPortCtx   - Pointer to a port context object which
                                      would be filled with appropriate port
                                      context upon exit if setting is detected
                                      for a port, othewise would be set to
                                      NULL.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - If operation is a legal call or if
                                         nParamIndex is not recognized. This
                                         index might be extension index and
                                         should be passed down to MMI device.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_SetParameterIsLegal
(
   OMX_IN      QOMX_PortContainerType       *pPortCtnr,
   OMX_IN      OMX_INDEXTYPE                 nParamIndex,
   OMX_IN      OMX_PTR                       pCmpntParm,
   OMX_OUT     QOMX_PortContextType        **ppPortCtx
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   QOMX_CmpntStateType  eCmpntState;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_SetParameterIsLegal, nParamIndex = 0x%x", nParamIndex );

   /**------------------------------------------------------------------------
      Initialization.
   -------------------------------------------------------------------------*/
   ( * ppPortCtx ) = NULL;

   /**------------------------------------------------------------------------
      Get component state.
   -------------------------------------------------------------------------*/
   eCmpntState = qomx_CmpntGetQOMXState( pPortCtnr->pCommonRef->hCmpnt );

   /**------------------------------------------------------------------------
      Get Port Index if applicable.
   -------------------------------------------------------------------------*/
   switch( nParamIndex )
   {
   case OMX_IndexParamPriorityMgmt:
      /* fall through */
   case OMX_IndexParamNumAvailableStreams:
      /* fall through */
   case OMX_IndexParamActiveStream:
      /* fall through */
   case OMX_IndexParamPortDefinition:
      /* fall through */
   case OMX_IndexParamCompBufferSupplier:
      /* fall through */
   case OMX_IndexParamAudioPortFormat:
      /* fall through */
   case OMX_IndexParamAudioPcm:
      /* fall through */
   case OMX_IndexParamAudioAac:
      /* fall through */
   case OMX_IndexParamAudioRa:
      /* fall through */
   case OMX_IndexParamAudioMp3:
      /* fall through */
   case OMX_IndexParamAudioAdpcm:
      /* fall through */
   case OMX_IndexParamAudioG723:
      /* fall through */
   case OMX_IndexParamAudioG729:
      /* fall through */
   case OMX_IndexParamAudioAmr:
      /* fall through */
   case OMX_IndexParamAudioWma:
      /* fall through */
   case OMX_IndexParamAudioSbc:
      /* fall through */
   case OMX_IndexParamAudioMidi:
      /* fall through */
   case OMX_IndexParamAudioGsm_FR:
      /* fall through */
   case OMX_IndexParamAudioMidiLoadUserSound:
      /* fall through */
   case OMX_IndexParamAudioG726:
      /* fall through */
   case OMX_IndexParamAudioGsm_EFR:
      /* fall through */
   case OMX_IndexParamAudioGsm_HR:
      /* fall through */
   case OMX_IndexParamAudioPdc_FR:
      /* fall through */
   case OMX_IndexParamAudioPdc_EFR:
      /* fall through */
   case OMX_IndexParamAudioPdc_HR:
      /* fall through */
   case OMX_IndexParamAudioTdma_FR:
      /* fall through */
   case OMX_IndexParamAudioTdma_EFR:
      /* fall through */
   case OMX_IndexParamAudioQcelp8:
      /* fall through */
   case OMX_IndexParamAudioQcelp13:
      /* fall through */
   case OMX_IndexParamAudioEvrc:
      /* fall through */
   case OMX_IndexParamAudioSmv:
      /* fall through */
   case OMX_IndexParamAudioVorbis:
      /* fall through */
   case OMX_IndexParamImagePortFormat:
      /* fall through */
   case OMX_IndexParamFlashControl:
      /* fall through */
   case OMX_IndexParamQFactor:
      /* fall through */
   case OMX_IndexParamQuantizationTable:
      /* fall through */
   case OMX_IndexParamHuffmanTable:
      /* fall through */
   case OMX_IndexParamVideoPortFormat:
      /* fall through */
   case OMX_IndexParamVideoQuantization:
      /* fall through */
   case OMX_IndexParamVideoFastUpdate:
      /* fall through */
   case OMX_IndexParamVideoBitrate:
      /* fall through */
   case OMX_IndexParamVideoMotionVector:
      /* fall through */
   case OMX_IndexParamVideoIntraRefresh:
      /* fall through */
   case OMX_IndexParamVideoErrorCorrection:
      /* fall through */
   case OMX_IndexParamVideoVBSMC:
      /* fall through */
   case OMX_IndexParamVideoMpeg2:
      /* fall through */
   case OMX_IndexParamVideoMpeg4:
      /* fall through */
   case OMX_IndexParamVideoWmv:
      /* fall through */
   case OMX_IndexParamVideoRv:
      /* fall through */
   case OMX_IndexParamVideoAvc:
      /* fall through */
   case OMX_IndexParamVideoH263:
      /* fall through */
   case OMX_IndexParamVideoProfileLevelQuerySupported:
      /* fall through */
   case OMX_IndexParamVideoProfileLevelCurrent:
      /* fall through */
   case OMX_IndexParamVideoMacroblocksPerFrame:
      /* fall through */
   case OMX_IndexParamVideoSliceFMO:
      /* fall through */
   case OMX_IndexParamCommonDeblocking:
      /* fall through */
   case OMX_IndexParamCommonSensorMode:
      /* fall through */
   case OMX_IndexParamCommonInterleave:
      /* fall through */
   case OMX_IndexParamCommonExtraQuantData:
      /* fall through */
   case OMX_IndexParamOtherPortFormat:
      {
         QOMX_PortParamPattern *pParam
               = ( QOMX_PortParamPattern * ) pCmpntParm;

         QOMX_MSG_L_MED( pCommonRef, "Param Index is port specific,"
            " nParamIndex = 0x%x", nParamIndex );

         /**------------------------------------------------------------------
            If Port index is OMX_ALL, MMI should validate SetParameter call.
            Setparameter is not a legal call on an enabled Port when
            component is not in Loaded state.
         -------------------------------------------------------------------*/
         if( OMX_ALL != pParam->nPortIndex )
         {
            /**---------------------------------------------------------------
               Get port context and check component and port states.
               Component should be in Loaded state or Port should be
               disabled.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortGetContext(
                              pPortCtnr, pParam->nPortIndex, ppPortCtx );

            if( ( OMX_ErrorNone == eRetVal )
               && ( OMX_TRUE == ( * ppPortCtx )->portDef.bEnabled )
               && ( QOMX_StateLoaded != eCmpntState ) )
            {
               QOMX_MSG_L_ERROR( pCommonRef, "nPortIndex = 0x%x, SetParameter"
                  "on enabled ports is allowed only in Loaded state.",
                  ( * ppPortCtx )->portDef.nPortIndex );

               /**------------------------------------------------------------
                  Incorrect state operation.
               -------------------------------------------------------------*/
               eRetVal = OMX_ErrorIncorrectStateOperation;

            }

         }
         else
         {
            QOMX_MSG_L_MED( pCommonRef, "SetParameter with OMX_ALL." );

         }

      }

      break;

   default:
      {
         /**------------------------------------------------------------------
            For all device extension indexes, MMI should validate
            SetParameter call.
            Component specific SetParameter calls are valid only in
            Loaded state.
         -------------------------------------------------------------------*/
         if( ( nParamIndex > OMX_IndexKhronosExtensions )
            && ( nParamIndex < OMX_IndexMax ) )
         {
            QOMX_MSG_L_MED( pCommonRef, "Khronos / Vendor extension index,"
               " nParamIndex = 0x%x", nParamIndex );

         }
         else if( QOMX_StateLoaded != eCmpntState )
         {
            QOMX_MSG_L_ERROR( pCommonRef, "SetParameter on component level"
                  "is allowed only in Loaded state." );

            /**---------------------------------------------------------------
               Incorrect state operation.
            ----------------------------------------------------------------*/
            eRetVal = OMX_ErrorIncorrectStateOperation;

         }

      }

      break;

   } /* end of switch( nParamIndex ) */


   return( eRetVal );

} /* end of function qomx_SetParameterIsLegal */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_EnableResp

         DESCRIPTION:
*//**                   This function processes the enable port command
                        response received from the device.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  nStatus     - Event status.
            @param[in]  bCmdStatus  - True if this function is called when
                                      processing device command status which
                                      is returned as function return type.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void     qomx_PortCommon_EnableResp
(
   OMX_IN   QOMX_PortContainerType    *pPortCtnr,
   OMX_IN   QOMX_PortContextType      *pPortCtx,
   OMX_IN   OMX_U32                    nStatus,
   OMX_IN   OMX_BOOL                   bSyncResp
)
{
   QOMX_CmpntStateType  eCmpntState;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortCommon_EnableResp, nPortIndex"
      " = 0x%x, nStatus = 0x%x", pPortCtx->portDef.nPortIndex, nStatus );

   /**---------------------------------------------------------------------
      Get current component state.
   ----------------------------------------------------------------------*/
   eCmpntState = qomx_CmpntGetQOMXState( pCommonRef->hCmpnt );


   if( MMI_S_COMPLETE == nStatus )
   {
      /*--------------------------------------------------------------------*/

      QOMX_MSG_L_HIGH( pCommonRef, "Enable port is successful,"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Set enabled flag in port definition.
      ----------------------------------------------------------------------*/
      pPortCtx->portDef.bEnabled  = OMX_TRUE;
      pPortCtx->bAlterCmdFinished = OMX_TRUE;

      /**---------------------------------------------------------------------
         Enable command is complete if component is in Loaded or WFR state
         which does not require buffers to be accumulated.
         Port may have 0 buffer requirement, enabling it would lead its
         state to EnabledPopulated ( if Component is Idle ) or
         EnabledRunning ( if Component is Executing ).
      ----------------------------------------------------------------------*/
      if( ( QOMX_StateLoaded == eCmpntState )
         || ( QOMX_StateWaitForResources == eCmpntState ) )
      {
         QOMX_MSG_L_MED( pCommonRef, "Enable port finished in Loaded / WFR"
            " state, nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Transition to EnabledUnpopulated state.
         -------------------------------------------------------------------*/
         if( QOMX_StatePortEnabledUnpopulated != pPortCtx->eState )
         {
            QOMX_MSG_L_HIGH( pCommonRef, "Move to EnabledUnpopulated state,"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

            ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                              pPortCtx, QOMX_StatePortEnabledUnpopulated, 0 );
         }

         /**------------------------------------------------------------------
            Send command complete to IL client for enable port.
         -------------------------------------------------------------------*/
         pPortCtx->bAlterRespPending = OMX_FALSE;

         QOMX_MSG_L_MED( pCommonRef,
            "Send OMX_CommandPortEnable notification, nPortIndex = 0x%x",
            pPortCtx->portDef.nPortIndex );

         ( void ) qomx_CmpntCmdComplete( pCommonRef, OMX_CommandPortEnable,
                              pPortCtx->portDef.nPortIndex, NULL );

      }
      else if( OMX_TRUE == qomx_PortCommon_CheckGuard(
                                 pPortCtx, QOMX_PORT_GUARD_POPULATED ) )
      {
         /**------------------------------------------------------------------
            Port has 0 buffer requirement or is already populated as of this
            point. If component state is Executing or Pause, move port to
            Running state, otherwise move it to Populated.
         -------------------------------------------------------------------*/
         if( ( QOMX_StateExecuting == eCmpntState )
            || ( QOMX_StateIdleToExecuting == eCmpntState )
            || ( QOMX_StatePause == eCmpntState ) )
         {
            QOMX_MSG_L_HIGH( pCommonRef, "Enable port finished in Executing /"
               " Pause state, Move to EnabledRunning state,"
               " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

            ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                              pPortCtx, QOMX_StatePortEnabledRunning, 0 );

         }
         else
         {
            QOMX_MSG_L_HIGH( pCommonRef, "Enable port finished in Idle state,"
               " Move to EnabledPopulated state nPortIndex = 0x%x",
               pPortCtx->portDef.nPortIndex );

            ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                              pPortCtx, QOMX_StatePortEnabledPopulated, 0 );

         }

         /**------------------------------------------------------------------
            Issue port enable command complete callback to IL client.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_MED( pCommonRef,
            "Send OMX_CommandPortEnable notification, nPortIndex = 0x%x",
            pPortCtx->portDef.nPortIndex );

         pPortCtx->bAlterRespPending = OMX_FALSE;

         ( void ) qomx_CmpntCmdComplete( pCommonRef, OMX_CommandPortEnable,
                              pPortCtx->portDef.nPortIndex, NULL );

      }
      else
      {
         QOMX_MSG_L_HIGH( pCommonRef, "Enable port, waiting for buffers to be"
            " assigned, Move to EnabledPopulating state, nPortIndex = 0x%x",
            pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Transition to Populating state and wait for buffers.
         -------------------------------------------------------------------*/
         pPortCtx->bAlterRespPending = OMX_TRUE;

         if( QOMX_StatePortEnabledPopulating != pPortCtx->eState )
         {
            ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                             pPortCtx, QOMX_StatePortEnabledPopulating, 0 );

         }

      }

   }
   else if( ( MMI_S_PENDING == nStatus ) && ( OMX_TRUE == bSyncResp ) )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Enable port status is pending,"
            " Move to EnabledPopulating state, nPortIndex = 0x%x",
            pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Device port enable is in progress. Set flags.
      ----------------------------------------------------------------------*/
      pPortCtx->portDef.bEnabled  = OMX_TRUE;
      pPortCtx->bAlterCmdFinished = OMX_FALSE;
      pPortCtx->bAlterRespPending = OMX_TRUE;

      /**---------------------------------------------------------------------
         Transition to a port state consistent with component state.
      ----------------------------------------------------------------------*/
      if( ( QOMX_StateLoaded == eCmpntState )
         || ( QOMX_StateWaitForResources == eCmpntState ) )
      {
         ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                             pPortCtx, QOMX_StatePortEnabledUnpopulated, 0 );
      }
      else
      {
         ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                             pPortCtx, QOMX_StatePortEnabledPopulating, 0 );
      }

   }
   else
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Unexpected status from MMI Enable"
         " response. Move to Invalid state, nPortIndex = 0x%x",
            pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Move component to Invalid state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

   }

   return;

} /* end of function qomx_PortCommon_EnableResp */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_DisableResp

         DESCRIPTION:
*//**                   This function processes the disable port command
                        response received from the device.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  nStatus     - Event status.
            @param[in]  bCmdStatus  - True if this function is called when
                                      processing device command status which
                                      is returned as function return type.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void     qomx_PortCommon_DisableResp
(
   OMX_IN   QOMX_PortContainerType    *pPortCtnr,
   OMX_IN   QOMX_PortContextType      *pPortCtx,
   OMX_IN   OMX_U32                    nStatus,
   OMX_IN   OMX_BOOL                   bSyncResp
)
{
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortCommon_DisableResp, nPortIndex"
      " = 0x%x, nStatus = 0x%x", pPortCtx->portDef.nPortIndex, nStatus );

   if( MMI_S_COMPLETE == nStatus )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Disable port is successful,"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Set enabled flag in port definition.
      ----------------------------------------------------------------------*/
      pPortCtx->portDef.bEnabled  = OMX_FALSE;
      pPortCtx->bAlterCmdFinished = OMX_TRUE;

      /**---------------------------------------------------------------------
         If port is already in disabled unpopulated state, we can send disable
         complete notification. Otherwise, notification will be sent upon
         entering this state.
      ----------------------------------------------------------------------*/
      if( QOMX_StatePortDisabledUnpopulated == pPortCtx->eState )
      {
         QOMX_MSG_L_MED( pCommonRef, "Disable port finished, "
            "nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Issue port disable command complete callback to IL client.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_MED( pCommonRef, "Send OMX_CommandPortDisable"
            " notification, nPortIndex = 0x%x",
            pPortCtx->portDef.nPortIndex );

         ( void ) qomx_CmpntCmdComplete( pCommonRef, OMX_CommandPortDisable,
                           pPortCtx->portDef.nPortIndex, NULL );
      }
      else
      {
         QOMX_MSG_L_HIGH( pCommonRef, "Disable port, waiting for buffers to "
            "be freed, nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      }

   }
   else if( ( MMI_S_PENDING == nStatus ) && ( OMX_TRUE == bSyncResp ) )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Disable port status is pending,"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Device port disable is in progress, set flags.
      ----------------------------------------------------------------------*/
      pPortCtx->portDef.bEnabled  = OMX_FALSE;
      pPortCtx->bAlterCmdFinished = OMX_FALSE;

   }
   else
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Unexpected status from MMI Disable"
         " response. Move to Invalid state, nPortIndex = 0x%x",
            pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Move component to Invalid state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

   }

   return;

} /* end of function qomx_PortCommon_DisableResp */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_Unpopulate

         DESCRIPTION:
                        This function will move the port state to depopulating.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_Unpopulate
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortCommon_Unpopulate, nPortIndex"
      " = 0x%x", pPortCtx->portDef.nPortIndex );

   ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                           pPortCtx, QOMX_StatePortEnabledDepopulating, 0 );


   return( eRetVal );

} /* end of function qomx_PortCommon_Unpopulate */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_DummyUnpopulate

         DESCRIPTION:
                        This function is a dummy funtion created to handle
                        Unpopulate primitive in port state table for states
                        EnabledDepopulating and EnabledUnpopulated where
                        Unpopulate might be legal, but should not take any
                        action.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_DummyUnpopulate
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
)
{
   OMX_ERRORTYPE        eRetVal = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_PortCommon_DummyUnpopulate called." );

   /**------------------------------------------------------------------------
      If Unpopulate gets called in states EnabledDepopulating and
      EnabledUnpopulated, this means port received an unexpected FreeBuffer
      and as a result went into these states before a legitiate state
      transition was sent. Therefore Unpopulate directive has to be accepted,
      but there is nothing to be done.
   -------------------------------------------------------------------------*/


   return( eRetVal );

} /* end of function qomx_PortCommon_DummyUnpopulate */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_EmptyThisBufferResp

         DESCRIPTION:
*//**                   This function processes empty buffer done response
                        from the device.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Pointer to the buffer header.
            @param [in] nEventStatus- Status of the event.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_EmptyThisBufferResp
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr,
   OMX_IN   OMX_U32                 nEventStatus
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pCommonRef, "qomx_PortCommon_EmptyThisBufferResp,"
      " nPortIndex = 0x%x, pBufferHdr = 0x%p",
      pPortCtx->portDef.nPortIndex, pBufferHdr );

   /**------------------------------------------------------------------------
      Decrement used buffer count. Increment client buffer count.
   -------------------------------------------------------------------------*/
   pPortCtx->nBuffersWithDevice--;
   pPortCtx->nBuffersWithClient++;

   /**------------------------------------------------------------------------
      Process buffer header.
   -------------------------------------------------------------------------*/
   if( MMI_S_EBUFFERNOTPROCESSED != nEventStatus )
   {
      ( void ) qomx_PortCommon_ProcessBufferHeader( pPortCtnr, pPortCtx,
                                    pBufferHdr, MMI_RESP_EMPTY_THIS_BUFFER );

   }

   if( ( MMI_S_COMPLETE == nEventStatus ) ||
         ( MMI_S_EBUFFERNOTPROCESSED == nEventStatus ) )
   {
      /**---------------------------------------------------------------------
         Send empty buffer done notification when non-tunneling.
      ----------------------------------------------------------------------*/
      if( NULL == pPortCtx->hTunneledComp )
      {
         QOMX_MSG_L_LOW( pCommonRef, "Not tunneling, send EBD, "
            "nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         eRetVal = qomx_CmpntEmptyBufferDone( pCommonRef, pBufferHdr );

      }
      else
      {
         /**------------------------------------------------------------------
            Return this buffer to the tunneled component.
         -------------------------------------------------------------------*/

         QOMX_MSG_L_LOW( pCommonRef,
            "Return buffer to tunneled component." );

         /**------------------------------------------------------------------
            Clear the buffer header.
         -------------------------------------------------------------------*/
         //pBufferHdr->nFilledLen           = 0;
         //pBufferHdr->nOffset              = 0;
         //pBufferHdr->nTickCount           = 0;
         //pBufferHdr->nTimeStamp           = 0;
         pBufferHdr->nFlags               = 0;
         pBufferHdr->hMarkTargetComponent = NULL;
         pBufferHdr->pMarkData            = NULL;

         pBufferHdr->nOutputPortIndex     = pPortCtx->nTunneledPort;

         /**------------------------------------------------------------------
            Release LOCK. This critical section was acquired when event
            handler qomx_DeviceEventHandler is called from MMI.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntUnlockContext( pCommonRef->hCmpnt );

         /**------------------------------------------------------------------
            Tunneled component, send OMX_FillThisBuffer.
         -------------------------------------------------------------------*/
         eRetVal = OMX_FillThisBuffer(
                                 pPortCtx->hTunneledComp, pBufferHdr );

         if( OMX_ErrorNone != eRetVal )
         {
            QOMX_MSG_L_ERROR( pCommonRef, "Tunneled peer rejected "
                "FillThisBuffer call, return code = 0x%08x", eRetVal );

            /**---------------------------------------------------------------
               Since we released the lock, we need special processing for this
               failure.
            ----------------------------------------------------------------*/
            qomx_PortCommon_BufferRejected( pPortCtnr, pPortCtx, pBufferHdr );

         }

         /**------------------------------------------------------------------
            Return CS released error to the API handler. API handler must
            not attempt to unlock context again.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ERROR_CS_RELEASED;

      }

   }
   else
   {
      OMX_ERRORTYPE  eReportError;
      /*--------------------------------------------------------------------*/

      QOMX_MSG_L_HIGH( pCommonRef,
         "Error status %d in EmptyThisBuffer resp.", nEventStatus );

      /**---------------------------------------------------------------
         Get OMX error.
      ----------------------------------------------------------------*/
      eReportError = qomx_GetOMXErrorCode( nEventStatus );

      /**---------------------------------------------------------------------
         Report this error to client. Move component to Invalid state
         if a fatal error.
      ----------------------------------------------------------------------*/
      if( OMX_ErrorInvalidState != eReportError )
      {
         /**------------------------------------------------------------------
            Notify error.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntNotifyError( pCommonRef, eReportError );

      }
      else
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Fatal error." );

         ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                 qomx_GetQOMXBaseEventCode( nEventStatus ) );

      }

      /**---------------------------------------------------------------------
         Return buffer now.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_LOW( pCommonRef, "Send empty buffer done." );

      eRetVal = qomx_CmpntEmptyBufferDone( pCommonRef, pBufferHdr );

   }
   if ( OMX_ERROR_CS_RELEASED == eRetVal )
   {
      /**
      If this is not a tunneled component
      bufWithClient = nBufferCountActual - nBuffersWithDevice
      or
      bufWithClient = nBuffersWithClient(ranges from 0 to -n) + nBufferCountActual(n)

      but for tunneled components, some buffers could be neither with device or client,
      but instead with downstream components. So, the actual

      bufWithClient = nBuffersWithClient(ranges from 0 to -n) + nBufferCountActual(n)
      Then,
      buffersWithDownstreamComponent =
            nBufferCountActual - (buffers with device + buffers with client)
      */
      OMX_U32 bufWithClient = (pPortCtx->nBuffersWithClient + pPortCtx->portDef.nBufferCountActual);
      QOMX_STATS_MSG( pPortCtnr->pCommonRef, QOMX_MSG_PRIORITY_LOW,
         "EBD buffers with device = %d, buffers with client = %d, TimeStamp = %lld",
         pPortCtx->nBuffersWithDevice, bufWithClient, pBufferHdr->nTimeStamp );
   }

   return( eRetVal );

} /* end of function qomx_PortCommon_EmptyThisBufferResp */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_EmptyThisBufferRespStopping

         DESCRIPTION:
*//**                   This function processes empty buffer done response
                        from the device when port is stopping.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Pointer to the buffer header.
            @param [in] nEventStatus- Status of the event.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_EmptyThisBufferRespStopping
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr,
   OMX_IN   OMX_U32                 nEventStatus
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pCommonRef,
      "qomx_PortCommon_EmptyThisBufferRespStopping, nPortIndex = 0x%x",
      pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Decrement used buffer count. Increment client buffer count.
   -------------------------------------------------------------------------*/
   pPortCtx->nBuffersWithDevice--;
   pPortCtx->nBuffersWithClient++;

   if( MMI_S_COMPLETE == nEventStatus )
   {
      /**---------------------------------------------------------------------
         Process buffer header.
      ----------------------------------------------------------------------*/
      ( void ) qomx_PortCommon_ProcessBufferHeader( pPortCtnr, pPortCtx,
                                    pBufferHdr, MMI_RESP_EMPTY_THIS_BUFFER );

      /**---------------------------------------------------------------------
         Send empty buffer done notification when non-tunneling.
      ----------------------------------------------------------------------*/
      if( NULL == pPortCtx->hTunneledComp )
      {
         QOMX_MSG_L_LOW( pCommonRef, "Send EmptyBufferDone notification"
            " nPortIndex = 0x%x, pBufferHdr = 0x%p",
            pPortCtx->portDef.nPortIndex, pBufferHdr );

         eRetVal = qomx_CmpntEmptyBufferDone( pCommonRef, pBufferHdr );

         /**------------------------------------------------------------------
            Check if we can move to next state.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_CheckStop( pPortCtnr, pPortCtx );

      }
      else
      {
         /**------------------------------------------------------------------
            Tunneling. Return this buffer only if port is non-supplier.
         -------------------------------------------------------------------*/
         if( QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx )  )
         {
            QOMX_MSG_L_LOW( pCommonRef,
               "Port is supplier, hold the buffer." );

            /**---------------------------------------------------------------
               Supplier, hold buffer, decrement buffer client, check for stop
               condition.
            ----------------------------------------------------------------*/
            pPortCtx->nBuffersWithClient--;

            ( void ) qomx_PortCommon_CheckStop( pPortCtnr, pPortCtx );

         }
         else
         {
            QOMX_MSG_L_LOW( pCommonRef, "Non-supplier. Return buffer to "
               "tunneled component, nPortIndex = 0x%x, pBufferHdr = 0x%p",
               pPortCtx->portDef.nPortIndex, pBufferHdr );

            /**---------------------------------------------------------------
               Clear the buffer header.
            ----------------------------------------------------------------*/
            pBufferHdr->nFilledLen           = 0;
            pBufferHdr->nOffset              = 0;
            pBufferHdr->nTickCount           = 0;
            pBufferHdr->nTimeStamp           = 0;
            pBufferHdr->nFlags               = 0;
            pBufferHdr->hMarkTargetComponent = NULL;
            pBufferHdr->pMarkData            = NULL;

            pBufferHdr->nOutputPortIndex     = pPortCtx->nTunneledPort;

            /**---------------------------------------------------------------
               Need to check stop condition before releasing the lock.
            ----------------------------------------------------------------*/
            ( void ) qomx_PortCommon_CheckStop( pPortCtnr, pPortCtx );

            /**---------------------------------------------------------------
               Release LOCK. This critical section was acquired when event
               handler qomx_DeviceEventHandler is called from MMI.
            ----------------------------------------------------------------*/
            ( void ) qomx_CmpntUnlockContext( pCommonRef->hCmpnt );


            /**---------------------------------------------------------------
               Tunneled component, send OMX_FillThisBuffer.
            ----------------------------------------------------------------*/
            eRetVal = OMX_FillThisBuffer(
                                 pPortCtx->hTunneledComp, pBufferHdr );

            if( OMX_ErrorNone != eRetVal )
            {
               QOMX_MSG_L_ERROR( pCommonRef, "Tunneled Peer rejected"
                  " FillThisBuffer nPortIndex = 0x%x, pBufferHdr = 0x%p",
                  pPortCtx->portDef.nPortIndex,  pBufferHdr );

               /**------------------------------------------------------------
                  Decrement buffer client.
               -------------------------------------------------------------*/
               pPortCtx->nBuffersWithClient--;

            }

            /**---------------------------------------------------------------
               Return CS released error to the API handler. API handler must
               not attempt to unlock context again.
            ----------------------------------------------------------------*/
            eRetVal = OMX_ERROR_CS_RELEASED;
         }

      }

   }
   else
   {
      OMX_ERRORTYPE  eReportError;
      /*--------------------------------------------------------------------*/

      QOMX_MSG_L_ERROR( pCommonRef, "EmptyThisBuffer error response,"
         " nPortIndex = 0x%x, pBufferHdr = 0x%p",
         pPortCtx->portDef.nPortIndex, pBufferHdr );

      /**---------------------------------------------------------------
         Get OMX error.
      ----------------------------------------------------------------*/
      eReportError = qomx_GetOMXErrorCode( nEventStatus );

      /**---------------------------------------------------------------------
         Report this error to client. Move component to Invalid state
         if a fatal error.
      ----------------------------------------------------------------------*/
      if( OMX_ErrorInvalidState != eReportError )
      {
         QOMX_MSG_L_MED( pCommonRef,
            "Send eReportError = 0x%x notification, nPortIndex = 0x%x",
            pPortCtx->portDef.nPortIndex, ( OMX_U32 ) eReportError );

         /**------------------------------------------------------------------
            Notify error.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntNotifyError( pCommonRef, eReportError );

         /**------------------------------------------------------------------
            Check if we can move to next state.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_CheckStop( pPortCtnr, pPortCtx );
      }
      else
      {
         QOMX_MSG_L_ERROR( pCommonRef,
            "Fatal error, Move to Invalid state, nPortIndex = 0x%x",
            pPortCtx->portDef.nPortIndex );

         ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                              qomx_GetQOMXBaseEventCode( nEventStatus ) );

      }

      /**---------------------------------------------------------------------
         Return buffer now.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_LOW( pCommonRef, "Send EmptyBufferDone notification"
         " nPortIndex = 0x%x, pBufferHdr = 0x%p",
         pPortCtx->portDef.nPortIndex, pBufferHdr );

      eRetVal = qomx_CmpntEmptyBufferDone( pCommonRef, pBufferHdr );

   }

   if ( OMX_ERROR_CS_RELEASED == eRetVal )
   {
      OMX_U32 bufWithClient = (pPortCtx->nBuffersWithClient + pPortCtx->portDef.nBufferCountActual);
      QOMX_STATS_MSG( pPortCtnr->pCommonRef, QOMX_MSG_PRIORITY_LOW,
         "EBD buffers with device = %d, buffers with client = %d, TimeStamp = %lld",
         pPortCtx->nBuffersWithDevice, bufWithClient, pBufferHdr->nTimeStamp );
   }
   return( eRetVal );

} /* end of function qomx_PortCommon_EmptyThisBufferRespStopping */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_FillThisBufferResp

         DESCRIPTION:
*//**                   This function processes fill buffer done response
                        from the device.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Pointer to the buffer header.
            @param [in] nEventStatus- Status of the event.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_FillThisBufferResp
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr,
   OMX_IN   OMX_U32                 nEventStatus
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType   *pCommonRef = pPortCtnr->pCommonRef;
   OMX_BUFFERHEADERTYPE sBufHdrTmp;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pCommonRef, "qomx_PortCommon_FillThisBufferResp,"
      " nPortIndex = 0x%x, pBufferHdr = 0x%p",
      pPortCtx->portDef.nPortIndex,  pBufferHdr );

   /**------------------------------------------------------------------------
      Decrement used buffer count. Increment client buffer count.
   -------------------------------------------------------------------------*/
   pPortCtx->nBuffersWithDevice--;
   pPortCtx->nBuffersWithClient++;

   /**------------------------------------------------------------------------
      Copy buffer header object.
   -------------------------------------------------------------------------*/
   QOMX_CMPNT_MEM_COPY(
                  &(sBufHdrTmp), pBufferHdr, sizeof( OMX_BUFFERHEADERTYPE ) );

   if( ( MMI_S_COMPLETE == nEventStatus ) ||
         ( MMI_S_EBUFFERNOTPROCESSED == nEventStatus ) )
   {
      /**---------------------------------------------------------------------
         Send fill buffer done notification when non-tunneling.
      ----------------------------------------------------------------------*/
      if( NULL == pPortCtx->hTunneledComp )
      {
         QOMX_MSG_L_LOW( pCommonRef, "Not tunneling, send FBD, "
            "nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         if ( !qmm_ListIsEmpty( &pPortCtx->MarkBufFullList ) )
         {
            /**------------------------------------------------------------------------
               MarkBuffer required, copy to buffer header and return Mark complete
            -------------------------------------------------------------------------*/
            (void) qomx_PortCommon_CopyMark( pPortCtnr ,pPortCtx, pBufferHdr);
         }

         eRetVal = qomx_CmpntFillBufferDone( pCommonRef, pBufferHdr );
      }
      else
      {
         /**------------------------------------------------------------------
            Return this buffer to the tunneled component.
         -------------------------------------------------------------------*/

         QOMX_MSG_L_LOW( pCommonRef,
            "Return buffer to tunneled component." );

         pBufferHdr->nInputPortIndex = pPortCtx->nTunneledPort;

         /**------------------------------------------------------------------
            Release LOCK. This critical section was acquired when event
            handler qomx_DeviceEventHandler is called from MMI.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntUnlockContext( pCommonRef->hCmpnt );


         /**------------------------------------------------------------------
            Tunneled component, send OMX_EmptyThisBuffer.
         -------------------------------------------------------------------*/
         eRetVal = OMX_EmptyThisBuffer(pPortCtx->hTunneledComp, pBufferHdr );

         if( OMX_ErrorNone != eRetVal )
         {
            QOMX_MSG_L_ERROR( pCommonRef, "Tunneled peer rejected "
                "EmptyThisBuffer call, return code = 0x%08x", eRetVal );

            /**---------------------------------------------------------------
               Since we released the lock, we need special processing for this
               failure.
            ----------------------------------------------------------------*/
            qomx_PortCommon_BufferRejected( pPortCtnr, pPortCtx, pBufferHdr );

         }

         /**------------------------------------------------------------------
            Return CS released error to the API handler. API handler must
            not attempt to unlock context again.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ERROR_CS_RELEASED;
      }
   }
   else
   {
      OMX_ERRORTYPE  eReportError;
      /*--------------------------------------------------------------------*/

      QOMX_MSG_L_HIGH( pCommonRef,
         "Error status %d in FillThisBuffer resp.", nEventStatus );

      /**---------------------------------------------------------------
         Get OMX error.
      ----------------------------------------------------------------*/
      eReportError = qomx_GetOMXErrorCode( nEventStatus );

      /**---------------------------------------------------------------------
         Report this error to client. Move component to Invalid state
         if a fatal error.
      ----------------------------------------------------------------------*/
      if( OMX_ErrorInvalidState != eReportError )
      {
         /**------------------------------------------------------------------
            Notify error.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntNotifyError( pCommonRef, eReportError );

      }
      else
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Fatal error." );

         ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                 qomx_GetQOMXBaseEventCode( nEventStatus ) );

      }

      /**---------------------------------------------------------------------
         Return buffer now.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_LOW( pCommonRef, "Send fill buffer done." );

      eRetVal = qomx_CmpntFillBufferDone( pCommonRef, pBufferHdr );
   }

   /**------------------------------------------------------------------------
      Process buffer header.
   -------------------------------------------------------------------------*/
   if( MMI_S_EBUFFERNOTPROCESSED != nEventStatus )
   {
      ( void ) qomx_PortCommon_ProcessBufferHeader( pPortCtnr, pPortCtx,
                                    &(sBufHdrTmp), MMI_RESP_FILL_THIS_BUFFER );

   }

   if ( OMX_ERROR_CS_RELEASED == eRetVal )
   {
      OMX_U32 bufWithClient = (pPortCtx->nBuffersWithClient + pPortCtx->portDef.nBufferCountActual);
      QOMX_STATS_MSG( pPortCtnr->pCommonRef, QOMX_MSG_PRIORITY_LOW,
         "FBD buffers with device = %d, buffers with client = %d, TimeStamp = %lld",
         pPortCtx->nBuffersWithDevice, bufWithClient, pBufferHdr->nTimeStamp );
   }
   return( eRetVal );

} /* end of function qomx_PortCommon_FillThisBufferResp */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_FillThisBufferRespStopping

         DESCRIPTION:
*//**                   This function processes fill buffer done response
                        from the device when the port is stopping.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Pointer to the buffer header.
            @param [in] nEventStatus- Status of the event.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_FillThisBufferRespStopping
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr,
   OMX_IN   OMX_U32                 nEventStatus
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_LOW( pCommonRef,
      "qomx_PortCommon_FillThisBufferRespStopping, nPortIndex = 0x%x",
      pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Decrement used buffer count. Increment client buffer count.
   -------------------------------------------------------------------------*/
   pPortCtx->nBuffersWithDevice--;
   pPortCtx->nBuffersWithClient++;

   if( MMI_S_COMPLETE == nEventStatus )
   {
      /**---------------------------------------------------------------------
         Process buffer header.
      ----------------------------------------------------------------------*/
      ( void ) qomx_PortCommon_ProcessBufferHeader( pPortCtnr, pPortCtx,
                                    pBufferHdr, MMI_RESP_FILL_THIS_BUFFER );

      /**---------------------------------------------------------------------
         Send fill buffer done notification when non-tunneling.
      ----------------------------------------------------------------------*/
      if( NULL == pPortCtx->hTunneledComp )
      {
         QOMX_MSG_L_LOW( pCommonRef, "Send FillBufferDone notification"
            " nPortIndex = 0x%x, pBufferHdr = 0x%p",
            pPortCtx->portDef.nPortIndex, pBufferHdr );

         eRetVal = qomx_CmpntFillBufferDone( pCommonRef, pBufferHdr );

         /**------------------------------------------------------------------
            Check if we can move to next state.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_CheckStop( pPortCtnr, pPortCtx );

      }
      else
      {
         /**------------------------------------------------------------------
            Tunneling. Return this buffer only if port is non-supplier.
         -------------------------------------------------------------------*/
         if( QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx )  )
         {
            QOMX_MSG_L_LOW( pCommonRef,
               "Port is supplier, hold the buffer." );

            /**---------------------------------------------------------------
               Supplier, hold buffer, decrement buffer client, check for stop
               condition.
            ----------------------------------------------------------------*/
            pPortCtx->nBuffersWithClient--;

            ( void ) qomx_PortCommon_CheckStop( pPortCtnr, pPortCtx );

         }
         else
         {
            QOMX_MSG_L_LOW( pCommonRef,
               "Non-supplier. Return buffer to tunneled component." );

            pBufferHdr->nInputPortIndex = pPortCtx->nTunneledPort;

            /**---------------------------------------------------------------
               Need to check stop condition before releasing the lock.
            ----------------------------------------------------------------*/
            ( void ) qomx_PortCommon_CheckStop( pPortCtnr, pPortCtx );

            /**---------------------------------------------------------------
               Release LOCK. This critical section was acquired when event
               handler qomx_DeviceEventHandler is called from MMI.
            ----------------------------------------------------------------*/
            ( void ) qomx_CmpntUnlockContext( pCommonRef->hCmpnt );


            /**---------------------------------------------------------------
               Tunneled component, send OMX_EmptyThisBuffer.
            ----------------------------------------------------------------*/
            eRetVal = OMX_EmptyThisBuffer(
                                 pPortCtx->hTunneledComp, pBufferHdr );

            if( OMX_ErrorNone != eRetVal )
            {
               QOMX_MSG_L_ERROR( pCommonRef, "Tunneled Peer rejected"
                  " EmptyThisBuffer nPortIndex = 0x%x, pBufferHdr = 0x%p",
                  pPortCtx->portDef.nPortIndex,  pBufferHdr );

               /**------------------------------------------------------------
                  Decrement buffer client.
               -------------------------------------------------------------*/
               pPortCtx->nBuffersWithClient--;

            }

            /**---------------------------------------------------------------
               Return CS released error to the API handler. API handler must
               not attempt to unlock context again.
            ----------------------------------------------------------------*/
            eRetVal = OMX_ERROR_CS_RELEASED;
         }

      }

   }
   else
   {
      OMX_ERRORTYPE  eReportError;
      /*--------------------------------------------------------------------*/

      QOMX_MSG_L_ERROR( pCommonRef, "FillThisBuffer error response,"
         " nPortIndex = 0x%x, pBufferHdr = 0x%p",
         pPortCtx->portDef.nPortIndex,  pBufferHdr );

      /**---------------------------------------------------------------
         Get OMX error.
      ----------------------------------------------------------------*/
      eReportError = qomx_GetOMXErrorCode( nEventStatus );

      /**---------------------------------------------------------------------
         Report this error to client. Move component to Invalid state
         if a fatal error.
      ----------------------------------------------------------------------*/
      if( OMX_ErrorInvalidState != eReportError )
      {
         QOMX_MSG_L_MED( pCommonRef,
            "Send eReportError = 0x%x notification, nPortIndex = 0x%x",
            pPortCtx->portDef.nPortIndex, ( OMX_U32 ) eReportError );

         /**------------------------------------------------------------------
            Notify error.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntNotifyError( pCommonRef, eReportError );

        /**------------------------------------------------------------------
            Check if we can move to next state.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_CheckStop( pPortCtnr, pPortCtx );
      }
      else
      {
         QOMX_MSG_L_ERROR( pCommonRef,
            "Fatal error, Move to Invalid state, nPortIndex = 0x%x",
            pPortCtx->portDef.nPortIndex );

         ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                              qomx_GetQOMXBaseEventCode( nEventStatus ) );

      }

      /**---------------------------------------------------------------------
         Return buffer now.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_LOW( pCommonRef, "Send FillBufferDone notification"
         " nPortIndex = 0x%x, pBufferHdr = 0x%p",
         pPortCtx->portDef.nPortIndex,  pBufferHdr );

      eRetVal = qomx_CmpntFillBufferDone( pCommonRef, pBufferHdr );

   }

   if ( OMX_ERROR_CS_RELEASED == eRetVal )
   {
      OMX_U32 bufWithClient = (pPortCtx->nBuffersWithClient + pPortCtx->portDef.nBufferCountActual);
      QOMX_STATS_MSG( pPortCtnr->pCommonRef, QOMX_MSG_PRIORITY_LOW,
         "FBD buffers with device = %d, buffers with client = %d, TimeStamp = %lld",
         pPortCtx->nBuffersWithDevice, bufWithClient, pBufferHdr->nTimeStamp );
   }
   return( eRetVal );

} /* end of function qomx_PortCommon_FillThisBufferRespStopping */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_StartTunneledDataFlow

         DESCRIPTION:
                        This function will start data flowing for tunneled
                        ports.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_StartTunneledDataFlow
(
   OMX_IN QOMX_PortContainerType *pPortCtnr,
   OMX_IN QOMX_PortContextType   *pPortCtx
)
{
   OMX_ERRORTYPE        eRetVal       = OMX_ErrorNone;
   QMM_ListHandleType  *pHBufHdrQueue = & ( pPortCtx->hBufHdrQueue );
   OMX_U32              i;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pCommonRef,
      "qomx_PortCommon_StartTunneledDataFlow, nPortIndex = 0x%x",
      pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      For non-vendor tunneling, start data flow by calling fill buffer if
      port is the buffer supplier.
   -------------------------------------------------------------------------*/

   for( i = 0; ( ( i < pPortCtx->portDef.nBufferCountActual )
               && ( OMX_ErrorNone == eRetVal ) ); i++ )
   {
      QMM_ListLinkType       *pQueueLink = NULL;
      QOMX_PortBufferHdrLink *pBufHdrLink;
      /*-----------------------------------------------------------------*/

      ( void ) qmm_ListPopFront( pHBufHdrQueue, & pQueueLink );

      pBufHdrLink = ( QOMX_PortBufferHdrLink * ) pQueueLink;

      ( void ) qmm_ListPushRear( pHBufHdrQueue, pQueueLink );

      if( NULL != pBufHdrLink )
      {
         pPortCtx->nBuffersWithClient++;

         if( OMX_DirInput == pPortCtx->portDef.eDir )
         {
            QOMX_MSG_L_HIGH( pCommonRef,
               "Calling FillThisBuffer on tunneled port." );

            /**------------------------------------------------------------
               For input ports, send fill this buffer request to the
               tunneled port.
            -------------------------------------------------------------*/
            eRetVal = OMX_FillThisBuffer( pPortCtx->hTunneledComp,
                                    pBufHdrLink->pBufferHdr );

         }
         else
         {
            QOMX_MSG_L_HIGH( pCommonRef,
               "Calling FillThisBuffer on self." );

            /**------------------------------------------------------------
               For output ports, send fill this buffer request to self.
            -------------------------------------------------------------*/
            eRetVal = qomx_PortFillThisBuffer( pPortCtnr,
                                    pBufHdrLink->pBufferHdr );

         }

      }

   }

   /**------------------------------------------------------------------------
      In case of failure, there is no choice but move to invalid.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone != eRetVal )
   {
      QOMX_MSG_L_ERROR( pCommonRef,
         "Error while starting tunnel data flow: %x.", eRetVal );

      ( void ) qomx_CmpntStateSetInvalid( pPortCtnr->pCommonRef->hCmpnt,
                                          QOMX_EVENT_UNKNOWN );
   }

   return( eRetVal );

} /* end of function qomx_PortCommon_StartTunneledDataFlow */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_SetupVendorTunnel

         DESCRIPTION:
                  This function attempts to set vendor tunnel between
                  the given port and the peer port of the tunneled
                  component.

                  a) Check whether both of the devices support vendor
                  tunneling.
                  b) Get the vendor tunneling device API table and
                  device handle of each device.
                  c) Exchange the vendor tunneling device API table
                  and device handle.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCommonRef     - Pointer to common reference object.
            @param[in]  pPortCtx       - Pointer to port context object.
            @param[in]  hTunneledComp  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nTunneledPort  - Refer OMX_Core.h / OMX IL spec.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_SetupVendorTunnel
(
 OMX_IN      QOMX_CommonRefType        *pCommonRef,
 OMX_IN      QOMX_PortContextType      *pPortCtx,
 OMX_IN      OMX_HANDLETYPE             hTunneledComp,
 OMX_IN      OMX_U32                    nTunneledPort
 )
{
   OMX_ERRORTYPE                    eRetVal = OMX_ErrorNone;
   OMX_U32                          nStatus = MMI_S_EFAIL;
   OMX_BOOL                         bDeviceVTMode = OMX_FALSE;
   OMX_BOOL                         bTunneledDeviceVTMode = OMX_FALSE;

   MMI_ParamVendorTunnelDeviceType  tunneledDevice;
   MMI_ParamVendorTunnelSetupType   tunneledSetup;
   MMI_DeviceType                   tunneledDeviceApi;

   MMI_ParamVendorTunnelDeviceType  localDevice;
   MMI_ParamVendorTunnelSetupType   localSetup;
   MMI_DeviceType                   localDeviceApi;

   MMI_OmxParamCmdType              stdCmd;
   OMX_INDEXTYPE                    eIndex;
   OMX_INDEXTYPE                    eTunneledIndex;
   QOMX_CmpntCtxType               *pTunneledCmpntCtx;
   QOMX_PortContextType            *pTunneledPortCtx = NULL;
   /*-----------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Check to see if the component supports vendor tunneling.
   -------------------------------------------------------------------------*/
   eRetVal = OMX_GetExtensionIndex( pCommonRef->hCmpnt,
                     QOMX_PARAM_NAME_VENDOR_TUNNEL_DEVICE, & eIndex );

   if( OMX_ErrorNone == eRetVal )
   {
      /**--------------------------------------------------------------------
        Check to see if the tunnelled component supports vendor tunneling.
      ---------------------------------------------------------------------*/
      eRetVal = OMX_GetExtensionIndex( hTunneledComp,
               QOMX_PARAM_NAME_VENDOR_TUNNEL_DEVICE, & eTunneledIndex );

   }

    /**-----------------------------------------------------------------------
       Get device table and handle
    ------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Get device information." );

      QOMX_CMPNT_MEM_SET( & localDevice, 0,
               sizeof( MMI_ParamVendorTunnelDeviceType ) );
      QOMX_CMPNT_MEM_SET( & localDeviceApi, 0, sizeof( MMI_DeviceType ) );

      localDevice.nPortIndex = pPortCtx->portDef.nPortIndex;
      localDevice.pDeviceApi = & localDeviceApi;

      stdCmd.nParamIndex  = eIndex;
      stdCmd.pParamStruct = & localDevice;

       /**--------------------------------------------------------------------
          Send command to device.
       ---------------------------------------------------------------------*/
       nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                     MMI_CMD_GET_STD_OMX_PARAM, & stdCmd );

       QOMX_MSG_L_HIGH( pCommonRef,
          "Vendor tunnel get device info command status = 0x%x.",
          nStatus );

   }

   /**------------------------------------------------------------------------
      Get device table and handle of the tunneled component
   -------------------------------------------------------------------------*/
   if( MMI_S_COMPLETE == nStatus )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Get tunneled device infomation." );

      QOMX_CMPNT_MEM_SET( & tunneledDevice, 0,
            sizeof( MMI_ParamVendorTunnelDeviceType ) );
      QOMX_CMPNT_MEM_SET( & tunneledDeviceApi, 0, sizeof( MMI_DeviceType ) );

      tunneledDevice.nPortIndex = nTunneledPort;
      tunneledDevice.pDeviceApi = & tunneledDeviceApi;

      eRetVal = OMX_GetParameter( hTunneledComp,
                       eTunneledIndex, ( OMX_PTR )( & tunneledDevice ) );

   }
   else
   {
      eRetVal = qomx_GetOMXErrorCode( nStatus );

   }

   /**------------------------------------------------------------------------
      Get the vendor tunnel setup index
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      eRetVal = OMX_GetExtensionIndex( pCommonRef->hCmpnt,
                     QOMX_PARAM_NAME_VENDOR_TUNNEL_SETUP, & eIndex );

   }

   /**------------------------------------------------------------------------
      Pass the device information of the tunneled component to MMI
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
       QOMX_MSG_L_HIGH( pCommonRef,
          "Attempt to setup vendor tunneling for local device." );

       /**--------------------------------------------------------------------
          Attempt to setup vendor tunneling.
       ---------------------------------------------------------------------*/
      localSetup.hCmpnt = pCommonRef->hCmpnt;
      localSetup.nPortIndex = pPortCtx->portDef.nPortIndex;
      localSetup.nTunneledPortIndex = nTunneledPort;
      localSetup.pDeviceApi = tunneledDevice.pDeviceApi;
      localSetup.hDevice = tunneledDevice.hDevice;

      stdCmd.nParamIndex = eIndex;
      stdCmd.pParamStruct = &localSetup;

       /**--------------------------------------------------------------------
          Send command to device.
       ---------------------------------------------------------------------*/
       nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                      MMI_CMD_SET_STD_OMX_PARAM, & stdCmd );

       QOMX_MSG_L_HIGH( pCommonRef,
          "Vendor tunnel setup command status = 0x%x.", nStatus );

   }

   /**------------------------------------------------------------------------
      Get the vendor tunnel setup index of the tunneled component.
   -------------------------------------------------------------------------*/
   if( MMI_S_COMPLETE == nStatus )
   {
      bDeviceVTMode = OMX_TRUE;

      eRetVal = OMX_GetExtensionIndex( hTunneledComp,
                  QOMX_PARAM_NAME_VENDOR_TUNNEL_SETUP, & eTunneledIndex );

   }
   else
   {
      eRetVal = qomx_GetOMXErrorCode( nStatus );

   }

   /**------------------------------------------------------------------------
      Pass the device information to the MMI of the tunneled component.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_MSG_L_HIGH( pCommonRef,
          "Attempt to setup vendor tunneling for tunneled device." );

      /**---------------------------------------------------------------------
         Attempt to setup vendor tunneling.
      ----------------------------------------------------------------------*/
      tunneledSetup.hCmpnt = hTunneledComp;
      tunneledSetup.nPortIndex = nTunneledPort;
      tunneledSetup.nTunneledPortIndex = pPortCtx->portDef.nPortIndex;
      tunneledSetup.pDeviceApi = localDevice.pDeviceApi;
      tunneledSetup.hDevice = localDevice.hDevice;

      eRetVal = OMX_SetParameter( hTunneledComp,
                        eTunneledIndex, &tunneledSetup );

   }

   /**------------------------------------------------------------------------
      Set the tunneling type.
   -------------------------------------------------------------------------*/
   if ( OMX_ErrorNone == eRetVal )
   {
      QOMX_PortContainerType *pPortCtnr;
      /*--------------------------------------------------------------------*/

      bTunneledDeviceVTMode = OMX_TRUE;

      // TODO zma: setting eTunneling mode for the vendor tunneled peer
      // component will be moved to SetParameter call once we move the
      // definition of the vendor tunnel setup extension index from MMI to
      // base class.

      pTunneledCmpntCtx = ( QOMX_CmpntCtxType * )
            ( ( OMX_COMPONENTTYPE * ) hTunneledComp )->pComponentPrivate;

      pPortCtnr = ( QOMX_PortContainerType * ) pTunneledCmpntCtx->hPortCtnr;

      eRetVal = qomx_PortGetContext( pPortCtnr, nTunneledPort,
                        & pTunneledPortCtx );

   }

   if( OMX_ErrorNone == eRetVal )
   {
      if ( pTunneledPortCtx )
      {
         pTunneledPortCtx->eTunneling = PORT_TUNNELING_VENDOR;
      }
      pPortCtx->eTunneling = PORT_TUNNELING_VENDOR;

      QOMX_MSG_L_HIGH( pCommonRef,
          "Vendor tunnel setup succeeded for devices." );

   }
   else
   {
      OMX_ERRORTYPE  eCancelRetVal = OMX_ErrorNone;
      /*--------------------------------------------------------------------*/

      QOMX_MSG_L_HIGH( pCommonRef,
          "Vendor tunnel setup failed for devices." );

      if( OMX_TRUE == bDeviceVTMode )
      {
         /**------------------------------------------------------------------
            Cancel vendor tunnel mode for the port.
         -------------------------------------------------------------------*/
         eCancelRetVal = qomx_CancelDeviceVendorTunnelMode(
                                             pCommonRef, pPortCtx );

         if( OMX_ErrorNone != eCancelRetVal )
         {
            QOMX_MSG_L_ERROR( pCommonRef, "Cancel vendor tunnel mode failed,"
                  " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         }

      }

      if( OMX_TRUE == bTunneledDeviceVTMode )
      {
         /**------------------------------------------------------------------
            Cancel vendor tunnel mode for the tunneled port.
         -------------------------------------------------------------------*/
         tunneledSetup.hCmpnt = NULL;
         tunneledSetup.nPortIndex = nTunneledPort;
         tunneledSetup.nTunneledPortIndex = 0;
         tunneledSetup.pDeviceApi = NULL;
         tunneledSetup.hDevice = NULL;

         eCancelRetVal = OMX_SetParameter( hTunneledComp,
                                       eTunneledIndex, &tunneledSetup );

         if( OMX_ErrorNone != eCancelRetVal )
         {
            QOMX_MSG_L_ERROR( pCommonRef, "Cancel vendor tunnel mode failed "
                  "on tunneled device, nPortIndex = 0x%x", nTunneledPort );

         }

      }

   }


   return eRetVal;

} /* end of function qomx_PortCommon_SetupVendorTunnel */

/*==========================================================================

         FUNCTION:      qomx_CancelDeviceVendorTunnelMode

         DESCRIPTION:
                  This function attempts to inform device to cancel vendor
                  tunnel mode of the given port.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCommonRef     - Pointer to common reference object.
            @param[in]  pPortCtx       - Pointer to port context object.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_CancelDeviceVendorTunnelMode
(
 OMX_IN      QOMX_CommonRefType        *pCommonRef,
 OMX_IN      QOMX_PortContextType      *pPortCtx
)
{
   OMX_ERRORTYPE                    eRetVal = OMX_ErrorNone;
   OMX_U32                          nStatus = MMI_S_EFAIL;

   MMI_ParamVendorTunnelSetupType   VTSetupParam = {0};
   MMI_OmxParamCmdType              stdCmd;
   OMX_INDEXTYPE                    eIndex;
   /*-----------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Get the vendor tunnel setup index
   -------------------------------------------------------------------------*/
   eRetVal = OMX_GetExtensionIndex( pCommonRef->hCmpnt,
                     QOMX_PARAM_NAME_VENDOR_TUNNEL_SETUP, & eIndex );

   /**------------------------------------------------------------------------
      Instruct MMI to cancel the vendor tunneled mode for the port.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_MSG_L_HIGH( pCommonRef,
          "Attempt to cancel vendor tunneling for device. nPortIndex = 0x%x.",
          pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Attempt to cancel vendor tunneling mode for device.
      ----------------------------------------------------------------------*/
      VTSetupParam.hCmpnt = NULL;
      VTSetupParam.nPortIndex = pPortCtx->portDef.nPortIndex;
      VTSetupParam.nTunneledPortIndex = 0;
      VTSetupParam.pDeviceApi = NULL;
      VTSetupParam.hDevice = NULL;

      stdCmd.nParamIndex = eIndex;
      stdCmd.pParamStruct = &VTSetupParam;

      /**---------------------------------------------------------------------
         Send command to device.
      ----------------------------------------------------------------------*/
      nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                      MMI_CMD_SET_STD_OMX_PARAM, & stdCmd );

      QOMX_MSG_L_HIGH( pCommonRef,
          "Vendor tunnel cancel command status = 0x%x. nPortIndex = 0x%x",
          nStatus, pPortCtx->portDef.nPortIndex );

      if( MMI_S_COMPLETE != nStatus )
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Vendor tunnel cancel command failed,"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            SetStdParam to cancel VT was failed by device.
            Return appropriate error.
         -------------------------------------------------------------------*/
         eRetVal = qomx_GetOMXErrorCode( nStatus );

      }

   }

   return eRetVal;

} /* end of function qomx_PortCommon_CancelVendorTunnel */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_TunnelRequest

         DESCRIPTION:
                        Refer to OMX_ComponentTunnelRequest in OMX_Core.h
                        or the OMX IL specification for details on the
                        ComponentTunnelRequest method.

                  1. Check port compatibility.

                        2. For an output port:
                     1) Set buffer supplier preferences.
                           2) If tunneled port is a QOMX port, Set race
                        condition flags.

                           For an input port:
                           1) If tunneled port is a QOMX port, attempt to
                        setup vendor tunneling.
                     2) Negotiate buffer requirements if it is normal
                        tunneling.
                     3) Read buffer preferences set by the output port.
                     4) If tunneled port is a QOMX port, Set race
                        condition flags.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr      - Pointer to the port container.
            @param[in]  nPort          - Refer OMX_Core.h / OMX IL spec.
            @param[in]  hTunneledComp  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nTunneledPort  - Refer OMX_Core.h / OMX IL spec.
            @param[out] pTunnelSetup   - Refer OMX_Core.h / OMX IL spec.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_TunnelRequest
(
 OMX_IN      QOMX_PortContainerType    *pPortCtnr,
 OMX_IN      QOMX_PortContextType      *pPortCtx,
 OMX_IN      OMX_HANDLETYPE             hTunneledComp,
 OMX_IN      OMX_U32                    nTunneledPort,
 OMX_INOUT   OMX_TUNNELSETUPTYPE       *pTunnelSetup
 )
{
   OMX_ERRORTYPE                 eRetVal    = OMX_ErrorNone;
   OMX_U32                       nStatus    = MMI_S_EFAIL;
   QOMX_CommonRefType           *pCommonRef = pPortCtnr->pCommonRef;
   OMX_PARAM_PORTDEFINITIONTYPE  portDef    = {0};
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pCommonRef,
      "qomx_PortCommon_TunnelRequest, nPortIndex = 0x%x",
      pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Check tunneled component.
   -------------------------------------------------------------------------*/
   if( 0 != hTunneledComp )
   {
      /**------------------------------------------------------------------
         Get tunneled component port definition.
      -------------------------------------------------------------------*/
      QOMX_SET_STRUCT_OBJ( portDef, OMX_PARAM_PORTDEFINITIONTYPE );
      portDef.nPortIndex = nTunneledPort;
      eRetVal = OMX_GetParameter( hTunneledComp,
         OMX_IndexParamPortDefinition, & portDef );

      /**---------------------------------------------------------------
         Check port compatability.
      ----------------------------------------------------------------*/
      if( OMX_ErrorNone == eRetVal )
      {
         if( portDef.eDomain != pPortCtx->portDef.eDomain )
         {
            eRetVal = OMX_ErrorPortsNotCompatible;
         }
      }

      if( OMX_ErrorNone == eRetVal )
      {
         switch( portDef.eDomain )
         {
         case OMX_PortDomainAudio:
            if( portDef.format.audio.eEncoding == OMX_AUDIO_CodingMax )
            {
               eRetVal = OMX_ErrorPortsNotCompatible;
            }
            else if( portDef.format.audio.eEncoding != OMX_AUDIO_CodingAutoDetect &&
                     pPortCtx->portDef.format.audio.eEncoding != OMX_AUDIO_CodingAutoDetect &&
                     portDef.format.audio.eEncoding !=
                     pPortCtx->portDef.format.audio.eEncoding )
            {
               eRetVal = OMX_ErrorPortsNotCompatible;
            }
            break;
         case OMX_PortDomainVideo:
            if( portDef.format.video.eCompressionFormat == OMX_VIDEO_CodingMax )
            {
               eRetVal = OMX_ErrorPortsNotCompatible;
            }
            else if( portDef.format.video.eCompressionFormat != OMX_VIDEO_CodingAutoDetect &&
                     pPortCtx->portDef.format.video.eCompressionFormat != OMX_VIDEO_CodingAutoDetect &&
                     portDef.format.video.eCompressionFormat !=
                     pPortCtx->portDef.format.video.eCompressionFormat )
            {
               eRetVal = OMX_ErrorPortsNotCompatible;
            }
            break;
         case OMX_PortDomainImage:
            if( portDef.format.image.eCompressionFormat == OMX_IMAGE_CodingMax )
            {
               eRetVal = OMX_ErrorPortsNotCompatible;
            }
            else if( portDef.format.image.eCompressionFormat != OMX_IMAGE_CodingAutoDetect &&
                     pPortCtx->portDef.format.image.eCompressionFormat != OMX_IMAGE_CodingAutoDetect &&
                     portDef.format.image.eCompressionFormat !=
                     pPortCtx->portDef.format.image.eCompressionFormat )
            {
               eRetVal = OMX_ErrorPortsNotCompatible;
            }
            break;
         case OMX_PortDomainOther:
            if( portDef.format.other.eFormat != pPortCtx->portDef.format.other.eFormat )
            {
               eRetVal = OMX_ErrorPortsNotCompatible;
            }
            break;
         default:
            eRetVal = OMX_ErrorPortsNotCompatible;
            break;
         }
      }

      if( OMX_ErrorNone != eRetVal )
      {
         /**---------------------------------------------------------------
            Ports not compatable, return error now.
         ----------------------------------------------------------------*/
         return eRetVal;
      }

      /**---------------------------------------------------------------------
         Check port direction.
      ----------------------------------------------------------------------*/
      if( OMX_DirOutput == pPortCtx->portDef.eDir )
      {
         OMX_INDEXTYPE                 eIndex;
         OMX_ERRORTYPE                 eRetValGetExt;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_HIGH( pCommonRef, "This is an output port." );

         /**------------------------------------------------------------------
            Set normal tunneling flag.
         -------------------------------------------------------------------*/
         pPortCtx->eTunneling = PORT_TUNNELING_NORMAL;

         /**------------------------------------------------------------------
            Initialize the buffer supplier preference to Unspecified.
         -------------------------------------------------------------------*/
         pTunnelSetup->eSupplier = OMX_BufferSupplyUnspecified;

         /**------------------------------------------------------------------
            Poll output device for its buffer supplier preference.
         -------------------------------------------------------------------*/
         eRetVal = qomx_GetDeviceBufSupplierPref( pCommonRef,
            pPortCtx->portDef.nPortIndex, & pTunnelSetup->eSupplier );

         if( OMX_ErrorNone == eRetVal )
         {
            /**---------------------------------------------------------------
               Poll the other port to see if it is QOMX also. If so, change
               the race condition signaling flags accordingly since STE
               solution will be used for handshaking.
            ----------------------------------------------------------------*/
            eRetValGetExt = OMX_GetExtensionIndex( hTunneledComp,
                                 QOMX_PARAM_NAME_QUALCOMM_TUNNEL, & eIndex);

            if( OMX_ErrorNone == eRetValGetExt &&
               QOMX_PARAM_INDEX_QUALCOMM_TUNNEL == eIndex )
            {
               pPortCtx->bTunnelPeerIsQOMX                = OMX_TRUE;
               pPortCtx->bTunnelPeerAcceptsUseBuffer      = OMX_FALSE;
               pPortCtx->bTunnelPeerAcceptsBufferExchange = OMX_FALSE;
               pPortCtx->bTunnelPeerAcceptsFreeBuffer     = OMX_FALSE;
               pPortCtx->bVendorTunnelPeerLoadedToIdle    = OMX_FALSE;
               pPortCtx->bVendorTunnelPeerPortEnable      = OMX_FALSE;
            }

            /**---------------------------------------------------------------
               TODO - Do we have a "read-only buffer" concept in QOMX?
            ----------------------------------------------------------------*/
            pTunnelSetup->nTunnelFlags = 0;

         }

      }
      else
      {
         OMX_INDEXTYPE  eIndex;
         OMX_ERRORTYPE  eRetValGetExt;
         OMX_BOOL       bQOMXTunneledPort = OMX_FALSE;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_HIGH( pCommonRef, "This is an input port." );

         /**------------------------------------------------------------------
            Poll the other port to see if it is QOMX also.
         -------------------------------------------------------------------*/
         eRetValGetExt = OMX_GetExtensionIndex( hTunneledComp,
                                 QOMX_PARAM_NAME_QUALCOMM_TUNNEL, & eIndex);

         if( OMX_ErrorNone == eRetValGetExt &&
             QOMX_PARAM_INDEX_QUALCOMM_TUNNEL == eIndex )
         {
            bQOMXTunneledPort = OMX_TRUE;

            /**---------------------------------------------------------------
               Attempt to setup vendor tunnel
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortCommon_SetupVendorTunnel( pCommonRef, pPortCtx,
                  hTunneledComp, nTunneledPort );

         }

         if( OMX_ErrorNone != eRetVal )
         {
            /**------------------------------------------------------
               Failed to setup vendor tunneling.
            -------------------------------------------------------*/
            pPortCtx->eTunneling = PORT_TUNNELING_DISABLED;

         }

         /**------------------------------------------------------------------
         Reset the error code.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorNone;

         /**------------------------------------------------------------------
            Set tunneling type
         -------------------------------------------------------------------*/
         if( PORT_TUNNELING_DISABLED == pPortCtx->eTunneling )
         {
            /**---------------------------------------------------------------
               Check to see if the tunneled component is a clock.
            ----------------------------------------------------------------*/
            OMX_BOOL isClockComponent  = OMX_FALSE;
            if (eRetVal == OMX_ErrorNone)
            {
               isClockComponent =
                  (OMX_BOOL) ((portDef.eDomain == OMX_PortDomainOther) &&
                  (portDef.format.other.eFormat == OMX_OTHER_FormatTime));
            }
            if (isClockComponent)
            {
               /**------------------------------------------------------------
                  Give the MMI device the clock component information.
               -------------------------------------------------------------*/
               MMI_CustomParamCmdType      customCmd;
               MMI_ParamClockComponentType clockParam;
               clockParam.nPortIndex   = pPortCtx->portDef.nPortIndex;
               clockParam.hClock       = hTunneledComp;
               clockParam.nClockPort   = nTunneledPort;
               customCmd.nParamIndex   = MMI_IndexClockComponent;
               customCmd.pParamStruct  = &clockParam;
               nStatus = pCommonRef->device.pfnCmd(pCommonRef->hFd,
                  MMI_CMD_SET_CUSTOM_PARAM, &customCmd);

               if( MMI_S_COMPLETE != nStatus )
               {
                  QOMX_MSG_L_ERROR( pCommonRef,
                     "Set custom param failed for clock component." );
               }

               pPortCtx->eTunneling    = PORT_TUNNELING_CLOCK;
            }
            else
            {
               pPortCtx->eTunneling = PORT_TUNNELING_NORMAL;
            }
         }

         /**------------------------------------------------------------------
            Negotiate buffer count with peer.
         -------------------------------------------------------------------*/
         if ( PORT_TUNNELING_VENDOR != pPortCtx->eTunneling )
         {
            eRetVal = qomx_PortCommon_TunnelNegotiateBuffers( pPortCtnr,
                                                           pPortCtx,
                                                          hTunneledComp,
                                                         nTunneledPort);
         }

         if( OMX_ErrorNone != eRetVal )
         {
            QOMX_MSG_L_ERROR( pCommonRef, "Buffer negotiation failed." );

         }
         else
         {
            /**----------------------------------------------------------------
               Negotiate buffer supplier preference with peer.
            -----------------------------------------------------------------*/
            eRetVal = qomx_TunnelNegotiateBufferSupplier(
                                          pCommonRef, pPortCtx, hTunneledComp,
                                          nTunneledPort, pTunnelSetup );

         }

         if( OMX_ErrorNone == eRetVal )
         {
            /**---------------------------------------------------------------
               If the other port is also QOMX, change the race condition
               signaling flags accordingly since STE solution will be used
               for handshaking.
            ----------------------------------------------------------------*/
            if( bQOMXTunneledPort )
            {
               pPortCtx->bTunnelPeerIsQOMX                = OMX_TRUE;
               pPortCtx->bTunnelPeerAcceptsUseBuffer      = OMX_FALSE;
               pPortCtx->bTunnelPeerAcceptsBufferExchange = OMX_FALSE;
               pPortCtx->bTunnelPeerAcceptsFreeBuffer     = OMX_FALSE;
               pPortCtx->bVendorTunnelPeerLoadedToIdle    = OMX_FALSE;
               pPortCtx->bVendorTunnelPeerPortEnable      = OMX_FALSE;
            }

            /**---------------------------------------------------------------
               TODO - Do we have a "read-only buffer" concept in QOMX?
            ----------------------------------------------------------------*/
            // pTunnelSetup->nTunnelFlags;

         }

      }

      if( OMX_ErrorNone == eRetVal )
      {
         /**------------------------------------------------------------------
            Set hTunneledComp and nTunneledPort variables for this port.
         -------------------------------------------------------------------*/
         pPortCtx->hTunneledComp = hTunneledComp;
         pPortCtx->nTunneledPort = nTunneledPort;

      }

   }
   else
   {
      /**---------------------------------------------------------------------
         Tunneling is being disabled.
      ----------------------------------------------------------------------*/
      if( PORT_TUNNELING_CLOCK == pPortCtx->eTunneling )
      {
         /**------------------------------------------------------------------
            Set the MMI device clock component parameter to NULL.
         -------------------------------------------------------------------*/
         MMI_CustomParamCmdType      customCmd;
         MMI_ParamClockComponentType clockParam;
         clockParam.nPortIndex   = pPortCtx->portDef.nPortIndex;
         clockParam.hClock       = hTunneledComp;
         clockParam.nClockPort   = nTunneledPort;
         customCmd.nParamIndex   = MMI_IndexClockComponent;
         customCmd.pParamStruct  = &clockParam;
         nStatus = pCommonRef->device.pfnCmd(pCommonRef->hFd,
            MMI_CMD_SET_CUSTOM_PARAM, &customCmd);

         if( MMI_S_COMPLETE != nStatus )
         {
            QOMX_MSG_L_ERROR( pCommonRef,
               "Set custom param failed for clock component." );
         }

      }
      else if( PORT_TUNNELING_VENDOR == pPortCtx->eTunneling )
      {
         eRetVal = qomx_CancelDeviceVendorTunnelMode( pCommonRef, pPortCtx );

      }

      if( OMX_ErrorNone == eRetVal )
      {
         pPortCtx->eTunneling = PORT_TUNNELING_DISABLED;
         pPortCtx->hTunneledComp = NULL;
         pPortCtx->nTunneledPort = 0;

         pPortCtx->bTunnelPeerIsQOMX                = OMX_FALSE;
         pPortCtx->bTunnelPeerAcceptsUseBuffer      = OMX_TRUE;
         pPortCtx->bTunnelPeerAcceptsBufferExchange = OMX_TRUE;
         pPortCtx->bTunnelPeerAcceptsFreeBuffer     = OMX_TRUE;
         pPortCtx->bVendorTunnelPeerLoadedToIdle    = OMX_TRUE;
         pPortCtx->bVendorTunnelPeerPortEnable      = OMX_TRUE;

      }

   }

   return( eRetVal );

} /* end of function qomx_PortCommon_TunnelRequest */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_GetTotalRates

         DESCRIPTION:
                        This function will fill the port throughput object
                        passed to it.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtx          - Pointer to the port context.
            @param[out] pTotalByteRate    - total byte rate.
            @param[out] pTotalPacketRate  - total packet rate.

**//*    RETURN VALUE:
*//**                   None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void qomx_PortCommon_GetTotalRates
(
   OMX_IN   QOMX_PortContextType   *pPortCtx,
   OMX_OUT  OMX_U32                *pTotalByteRate,
   OMX_OUT  double                 *pTotalPacketRate
)
{
   OMX_U64  msTime = 0;
   OMX_U32  avgBufDuration;
   OMX_U32  bitrateDuration;
   /*-----------------------------------------------------------------------*/

   ( void ) qomx_GetTime( & msTime );

   ( *pTotalByteRate )    = 0;
   ( *pTotalPacketRate )  = 0;

   /**------------------------------------------------------------------------
      Calculate the total packet and byte rates.
   -------------------------------------------------------------------------*/
   if( ( pPortCtx->nRatePacketsTotal > 1 )
      && ( msTime > pPortCtx->nRateFirstTS ) )
   {
      /**---------------------------------------------------------------------
         Since buffers contain only the start time, and no duration, in order
         get get an accurate cummulative average bitrate, we must first
         calculate the average duration of a buffer, then add that value to
         nBuffersLastTS. Average buffer duration is calculated by dividing the
         last buffer time by the count of buffers minus one, since we don't
         know the duration of the final buffer, we have to subtract one buffer
         from the calculation.
      ----------------------------------------------------------------------*/
      avgBufDuration
         = ( msTime - pPortCtx->nRateFirstTS )
            / ( pPortCtx->nRatePacketsTotal - 1 );

      bitrateDuration
         = msTime + avgBufDuration - pPortCtx->nRateFirstTS;

      if( bitrateDuration > 0 )
      {
         ( *pTotalByteRate )
            = ( pPortCtx->nRateDataTotal * 1000 ) / bitrateDuration;

         ( *pTotalPacketRate )
            = ( ( double ) pPortCtx->nRatePacketsTotal * 1000.0 )
               / ( double ) bitrateDuration;

      }

   }

} /* end of function qomx_PortCommon_GetTotalRates */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_SupplyTunnelBuffers

         DESCRIPTION:
                        This function will be called for a tunneling supplier
                        port. It will allocate buffers and pass them on to the
                        peer component.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_SupplyTunnelBuffers
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
)
{
   OMX_ERRORTYPE                 eRetVal = OMX_ErrorNone;
   OMX_PARAM_PORTDEFINITIONTYPE  peerPortDef;
   OMX_U32                       nTunnelBufferSize;
   OMX_U32                       i;
   QOMX_CommonRefType           *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pCommonRef,
      "qomx_PortCommon_SupplyTunnelBuffers, nPortIndex = 0x%x",
      pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Obtain port definition of peer port to determine buffer size first.
   -------------------------------------------------------------------------*/
   QOMX_SET_STRUCT_OBJ( peerPortDef, OMX_PARAM_PORTDEFINITIONTYPE );
   peerPortDef.nPortIndex = pPortCtx->nTunneledPort;
   eRetVal = OMX_GetParameter( pPortCtx->hTunneledComp,
                               OMX_IndexParamPortDefinition, & peerPortDef );

   QOMX_MSG_L_HIGH( pCommonRef,
      "Port's buffer size is %d, peer's buffer size is %d.",
      pPortCtx->portDef.nBufferSize, peerPortDef.nBufferSize );

   /**------------------------------------------------------------------------
      Buffer size is a read-only field in port definition. We cannot
      directly set it. Instead, a supplier port should use the maximum of
      buffer sizes specified by ports during buffer allocation.
   -------------------------------------------------------------------------*/
   if( peerPortDef.nBufferSize > pPortCtx->portDef.nBufferSize )
   {
      nTunnelBufferSize = peerPortDef.nBufferSize;

   }
   else
   {
      nTunnelBufferSize = pPortCtx->portDef.nBufferSize;
   }

   /**------------------------------------------------------------------------
      Start allocating now.
   -------------------------------------------------------------------------*/
   for( i = 0; ( ( i < pPortCtx->portDef.nBufferCountActual )
            && ( OMX_ErrorNone == eRetVal ) ); i++ )
   {
      OMX_BUFFERHEADERTYPE  *pBufHdr;
      /*--------------------------------------------------------------------*/

      eRetVal = qomx_PortAllocateBuffer( ( OMX_HANDLETYPE ) pPortCtnr,
                           pPortCtx->portDef.nPortIndex, & pBufHdr,
                           NULL, nTunnelBufferSize );

   }

   /**------------------------------------------------------------------------
      In case of failure, there is no choice but move to invalid.
   -------------------------------------------------------------------------*/
   if (OMX_ErrorNone != eRetVal)
   {
      QOMX_MSG_L_ERROR( pCommonRef,
         "Error while supplying tunnel buffers: %x.", eRetVal );

      ( void ) qomx_CmpntStateSetInvalid( pPortCtnr->pCommonRef->hCmpnt,
                                          QOMX_EVENT_UNKNOWN );
   }

   return( eRetVal );

} /* end of function qomx_PortCommon_SupplyTunnelBuffers */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_FreeTunnelBuffers

         DESCRIPTION:
                        This function will be called for a tunneling supplier
                        port. It will free buffers it allocated and ask peer
                        to free associated headers.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_FreeTunnelBuffers
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
)
{
   OMX_ERRORTYPE        eRetVal        = OMX_ErrorNone;
   QMM_ListHandleType  *pHBufHdrQueue  = &pPortCtx->hBufHdrQueue;
   QMM_ListErrorType    eListRetVal;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pCommonRef,
      "qomx_PortCommon_FreeTunnelBuffers, nPortIndex = 0x%x",
      pPortCtx->portDef.nPortIndex );

   /**---------------------------------------------------------------------
      Traverse through the list while freeing each header.
   ----------------------------------------------------------------------*/
   do
   {
      QMM_ListLinkType    *pQueueLink;
      /*-----------------------------------------------------------------*/

      /**------------------------------------------------------------------
         Peek front element.
      -------------------------------------------------------------------*/
      eListRetVal = qmm_ListPeekFront( pHBufHdrQueue, & pQueueLink );

      if ( QMM_LIST_ERROR_NONE == eListRetVal )
      {
         QOMX_PortBufferHdrLink *pBufHdrLnk
            = (QOMX_PortBufferHdrLink*)pQueueLink;

         OMX_BUFFERHEADERTYPE   *pBufferHdr = pBufHdrLnk->pBufferHdr;
         /*--------------------------------------------------------------*/

         /**---------------------------------------------------------------
            Free buffer now.
         ----------------------------------------------------------------*/
         eRetVal = qomx_PortFreeBuffer( ( OMX_HANDLETYPE ) pPortCtnr,
                              pPortCtx->portDef.nPortIndex, pBufferHdr );

      }

   } while( ( QMM_LIST_ERROR_NONE == eListRetVal )
         && ( eRetVal == OMX_ErrorNone ) );

   /**------------------------------------------------------------------------
      In case of failure, there is no choice but move to invalid.
   -------------------------------------------------------------------------*/
   if (OMX_ErrorNone != eRetVal)
   {
      QOMX_MSG_L_ERROR( pCommonRef,
         "Error while freeing tunnel buffers: %x.", eRetVal );

      ( void ) qomx_CmpntStateSetInvalid( pPortCtnr->pCommonRef->hCmpnt,
                                          QOMX_EVENT_UNKNOWN );
   }

   return( eRetVal );

} /* end of function qomx_PortCommon_FreeTunnelBuffers */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_FreeBufferUnexpected

         DESCRIPTION:
*//**                   This function processes free buffer request when port
                        is in a state in which buffer freeing is not normally
                        expected such as Running or Populated.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.
@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_FreeBufferUnexpected
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN OMX_BUFFERHEADERTYPE           *pBufferHdr
)
{
   OMX_ERRORTYPE        eRetVal;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_ERROR( pCommonRef,
      "qomx_PortCommon_FreeBufferUnexpected, nPortIndex = 0x%x",
      pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Since port lost a buffer unexpectedly, if it is currently populated, a
      PortUnpopulated notification must be sent to the IL client.
   -------------------------------------------------------------------------*/
   if( pPortCtx->portDef.bPopulated )
   {
      QOMX_MSG_L_HIGH( pCommonRef,
         "Sending PortUnpopulated notification." );

      ( void ) qomx_CmpntNotifyEvent( pPortCtnr->pCommonRef,
                  OMX_EventError, ( OMX_U32 ) OMX_ErrorPortUnpopulated,
                  pPortCtx->portDef.nPortIndex, NULL );
   }

   /**------------------------------------------------------------------------
      Free buffer now.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortCommon_FreeBuffer( pPortCtnr, pPortCtx, pBufferHdr );

   /**------------------------------------------------------------------------
      If free buffer successfully completed, Port is no longer populated
      completely. Change the port definition and the state.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      /**---------------------------------------------------------------------
         Transition to EnabledDepopulating state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr, pPortCtx,
                                       QOMX_StatePortEnabledDepopulating, 0 );

   }

   return( eRetVal );

} /* end of function qomx_PortCommon_FreeBufferUnexpected */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_CheckStop

         DESCRIPTION:
*//**                   This function checks the port buffer counters to see
                        if stopping process can be completed. If so,
                        it transitions the port to the next state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortCommon_CheckStop
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /**----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_PortCommon_CheckStop, nPortIndex = 0x%x",
      pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Port is stopping, complete it when buffer count reaches zero.
   -------------------------------------------------------------------------*/
   if( 0 == pPortCtx->nBuffersWithDevice &&
       0 == pPortCtx->nBuffersWithClient )
   {

      QOMX_MSG_L_HIGH( pCommonRef, "Stop condition satisfied." );

      if( QOMX_StatePortEnabledStopping == pPortCtx->eState )
      {
         /**------------------------------------------------------------------
            Move to EnabledPopulated state.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_HIGH( pCommonRef,
            "Move to PortEnabledPopulated state." );

         ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                              pPortCtx, QOMX_StatePortEnabledPopulated, 0 );

      }
      else if( QOMX_StatePortDisabledStopping == pPortCtx->eState )
      {
         /**------------------------------------------------------------------
            Move to DisabledDepopulating state.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_HIGH( pCommonRef,
            "Move to PortDisabledDepopulating state." );

         ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                            pPortCtx, QOMX_StatePortDisabledDepopulating, 0 );

      }

   }

} /* end of function qomx_PortCommon_CheckStop */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_ProcessTunnelPeerStatus

         DESCRIPTION:
                        This function is called when component receives an
                        OMX_SetConfig with IndexConfigTunneledPortStatus from
                        its tunneling peer.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pTunneledPortStatus - Status of tunnel peer.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE  qomx_PortCommon_ProcessTunnelPeerStatus
(
   OMX_IN      QOMX_PortContainerType              *pPortCtnr,
   OMX_IN      QOMX_CONFIG_TUNNELEDPORTSTATUSTYPE   *pTunneledPortStatus
)
{
   OMX_ERRORTYPE           eRetVal     = OMX_ErrorNone;
   OMX_U32                 nPortIndex  = pTunneledPortStatus->nPortIndex;
   OMX_U32                 nPortStatus = pTunneledPortStatus->nTunneledPortStatus;
   QOMX_PortContextType   *pPortCtx;
   QOMX_CommonRefType     *pCommonRef  = pPortCtnr->pCommonRef;
   /*----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pCommonRef,
      "Received IndexConfigTunneledPortStatus: port %d, status %d.",
      nPortIndex, nPortStatus );

   eRetVal = qomx_PortGetContext( pPortCtnr, nPortIndex, & pPortCtx );

   if( OMX_ErrorNone == eRetVal )
   {
      if( ( PORT_TUNNELING_DISABLED != pPortCtx->eTunneling )
        && ( PORT_TUNNELING_VENDOR != pPortCtx->eTunneling )
          && ( QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx ) ) )
      {
         OMX_BOOL bAcceptUseBuffer =
                  ( nPortStatus & QOMX_PORTSTATUS_ACCEPTSUSEBUFFER )
                  ? OMX_TRUE : OMX_FALSE;

         OMX_BOOL bAcceptBufferExchange =
                  ( nPortStatus & QOMX_PORTSTATUS_ACCEPTSBUFFEREXCHANGE )
                  ? OMX_TRUE : OMX_FALSE;

         OMX_BOOL bAcceptFreeBuffer =
                  ( nPortStatus & OMX_PORTSTATUS_ACCEPTSFREEBUFFER )
                  ? OMX_TRUE : OMX_FALSE;
         /*-----------------------------------------------------------------*/

         if( !pPortCtx->bTunnelPeerAcceptsUseBuffer &&
            bAcceptUseBuffer )
         {
            QOMX_MSG_L_HIGH( pCommonRef,
               "Peer accepts UseBuffer calls now." );

            /**---------------------------------------------------------------
               If this port is already in populating state, buffers need to be
            supplied at this point.
            ----------------------------------------------------------------*/
            if( QOMX_StatePortEnabledPopulating == pPortCtx->eState )
            {
               QOMX_MSG_L_HIGH( pCommonRef,
                  "Port is already populating." );

               eRetVal = qomx_PortCommon_SupplyTunnelBuffers(pPortCtnr,
                                                             pPortCtx);

            }

         }
         else if( !pPortCtx->bTunnelPeerAcceptsBufferExchange &&
                     bAcceptBufferExchange )
         {
            QOMX_MSG_L_HIGH( pCommonRef,
               "Peer accepts buffer exchange now." );

            /**---------------------------------------------------------------
               If this port is already in running state, data flow has to
            start at this point.
            ----------------------------------------------------------------*/
            if( QOMX_StatePortEnabledRunning == pPortCtx->eState )
            {
               QOMX_MSG_L_HIGH( pCommonRef,
                  "Port is already running." );

               eRetVal = qomx_PortCommon_StartTunneledDataFlow(pPortCtnr,
                                                     pPortCtx);
            }

         }
         else if( !pPortCtx->bTunnelPeerAcceptsFreeBuffer &&
                     bAcceptFreeBuffer )
         {
            QOMX_MSG_L_HIGH( pCommonRef,
               "Peer accepts buffer freeing now." );

            /**---------------------------------------------------------------
               If this port has already received all its buffers,
               freeing needs to start at this point.
            ----------------------------------------------------------------*/
            if( QOMX_StatePortEnabledDepopulating == pPortCtx->eState
                || QOMX_StatePortDisabledDepopulating == pPortCtx->eState )
            {
               QOMX_MSG_L_HIGH( pCommonRef,
                  "Port is already depopulating." );

               eRetVal = qomx_PortCommon_FreeTunnelBuffers(pPortCtnr,
                                                           pPortCtx);
            }

         }

         pPortCtx->bTunnelPeerAcceptsUseBuffer      = bAcceptUseBuffer;
         pPortCtx->bTunnelPeerAcceptsBufferExchange = bAcceptBufferExchange;
         pPortCtx->bTunnelPeerAcceptsFreeBuffer     = bAcceptFreeBuffer;

      }
      else if( PORT_TUNNELING_VENDOR == pPortCtx->eTunneling )
      {
         eRetVal = qomx_PortCommon_ProcessVendorTunnelPeerStatus(pPortCtnr,
                                       pPortCtx, nPortStatus);

      }
      else
      {
         QOMX_MSG_L_ERROR( pCommonRef, "QOMX_IndexConfigTunneledPortStatus "
            "must be called on tunneling supplier." );

         eRetVal = OMX_ErrorBadParameter;
      }
   }

   return( eRetVal );

} /* end of function qomx_PortCommon_ProcessTunnelPeerStatus */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_ProcessVendorTunnelPeerStatus

         DESCRIPTION:
                        This function is called when component receives an
                        OMX_SetConfig with IndexConfigTunneledPortStatus from
                        its vendor tunneling peer.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
         @param[in]  nPortStatus - Port status.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE  qomx_PortCommon_ProcessVendorTunnelPeerStatus
(
   OMX_IN      QOMX_PortContainerType              *pPortCtnr,
   OMX_IN      QOMX_PortContextType             *pPortCtx,
   OMX_IN      OMX_U32                        nPortStatus
)
{
   OMX_ERRORTYPE           eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType     *pCommonRef  = pPortCtnr->pCommonRef;
   /*----------------------------------------------------------------------*/

   OMX_BOOL bVendorPeerPortEnable =
                  ( nPortStatus & OMX_PORTSTATUS_VTACCEPTSPORTENABLE )
                  ? OMX_TRUE : OMX_FALSE;

   OMX_BOOL bVendorPeerLoadedToIdle =
              ( nPortStatus & OMX_PORTSTATUS_VTACCEPTSLOADEDTOIDLE )
              ? OMX_TRUE : OMX_FALSE;

   OMX_BOOL bAcceptBufferExchange =
                  ( nPortStatus & OMX_PORTSTATUS_VTACCEPTSBUFFEREXCHANGE )
                  ? OMX_TRUE : OMX_FALSE;

   if( !pPortCtx->bVendorTunnelPeerLoadedToIdle && bVendorPeerLoadedToIdle )
   {
      QOMX_MSG_L_HIGH( pCommonRef,
         "Vendor-tunneled peer receives Loaded->Idle command." );

   }
   else if( !pPortCtx->bVendorTunnelPeerPortEnable && bVendorPeerPortEnable )
   {
     QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
     OMX_U32              nStatus     = MMI_S_EFAIL;
     MMI_PortCmdType      portCmd;
     /*--------------------------------------------------------------------*/

     QOMX_MSG_L_HIGH( pCommonRef,
        "Vendor-tunneled peer port already receives port enable "
        "command." );

     if ( pPortCtx->bAlterCmdPending )
     {
       MMI_VendorTunnelPortCmdData portCmdData = { OMX_FALSE, OMX_FALSE };
       QDFC_ErrorType    eErrVal = QDFC_ERROR_NONE;
       /*-----------------------------------------------------------------*/

       if ( QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx ) )
       {
         portCmdData.bAllocateBuffer = OMX_TRUE;
       }

       /**------------------------------------------------------------------
          Send enable command to device.
       -------------------------------------------------------------------*/
       portCmd.nPortIndex = pPortCtx->portDef.nPortIndex;
       portCmd.pCmdData = & portCmdData;

       nStatus = pCommonRef->device.pfnCmd(
                           pCommonRef->hFd, MMI_CMD_ENABLE_PORT, & portCmd );

       QOMX_MSG_L_HIGH( pCommonRef,
          "Enable command status = 0x%x", nStatus );

       pPortCtx->bAlterCmdPending = OMX_FALSE;

       /**------------------------------------------------------------------
         Handle enable command response.
       -------------------------------------------------------------------*/
       ( void ) qomx_PortCommon_EnableResp(
                           pPortCtnr, pPortCtx, nStatus, OMX_TRUE );

       /**------------------------------------------------------------------
         If the port is buffer supplier, signal the peer that buffer
         allocation is done and the peer port should send port enable MMI
         command.
       -------------------------------------------------------------------*/
       if ( QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx ) )
       {
         eErrVal = qdfc_EnqueueArg6Function(pPortCtnr->pCommonRef->hDfc,
                 ( qfc_Arg6FpType ) ( qomx_PortCommon_SignalTunnelPeer ),
                 ( QDFC_ArgType ) pPortCtx->hTunneledComp,
                 ( QDFC_ArgType ) pPortCtx->nTunneledPort,
                 ( QDFC_ArgType ) OMX_PORTSTATUS_VTACCEPTSPORTENABLE,
                 ( QDFC_ArgType ) 0,
                 ( QDFC_ArgType ) 0,
                 ( QDFC_ArgType ) 0 );
       }

       if( QDFC_ERROR_NONE != eErrVal )
       {
         QOMX_MSG_L_ERROR( pCommonRef,
            "DFC EnQueue error = %d. Event dropped", eErrVal );

       }

     }

   }
   else if( !pPortCtx->bTunnelPeerAcceptsBufferExchange &&
         bAcceptBufferExchange )
   {
      QOMX_MSG_L_HIGH( pCommonRef,
         "Vendor tunneled peer accepts buffer exchange now." );

   }

   pPortCtx->bVendorTunnelPeerLoadedToIdle      = bVendorPeerLoadedToIdle;
   pPortCtx->bVendorTunnelPeerPortEnable     = bVendorPeerPortEnable;
   pPortCtx->bTunnelPeerAcceptsBufferExchange   = bAcceptBufferExchange;

   return( eRetVal );
}

/*==========================================================================

         FUNCTION:      qomx_PortCommon_SignalTunnelPeer

         DESCRIPTION:
                        This function is used when a non-supplier needs to
                        signal its status to its tunneling peer using
                        OMX_SetConfig with IndexConfigTunneledPortStatus. It
                        will typically be called from DFC thread.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hTunneledComp        - Handle of tunnel peer.
            @param[in]  nTunneledPort        - Peer tunnel port.
            @param[in]  nTunneledPortStatus  - Port status requested to be
                                               sent.

**//*    RETURN VALUE:
*//**       @return     None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortCommon_SignalTunnelPeer
(
   OMX_IN      OMX_HANDLETYPE       hTunneledComp,
   OMX_IN      OMX_U32              nTunneledPort,
   OMX_IN      OMX_U32              nTunneledPortStatus
)
{
   OMX_ERRORTYPE                      eRetVal;
   QOMX_CONFIG_TUNNELEDPORTSTATUSTYPE  tunneledPortStatus;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_HIGH("Signaling tunnel peer 0x%p, port 0x%x.",
      hTunneledComp, nTunneledPort );

   QOMX_SET_STRUCT_OBJ( tunneledPortStatus, QOMX_CONFIG_TUNNELEDPORTSTATUSTYPE )

   tunneledPortStatus.nPortIndex = nTunneledPort;
   tunneledPortStatus.nTunneledPortStatus = nTunneledPortStatus;

   eRetVal = OMX_SetConfig( hTunneledComp,
                            (OMX_INDEXTYPE) QOMX_IndexConfigTunneledPortStatus,
                            & tunneledPortStatus);

   if( OMX_ErrorNone != eRetVal )
   {
      QOMX_MSG_ERROR("SetConfig IndexConfigTunneledPortStatus on peer failed."
          );
   }

} /* end of function qomx_PortCommon_SignalTunnelPeer */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_BufferRejected

         DESCRIPTION:   This function is called after a tunneling component
                        tries to pass a buffer back to the peer and fails.
                        This is a likely scenario when a non-supplier is
                        already transitioning from executing to idle and
                        rejecting any buffers sent by supplier. Since lock
                        gets released prematurely in these cases, special
                        handling is required to prevent race conditions.
*//**

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Pointer to the buffer header.

**//*     RETURN VALUE:
*//**       @return     None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void  qomx_PortCommon_BufferRejected
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr
)
{
   OMX_HANDLETYPE       hCmpnt = pPortCtnr->pCommonRef->hCmpnt;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pCommonRef,
      "qomx_PortCommon_BufferRejected, nPortIndex = 0x%x",
      pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      This function is called only when context is unlocked. We MUST lock and
      unlock CS within this function.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntLockContext( hCmpnt );

   /**------------------------------------------------------------------------
      If port is still running, simply decrementing the counter is sufficient.
   -------------------------------------------------------------------------*/
   if( QOMX_StatePortEnabledRunning == pPortCtx->eState )
   {
      pPortCtx->nBuffersWithClient--;

      ( void ) qomx_CmpntUnlockContext( hCmpnt );
   }
   else
   {
      OMX_ERRORTYPE  eRetVal;

      ( void ) qomx_CmpntUnlockContext( hCmpnt );

      /**---------------------------------------------------------------------
         Port has already changed its state and state machine now erroneously
         thinks it has an outstanding buffer. The safest solution is to make
         it look like the buffer is getting returned by the peer.
      ----------------------------------------------------------------------*/
      if( OMX_DirInput == pPortCtx->portDef.eDir )
      {
         eRetVal = OMX_EmptyThisBuffer( hCmpnt, pBufferHdr );
      }
      else
      {
         eRetVal = OMX_FillThisBuffer( hCmpnt, pBufferHdr );
      }

      if ( OMX_ErrorNone != eRetVal )
      {
         QOMX_MSG_L_ERROR( pCommonRef,
            "Failure pushing buffer on self." );
      }

   }

} /* end of function qomx_PortCommon_BufferRejected */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_DisableFlushResp

         DESCRIPTION:
*//**                   This function processes flush response received from
                        device when port is disabled.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void    qomx_PortCommon_DisableFlushResp
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /**----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_PortCommon_DisableFlushResp, nPortIndex = 0x%x",
      pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      If Flush command was sent to device on Disable Port request from
      application, do disable port on device now.
      Otherwise this Flush command to device was result of Flush command
      from application, send flush done notification now.
   -------------------------------------------------------------------------*/
   if( OMX_TRUE == pPortCtx->bAlterCmdPending )
   {
      pPortCtx->bAlterCmdPending = OMX_FALSE;

      /**---------------------------------------------------------------------
         Send disable port request to device now.
      ----------------------------------------------------------------------*/
      ( void ) qomx_PortCommon_Disable( pPortCtnr, pPortCtx );

   }
   else
   {
      /**---------------------------------------------------------------------
         Send flush done response now.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntCmdComplete( pPortCtnr->pCommonRef,
                     OMX_CommandFlush, pPortCtx->portDef.nPortIndex, NULL );

   }

   return;

} /* end of function qomx_PortCommon_DisableFlushResp */

/*==========================================================================

         FUNCTION:      qomx_PortCommon_TunnelNegotiateBuffers

         DESCRIPTION:
                        This function is called during tunnel setup to
                        ensure two tunneled ports have compatible buffer
                        counts.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr     - Pointer to the port container.
            @param[in]  pPortCtx      - Pointer to the port context.
            @param[in]  hTunneledComp - Component handle for the tunnel peer.
            @param[in]  nTunneledPort - Port index for the tunnel peer.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortCommon_TunnelNegotiateBuffers
(
   OMX_IN   QOMX_PortContainerType    *pPortCtnr,
   OMX_IN   QOMX_PortContextType      *pPortCtx,
   OMX_HANDLETYPE                      hTunneledComp,
   OMX_U32                             nTunneledPort
)
{
   OMX_ERRORTYPE  eRetVal  =  OMX_ErrorNone;
   OMX_PARAM_PORTDEFINITIONTYPE  peerPortDef;
   QOMX_CommonRefType  *pCommonRef  = pPortCtnr->pCommonRef;
   /**----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_PortCommon_TunnelNegotiateBuffers, nPortIndex = 0x%x",
      pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Obtain the port definition of the peer port first.
   -------------------------------------------------------------------------*/
   QOMX_SET_STRUCT_OBJ( peerPortDef, OMX_PARAM_PORTDEFINITIONTYPE );
   peerPortDef.nPortIndex = nTunneledPort;
   eRetVal = OMX_GetParameter( hTunneledComp,
                               OMX_IndexParamPortDefinition,
                               & peerPortDef );

   if( OMX_ErrorNone == eRetVal )
   {

      QOMX_MSG_L_HIGH( pCommonRef,
         "Port's buffer count is %d, peer's buffer count is %d.",
         pPortCtx->portDef.nBufferCountActual,
         peerPortDef.nBufferCountActual );

      /**---------------------------------------------------------------------
         Actual buffer count should be the maximum of actual counts of two
         sides. If they are not already equal, one side has to be modified
         with the larger value.
      ----------------------------------------------------------------------*/
      if( peerPortDef.nBufferCountActual <
                                       pPortCtx->portDef.nBufferCountActual )
      {
         QOMX_MSG_L_HIGH( pCommonRef, "Updating peer's buffer count." );

         peerPortDef.nBufferCountActual =
                                       pPortCtx->portDef.nBufferCountActual;

         eRetVal = OMX_SetParameter( hTunneledComp,
                                     OMX_IndexParamPortDefinition,
                                     ( OMX_PTR ) ( & peerPortDef ) );

      }
      else if( pPortCtx->portDef.nBufferCountActual <
                                       peerPortDef.nBufferCountActual )
      {
         OMX_PARAM_PORTDEFINITIONTYPE  newPortDef;
         /**----------------------------------------------------------------*/

         QOMX_MSG_L_HIGH( pCommonRef, "Updating self buffer count." );

         QOMX_SET_STRUCT_OBJ( newPortDef, OMX_PARAM_PORTDEFINITIONTYPE );
         QOMX_CMPNT_MEM_COPY( & newPortDef, & pPortCtx->portDef,
                              sizeof( newPortDef ) );

         newPortDef.nBufferCountActual = peerPortDef.nBufferCountActual;

         eRetVal = qomx_SetParmPortDefinition( pPortCtnr->pCommonRef,
                                               pPortCtx,
                                               ( OMX_PTR ) ( & newPortDef ) );

      }

   }

   return eRetVal;

} /* end of function qomx_PortCommon_TunnelNegotiateBuffers */


/*==========================================================================

         FUNCTION:      qomx_TunnelNegotiateBufferSupplier

         DESCRIPTION:
                        This function is called during tunnel setup to
                        negotiate buffer supplier setting.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]    pPortCtnr     - Pointer to the port container.
            @param[inout] pPortCtx      - Pointer to the port context.
            @param[in]    hTunneledComp - Component handle for the tunnel peer.
            @param[in]    nTunneledPort - Port index for the tunnel peer.
            @parem[inout] pTunnelSetup  - Refer OMX_Core.h / OMX IL spec.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE qomx_TunnelNegotiateBufferSupplier
(
   OMX_IN      QOMX_CommonRefType        *pCommonRef,
   OMX_IN      QOMX_PortContextType      *pPortCtx,
   OMX_IN      OMX_HANDLETYPE             hTunneledComp,
   OMX_IN      OMX_U32                    nTunneledPort,
   OMX_INOUT   OMX_TUNNELSETUPTYPE       *pTunnelSetup
)
{
   OMX_ERRORTYPE           eRetVal = OMX_ErrorNone;
   OMX_BUFFERSUPPLIERTYPE  eDevBufSupplier = OMX_BufferSupplyUnspecified;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
         "qomx_TunnelNegotiateBufferSupplier, nPortIndex = 0x%x",
         pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      Poll MMI for device buffer supplier preference.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_GetDeviceBufSupplierPref( pCommonRef,
              pPortCtx->portDef.nPortIndex, & eDevBufSupplier );

   if( OMX_ErrorNone == eRetVal )
   {
      pPortCtx->eBufferSupplier = eDevBufSupplier;

      /**---------------------------------------------------------------------
         Decide buffer supplier based on device supplier preferences of the
         input port and the output port to be tunneled.
      ----------------------------------------------------------------------*/
      ( void )qomx_TunnelSetSupplier(
                     & pPortCtx->eBufferSupplier, & pTunnelSetup->eSupplier );

      QOMX_MSG_L_HIGH( pCommonRef,
         "eBufferSupplier = 0x%x is chosen after buffer supplier negotiation."
         " nInputPortIndex = 0x%x",
         pTunnelSetup->eSupplier, pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         If the chosen supplier preference is different from its device
         supplier preference, informationally set its device supplier
         preference to the chosen preference.
      ----------------------------------------------------------------------*/
      if( eDevBufSupplier != pPortCtx->eBufferSupplier )
      {
         eRetVal = qomx_SetDeviceBufSupplierPref( pCommonRef,
                    pPortCtx->portDef.nPortIndex, pPortCtx->eBufferSupplier );

      }

   }

   if( OMX_ErrorNone == eRetVal )
   {
      OMX_PARAM_BUFFERSUPPLIERTYPE bufSup;
      /*--------------------------------------------------------------------*/

      /**---------------------------------------------------------------------
         Set supplier preference to the peer after the negotiation.
      ----------------------------------------------------------------------*/
      QOMX_SET_STRUCT_OBJ( bufSup, OMX_PARAM_BUFFERSUPPLIERTYPE );
      bufSup.nPortIndex = nTunneledPort;
      bufSup.eBufferSupplier = pPortCtx->eBufferSupplier;
      eRetVal = OMX_SetParameter(hTunneledComp,
                           OMX_IndexParamCompBufferSupplier, &bufSup);

      if ( OMX_ErrorNone != eRetVal )
      {
         QOMX_MSG_L_ERROR( pCommonRef,
               "Set supplier preference on the peer port FAILED. "
               "hTunneledCmpnt = 0x%p, portIndex = 0x%x.",
               hTunneledComp, nTunneledPort );

      }

   }

   return( eRetVal );

} /* end of function qomx_TunnelNegotiateBufferSupplier */


/*==========================================================================

         FUNCTION:      qomx_GetDeviceBufSupplierPref

         DESCRIPTION:
                        This function is called during tunnel setup to
                        query MMI for its buffer supplier preference.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]    pPortCtnr        - Pointer to the port container.
            @param[in]    nPortIndex       - Port Index.
            @param[out]   peBufferSupplier - Pointer to supplier preference
                                             enum to be filled by MMI.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE qomx_GetDeviceBufSupplierPref
(
   OMX_IN      QOMX_CommonRefType        *pCommonRef,
   OMX_IN      OMX_U32                    nPortIndex,
   OMX_OUT     OMX_BUFFERSUPPLIERTYPE    *peBufferSupplier
)
{
   OMX_ERRORTYPE                    eRetVal  = OMX_ErrorNone;
   OMX_U32                          nStatus  = MMI_S_EFAIL;
   MMI_OmxParamCmdType              stdCmd;
   OMX_PARAM_BUFFERSUPPLIERTYPE     bufSup;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
         "qomx_GetDeviceBufSupplierPref, nPortIndex = 0x%x",
         nPortIndex );

   /**------------------------------------------------------------------------
      Poll MMI for its buffer supplier preference.
   -------------------------------------------------------------------------*/
   QOMX_MSG_L_HIGH( pCommonRef, "Get device supplier preference "
            "hCmpnt = 0x%p, portIndex = 0x%x.",
            pCommonRef->hCmpnt, nPortIndex );

   QOMX_SET_STRUCT_OBJ( bufSup, OMX_PARAM_BUFFERSUPPLIERTYPE );

   bufSup.nPortIndex       = nPortIndex;
   bufSup.eBufferSupplier  = OMX_BufferSupplyUnspecified;

   stdCmd.nParamIndex      = OMX_IndexParamCompBufferSupplier;
   stdCmd.pParamStruct     = & bufSup;

   /**------------------------------------------------------------------------
      Send command to device.
   -------------------------------------------------------------------------*/
   nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                     MMI_CMD_GET_STD_OMX_PARAM, & stdCmd );

   QOMX_MSG_L_HIGH( pCommonRef,
          "Get device supplier preference command status = 0x%x. "
          "portIndex = 0x%x", nStatus, nPortIndex );

   /**------------------------------------------------------------------------
      Check MMI return code:
      1. MMI_S_COMPLETE - the MMI supplier preference is retrieved
         successfully;
      2. MMI_S_ENOTSUPIDX - the MMI does not support GET_STD_OMX_PARAM on
         OMX_IndexParamCompBufferSupplier;
      3. Otherwise - ignore error code since MMI is not required to support
         get param on OMX_IndexParamCompBufferSupplier.
   -------------------------------------------------------------------------*/
   if( nStatus == MMI_S_COMPLETE )
   {
      if( ( OMX_BufferSupplyUnspecified != bufSup.eBufferSupplier )
         && ( OMX_BufferSupplyInput != bufSup.eBufferSupplier )
         && ( OMX_BufferSupplyOutput != bufSup.eBufferSupplier) )
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Unsupported buffer supplier setting,"
            " nPortIndex = 0x%x", nPortIndex );

         /**------------------------------------------------------------------
            Attempt to set an invalid buffer supplier.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorUnsupportedSetting;

      }
      else
      {
         *peBufferSupplier = bufSup.eBufferSupplier;

      }

   }
   else
   {
      if( nStatus == MMI_S_ENOTSUPIDX )
      {
         QOMX_MSG_L_HIGH( pCommonRef,
               "MMI does not support GET_STD_OMX_PARAM with "
               "OMX_IndexParamCompBufferSupplier. status = 0x%x, "
               "portIndex = 0x%x.", nStatus, nPortIndex );
      }
      else
      {
         QOMX_MSG_L_HIGH( pCommonRef,
               "Get tunneled device supplier preference command failed. "
               "Ignore error status = 0x%x, portIndex = 0x%x.",
               nStatus, nPortIndex );

      }

   }

   return( eRetVal );

} /* end of function qomx_GetDeviceBufSupplierPref */

/*==========================================================================

         FUNCTION:      qomx_SetDeviceBufSupplierPref

         DESCRIPTION:
                        This function is called during tunnel setup to
                        query MMI for its buffer supplier preference.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]    pPortCtnr        - Pointer to the port container.
            @param[in]    nPortIndex       - Port Index.
            @param[in]    eBufferSupplier  - Supplier preference enum.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE qomx_SetDeviceBufSupplierPref
(
   OMX_IN      QOMX_CommonRefType        *pCommonRef,
   OMX_IN      OMX_U32                    nPortIndex,
   OMX_IN      OMX_BUFFERSUPPLIERTYPE     eBufferSupplier
)
{
   OMX_ERRORTYPE                    eRetVal  = OMX_ErrorNone;
   OMX_U32                          nStatus  = MMI_S_EFAIL;
   MMI_OmxParamCmdType              stdCmd;
   OMX_PARAM_BUFFERSUPPLIERTYPE     bufSup;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
         "qomx_SetDeviceBufSupplierPref, nPortIndex = 0x%x",
         nPortIndex );

   /**------------------------------------------------------------------------
      Poll MMI for its buffer supplier preference.
   -------------------------------------------------------------------------*/
   QOMX_MSG_L_HIGH( pCommonRef, "Get device supplier preference "
            "hCmpnt = 0x%p, portIndex = 0x%x.",
            pCommonRef->hCmpnt, nPortIndex );

   QOMX_SET_STRUCT_OBJ( bufSup, OMX_PARAM_BUFFERSUPPLIERTYPE );
   bufSup.nPortIndex       = nPortIndex;
   bufSup.eBufferSupplier  = eBufferSupplier;

   stdCmd.nParamIndex      = OMX_IndexParamCompBufferSupplier;
   stdCmd.pParamStruct     = & bufSup;

   /**------------------------------------------------------------------------
      Send command to device.
   -------------------------------------------------------------------------*/
   nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                     MMI_CMD_SET_STD_OMX_PARAM, & stdCmd );

   QOMX_MSG_L_HIGH( pCommonRef,
          "Set device supplier preference command status = 0x%x. "
          "portIndex = 0x%x", nStatus, nPortIndex );

   /**------------------------------------------------------------------------
      Check MMI return code:
      1. MMI_S_COMPLETE - the MMI supplier preference is set successfully;
      2. MMI_S_ENOTSUPIDX - the MMI does not support SET_STD_OMX_PARAM on
         OMX_IndexParamCompBufferSupplier;
      3. Otherwise - Ignore error code since this is an informational command
         only and MMI does not have to support it.
   -------------------------------------------------------------------------*/
   if( nStatus != MMI_S_COMPLETE )
   {
      if( nStatus == MMI_S_ENOTSUPIDX )
      {
         QOMX_MSG_L_HIGH( pCommonRef,
               "MMI does not support SET_STD_OMX_PARAM with "
               "OMX_IndexParamCompBufferSupplier. status = 0x%x, "
               "portIndex = 0x%x.", nStatus, nPortIndex );
      }
      else
      {
         QOMX_MSG_L_HIGH( pCommonRef,
               "Set tunneled device supplier preference command failed. "
               "Ignore error status = 0x%x, portIndex = 0x%x.", nStatus,
               nPortIndex );

      }

   }

   return( eRetVal );

} /* end of function qomx_SetDeviceBufSupplierPref */

/*==========================================================================

         FUNCTION:      qomx_TunnelSetSupplier

         DESCRIPTION:
                        This function is called to decide buffer supplier
                        setting during tunnel setup, based on MMI's supplier
                        preference of the input port and MMI's supplier
                        preference of the output port.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[inout] peSupPrefInputPort  - Pointer to device supplier
                                                preference of the input port.
            @param[inout] peSupPrefOutputPort - Pointer to device supplier
                                                preference of the output port.

**//*    RETURN VALUE:
*//**       @return     None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void qomx_TunnelSetSupplier
(
   OMX_INOUT   OMX_BUFFERSUPPLIERTYPE  *peSupPrefInputPort,
   OMX_INOUT   OMX_BUFFERSUPPLIERTYPE  *peSupPrefOutputPort
)
{
   OMX_BOOL bUseDefaultSupplierPref = OMX_FALSE;
   /*-----------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      If only one of the devices specifies buffer supplier preference, assign
      this preference to the peer;
      If both of the devices specify buffer supplier preference, check if
      they have conflicted preferences; if so, set UseDefault flag to TRUE.
   -------------------------------------------------------------------------*/
   if( ( OMX_BufferSupplyUnspecified != *peSupPrefInputPort )
     || ( OMX_BufferSupplyUnspecified != *peSupPrefOutputPort ) )
   {
      if ( OMX_BufferSupplyUnspecified == *peSupPrefInputPort )
      {
         *peSupPrefInputPort = *peSupPrefOutputPort;

      }
      else if ( OMX_BufferSupplyUnspecified == *peSupPrefOutputPort )
      {
         *peSupPrefOutputPort = *peSupPrefInputPort;

      }
      else if ( *peSupPrefInputPort != *peSupPrefOutputPort )
      {
         bUseDefaultSupplierPref = OMX_TRUE;

      }
   }
   /**------------------------------------------------------------------------
      If neither of the devices specifies buffer supplier preference, set
      UseDefault flag to TRUE.
   -------------------------------------------------------------------------*/
   else
   {
      bUseDefaultSupplierPref = OMX_TRUE;

   }

   /**------------------------------------------------------------------------
      If neither device specifies supplier preference, or device has
      conflicted supplier preference, use the default rule: set output port
      as the supplier.
   -------------------------------------------------------------------------*/
   if( OMX_TRUE == bUseDefaultSupplierPref )
   {
      *peSupPrefInputPort = OMX_BufferSupplyOutput;
      *peSupPrefOutputPort = OMX_BufferSupplyOutput;

   }

   return;

} /* end of function qomx_TunnelSetSupplier */


/*==========================================================================

         FUNCTION:      qomx_PortCommon_CopyMark

         DESCRIPTION:
*//**                   This function copy mark from port context to
                        buffer header.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr      - Pointer to the port container.
            @param[in]  pPortCtx       - Pointer to the port context.
            @param[in]  pBufferHdr     - Pointer to the port buffer header

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_CopyMark
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType   *pCommonRef = pPortCtnr->pCommonRef;
   QMM_ListLinkType     *link;
   QOMX_MarkBufferList  *pMarkBufList;
   QMM_ListErrorType    listError;

   listError = qmm_ListPopFront ( &pPortCtx->MarkBufFullList, &link );

   if ( QMM_LIST_ERROR_NONE == listError )
   {
       pMarkBufList = ( QOMX_MarkBufferList * ) link;

       /**---------------------------------------------------------------------
          Check for the mark buffer and copy the mark buffer data in port
          message. Send notification to the application.
        ----------------------------------------------------------------------*/
        if( ( NULL != pMarkBufList->markBuffer.hMarkTargetComponent )
              && ( NULL == pBufferHdr->hMarkTargetComponent ) )
        {
           QOMX_MSG_L_MED( pCommonRef, "nPortIndex = 0x%x, Copying mark data,"
                " hMarkTargetComponent 0x%p", pPortCtx->portDef.nPortIndex,
                pMarkBufList->markBuffer.hMarkTargetComponent );

           /**------------------------------------------------------------------
                 Copy mark information.
              -------------------------------------------------------------------*/
           pBufferHdr->hMarkTargetComponent
                    = pMarkBufList->markBuffer.hMarkTargetComponent;

           pBufferHdr->pMarkData = pMarkBufList->markBuffer.pMarkData;

           QOMX_CMPNT_MEM_SET( & pMarkBufList->markBuffer, 0, sizeof( OMX_MARKTYPE ) );

           if ( QMM_LIST_ERROR_NONE != qmm_ListPushRear( &pPortCtx->MarkBufEmptyList, link) )
           {
               QOMX_MSG_L_ERROR( pCommonRef, "nPortIndex = 0x%x, qmm_ListPushRead of MarkBufEmptyList failed",
                     pPortCtx->portDef.nPortIndex);
           }

           /**------------------------------------------------------------------
              Send mark buffer response.
           -------------------------------------------------------------------*/
           QOMX_MSG_L_MED( pCommonRef, "nPortIndex = 0x%x, Send"
              " OMX_CommandMarkBuffer notification",
               pPortCtx->portDef.nPortIndex );

           ( void ) qomx_CmpntCmdComplete( pCommonRef, OMX_CommandMarkBuffer,
                                   pPortCtx->portDef.nPortIndex, NULL );
        }
   }
   else
   {
       QOMX_MSG_L_ERROR( pCommonRef, "Failed to pop from MarkBufFullList, list err = 0x%x", listError);

       /* return failure for mark buffer cmd */
       qomx_CmpntNotifyError(pCommonRef, OMX_ErrorUndefined );
   }

   return eRetVal;

} /* end of function qomx_PortCommon_CopyMark */

