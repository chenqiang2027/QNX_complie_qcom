#ifndef __QOMX_COMMON_H__
#define __QOMX_COMMON_H__

/*========================================================================

*//** @file qomxCommon.h

@par FILE SERVICES:
      Common Header File.

      This file contains the macros, data types and methods which are common
      to the all component states and port states. This includes accessor
      functions for port to component etc. This header file facilitates
      OpenMax data types to all the files within the component so that each
      individual file need not include openmax header files.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2009-2018,2020 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCommon.h#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
08/19/20   jz     Increase QDFC queue size
04/05/18   rz     Fix print fmt check errors
01/28/13   dp     Add error code (fatal) for stream not supported.
08/08/11   dm     Hardware critical error handling.
12/10/10   zm     Remove the QOMX extension param structure for supplier
                  preference.
12/06/10   zm     Add support to query device for its supplier preference.
11/22/10   zm     Added macro to validate structure size and heap memory
                  management APIs to commonRef structure.
09/30/10   zm     Use string name size macro defined in OMX_Core.h.
09/13/10   dm     Adding component name and handle in logging messages.
08/28/10   zm     Added support for vendor tunneling.
07/16/10   dm     Remove redundant checks in handle validation.
07/15/10   yt     Added Qualcomm specific flag for freeing buffers.
07/14/10   dm     Added structures for Qualcomm tunneling extension.
06/10/10   dm     Added return type in event handler.
05/06/10   dm     Allow all extension indexes.
03/18/10   spl    Added support for Port Throughput extension.
03/17/10   dm     Post all event callbacks to DFC queue.
11/24/09   dm     Added support for device extension indexes.
10/30/09   dm     Defined macro for structure size and version validation.
10/29/09   dm     Moved index typedefs to component common private file.
06/16/09   dm     Initial Creation.

========================================================================== */

/*========================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */

#include <OMX_Audio.h>              /**< OpenMax Headers */
#include <OMX_Component.h>
#include <OMX_ContentPipe.h>
#include <OMX_Core.h>
#include <OMX_CoreExt.h>
#include <OMX_Image.h>
#include <OMX_Index.h>
#include <OMX_IndexExt.h>
#include <OMX_IVCommon.h>
#include <OMX_Other.h>
#include <OMX_Types.h>
#include <OMX_Video.h>

#include "mmiDeviceApi.h"           /**< QOMX External Interface Headers */
#include "qomxCmpntApi.h"
#include "qomxOSAbstraction.h"
#include "qomxCmpntDebugExt.h"
#include "QOMX_CoreExtensions.h"

#include "qomxStates.h"             /**< QOMX Internal Headers */
#include "qomxUtils.h"
#include "qomxGuards.h"
#include "qmmList.h"
#include "qmmDfcApi.h"

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */


/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */


/**
 *
 * These macros define OpenMax spec version.
 *
 */

#define QOMX_SPEC_VERSION_MAJOR              ( 1 )
#define QOMX_SPEC_VERSION_MINOR              ( 1 )
#define QOMX_SPEC_REVISION                   ( 2 )
#define QOMX_SPEC_STEP                       ( 1 )


/**
 *
 * These macros define OpenMax component version.
 *
 */

#define QOMX_CMPNT_VERSION_MAJOR             ( 1 )
#define QOMX_CMPNT_VERSION_MINOR             ( 1 )
#define QOMX_CMPNT_REVISION                  ( 2 )
#define QOMX_CMPNT_STEP                      ( 1 )


/**
 *
 * This macro sets openmax spec version.
 *
 */

#define SET_QOMX_SPEC_VERSION( verObj )                                      \
   {                                                                         \
      ( verObj ).s.nVersionMajor  = QOMX_SPEC_VERSION_MAJOR;                 \
      ( verObj ).s.nVersionMinor  = QOMX_SPEC_VERSION_MINOR;                 \
      ( verObj ).s.nRevision      = QOMX_SPEC_REVISION;                      \
      ( verObj ).s.nStep          = QOMX_SPEC_STEP;                          \
   }


/**
 *
 * This macro sets openmax component version.
 *
 */

#define SET_QOMX_CMPNT_VERSION( verObj )                                     \
   {                                                                         \
      ( verObj ).s.nVersionMajor  = QOMX_CMPNT_VERSION_MAJOR;                \
      ( verObj ).s.nVersionMinor  = QOMX_CMPNT_VERSION_MINOR;                \
      ( verObj ).s.nRevision      = QOMX_CMPNT_REVISION;                     \
      ( verObj ).s.nStep          = QOMX_CMPNT_STEP;                         \
   }


/**
 *
 * This macro defines OMX version comparison condition, which can be used to
 * determine if some structure object has version mismatch.
 * Here 'verObj' is the Version object.
 *
 */

/*hack: conformance test has version string as 1.1.0.0, there is version
        mismatch between base class and conformance test. Comment should be
        removed later with upgraded conformance test */
#if 1
#define QOMX_CMPNT_VERSION_MISMATCH( verObj )  ( OMX_FALSE )
#else
#define QOMX_CMPNT_VERSION_MISMATCH( verObj )                                \
         (                                                                   \
               ( ( verObj ).s.nVersionMajor != QOMX_CMPNT_VERSION_MAJOR )    \
            || ( ( verObj ).s.nVersionMinor != QOMX_CMPNT_VERSION_MINOR )    \
            || ( ( verObj ).s.nRevision     != QOMX_CMPNT_REVISION )         \
            || ( ( verObj ).s.nStep         != QOMX_CMPNT_STEP )             \
          )
#endif


/**
  *
  * This macro validates the size of the structure passed as the nSize in the
  * structure object against structure size, checks for any version mismatch
  * and sets the result of this validation in the error status object. Else
  * part of this validation need to be implemented in the function where this
  * macro is being invoked.
  *
  *   @param[in]  pObj        - Pointer to the structure object.
  *   @param[in]  structType  - Data type for the structure.
  *   @param[in]  eError      - Error type object where any detected error
  *                             need to be set.
  *
  */

#define QOMX_IF_VALID_STRUCT_OBJ( pCRef, pStructObj, structType, eError )    \
                                                                             \
   if( pStructObj->nSize != sizeof( structType ) )                           \
   {                                                                         \
      QOMX_MSG_L_ERROR( pCRef, "Size mismatch. Object size = %d, "           \
         "Struct size = %zd", pStructObj->nSize, sizeof( structType ) );      \
                                                                             \
      eRetVal = OMX_ErrorBadParameter;                                       \
   }                                                                         \
   else if( QOMX_CMPNT_VERSION_MISMATCH( pStructObj->nVersion ) )            \
   {                                                                         \
      QOMX_MSG_L_ERROR( pCRef, "Version mismatch." );                  \
                                                                             \
      eRetVal = OMX_ErrorVersionMismatch;                                    \
   }                                                                         \
   else
   /* else will be defined in the function where this macro is invoked. */

/**
  *
  * This macro validates the size of the structure passed as the nSize in the
  * structure object against structure size and sets the result of this
  * validation in the error status object. Else part of this validation need
  * to be implemented in the function where this macro is being invoked.
  *
  *   @param[in]  pObj        - Pointer to the structure object.
  *   @param[in]  structType  - Data type for the structure.
  *   @param[in]  eError      - Error type object where any detected error
  *                             need to be set.
  *
  */

#define QOMX_IF_VALID_STRUCT_SIZE( pStructObj, structType, eError )          \
                                                                             \
   if( pStructObj->nSize != sizeof( structType ) )                           \
   {                                                                         \
      QOMX_MSG_ERROR( "Size mismatch. Object size = %d, "                    \
         "Struct size = %zd", pStructObj->nSize, sizeof( structType ) );      \
                                                                             \
      eRetVal = OMX_ErrorBadParameter;                                       \
   }                                                                         \
   else
   /* else will be defined in the function where this macro is invoked. */

/**
  *
  * This macro sets the size of the structure nSize and component version
  * nVersion in the parameter object.
  *
  *   @param[in]  structObj   - Structure object.
  *   @param[in]  structType  - Data type for the structure.
  *
  */

#define QOMX_SET_STRUCT_OBJ( structObj, structType )                         \
   {                                                                         \
      ( structObj ).nSize = sizeof( structType );                            \
      SET_QOMX_CMPNT_VERSION( ( structObj ).nVersion );                      \
   }


/**
 *
 * This macro defines an unknown event which can be used to take a particular
 * action ( state transition to invalid  etc. ) when reason for certain thing
 * is unknown.
 *
 */

#define QOMX_DFC_QUEUE_DEPTH                 ( 1024 * 10 )


/**
 *
 * This macro defines an unknown event which can be used to take a particular
 * action ( state transition to invalid  etc. ) when reason for certain thing
 * is unknown.
 *
 */

#define QOMX_EVENT_UNKNOWN                   ( 0x0 )

/**
 *
 * This macro defines an fatal error event.
 */

#define QOMX_EVENT_ERROR_FATAL               ( 0x1 )

/**
 *
 * This macro defines an fatal error event.
 */

#define QOMX_EVENT_ERROR_FATAL_HARDWARE      ( 0x2 )



/**
  *
  * This macro defines OMX_ERRORTYPE extension for Critical Section release.
  * This error code is returned by a function if it releases the critical
  * section which is initially acquired by an API call. When API handlerer
  * gets this error code, it must not try to release the critical section.
  *
  */

#define OMX_ERROR_CS_RELEASED                ( ( OMX_ERRORTYPE ) 0x9EEEEEEE )


/**
  *
  * These macros define logging patterns for this instance of base class.
  *
  */

/** Enable critical messages */
#define QOMX_DEBUG_MSG_CRITICAL              ( 0x01 )

/** Enable high messages */
#define QOMX_DEBUG_MSG_HIGH                  ( 0x02 )

/** Enable medium messages */
#define QOMX_DEBUG_MSG_MEDIUM                ( 0x04 )

/** Enable low messages */
#define QOMX_DEBUG_MSG_LOW                   ( 0x08 )

/** Enable Component Name priting */
#define QOMX_DEBUG_MSG_COMPONENT_NAME        ( 0x10 )


/** Disable all messages */
#define QOMX_DEBUG_MSG_LEVEL_DISABLE_ALL     ( 0x00 )

/** Enable all messages */
#define QOMX_DEBUG_MSG_LEVEL_ENABLE_ALL      ( QOMX_DEBUG_MSG_CRITICAL       \
                                               | QOMX_DEBUG_MSG_HIGH         \
                                               | QOMX_DEBUG_MSG_MEDIUM       \
                                               | QOMX_DEBUG_MSG_LOW )

/** Enable critical level messages */
#define QOMX_DEBUG_MSG_LEVEL_CRITICAL        ( QOMX_DEBUG_MSG_CRITICAL )

/** Enable high level messages i.e. critical and high */
#define QOMX_DEBUG_MSG_LEVEL_HIGH            ( QOMX_DEBUG_MSG_CRITICAL       \
                                               | QOMX_DEBUG_MSG_HIGH )

/** Enable medium level messages i.e. critical, high and medium */
#define QOMX_DEBUG_MSG_LEVEL_MEDIUM          ( QOMX_DEBUG_MSG_CRITICAL       \
                                               | QOMX_DEBUG_MSG_HIGH         \
                                               | QOMX_DEBUG_MSG_MEDIUM )

/**
  *
  * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  * Macros to define extension indexes.
  * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  *
  */


/**
  *
  * This macro defines the tunneling extension index name which is used to
  * check if the peer tunneling port is a Qualcomm component's port.
  *
  * Associated Structure: QOMX_ParamQTunnelMode
  *
  */
#define QOMX_PARAM_NAME_QUALCOMM_TUNNEL \
                        "OMX.qcom.param.qualcomm.tunnel"

/**
  *
  * Base value which need to be added in all the base class extension indexes
  * defined below.
  *
  */
#define QOMX_EXT_IDX_BASE                    ( 0x7F001000 )

/**
  *
  * This macro defines the custom OMX parameter value used to get the port
  * throughput data.
  *
  * Associated Structure: QOMX_PARAM_PORT_THROUGHPUT
  *
  */
#define QOMX_PARAM_INDEX_PORT_THROUGHPUT     ( QOMX_EXT_IDX_BASE + 1 )

/**
  *
  * This macro defines the custom OMX parameter value used to check if the
  * tunnel is being established between two qualcomm components.
  *
  * Associated Structure: QOMX_ParamQTunnelMode
  *
  */
#define QOMX_PARAM_INDEX_QUALCOMM_TUNNEL     ( QOMX_EXT_IDX_BASE + 2 )


/**
  *
  * This macro defines a Qualcomm internal flag to be used with
  * nTunneledPortStatus field of OMX_CONFIG_TUNNELEDPORTSTATUSTYPE struct.
  * It extends the standardized tunneling race condition signaling to session
  * teardown so that Qualcomm components can have a cleaner transition,
  * eliminating the possibility of receiving a FreeBuffer call while port is
  * still running.
  */
#define OMX_PORTSTATUS_ACCEPTSFREEBUFFER 0x00000004

/**
  *
  * This macro defines a Qualcomm internal flag to be used with
  * nTunneledPortStatus field of OMX_CONFIG_TUNNELEDPORTSTATUSTYPE struct.
  * It extends the standardized tunneling race condition signaling to loaded
  * to idle transition for vendor tunneled components, eliminating the
  * possibility of one of the vendor-tunneled components in idle state while
  * the peer is still in loaded state.
  */
#define OMX_PORTSTATUS_VTACCEPTSLOADEDTOIDLE 0x00000008

/**
  *
  * This macro defines a Qualcomm internal flag to be used with
  * nTunneledPortStatus field of OMX_CONFIG_TUNNELEDPORTSTATUSTYPE struct.
  * It extends the standardized tunneling race condition signaling to enabling
  * vendor-tunneled ports, eliminating the possibility of one of the ports is
  * enabled while the the peer is still disabled.
  */
#define OMX_PORTSTATUS_VTACCEPTSPORTENABLE 0x00000010

/**
  *
  * This macro defines a Qualcomm internal flag to be used with
  * nTunneledPortStatus field of OMX_CONFIG_TUNNELEDPORTSTATUSTYPE struct.
  * It extends the standardized tunneling race condition signaling to starting
  * buffer flow in MMI for vendor-tunneled ports, eliminating the possibility
  * of one of the ports is still in Loaded/WFR/Idle state while the the peer
  * already transitions to Executing state.
  */
#define OMX_PORTSTATUS_VTACCEPTSBUFFEREXCHANGE 0x00000020

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
  *
  * This data type is used to retrieve Vendor Tunnel Device API table and
  * handle from the MMI device. This data type is used with the index
  * corresponding to QOMX_PARAM_NAME_VENDOR_TUNNEL_DEVICE.
  *
  * MMI may use a different set of values of the four function pointers in the
  * MMI_DeviceType structure, such that MMI can override the implemenation (in
  * base profile or normal tunneling) of each of them for vendor tunneling.
  * The only requirement for MMI is not to change the signature of the four
  * functions (MMI_OpenType, MMI_RegisterEvtHandlerType, MMI_CmdType and
  * MMI_CloseType).
  *
  * MMI may use a different device handle (vendor tunneling specific handle)
  * if necessary.
  *
  */

typedef struct
{
   OMX_U32           nSize;               /**
                                          * This is size of the structure in
                                          * bytes.
                                          */

   OMX_VERSIONTYPE   nVersion;            /**
                                          * This is OMX specification version
                                          * information.
                                          */

   OMX_U32           nPortIndex;          /**<
                                          * This is port index.
                                          */

   MMI_DeviceType   *pDeviceApi;          /**<
                                          * This is the pointer to the
                                          * (vendor-tunneling specifc) device
                                          * API table.
                                          */

   OMX_HANDLETYPE    hDevice;             /**<
                                          * This is the pointer to the device
                                          * handle.
                                          */

} QOMX_ParamVendorTunnelDevice;


/**
  *
  * This data type is used to set Vendor Tunnel Device API table and handle
  * of the peer MMI device.
  *
  * This data type is used with the index corresponding
  * to QOMX_PARAM_NAME_VENDOR_TUNNEL_SETUP.
  *
  */

typedef struct
{
   OMX_U32           nSize;               /**
                                          * This is size of the structure in
                                          * bytes.
                                          */

   OMX_VERSIONTYPE   nVersion;            /**
                                          * This is OMX specification version
                                          * information.
                                          */

   OMX_HANDLETYPE  hCmpnt;                /**
                                          * This is component handle of this
                                          * component; this is needed for mark
                                          * buffer component handle comparison
                                          * in MMI to check whether it is the
                                          * mark buffer target component.
                                          */

   OMX_U32           nPortIndex;          /**<
                                          * This is port index of the port
                                          * on this component.
                                          */

   OMX_U32           nTunneledPortIndex;  /**<
                                          * This is port index of the peer
                                          * port on the tunneled component.
                                          */

   MMI_DeviceType   *pDeviceApi;          /**<
                                          * This is the pointer to the
                                          * (vendor-tunneling specifc) device
                                          * API table for the tunneled
                                          * component.
                                          */

   OMX_HANDLETYPE    hDevice;             /**<
                                          * This is the pointer to the device
                                          * handle for the tunneled component.
                                          */

} QOMX_ParamVendorTunnelSetup;


/**
 *
 *  This enumeration contains extension indexes used by base class.
 *  MMI must not use indexes within the range of 0x7FFFF000 ~ 0x7FFFFFFE
 *
 */

typedef enum
{
   /**------------------------------------------------------------------------
      Lower bound for Parameter extensions defined by base class.
      All Parameter extension indexes must fall between
      QOMX_IndexParamStartUnused & QOMX_IndexConfigStartUnused.
   -------------------------------------------------------------------------*/
   QOMX_IndexParamStartUnused = 0x7FFFF000,

   /*-----------------------------------------------------------------------*/

   QOMX_IndexParamVendorTunnelDevice,  /**<
                                       * Custom OMX parameter value used to
                                       * get the Vendor Tunnel Device info
                                       * from component. This is read only
                                       * parameter.
                                       * Associated Parameter Name:
                                       * QOMX_PARAM_NAME_VENDOR_TUNNEL_DEVICE
                                       */

   QOMX_IndexParamVendorTunnelEnabled, /**<
                                       * Custom OMX parameter value used to
                                       * set the Vendor Tunnel Setup status
                                       * info for a component. This is write
                                       * only parameter.
                                       * Associated Parameter Name:
                                       * QOMX_PARAM_NAME_VENDOR_TUNNEL_ENABLED
                                       */

   QOMX_IndexParamPortThroughput,      /**<
                                       * Custom OMX parameter value used to
                                       * get the Port Throughput data info
                                       * info for a component. This is read
                                       * only parameter.
                                       * Associated Parameter Name:
                                       * QOMX_PARAM_NAME_PORT_THROUGHPUT
                                       */

   /**------------------------------------------------------------------------
      Lower bound for Configuration extensions defined by base class.
      All Config extension indexes must fall between
      QOMX_IndexConfigStartUnused & QOMX_IndexConfigMax.
   -------------------------------------------------------------------------*/
   QOMX_IndexConfigStartUnused = 0x7FFFF7FF,

   /*-----------------------------------------------------------------------*/

   QOMX_IndexConfigDebugMsg,           /**<
                                       * Enable/disable printing messages
                                       * (low, med, high, error) and component
                                       * name for this base class instance.
                                       * Associated Parameter Name:
                                       * QOMX_CONFIG_NAME_DEBUG_MSG
                                       */

   /**------------------------------------------------------------------------
      Upper bound for all base class extension indexes.
   -------------------------------------------------------------------------*/
   QOMX_IndexConfigMax = 0x7FFFFFFE

} QOMX_IndexType;


/**
 *
 * Following stucture holds the configuration for various debug messages that
 * base class prints.
 *
 */

typedef struct
{
   OMX_U8               nDebugMsgLevelFlags;
                                          /**
                                          * Level of debug messages for this
                                          * instance of base class.
                                          * Default Setting:
                                          * QOMX_DEBUG_MSG_LEVEL_ENABLE_ALL
                                          */

   OMX_U8               acCustomName[ OMX_MAX_STRINGNAME_SIZE ];
                                          /**
                                          * Custom name which can be prefixed
                                          * before component handle. This is
                                          * useful when large component names
                                          * need to be trimmed so that overall
                                          * message length can be reduced.
                                          * If it is specified as NULL, by
                                          * default, base class will pick full
                                          * component name for printing.
                                          * Maximum length = 127 bytes.
                                          */

} QOMX_DebugMsgPropType;


/**
 *
 * Following stucture holds the device table, device instance, application
 * callbacks, data, component handle etc. which are referred by both
 * Component and Port implementations for communication with the device
 * and the application.
 *
 */

typedef struct
{
   /**------------------------------------------------------------------------
      Component characterstics.
   -------------------------------------------------------------------------*/

   OMX_U8                     acCmpntName[ OMX_MAX_STRINGNAME_SIZE ];
                                             /**<
                                             * Component name.
                                             */

   OMX_UUIDTYPE               cmpntUUID;     /**<
                                             * Component UUID.
                                             */

   OMX_HANDLETYPE             hCmpnt;        /**<
                                             * Component handle to be refered
                                             * back for callback processing.
                                             * Component handle allocation is
                                             * done by the core before calling
                                             * GetHandle.
                                             */

   /**------------------------------------------------------------------------
      Client characterstics.
   -------------------------------------------------------------------------*/

   OMX_CALLBACKTYPE           clientCB;      /**<
                                             * Call back functions registered
                                             * by the OMX IL client.
                                             */

   OMX_PTR                    pAppData;      /**<
                                             * Application Data pointer.
                                             */

   /**------------------------------------------------------------------------
      MMI characterstics.
   -------------------------------------------------------------------------*/

   MMI_DeviceType             device;        /**<
                                             * Primitive table for the device.
                                             * All device access funtions are
                                             * contained in this.
                                             */

   OMX_HANDLETYPE             hFd;           /**<
                                             * Unique handle to the underlying
                                             * device.
                                             */

   /**------------------------------------------------------------------------
      Other characterstics.
   -------------------------------------------------------------------------*/

   OMX_HANDLETYPE             hHeap;         /**<
                                             * Heap handle to be refered back
                                             * for memory all allocations and
                                             * de-allocations.
                                             */

   QDFC_HandleType            hDfc;          /**<
                                             * Unique handle to the DFC queue
                                             * which will be used to post
                                             * events to the IL client.
                                             */

   MMI_GetHeapHandleType      pfnGetHeapHandle;       /**<
                                                       * Funciton pointer to
                                                       * GetHeapHandle routine.
                                                       */

   MMI_ReleaseHeapHandleType  pfnReleaseHeapHandle;   /**<
                                                       * Funciton pointer to
                                                       * ReleaseHeapHanle routine.
                                                       */

   MMI_MallocType             pfnMalloc;              /**<
                                                       * Funciton pointer to
                                                       * Malloc routine.
                                                       */

   MMI_FreeType               pfnFree;                /**<
                                                       * Funciton pointer to
                                                       * Free routine.
                                                       */

   /**------------------------------------------------------------------------
      For Deubugging.
   -------------------------------------------------------------------------*/

   QOMX_DebugMsgPropType      debugMsgProp;  /**<
                                             * Debug messages configuration
                                             * for this instance of base class.
                                             */

} QOMX_CommonRefType;



/* -----------------------------------------------------------------------
** Functions
** ----------------------------------------------------------------------- */


/*==========================================================================

         FUNCTION:      qomx_GetOMXErrorCode

         DESCRIPTION:
                        This function returns an appropriate OMX error code
                        corresponding to a device error code.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  nDevErrorCode  - Device error code.

**//*    RETURN VALUE:
*//**       @return
                        OMX Error code - As appropriate.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_GetOMXErrorCode
(
   OMX_IN   int   nDevErrorCode
);


/*==========================================================================

         FUNCTION:      qomx_GetQOMXBaseEventCode

         DESCRIPTION:
                        This function returns an appropriate QOMX base class
                        event code corresponding to a device event code.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  nDevEventCode  - Device event code.

**//*    RETURN VALUE:
*//**       @return
                        QOMX Base class event code - As appropriate.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_U8   qomx_GetQOMXBaseEventCode
(
   OMX_IN   int   nDevEventCode
);


/*==========================================================================

         FUNCTION:      qomx_CmpntFillBufferDone

         DESCRIPTION:
                        This function is used to send fill buffer done
                        response through the IL registered callback
                        FillBufferDone.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[in]  pBufferHdr  - Pointer to the buffer header associated
                                      with the fill buffer done response.

**//*    RETURN VALUE:
*//**       @return     OMX_ERROR_CS_RELEASED

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntFillBufferDone
(
   OMX_IN   QOMX_CommonRefType     *pCommonRef,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr
);


/*==========================================================================

         FUNCTION:      qomx_CmpntEmptyBufferDone

         DESCRIPTION:
                        This function is used to send empty buffer done
                        response through the IL registered callback
                        EmptyBufferDone.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[in]  pBufferHdr  - Pointer to the buffer header associated
                                      with the empty buffer done response.

**//*    RETURN VALUE:
*//**       @return     OMX_ERROR_CS_RELEASED

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntEmptyBufferDone
(
   OMX_IN   QOMX_CommonRefType     *pCommonRef,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr
);


/*==========================================================================

         FUNCTION:      qomx_CmpntNotifyEvent

         DESCRIPTION:
                        This function is used to send a notification to the
                        application on an event.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[in]  eEvent      - Refer 'EventHandler' in OMX_Core.h or
                                      IL spec.
            @param[in]  nData1      - Refer 'EventHandler' in OMX_Core.h or
                                      IL spec.
            @param[in]  nData2      - Refer 'EventHandler' in OMX_Core.h or
                                      IL spec.
            @param[in]  pEventData  - Refer 'EventHandler' in OMX_Core.h or
                                      IL spec.

**//*    RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntNotifyEvent
(
   OMX_IN   QOMX_CommonRefType     *pCommonRef,
   OMX_IN   OMX_EVENTTYPE           eEvent,
   OMX_IN   OMX_U32                 nData1,
   OMX_IN   OMX_U32                 nData2,
   OMX_IN   OMX_PTR                 pEventData
);


/*==========================================================================

         FUNCTION:      qomx_CmpntCmdComplete

         DESCRIPTION:
                        This function is used to send a command complete
                        notification to the application for the given
                        command.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[in]  nData1      - Refer 'EventHandler' in OMX_Core.h or
                                      IL spec.
            @param[in]  nData2      - Refer 'EventHandler' in OMX_Core.h or
                                      IL spec.
            @param[in]  pEventData  - Refer 'EventHandler' in OMX_Core.h or
                                      IL spec.

**//*    RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntCmdComplete
(
   OMX_IN   QOMX_CommonRefType     *pCommonRef,
   OMX_IN   OMX_U32                 nData1,
   OMX_IN   OMX_U32                 nData2,
   OMX_IN   OMX_PTR                 pEventData
);


/*==========================================================================

         FUNCTION:      qomx_CmpntNotifyError

         DESCRIPTION:
                        This function is used to send a notification to the
                        application on an event.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[in]  eError      - Error code associated with this
                                      notification.

**//*    RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntNotifyError
(
   OMX_IN   QOMX_CommonRefType     *pCommonRef,
   OMX_IN   OMX_ERRORTYPE           eError
);


/*==========================================================================

         FUNCTION:      qomx_CmpntStateSetInvalid

         DESCRIPTION:
                        This function is used to set the QOMX state of the
                        component to Invalid. This function should be called
                        only when an irrecoverable error is detected.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt   - Component Handle.
            @param[in]  nEvent   - Uniqueue event code.

**//*    RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntStateSetInvalid
(
   OMX_IN   OMX_HANDLETYPE    hCmpnt,
   OMX_IN   OMX_U8            nEvent
);


/*==========================================================================

         FUNCTION:      qomx_CmpntGetQOMXState

         DESCRIPTION:
                        This function is used to get the QOMX state of the
                        component.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hCmpnt      - Component Handle.

**//*    RETURN VALUE:
*//**       @return     QOMX_CmpntStateType enum as appropriate.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
QOMX_CmpntStateType  qomx_CmpntGetQOMXState
(
   OMX_IN   OMX_HANDLETYPE          hCmpnt
);


/*==========================================================================

         FUNCTION:      qomx_CmpntLockContext

         DESCRIPTION:
*//**                   This function is used to lock the component context.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  hCmpnt      - Component Handle.

**//*     RETURN VALUE:
*//**                   None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntLockContext
(
   OMX_IN   OMX_HANDLETYPE          hCmpnt
);


/*==========================================================================

         FUNCTION:      qomx_CmpntUnlockContext

         DESCRIPTION:
*//**                   This function is used to unlock the component context.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  hCmpnt      - Component Handle.

**//*     RETURN VALUE:
*//**                   None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntUnlockContext
(
   OMX_IN   OMX_HANDLETYPE          hCmpnt
);


/*==========================================================================

         FUNCTION:      qomx_CmpntValidateHandle

         DESCRIPTION:
                        This function checks for the validity of the component
                        handle passed to it.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pComp       - Pointer to the component context.
                        bCallback   - Whether callback validation is required.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on successful validation.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntValidateHandle
(
   OMX_IN   OMX_COMPONENTTYPE   *pComp,
   OMX_IN   OMX_BOOL             bCallback
);


#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */

#endif /* end of macro __QOMX_COMMON_H__ */
