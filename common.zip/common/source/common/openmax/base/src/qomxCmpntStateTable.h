#ifndef __QOMX_CMPNT_STATE_TABLE_H__
#define __QOMX_CMPNT_STATE_TABLE_H__

/*========================================================================

*//** @file qomxCmpntStateTable.h

@par FILE SERVICES:       
      Component State Primitive Table Header File
      
      This file contains the declarations for component function pointers
      table which is used by every state implementation for defining
      the component behaviour on a particular operation.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2010 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCmpntStateTable.h#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
06/10/10   dm     Added return type in event handler.
06/12/09   dm     Initial creation.

========================================================================== */

/*======================================================================== 
 
                     INCLUDE FILES FOR MODULE 
 
========================================================================== */
#include "qomxCmpntContext.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */


/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 *
 *  This function is invoked by the device into the IL client. IL base class
 *  registers this function into the device layer.
 *  
 *  Device realizes this by setting up a signal or message queue with the
 *  kernel mode driver ( if one exists ).
 *
 *  @param [in] pCmpntCtx  - Component state machine context.
 *  @param [in] nEventCode - Unique event code which is generally assoicated
 *                           with a command sent to the device.
 *  @param [in] nEventStatus
 *                         - Event status code which was the result of the
 *                           command. This is valid when the event is a
 *                           response to a command. In general if this event
 *                           code is not valid the device should set it to
 *                           MMI_S_COMPLETE. This avoids unnecessary
 *                           confusion and graph tier down as a result from
 *                           base class.
 *  @param [in] nParamSize - Size in bytes for the event related data,
 *                           which is saved in the passed pointer.
 *  @param [in] pParam     - Event related payload. 
 *                           
 */

typedef OMX_ERRORTYPE ( *QOMX_CmpntDeviceEventCallbackType )
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
);


/**
 *
 *  This is the function which is invoked every time a state is entered.
 *  Entry into the state should contain all event agnostic execution.
 *  
 *  @param [in] pCmpntCtx  - Component state machine context.
 *  @param [in] nEvent     - Unique code relating the API or trigger which
 *                           caused the transition.
 *
 */

typedef void ( *QOMX_CmpntStateEntryHandlerType )
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
);


/*
 *
 *  This is the function which is invoked every time a state is exited. This 
 *  should contain all event agnostic execution upon exit out of the state.
 *
 *  @param [in] pCmpntCtx  - Component state machine context.
 *  @param [in] nEvent     - Unique code relating the API or trigger which
 *                           caused the transition.
 */

typedef void ( *QOMX_CmpntStateExitHandlerType )
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
);


/** 
 *
 * The structure contains the state function table for OMX IL main state 
 * machine. 
 *  
 * 3 kind of state handler functions 
 *  
 * 1) OMX input functions 
 * 2) Device or internal events 
 * 3) State management a) Entry and b) Exit 
 *                       
 */

typedef struct
{
   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/

   /**<
   * Refer to OMX_GetComponentVersion in OMX_Core.h or the OMX IL 
   * specification for details on the GetComponentVersion method.
   */
   OMX_ERRORTYPE ( *GetComponentVersion ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_OUT     OMX_STRING              pComponentName,
         OMX_OUT     OMX_VERSIONTYPE        *pComponentVersion,
         OMX_OUT     OMX_VERSIONTYPE        *pSpecVersion,
         OMX_OUT     OMX_UUIDTYPE           *pComponentUUID );

   /**<
   * Refer to OMX_SendCommand in OMX_Core.h or the OMX IL 
   * specification for details on the SendCommand method.
   */
   OMX_ERRORTYPE ( *SendCommand ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_IN      OMX_COMMANDTYPE         eCmd,
         OMX_IN      OMX_U32                 nParam,
         OMX_IN      OMX_PTR                 pCmdData );

   /**<
   * Refer to OMX_GetParameter in OMX_Core.h or the OMX IL 
   * specification for details on the GetParameter method.
   */
   OMX_ERRORTYPE ( *GetParameter ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_IN      OMX_INDEXTYPE           nParamIndex,
         OMX_INOUT   OMX_PTR                 pCmpntParm );

   /**<
   * Refer to OMX_SetParameter in OMX_Core.h or the OMX IL 
   * specification for details on the SetParameter method.
   */
   OMX_ERRORTYPE ( *SetParameter ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_IN      OMX_INDEXTYPE           nParamIndex,
         OMX_IN      OMX_PTR                 pCmpntParm );

   /**<
   * Refer to OMX_GetConfig in OMX_Core.h or the OMX IL 
   * specification for details on the GetConfig method.
   */
   OMX_ERRORTYPE ( *GetConfig ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_IN      OMX_INDEXTYPE           nConfigIndex,
         OMX_INOUT   OMX_PTR                 pCmpntCfg );

   /**<
   * Refer to OMX_SetConfig in OMX_Core.h or the OMX IL 
   * specification for details on the SetConfig method.
   */
   OMX_ERRORTYPE ( *SetConfig ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_IN      OMX_INDEXTYPE           nConfigIndex,
         OMX_IN      OMX_PTR                 pCmpntCfg );

   /**<
   * Refer to OMX_GetExtensionIndex in OMX_Core.h or the OMX IL 
   * specification for details on the GetExtensionIndex method.
   */
   OMX_ERRORTYPE ( *GetExtensionIndex ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_IN      OMX_STRING              cParameterName,
         OMX_OUT     OMX_INDEXTYPE          *pIndexType );

   /**<
   * Refer to OMX_GetState in OMX_Core.h or the OMX IL 
   * specification for details on the GetState method.
   */
   OMX_ERRORTYPE ( *GetState ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_OUT     OMX_STATETYPE          *pState );

   /**<
   * Refer to OMX_SetupTunnel in OMX_Core.h or the OMX IL 
   * specification for details on the ComponentTunnelRequest method.
   */
   OMX_ERRORTYPE ( *ComponentTunnelRequest ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_IN      OMX_U32                 nPort,
         OMX_IN      OMX_HANDLETYPE          hTunneledComp,
         OMX_IN      OMX_U32                 nTunneledPort,
         OMX_INOUT   OMX_TUNNELSETUPTYPE    *pTunnelSetup ); 

   /**<
   * Refer to OMX_UseBuffer in OMX_Core.h or the OMX IL 
   * specification for details on the UseBuffer method.
   */
   OMX_ERRORTYPE ( *UseBuffer ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_OUT     OMX_BUFFERHEADERTYPE  **ppBufferHdr,
         OMX_IN      OMX_U32                 nPortIndex,
         OMX_IN      OMX_PTR                 pAppPrivate,
         OMX_IN      OMX_U32                 nSizeBytes,
         OMX_IN      OMX_U8                 *pBuffer );

   /**<
   * Refer to OMX_AllocateBuffer in OMX_Core.h or the OMX IL 
   * specification for details on the AllocateBuffer method.
   */
   OMX_ERRORTYPE ( *AllocateBuffer ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_OUT     OMX_BUFFERHEADERTYPE  **ppBufferHdr,
         OMX_IN      OMX_U32                 nPortIndex,
         OMX_IN      OMX_PTR                 pAppPrivate,
         OMX_IN      OMX_U32                 nSizeBytes );

   /**<
   * Refer to OMX_FreeBuffer in OMX_Core.h or the OMX IL 
   * specification for details on the FreeBuffer method.
   */
   OMX_ERRORTYPE ( *FreeBuffer ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_IN      OMX_U32                 nPortIndex,
         OMX_IN      OMX_BUFFERHEADERTYPE   *pBufferHdr );

   /**<
   * Refer to OMX_EmptyThisBuffer in OMX_Core.h or the OMX IL 
   * specification for details on the EmptyThisBuffer method.
   */
   OMX_ERRORTYPE ( *EmptyThisBuffer ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_IN      OMX_BUFFERHEADERTYPE   *pBufferHdr );

   /**<
   * Refer to OMX_EmptyThisBuffer in OMX_Core.h or the OMX IL 
   * specification for details on the EmptyThisBuffer method.
   */
   OMX_ERRORTYPE ( *FillThisBuffer ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_IN      OMX_BUFFERHEADERTYPE   *pBufferHdr );

   /**<
   * The SetCallbacks method is used by the core to specify the callback
   * structure from the application to the component. This is a blocking
   * call. The component will return from this call within 5 msec.
   *    @param [in] hComponent
   *        Handle of the component to be accessed.  This is the component
   *        handle returned by the call to the GetHandle function.
   *    @param [in] pCallbacks
   *        Pointer to an OMX_CALLBACKTYPE structure used to provide the 
   *        callback information to the component.
   *    @param [in] pAppData
   *        Pointer to an application defined value.  It is anticipated that 
   *        the application will pass a pointer to a data structure or a "this
   *        pointer" in this area to allow the callback (in the application)
   *        to determine the context of the call.
   *    @return OMX_ERRORTYPE
   *        If the command successfully executes, the return code will be
   *        OMX_ErrorNone. Otherwise the appropriate OMX error will be
   *        returned.
   */
   OMX_ERRORTYPE ( *SetCallbacks ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_IN      OMX_CALLBACKTYPE       *pCallbacks,
         OMX_IN      OMX_PTR                 pAppData );

   /**<
   * ComponentDeInit method is used to deinitialize the component providing
   * a means to free any resources allocated at component initialization.
   * NOTE: After this call the component handle is not valid for further use.
   *    @param [in] hComponent
   *        Handle of the component to be accessed.  This is the component
   *        handle returned by the call to the GetHandle function.
   *    @return OMX_ERRORTYPE
   *        If the command successfully executes, the return code will be
   *        OMX_ErrorNone. Otherwise the appropriate OMX error will be
   *        returned.
   */
   OMX_ERRORTYPE ( *ComponentDeInit ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx );

   /**<
   * Refer to OMX_UseEGLImage in OMX_Core.h or the OMX IL 
   * specification for details on the UseEGLImage method.
   */
   OMX_ERRORTYPE ( *UseEGLImage ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_INOUT   OMX_BUFFERHEADERTYPE  **ppBufferHdr,
         OMX_IN      OMX_U32                 nPortIndex,
         OMX_IN      OMX_PTR                 pAppPrivate,
         OMX_IN      void                   *eglImage );

   /**<
   * Refer to OMX_ComponentRoleEnum in OMX_Core.h or the OMX IL 
   * specification for details on the ComponentRoleEnum method.
   */
   OMX_ERRORTYPE ( *ComponentRoleEnum ) (
         OMX_IN      QOMX_CmpntCtxType      *pCmpntCtx,
         OMX_OUT     OMX_U8                 *cRole,
         OMX_IN      OMX_U32                 nIndex );

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/

   /**<
   * This function is invoked by the device into the IL client.
   */
   QOMX_CmpntDeviceEventCallbackType   pfnEventHandler;


   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/

   /**<
   * This function is invoked by every time a state is entered.
   */
   QOMX_CmpntStateEntryHandlerType     pfnEntryHandler;   

   /**<
   * This function is invoked by every time a state is entered.
   */
   QOMX_CmpntStateExitHandlerType      pfnExitHandler;

   
} QOMX_CmpntStateTableType;


#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */

#endif /* end of macro __QOMX_CMPNT_STATE_TABLE_H__ */
