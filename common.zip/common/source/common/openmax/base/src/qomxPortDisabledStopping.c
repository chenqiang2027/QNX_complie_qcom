/*========================================================================

*//** @file qomxPortDisabledStopping.c

@par FILE SERVICES:
      Implementation file for Port state QOMX_StatePortDisabledStopping.

      This file contains the definitions for the port methods which are
      called when port state is QOMX_StatePortDisabledStopping. This
      state is assumed when port is processing disable command and buffers
      are being released.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxPortDisabledStopping.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
10/23/13   dp     Add missing variable to messages.
08/05/10   yt     Refactoring of disable procedure for tunneling.
03/26/10   dm     Initial Creation.

========================================================================== */

/*========================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxPortCommon.h"
#include "qomxPortUtils.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/**
 *
 * Forward declaration for the functions defined statically in this file.
 *
 */

static void    qomx_PortDisabledStopping_StateEntryHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
);

static void    qomx_PortDisabledStopping_StateExitHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
);

static OMX_ERRORTYPE    qomx_PortDisabledStopping_EmptyThisBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE         *pBufferHdr
);

static OMX_ERRORTYPE    qomx_PortDisabledStopping_FillThisBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE         *pBufferHdr
);

static OMX_ERRORTYPE    qomx_PortDisabledStopping_DeviceEventHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEventCode,
   OMX_IN   OMX_U32                       nEventStatus,
   OMX_IN   OMX_U32                       nParamSize,
   OMX_IN   OMX_PTR                      *pParam
);


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_PortDisabledStopping_LoadStateTable

         DESCRIPTION:
                        This function will load the port state table
                        supported by the QOMX_StatePortDisabledStopping
                        state in the object of state table being passed.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable    - Pointer to the state primitive table
                                      object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortDisabledStopping_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType      *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      port is in QOMX_StatePortDisabledStopping state. NULL entry
      indicates that the specific function call is not allowed in this state,
      thus port utilities should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/
   pStTable->Enable           = NULL;
   pStTable->Disable          = NULL;
   pStTable->TunnelRequest    = NULL;
   pStTable->Populate         = NULL;
   pStTable->Unpopulate       = NULL;
   pStTable->Run              = NULL;
   pStTable->Stop             = NULL;
   pStTable->UseBuffer        = NULL;
   pStTable->AllocateBuffer   = NULL;
   pStTable->FreeBuffer       = qomx_PortCommon_FreeBuffer;
   pStTable->EmptyThisBuffer  = qomx_PortDisabledStopping_EmptyThisBuffer;
   pStTable->FillThisBuffer   = qomx_PortDisabledStopping_FillThisBuffer;
   pStTable->Flush            = NULL;
   pStTable->DeInit           = qomx_PortCommon_DeInit;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler
                     = qomx_PortDisabledStopping_DeviceEventHandler;

   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler
                     = qomx_PortDisabledStopping_StateEntryHandler;
   pStTable->pfnExitHandler
                     = qomx_PortDisabledStopping_StateExitHandler;

   return;

} /* end of function qomx_PortDisabledStopping_LoadStateTable */


/*==========================================================================

         FUNCTION:      qomx_PortDisabledStopping_StateEntryHandler

         DESCRIPTION:
*//**                   This function executes initial routines when port
                        moves in QOMX_StatePortDisabledPopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the Port context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_PortDisabledStopping_StateEntryHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
)
{
   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Entering DisabledStopping"
      " State, nPortIndex = 0x%x, nEvent = 0x%x",
      pPortCtx->portDef.nPortIndex, nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pPortCtx->eState = QOMX_StatePortDisabledStopping;

   /**------------------------------------------------------------------------
      If no buffers to wait or return, proceed to depopulating state.
   -------------------------------------------------------------------------*/
   ( void ) qomx_PortCommon_CheckStop( pPortCtnr, pPortCtx );

   return;

} /* end of function qomx_PortDisabledStopping_StateEntryHandler */


/*==========================================================================

         FUNCTION:      qomx_PortDisabledStopping_StateExitHandler

         DESCRIPTION:
*//**                   This function executes initial routines when port
                        moves out of QOMX_StatePortDisabledPopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the Port context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_PortDisabledStopping_StateExitHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
)
{
   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Exiting DisabledStopping"
      " State, nPortIndex = 0x%x, nEvent = 0x%x",
      pPortCtx->portDef.nPortIndex, nEvent );

   return;

} /* end of function qomx_PortDisabledStopping_StateExitHandler */

/*==========================================================================

         FUNCTION:      qomx_PortDisabledStopping_EmptyThisBuffer

         DESCRIPTION:
*//**                   This function processes empty this buffer request when
                        port is in QOMX_StatePortDisabledStopping state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.
@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortDisabledStopping_EmptyThisBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE         *pBufferHdr
)
{
   OMX_ERRORTYPE        eRetVal        = OMX_ErrorNone;
   QMM_ListHandleType  *pHBufHdrQueue  = & ( pPortCtx->hBufHdrQueue );
   QOMX_CommonRefType  *pCommonRef     = pPortCtnr->pCommonRef;
   QMM_ListErrorType    eListRetVal;
   QMM_ListLinkType    *pQueueLink;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_PortDisabledStopping_EmptyThisBuffer, nPortIndex = 0x%x",
      pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      In stopping state, ETB/FTB should only be accepted by a tunneling
      supplier.
   -------------------------------------------------------------------------*/
   if( ( PORT_TUNNELING_DISABLED != pPortCtx->eTunneling )
         && ( PORT_TUNNELING_VENDOR != pPortCtx->eTunneling )
         && ( QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx ) ) )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Port is tunnel supplier." );

      /**---------------------------------------------------------------------
         Search this buffer in queue.
      ----------------------------------------------------------------------*/
      eListRetVal = qmm_ListSearch(
                           pHBufHdrQueue, qomx_PortCommon_BufferHdrLinkCmp,
                           ( void * ) pBufferHdr, & pQueueLink );

      if( QMM_LIST_ERROR_NOT_PRESENT == eListRetVal )
      {
         QOMX_MSG_L_ERROR( pCommonRef,
            "Buffer header not found in list." );

         /**------------------------------------------------------------------
            Link is not found in buffer queue, it may not be belonging to the
            current port, return bad parameter error.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorBadParameter;

      }
      else if( QMM_LIST_ERROR_PRESENT != eListRetVal )
      {
         QOMX_MSG_L_ERROR( pCommonRef,
            "Corruption detected in the list." );

         /**------------------------------------------------------------------
            Queue is corrupted, Component should move into an invalid state
            which is not recoverable now.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorInvalidState;

      }
      else
      {
         /**------------------------------------------------------------------
            Reduce buffer count that is with the client.
         -------------------------------------------------------------------*/
         pPortCtx->nBuffersWithClient--;

         QOMX_MSG_L_HIGH( pCommonRef, "Client buffer count = 0x%x.",
            pPortCtx->nBuffersWithClient );

         /**------------------------------------------------------------------
            Process buffer header.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_ProcessBufferHeader( pPortCtnr,
                           pPortCtx, pBufferHdr, MMI_CMD_EMPTY_THIS_BUFFER );

         /**------------------------------------------------------------------
            If port is stopping, complete it when buffer count reaches zero.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_CheckStop( pPortCtnr, pPortCtx );

      }

   }
   else
   {
      QOMX_MSG_L_HIGH( pCommonRef,
         "Not tunnel supplier, command rejected." );

      eRetVal = OMX_ErrorIncorrectStateOperation;
   }

   /**------------------------------------------------------------------------
      Move component to Invalid state on fatal error.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorInvalidState == eRetVal )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Fatal error." );

      ( void ) qomx_CmpntStateSetInvalid(
                              pCommonRef->hCmpnt, QOMX_EVENT_UNKNOWN );

   }

   return( eRetVal );

} /* end of function qomx_PortDisabledStopping_EmptyThisBuffer */

/*==========================================================================

         FUNCTION:      qomx_PortDisabledStopping_FillThisBuffer

         DESCRIPTION:
*//**                   This function processes fill this buffer request when
                        port is in QOMX_StatePortDisabledStopping state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortDisabledStopping_FillThisBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE         *pBufferHdr
)
{
   OMX_ERRORTYPE        eRetVal        = OMX_ErrorNone;
   QMM_ListHandleType  *pHBufHdrQueue  = & ( pPortCtx->hBufHdrQueue );
   QOMX_CommonRefType  *pCommonRef     = pPortCtnr->pCommonRef;
   QMM_ListErrorType    eListRetVal;
   QMM_ListLinkType    *pQueueLink;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_PortDisabledStopping_FillThisBuffer, nPortIndex = 0x%x",
      pPortCtx->portDef.nPortIndex );

   /**------------------------------------------------------------------------
      In stopping state, ETB/FTB should only be accepted by a tunneling
      supplier.
   -------------------------------------------------------------------------*/
   if( ( PORT_TUNNELING_DISABLED != pPortCtx->eTunneling )
         && ( PORT_TUNNELING_VENDOR != pPortCtx->eTunneling )
         && ( QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx ) ) )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Port is tunnel supplier." );

      /**---------------------------------------------------------------------
         Search this buffer in queue.
      ----------------------------------------------------------------------*/
      eListRetVal = qmm_ListSearch(
                           pHBufHdrQueue, qomx_PortCommon_BufferHdrLinkCmp,
                           ( void * ) pBufferHdr, & pQueueLink );

      if( QMM_LIST_ERROR_NOT_PRESENT == eListRetVal )
      {
         QOMX_MSG_L_ERROR( pCommonRef,
            "Buffer header not found in list." );

         /**------------------------------------------------------------------
            Link is not found in buffer queue, it may not be belonging to the
            current port, return bad parameter error.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorBadParameter;

      }
      else if( QMM_LIST_ERROR_PRESENT != eListRetVal )
      {
         QOMX_MSG_L_ERROR( pCommonRef,
            "Corruption detected in the list." );

         /**------------------------------------------------------------------
            Queue is corrupted, Component should move into an invalid state
            which is not recoverable now.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorInvalidState;

      }
      else
      {
         /**------------------------------------------------------------------
            Reduce buffer count that is with the client.
         -------------------------------------------------------------------*/
         pPortCtx->nBuffersWithClient--;

         QOMX_MSG_L_HIGH( pCommonRef, "Client buffer count = 0x%x.",
            pPortCtx->nBuffersWithClient );

         /**------------------------------------------------------------------
            Process buffer header.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_ProcessBufferHeader( pPortCtnr,
                           pPortCtx, pBufferHdr, MMI_CMD_FILL_THIS_BUFFER );

         /**------------------------------------------------------------------
            If port is stopping, complete it when buffer count reaches zero.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_CheckStop( pPortCtnr, pPortCtx );

      }

   }
   else
   {
      QOMX_MSG_L_HIGH( pCommonRef,
         "Not tunnel supplier, command rejected." );

      eRetVal = OMX_ErrorIncorrectStateOperation;
   }

   /**------------------------------------------------------------------------
      Move component to Invalid state on fatal error.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorInvalidState == eRetVal )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Fatal error." );

      ( void ) qomx_CmpntStateSetInvalid(
                              pCommonRef->hCmpnt, QOMX_EVENT_UNKNOWN );

   }

   return( eRetVal );

} /* end of function qomx_PortDisabledStopping_FillThisBuffer */

/*==========================================================================

         FUNCTION:      qomx_PortDisabledStopping_DeviceEventHandler

         DESCRIPTION:
*//**                   This function processes events from device when port
                        is in QOMX_StatePortDisabledStopping state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  nEventCode  - Event code.
            @param [in] nEventStatus- Status of the event.
            @param [in] nParamSize  - Size in bytes for the event related
                                      data which is pointed by the payload.
            @param [in] pParam      - Event related payload.

**//*     RETURN VALUE:
                        OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortDisabledStopping_DeviceEventHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEventCode,
   OMX_IN   OMX_U32                       nEventStatus,
   OMX_IN   OMX_U32                       nParamSize,
   OMX_IN   OMX_PTR                      *pParam
)
{
   OMX_ERRORTYPE  eRetVal = OMX_ErrorNone;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
      "qomx_PortDisabledStopping_DeviceEventHandler, nPortIndex = 0x%x,"
      " nEventCode = 0x%x", pPortCtx->portDef.nPortIndex, nEventCode );

   /**------------------------------------------------------------------------
      Check event code.
   -------------------------------------------------------------------------*/
   switch( nEventCode )
   {
   case MMI_RESP_DISABLE_PORT:
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
            "Received disable port response." );

         /**------------------------------------------------------------------
            Handle disable command response.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_DisableResp(
                              pPortCtnr, pPortCtx, nEventStatus, OMX_FALSE );

      }

      break;

   case MMI_RESP_EMPTY_THIS_BUFFER:
      {
         MMI_BufferDoneMsgType *bufMsg = ( MMI_BufferDoneMsgType * ) pParam;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_LOW( pPortCtnr->pCommonRef,
            "Received Empty This Buffer response." );

         /**------------------------------------------------------------------
            Process empty this buffer response.
         -------------------------------------------------------------------*/
         eRetVal = qomx_PortCommon_EmptyThisBufferRespStopping( pPortCtnr,
                              pPortCtx, bufMsg->pBufferHdr, nEventStatus );

      }

      break;

   case MMI_RESP_FILL_THIS_BUFFER:
      {
         MMI_BufferDoneMsgType *bufMsg = ( MMI_BufferDoneMsgType * ) pParam;
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_LOW( pPortCtnr->pCommonRef,
            "Received Fill This Buffer response." );

         /**------------------------------------------------------------------
            Process fill this buffer response.
         -------------------------------------------------------------------*/
         eRetVal = qomx_PortCommon_FillThisBufferRespStopping( pPortCtnr,
                              pPortCtx, bufMsg->pBufferHdr, nEventStatus );

      }

      break;

   case MMI_RESP_FLUSH:
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
            "Received Flush response." );

         /**------------------------------------------------------------------
            Call internal function to process this flush response.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_DisableFlushResp( pPortCtnr, pPortCtx );

      }

      break;

   default:
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef,
            "Unexpected parameters in Device event: nEventCode = 0x%x, nPortIndex = 0x%x",
            nEventCode, pPortCtx->portDef.nPortIndex );

      }

      break;

   } /* end of switch( nEventCode ) */

   return( eRetVal );

} /* end of function qomx_PortDisabledStopping_DeviceEventHandler */
