#ifndef __QOMX_STATES_H__
#define __QOMX_STATES_H__

/*========================================================================

*//** @file qomxStates.h

@par FILE SERVICES:       
      Component State Machine Header File.
      
      This file contains the state machine which controls the OMX behavior 
      of Qualcomm components. This state machine is an adaptation of OMX 
      state machine as specified by Khronos to fit qualcomm driver model.

      This state machine is a flat state machine which comprises of 2 kinds 
      of states.
      
      1) OMX states. These are states documented by OMX spec.
      2) Component transitional states and port states which are not
         documented by OMX doc.
         These states are introduced to get a clean state machine with very 
         few flags or guard conditions.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2010 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxStates.h#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
07/15/10   yt     Added PortEnabledDepopulating state.
03/26/10   spl    Modified to support interop-profile.
10/14/09   dm     Split port states.
10/01/09   dm     Split component states.
06/12/09   dm     Redefined configuration structures.
05/01/09   srk    Initial Creation.

========================================================================== */

/*======================================================================== 
 
                     INCLUDE FILES FOR MODULE 
 
========================================================================== */

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 * 
 *  This enumeration contain OpenMax states and the internal states which
 *  are implemented for clarity of the internal states.
 *  States which are funcitonally equivalent to OMX states are called out the
 *  same way.
 *  NOTE: This enums must start with '0' and with increment of '1' only for
 *        each state, since state primitive tables are indexed based on these
 *        state enums.
 * 
 */

typedef enum
{
   /**------------------------------------------------------------------------
      State equivalent to OpenMax states which are documented in IL
      specification i.e. OMX_StateInvalid etc.
   -------------------------------------------------------------------------*/
   QOMX_StateInvalid = 0,                 /**<
                                          * Component has detected that it's
                                          * internal data structures are 
                                          * corrupted to the point that it can
                                          * not determine it's state properly.
                                          * State behaviour is equivalent to
                                          * OMX state 'OMX_StateInvalid'.
                                          * Refer OMX_Core.h for more details.
                                          */
   
   QOMX_StateLoaded,                      /**<
                                          * Component has been loaded but has
                                          * no resources allocated.
                                          * State behaviour is equivalent to
                                          * OMX state 'OMX_StateLoaded'.
                                          * Refer OMX_Core.h for more details.
                                          */

   QOMX_StateIdle,                        /**<
                                          * Component has all resources but has
                                          * not transferred any buffers or begun
                                          * processing data.
                                          * State behaviour is equivalent to
                                          * OMX state 'OMX_StateIdle'.
                                          * Refer OMX_Core.h for more details.
                                          */

   QOMX_StateExecuting,                   /**<
                                          * Devicet has accepted the start
                                          * command, Component is transferring
                                          * buffers and is processing data
                                          * ( if data is available ).
                                          * State behaviour is equivalent to
                                          * OMX state 'OMX_StateExecuting'.
                                          * Refer OMX_Core.h for more details.
                                          */

   QOMX_StatePause,                       /**<
                                          * Component data processing has been
                                          * paused but may be resumed from the
                                          * point it was paused.
                                          * State behaviour is equivalent to
                                          * OMX state OMX_StatePause.
                                          * Refer OMX_Core.h for more details.
                                          */

   QOMX_StateWaitForResources,            /**<
                                          * Component is waiting for resources
                                          * to become available either after
                                          * preemption.
                                          * State behaviour is equivalent to
                                          * OMX state
                                          * 'OMX_StateWaitForResources'.
                                          * Refer OMX_Core.h for more details.
                                          */

   /**------------------------------------------------------------------------
      Transitional states not documented in OpenMax IL specification. This
      states are assumed during transition from one OMX state to another
      where component waits for some processing to happen and complete
      before entering into the destination state.
   -------------------------------------------------------------------------*/
   QOMX_StateLoadedToIdle,                /**<
                                          * This state is entered when the IL
                                          * client instructs base class to
                                          * move to Idle state from Loaded
                                          * state or component start auto 
                                          * transition to Idle state from
                                          * WaitForResources state. Buffers
                                          * are assigned and resources are
                                          * allocated in this transitional
                                          * state.
                                          */

   QOMX_StateIdleToLoaded,                /**<
                                          * This state is entered when the IL
                                          * client instructs base class to
                                          * move to Loaded state from Idle
                                          * or WaitForResources state. All
                                          * buffers are released and the 
                                          * resources are deallocated in
                                          * this transitional state.
                                          */

   QOMX_StateIdleToExecuting,             /**<
                                          * This state is entered when the IL
                                          * client instructs base class to
                                          * move to Executing state from Idle
                                          * state.
                                          */

   QOMX_StateIdleToPause,                 /**<
                                          * This state is entered when the IL
                                          * client instructs base class to
                                          * move to Pause state from Idle
                                          * state.
                                          */

   QOMX_StateExecutingToIdle,             /**<
                                          * This state is entered when the IL
                                          * client instructs base class to
                                          * move to Idle state from Executing
                                          * or Pause state.
                                          * Note: Executing To Idle and Pause
                                          * To Idle mimics the same behavior
                                          * i.e. Stop the device and thus
                                          * states are merged into one.
                                          */

   QOMX_StateExecutingToPause,            /**<
                                          * This state is entered when the IL
                                          * client instructs base class to
                                          * move to Pause state from Executing
                                          * state.
                                          */

   QOMX_StatePauseToExecuting,            /**<
                                          * This state is entered when the IL
                                          * client instructs base class to
                                          * move to Executing state from Pause
                                          * state.
                                          */

   /**------------------------------------------------------------------------
      Upper bound for component states. No state enumerations are allowed
      after this bound.
   -------------------------------------------------------------------------*/
   QOMX_StateMax,                         /**<
                                          * This enum is used to define the
                                          * upper bound for component state
                                          * enumeration. All component states
                                          * must be defined between '0' and
                                          * this upper bound.
                                          */

} QOMX_CmpntStateType;



/**
 * 
 *  This enumeration contain QOMX Port internal states which are implemented
 *  for clarity of port transitions.
 *  NOTE: This enums must start with '0' and with increment of '1' only for
 *        each state, since state primitive tables are indexed based on these
 *        state enums.
 */

typedef enum
{
   QOMX_StatePortEnabledUnpopulated = 0,  /**<
                                          * Port has been enabled but it does
                                          * not have any buffer assigned. This
                                          * state is assumed when component is
                                          * initially loaded or component is 
                                          * moved back to Loaded state while
                                          * this port is enabled.
                                          */

   QOMX_StatePortEnabledPopulating,       /**< 
                                          * Port is enabled and the buffer
                                          * acquisition is in progress.
                                          */

   QOMX_StatePortEnabledDepopulating,     /**< 
                                          * Port is enabled and buffers
                                          * are being revoked.
                                          */

   QOMX_StatePortEnabledPopulated,        /**<
                                          * Port is enabled and all the 
                                          * buffers have been aquired.
                                          */

   QOMX_StatePortEnabledRunning,          /**<
                                          * Port is enabled and buffers are
                                          * being processed.
                                          */

   QOMX_StatePortEnabledStopping,         /**<
                                          * Port is enabled in the process
                                          * of stopping.
                                          */

   QOMX_StatePortDisabledDepopulating,    /**<
                                          * Port has been disabled and the 
                                          * buffers are being revoked.
                                          */

   QOMX_StatePortDisabledUnpopulated,     /**<
                                          * Port is disabled and all the 
                                          * buffers have been revoked.
                                          */

   QOMX_StatePortDisabledStopping,        /**<
                                          * Port is disabled in the process
                                          * of stopping.
                                          */

   /**------------------------------------------------------------------------
      Upper bound for port states. No state enumerations are allowed
      after this bound.
   -------------------------------------------------------------------------*/
   QOMX_StatePortMax,                     /**<
                                          * This enum is used to define the
                                          * upper bound for port state
                                          * enumeration. All port states must
                                          * be defined between '0' and
                                          * this upper bound.
                                          */

} QOMX_PortStateType;


#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */


#endif /* end of macro __QOMX_STATES_H__ */
