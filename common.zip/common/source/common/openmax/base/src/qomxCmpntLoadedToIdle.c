/*========================================================================

*//** @file qomxCmpntLoadedToIdle.c 

@par FILE SERVICES:       
      Component LoadedToIdle State Implementation File.

      This file implements all the methods which are applicable for
      LoadedToIdle state.
      
      Main functions are Send Command, AllocateBuffer, UseBuffer and
      FreeBuffer. Functions which are common for all states are 
      implemented in the common functions table.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCmpntLoadedToIdle.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
03/20/13   am     Rename QOMX_CONFIG_TUNNELEDPORTSTATUSTYPE and associated variables
                  to QC omx extension for 1.1.2
08/08/11   dm     Hardware critical error handling.
11/08/10   zm     Set vendor-tunneled port state to Populated after load
                  resource command succeeds, only if the port is enabled.
08/28/10   zm     Added support for vendor tunneling.
07/22/10   zm     Add component handle in each base class logging message.
07/15/10   yt     Special SetConfig handling for tunneling.
06/10/10   dm     Added return type in event handler.
03/26/10   spl    Modified to support interop-profile.
10/29/09   dm     Disallow port commands in component transitional states.
10/28/09   dm     Return same state error for WFR - WFR transition.
09/30/09   dm     Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxCmpntCommon.h"
#include "qomxPortUtils.h"

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 * 
 * Forward declaration for the functions statically defined in this file.
 * 
 */

static void    qomx_CmpntLoadedToIdle_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
);

static void    qomx_CmpntLoadedToIdle_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
   
);

static OMX_ERRORTYPE    qomx_CmpntLoadedToIdle_SendCommand
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE         eCmd,
   OMX_IN   OMX_U32                 nParam,
   OMX_IN   OMX_PTR                 pCmdData
);

static OMX_ERRORTYPE    qomx_CmpntLoadedToIdle_UseBuffer
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_OUT  OMX_BUFFERHEADERTYPE  **ppBufferHdr,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_IN   OMX_PTR                 pAppPrivate,
   OMX_IN   OMX_U32                 nSizeBytes,
   OMX_IN   OMX_U8*                 pBuffer
);

static OMX_ERRORTYPE    qomx_CmpntLoadedToIdle_AllocateBuffer
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_OUT  OMX_BUFFERHEADERTYPE  **ppBufferHdr,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_IN   OMX_PTR                 pAppPrivate,
   OMX_IN   OMX_U32                 nSizeBytes
);

static OMX_ERRORTYPE    qomx_CmpntLoadedToIdle_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
);

static void    qomx_CmpntLoadedToIdle_SetStateLoaded
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);

static void    qomx_CmpntLoadedToIdle_SetStateWFR
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);

static void    qomx_CmpntLoadedToIdle_UpdateResources
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);

static void    qomx_CmpntLoadedToIdle_LoadResourcesResp
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nStatus,
   OMX_IN   OMX_BOOL                bCmdStatus
);

static OMX_ERRORTYPE  qomx_CmpntLoadedToIdle_SetConfig
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE           nIndex, 
   OMX_IN   OMX_PTR                 pCmpntCfg
);


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_CmpntLoadedToIdle_LoadStateTable

         DESCRIPTION:
                        This function will load the component state table
                        supported by the LoadedToIdle state in the object of
                        state table being passed.
            
@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable    - Pointer to the state primitive table
                                      object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntLoadedToIdle_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      component is in QOMX_StateLoadedToIdle state. NULL entry indicates that
      the specific function call is not allowed in this state, thus component
      API should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/   
   pStTable->GetComponentVersion    = qomx_CmpntCommon_GetComponentVersion;
   pStTable->SendCommand            = qomx_CmpntLoadedToIdle_SendCommand;
   pStTable->GetParameter           = qomx_CmpntCommon_GetParameter;
   pStTable->SetParameter           = qomx_CmpntCommon_SetParameter;
   pStTable->GetConfig              = qomx_CmpntCommon_GetConfig;
   pStTable->SetConfig              = qomx_CmpntLoadedToIdle_SetConfig;
   pStTable->GetExtensionIndex      = qomx_CmpntCommon_GetExtensionIndex;
   pStTable->GetState               = qomx_CmpntCommon_GetState;
   pStTable->ComponentTunnelRequest = qomx_CmpntCommon_TunnelRequest;
   pStTable->UseBuffer              = qomx_CmpntLoadedToIdle_UseBuffer;
   pStTable->AllocateBuffer         = qomx_CmpntLoadedToIdle_AllocateBuffer;
   pStTable->FreeBuffer             = qomx_CmpntCommon_FreeBuffer;
   pStTable->EmptyThisBuffer        = NULL;
   pStTable->FillThisBuffer         = NULL;
   pStTable->SetCallbacks           = NULL;
   pStTable->ComponentDeInit        = qomx_CmpntCommon_ComponentDeInit;
   pStTable->UseEGLImage            = NULL;
   pStTable->ComponentRoleEnum      = qomx_CmpntCommon_ComponentRoleEnum;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler     
                        = qomx_CmpntLoadedToIdle_DeviceEventHandler;
   
   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler     
                        = qomx_CmpntLoadedToIdle_StateEntryHandler;
   pStTable->pfnExitHandler      
                        = qomx_CmpntLoadedToIdle_StateExitHandler;

   return;   

} /* end of function qomx_CmpntLoadedToIdle_LoadStateTable */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntLoadedToIdle_StateEntryHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateLoadedToIdle is entered. Entry into the state
                        performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntLoadedToIdle_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Entering LoadedToIdle State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Entering LoadedToIdle State, nEvent = 0x%x", nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pCmpntCtx->eMainState = QOMX_StateLoadedToIdle;

   /**------------------------------------------------------------------------
      Prepare ports to be ready to populate.
      Ignore the return value of qomx_PortStartPopulating. Set State Idle
      should succeed even if populating the port fails, leaving the port in
      the Transition To Idle state.
   -------------------------------------------------------------------------*/
   (void)qomx_PortStartPopulating( pCmpntCtx->hPortCtnr );

   /**------------------------------------------------------------------------
      Call internal function which checks port population and request
      device to load resources if needed.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntLoadedToIdle_UpdateResources( pCmpntCtx );

   return;

} /* end of function qomx_CmpntLoadedToIdle_StateEntryHandler */


/*==========================================================================

         FUNCTION:      qomx_CmpntLoadedToIdle_StateExitHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateLoadedToIdle is exited. Exit from this state
                        performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntLoadedToIdle_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Exiting LoadedToIdle State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Exiting LoadedToIdle State, nEvent = 0x%x", nEvent );

   return;

} /* end of function qomx_CmpntLoadedToIdle_StateExitHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntLoadedToIdle_SendCommand

         DESCRIPTION:
*//**                   This function is called every time when Send command
                        is invoked in LoadedToIdle state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.
            @param[in]  eCmd        - Command which is being invoked.
            @param[in]  nParam      - Parameter 1. Refer OMX Spec.
            @param[in]  pCmdData    - Command payload. Refer OMX Spec.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntLoadedToIdle_SendCommand 
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE            eCmd,
   OMX_IN   OMX_U32                    nParam,
   OMX_IN   OMX_PTR                    pCmdData
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntLoadedToIdle_SendCommand,"
      " eCmd = 0x%x, nParam = 0x%x", eCmd, nParam );

   /**------------------------------------------------------------------------
      Check the command type.
   -------------------------------------------------------------------------*/
   switch( eCmd )
   {
      /**--------------------------------------------------------------------- 
         Component specific commands which are allowed in this state.
      ----------------------------------------------------------------------*/
      case OMX_CommandStateSet:
         {
            if( OMX_StateLoaded == nParam )
            {
               QOMX_MSG_L_MED( pCommonRef, "Set Loaded state." );

               /**------------------------------------------------------------
                  Call internal function to do steps to move to Loaded state.
               -------------------------------------------------------------*/
               ( void ) qomx_CmpntLoadedToIdle_SetStateLoaded( pCmpntCtx );

            }
            else if( OMX_StateWaitForResources == nParam )
            {
               QOMX_MSG_L_MED( pCommonRef, "Set WFR state." );

               /**------------------------------------------------------------
                  Call internal function to do steps to move to WFR state.
               -------------------------------------------------------------*/
               ( void ) qomx_CmpntLoadedToIdle_SetStateWFR( pCmpntCtx );

            }
            else 
            {
               /**------------------------------------------------------------
                  Call common routine to handle set state command.
               -------------------------------------------------------------*/
               ( void ) qomx_CmpntCommon_CommandStateSet( pCmpntCtx, nParam );

            }

         }

         break;

      /**---------------------------------------------------------------------
         Port specific commands which allowed.
      ----------------------------------------------------------------------*/
      case OMX_CommandPortDisable:
         {
            /**---------------------------------------------------------------
               Send port disable request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortDisable( pCmpntCtx->hPortCtnr, nParam );

         }

         break;

      case OMX_CommandPortEnable:
         {
            /**---------------------------------------------------------------
               Send port enable request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortEnable( pCmpntCtx->hPortCtnr, nParam );

         }

         break;


      default:
         {
            /**---------------------------------------------------------------
               Call common routine to handle rest of the commands.
            ----------------------------------------------------------------*/
            eRetVal = qomx_CmpntCommon_SendCommand(
                                          pCmpntCtx, eCmd, nParam, pCmdData );

         }

         break;

   } /* end of switch( eCmd ) */

   return( eRetVal );

} /* end of function qomx_CmpntLoadedToIdle_SendCommand */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntLoadedToIdle_UseBuffer

         DESCRIPTION:
*//**                   This function is the equivalent of OMX_UseBuffer
                        macro. Please refer to OMX IL spec for more details.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL specification.
            @param[in]  nPortIndex  - Index for the port on which method 
                                      need to be executed.
            @param[in]  nSizeBytes  - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pBuffer     - Refer OMX_Core.h / OMX IL specification.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntLoadedToIdle_UseBuffer
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_OUT  OMX_BUFFERHEADERTYPE  **ppBufferHdr,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_IN   OMX_PTR                 pAppPrivate,
   OMX_IN   OMX_U32                 nSizeBytes,
   OMX_IN   OMX_U8*                 pBuffer
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntLoadedToIdle_UseBuffer,"
      " nPortIndex = 0x%x, nSizeBytes = %d", nPortIndex, nSizeBytes );

   /**------------------------------------------------------------------------
      Call the appropriate port handler.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortUseBuffer( pCmpntCtx->hPortCtnr, nPortIndex,
                           ppBufferHdr, pAppPrivate, nSizeBytes, pBuffer );

   /**------------------------------------------------------------------------
      If the port has handled the buffer and there was no error, check the
      resources status and see if we can transition to Idle the destination
      state.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      /**---------------------------------------------------------------------
         Call internal function which checks port population and
         request device to load resource if needed.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLoadedToIdle_UpdateResources( pCmpntCtx );

   }

   return( eRetVal );
   
} /* end of function qomx_CmpntLoadedToIdle_UseBuffer */


/*==========================================================================
     
         FUNCTION:      qomx_LoadedToIdleAllocateBuffer

         DESCRIPTION:
*//**                   This function is the equivalent of OMX_AllocateBuffer
                        macro. Please refer to OMX IL spec for more details.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL specification.
            @param[in]  nPortIndex  - Index for the port on which method 
                                      need to be executed.
            @param[in]  nSizeBytes  - Refer OMX_Core.h / OMX IL specification.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntLoadedToIdle_AllocateBuffer
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_OUT  OMX_BUFFERHEADERTYPE  **ppBufferHdr,
   OMX_IN   OMX_U32                 nPortIndex,
   OMX_IN   OMX_PTR                 pAppPrivate,
   OMX_IN   OMX_U32                 nSizeBytes
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntLoadedToIdle_AllocateBuffer,"
      " nPortIndex = 0x%x, nSizeBytes = %d", nPortIndex, nSizeBytes );

   /**------------------------------------------------------------------------
      Call the appropriate port handler.
   -------------------------------------------------------------------------*/
   eRetVal = qomx_PortAllocateBuffer( pCmpntCtx->hPortCtnr,
                        nPortIndex, ppBufferHdr, pAppPrivate, nSizeBytes );

   /**------------------------------------------------------------------------
      If the port has handled the buffer and there was no error, check the
      resources status and see if we can transition to Idle the destination
      state.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      /**---------------------------------------------------------------------
         Call internal function which checks port population and
         request device to load resource if needed.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLoadedToIdle_UpdateResources( pCmpntCtx );

   }

   return( eRetVal );

} /* end of function qomx_CmpntLoadedToIdle_AllocateBuffer */
 

/*==========================================================================

         FUNCTION:      qomx_CmpntLoadedToIdle_DeviceEventHandler

         DESCRIPTION:
*//**                   This function is called when the device want to 
                        communicate with the component when it is in 
                        LoadedToIdle state.
         
@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx      -  Context structure pointer.
            @param[in]  nEventCode     -  Event code.
            @param[in]  nEventStatus   -  Event status.
            @param[in]  nParamSize     -  Payload length.
            @param[in]  pParam         -  Payload corresponding to this event.

*//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None
                                                                        
===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntLoadedToIdle_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntLoadedToIdle_DeviceEventHandler,"
      " nEventCode = 0x%x, nEventStatus = 0x%x", nEventCode, nEventStatus );

   /**------------------------------------------------------------------------
      Check ports population and finish moving to Idle state, if load
      resource response from device is received.
   -------------------------------------------------------------------------*/
   if( MMI_RESP_LOAD_RESOURCES == nEventCode )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "MMI_RESP_LOAD_RESOURCES event." );

      /**---------------------------------------------------------------------
         Process load resource response.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLoadedToIdle_LoadResourcesResp(
                                       pCmpntCtx, nEventStatus, OMX_FALSE );

   }
   else
   {
      /**---------------------------------------------------------------------
         Pass this to common device handler routine.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntCommon_DeviceEventHandler( pCmpntCtx,
                              nEventCode, nEventStatus, nParamSize, pParam );

   }

   return( eRetVal );

} /* end of function qomx_CmpntLoadedToIdle_DeviceEventHandler */


/*==========================================================================

         FUNCTION:      qomx_CmpntLoadedToIdle_SetStateLoaded

         DESCRIPTION:
*//**                   This function will move component to IdleToLoaded
                        state which will check ports population status,
                        wait for buffer release and unload resources.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntLoadedToIdle_SetStateLoaded
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_CmpntLoadedToIdle_SetStateLoaded" );

   /**------------------------------------------------------------------------
      Process this command only if resources reservation command is not sent
      to device or reservation has failed.
   -------------------------------------------------------------------------*/
   if( ( QOMX_RESOURCES_UNRESERVED == pCmpntCtx->eResState )
      || ( QOMX_RESOURCES_RESERVATION_FAILED == pCmpntCtx->eResState ) )
   {

      QOMX_MSG_L_MED( pCommonRef, "Resources not reserved yet." );

      /**---------------------------------------------------------------------
         Move to transitional state IdleToLoaded which will check ports
         population status, and wait for buffer release.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, "Move to QOMX_StateIdleToLoaded." );

      ( void ) qomx_CmpntCommon_DoStateTransition( 
                     pCmpntCtx, QOMX_StateIdleToLoaded, QOMX_EVENT_UNKNOWN );

   }
   else
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Resources reservation is in progress,"
         "Incorrect state operation." );

      /**---------------------------------------------------------------------
         Command is not allowed in the current state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntNotifyError( & ( pCmpntCtx->commonRef ),
                                 OMX_ErrorIncorrectStateOperation );

   }

   return;

} /* end of function qomx_CmpntLoadedToIdle_SetStateLoaded */


/*==========================================================================

         FUNCTION:      qomx_CmpntLoadedToIdle_SetStateWFR

         DESCRIPTION:
*//**                   This function will move component to WFR state
                        based on the resources allocation status.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntLoadedToIdle_SetStateWFR
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_CmpntLoadedToIdle_SetStateWFR" );

   /**------------------------------------------------------------------------
      If resources reservation has failed, move to WFR state.
      If resources reservation is not requested yet and component's current
      OMX state is WFR, return SameState error.
      Else do not allow this command.
   -------------------------------------------------------------------------*/
   if( QOMX_RESOURCES_RESERVATION_FAILED == pCmpntCtx->eResState ) 
   {
      QOMX_MSG_L_MED( pCommonRef, 
         "Move to QOMX_StateWaitForResources." );

      /**---------------------------------------------------------------------
         Move to destination state QOMX_StateWaitForResources.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                           QOMX_StateWaitForResources, QOMX_EVENT_UNKNOWN );

   }
   else if( ( QOMX_RESOURCES_UNRESERVED == pCmpntCtx->eResState ) 
      && ( OMX_StateWaitForResources == pCmpntCtx->eOmxState ) )
   {
      QOMX_MSG_L_ERROR( pCommonRef, 
         "Same state error, already in OMX_StateWaitForResources." );

      /**---------------------------------------------------------------------
         Same state error.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
            "Send OMX_ErrorSameState notification." );

      ( void ) qomx_CmpntNotifyError(
                           & ( pCmpntCtx->commonRef ), OMX_ErrorSameState );

   }
   else
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Incorrect state operation." );

      /**---------------------------------------------------------------------
         Command is not allowed in the current state.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
            "Send OMX_ErrorIncorrectStateOperation notification." );

      ( void ) qomx_CmpntNotifyError( & ( pCmpntCtx->commonRef ),
                                    OMX_ErrorIncorrectStateOperation );

   }

   return;

} /* end of function qomx_CmpntLoadedToIdle_SetStateWFR */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntLoadedToIdle_UpdateResources

         DESCRIPTION:
*//**                   This function will check the resources reservation
                        status / port population status and do next step
                        so that component can move to the destination state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntLoadedToIdle_UpdateResources
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_CmpntLoadedToIdle_UpdateResources" );

   /**------------------------------------------------------------------------
      If all enabled ports are populated, check and start making resources
      reservation now.
   -------------------------------------------------------------------------*/
   if( OMX_TRUE == qomx_GuardIsTrue( pCommonRef->hCmpnt,
                              QOMX_GUARD_ALL_ENABLED_PORTS_POPULATED ) )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "All enabled ports are populated." );

      /**---------------------------------------------------------------------
         If resources are loaded, complete transition to Idle state.
         If all enabled ports are populated and reservation request is not 
         yet sent to the device, send it now.
      ----------------------------------------------------------------------*/
      if( pCmpntCtx->eResState == QOMX_RESOURCES_RESERVED )
      {
         QOMX_MSG_L_MED( pCommonRef, "Resources already reserved." );

         /**------------------------------------------------------------------
            Move to destination state QOMX_StateIdle.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_MED( pCommonRef, "Move to QOMX_StateIdle." );

         ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                                       QOMX_StateIdle, QOMX_EVENT_UNKNOWN );

         /**------------------------------------------------------------------
            Send state transition success callback.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_MED( pCommonRef, 
            "Send OMX_StateIdle transition callback." );

         ( void ) qomx_CmpntCommon_StateTransitionCallback( 
                                       pCmpntCtx, OMX_StateIdle );

      }
      else if( pCmpntCtx->eResState == QOMX_RESOURCES_UNRESERVED )
      {
         OMX_U32  nStatus = MMI_S_EFAIL;
         /*-----------------------------------------------------------------*/
         QOMX_MSG_L_MED( pCommonRef, "Load resources now." );

         /**------------------------------------------------------------------
            Send load resources request to device.
         -------------------------------------------------------------------*/
         nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                                       MMI_CMD_LOAD_RESOURCES, NULL );

         QOMX_MSG_L_HIGH( pCommonRef, 
            "MMI_CMD_LOAD_RESOURCES status = 0x%x", nStatus );

         /**------------------------------------------------------------------
            Process device response.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntLoadedToIdle_LoadResourcesResp(
                                       pCmpntCtx, nStatus, OMX_TRUE );

      }

   }

   return;

} /* end of function qomx_CmpntLoadedToIdle_UpdateResources */


/*==========================================================================

         FUNCTION:      qomx_CmpntLoadedToIdle_LoadResourcesResp

         DESCRIPTION:
*//**                   This function processes the load resource command
                        response received from the device.
         
@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Context structure pointer.
            @param[in]  nStatus     - Event status.
            @param[in]  bCmdStatus  - True if this function is called when
                                      processing device command status which
                                      is returned as function return type.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
                                                                        
===========================================================================*/
static void    qomx_CmpntLoadedToIdle_LoadResourcesResp
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nStatus,
   OMX_IN   OMX_BOOL                bSyncResp
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_CmpntLoadedToIdle_LoadResourcesResp" );

   /**------------------------------------------------------------------------
      MMI_S_PENDING is expected only as device command return type.
   -------------------------------------------------------------------------*/
   if ( MMI_S_COMPLETE == nStatus )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Load resources successful." );

      /**---------------------------------------------------------------------
         Mark that the component has all the resources required for 
         realization of the functionality.
      ----------------------------------------------------------------------*/
      pCmpntCtx->eResState = QOMX_RESOURCES_RESERVED;

	  /**---------------------------------------------------------------------
        Transition all enabled vendor tunneled ports to EnabledPopulated 
        state.
		  (For each vendor-tunneled port, if the port buffer requirement is not 
        zero, it should not transition to EnabledPopulated until load 
        resource MMI command succeeds.)
      ----------------------------------------------------------------------*/
	  ( void ) qomx_VendorTunnel_SetEnabledPortsPopulated( 
					& pCmpntCtx->commonRef, 
					pCmpntCtx->hPortCtnr);

      /**---------------------------------------------------------------------
         If all enabled ports are populated, complete transition to Idle.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntLoadedToIdle_UpdateResources( pCmpntCtx );

   }
   else if( ( MMI_S_PENDING == nStatus ) && ( OMX_TRUE == bSyncResp ) )
   {
      QOMX_MSG_L_HIGH( pCommonRef,
         "Wait for load resources response." );

      /**---------------------------------------------------------------------
         Device is processing command asynchronously, set resource state
         and wait for callback.
      ----------------------------------------------------------------------*/
      pCmpntCtx->eResState = QOMX_RESOURCES_RESERVING;

   }
   else if( ( MMI_S_ENOHWRES == nStatus ) 
         || ( MMI_S_ENOSWRES == nStatus ) )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Insufficient SW/HW resources." );

      /**---------------------------------------------------------------------
         Set the reservation status.
      ----------------------------------------------------------------------*/
      pCmpntCtx->eResState = QOMX_RESOURCES_RESERVATION_FAILED;

      /**---------------------------------------------------------------------
         Send insufficient resources event to the client. Client may 
         instruct component to go to WaitForResources state.
         Component will remain in this state until client instructs the 
         component to move to WaitForResources state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntNotifyError( & ( pCmpntCtx->commonRef ),
                                    OMX_ErrorInsufficientResources );

   }
   else
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Unexpected status in release resources"
         "response, nStatus = 0x%x, Move to Invalid state.", nStatus );

      /**---------------------------------------------------------------------
         Move component in Invalid state.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx,
                  QOMX_StateInvalid, qomx_GetQOMXBaseEventCode( nStatus ) );

   }

   return;

} /* end of function qomx_CmpntLoadedToIdle_LoadResourcesResp */

/*==========================================================================

         FUNCTION:      qomx_CmpntLoadedToIdle_SetConfig

         DESCRIPTION:
                        Refer to OMX_SetConfig in OMX_Core.h or the
                        OMX IL specification for details on the 
                        SetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  nIndex         - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[in]  pCmpntCfg      - Refer OMX_Core.h or OMX IL
                                         specification.
**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE  qomx_CmpntLoadedToIdle_SetConfig
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE           nIndex, 
   OMX_IN   OMX_PTR                 pCmpntCfg
)
{
   OMX_ERRORTYPE  eRetVal = OMX_ErrorNone;
   /*-----------------------------------------------------------------------*/

   eRetVal = qomx_CmpntCommon_SetConfig( pCmpntCtx, nIndex, pCmpntCfg);

   /**------------------------------------------------------------------------
      If this is a signal from tunneling peer, need to check guards again.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal && 
       ((OMX_U32)QOMX_IndexConfigTunneledPortStatus) == ((OMX_U32)nIndex) )
   {
      ( void ) qomx_CmpntLoadedToIdle_UpdateResources( pCmpntCtx );
   }

   return eRetVal;
} /* end of function qomx_CmpntLoadedToIdle_SetConfig */
