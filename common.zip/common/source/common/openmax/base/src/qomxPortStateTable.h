#ifndef __QOMX_PORT_STATE_TABLE_H__
#define __QOMX_PORT_STATE_TABLE_H__

/*========================================================================

*//** @file qomxPortStateTable.h

@par FILE SERVICES:       
      Port State Primitive Table Header File
      
      This file contains the declarations for port function pointers table
      which is used by every state implementation for defining the component
      behaviour on a particular operation.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2010 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxPortStateTable.h#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
06/10/10   dm     Added return type in event handler.
06/15/09   dm     Initial creation.

========================================================================== */

/*======================================================================== 
 
                     INCLUDE FILES FOR MODULE 
 
========================================================================== */
#include "qomxCommon.h"
#include "qomxPortContext.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */


/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 *
 *  This function is invoked by the device into the IL client. IL base class
 *  registers this function into the device layer.
 *  
 *  Device realizes this by setting up a signal or message queue with the
 *  kernel mode driver ( if one exists ).
 *
 *  @param [in] pPortCtnr  - Pointer to the port container object.
 *  @param [in] pPortCtx   - Pointer to the port context object.
 *  @param [in] nEventCode - Unique event code which is generally assoicated
 *                           with a command sent to the device.
 *  @param [in] nEventStatus
 *                         - Event status code which was the result of the
 *                           command. This is valid when the event is a
 *                           response to a command. In general if this event
 *                           code is not valid the device should set it to
 *                           MMI_S_COMPLETE. This avoids unnecessary
 *                           confusion and graph tier down as a result from
 *                           base class.
 *  @param [in] nParamSize - Size in bytes for the event related data,
 *                           which is saved in the passed pointer.
 *  @param [in] pParam     - Event related payload. 
 *                           
 */

typedef OMX_ERRORTYPE ( *QOMX_PortDeviceEventCallbackType )
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
);


/**
 *
 *  This is the function which is invoked every time a state is entered.
 *  Entry into the state should contain all event agnostic execution.
 *  
 *  @param [in] pPortCtnr  - Pointer to the port container object.
 *  @param [in] pPortCtx   - Pointer to the port context object.
 *  @param [in] nEvent     - Unique code relating the API or trigger which
 *                           caused the transition.
 *
 */

typedef void ( *QOMX_PortStateEntryHandlerType )
( 
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx, 
   OMX_IN   OMX_U32                 nEvent
);

/*
 *
 *  This is the function which is invoked every time a state is exited. This 
 *  should contain all event agnostic execution upon exit out of the state.
 *
 *  @param [in] pPortCtnr  - Pointer to the port container object.
 *  @param [in] pPortCtx   - Pointer to the port context object.
 *  @param [in] nEvent     - Unique code relating the API or trigger which
 *                           caused the transition.
 *
 */

typedef void ( *QOMX_PortStateExitHandlerType )
( 
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx, 
   OMX_IN   OMX_U32                 nEvent
);



/**
 *
 * The structure contains the state function table for OMX Port state
 * machine.
 * 
 * 3 kind of state handler functions
 * 
 * 1) OMX input functions
 * 2) Device or internal events
 * 3) State management a) Entry and b) Exit
 *
 *
 */

typedef struct
{
   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/

   /**<
   * Refer to OMX_SendCommand in OMX_Core.h or the OMX IL 
   * specification for details on the Enable command.
   */
   OMX_ERRORTYPE ( *Enable ) (
         OMX_IN      QOMX_PortContainerType *pPortCtnr,
         OMX_IN      QOMX_PortContextType   *pPortCtx );

   /**<
   * Refer to OMX_SendCommand in OMX_Core.h or the OMX IL 
   * specification for details on the Disable command.
   */
   OMX_ERRORTYPE ( *Disable ) (
         OMX_IN      QOMX_PortContainerType *pPortCtnr,
         OMX_IN      QOMX_PortContextType   *pPortCtx );

   /**<
   * Refer to OMX_SetupTunnel in OMX_Core.h or the OMX IL 
   * specification for details on the TunnelRequest method.
   */
   OMX_ERRORTYPE ( *TunnelRequest ) (
         OMX_IN      QOMX_PortContainerType *pPortCtnr,
         OMX_IN      QOMX_PortContextType   *pPortCtx,
         OMX_IN      OMX_HANDLETYPE          hTunneledComp,
         OMX_IN      OMX_U32                 nTunneledPort,
         OMX_INOUT   OMX_TUNNELSETUPTYPE    *pTunnelSetup ); 

   /**<
   * This function is called to move port to populating state
   * so that it can begin accepting / allocating buffers.
   */
   OMX_ERRORTYPE ( *Populate ) (
         OMX_IN      QOMX_PortContainerType *pPortCtnr,
         OMX_IN      QOMX_PortContextType   *pPortCtx );

   /**<
   * This function is called to move port to unpopulated state.
   */
   OMX_ERRORTYPE ( *Unpopulate ) (
         OMX_IN      QOMX_PortContainerType *pPortCtnr,
         OMX_IN      QOMX_PortContextType   *pPortCtx );

   /**<
   * This function is called to start buffer processing applicable
   * to this port.
   */
   OMX_ERRORTYPE ( *Run ) (
         OMX_IN      QOMX_PortContainerType *pPortCtnr,
         OMX_IN      QOMX_PortContextType   *pPortCtx );

   /**<
   * This function is called to stop buffer processing applicable
   * to this port.
   */
   OMX_ERRORTYPE ( *Stop ) (
         OMX_IN      QOMX_PortContainerType *pPortCtnr,
         OMX_IN      QOMX_PortContextType   *pPortCtx );

   /**<
   * Refer to OMX_UseBuffer in OMX_Core.h or the OMX IL 
   * specification for details on the UseBuffer command.
   */
   OMX_ERRORTYPE ( *UseBuffer ) (
         OMX_IN      QOMX_PortContainerType *pPortCtnr,
         OMX_IN      QOMX_PortContextType   *pPortCtx,
         OMX_OUT     OMX_BUFFERHEADERTYPE  **ppBufferHdr,
         OMX_IN      OMX_PTR                 pAppPrivate,
         OMX_IN      OMX_U32                 nSizeBytes,
         OMX_IN      OMX_U8                 *pBuffer );

   /**<
   * Refer to OMX_AllocateBuffer in OMX_Core.h or the OMX IL 
   * specification for details on the AllocateBuffer command.
   */
   OMX_ERRORTYPE ( *AllocateBuffer )(
         OMX_IN      QOMX_PortContainerType *pPortCtnr,
         OMX_IN      QOMX_PortContextType   *pPortCtx,
         OMX_OUT     OMX_BUFFERHEADERTYPE  **ppBufferHdr,
         OMX_IN      OMX_PTR                 pAppPrivate,
         OMX_IN      OMX_U32                 nSizeBytes );

   /**<
   * Refer to OMX_FreeBuffer in OMX_Core.h or the OMX IL 
   * specification for details on the FreeBuffer command.
   */
   OMX_ERRORTYPE ( *FreeBuffer ) (
         OMX_IN      QOMX_PortContainerType *pPortCtnr,
         OMX_IN      QOMX_PortContextType   *pPortCtx,
         OMX_IN      OMX_BUFFERHEADERTYPE   *pBufferHdr );

   /**<
   * Refer to OMX_EmptyThisBuffer in OMX_Core.h or the OMX IL 
   * specification for details on the EmptyThisBuffer command.
   */
   OMX_ERRORTYPE ( *EmptyThisBuffer ) (
         OMX_IN      QOMX_PortContainerType *pPortCtnr,
         OMX_IN      QOMX_PortContextType   *pPortCtx,
         OMX_IN      OMX_BUFFERHEADERTYPE   *pBufferHdr);

   /**<
   * Refer to OMX_FillThisBuffer in OMX_Core.h or the OMX IL 
   * specification for details on the FillThisBuffer command.
   */
   OMX_ERRORTYPE ( *FillThisBuffer ) (
         OMX_IN      QOMX_PortContainerType *pPortCtnr,
         OMX_IN      QOMX_PortContextType   *pPortCtx,
         OMX_IN      OMX_BUFFERHEADERTYPE   *pBufferHdr );

   /**<
   * Refer to OMX_SendCommand in OMX_Core.h or the OMX IL 
   * specification for details on the Flush command.
   */
   OMX_ERRORTYPE ( *Flush ) (
         OMX_IN      QOMX_PortContainerType *pPortCtnr,
         OMX_IN      QOMX_PortContextType   *pPortCtx );

   /**<
   * This method is used to deinitialize the port providing means to free
   * any resources allocated at port initialization. After this call the
   * the port context is not valid for any further use.
   */
   OMX_ERRORTYPE ( *DeInit ) (
         OMX_IN      QOMX_PortContainerType *pPortCtnr,
         OMX_IN      QOMX_PortContextType   *pPortCtx );

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/

   /**<
   * This function is invoked by the device into the IL client.
   */
   QOMX_PortDeviceEventCallbackType    pfnEventHandler;

    
   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/

   /**<
   * This function is invoked by every time a state is entered.
   */
   QOMX_PortStateEntryHandlerType      pfnEntryHandler;   
   
   /**<
   * This function is invoked by every time a state is entered.
   */
   QOMX_PortStateExitHandlerType       pfnExitHandler;


} QOMX_PortStateTableType;


#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */


#endif /* end of macro __QOMX_PORT_STATE_TABLE_H__ */
