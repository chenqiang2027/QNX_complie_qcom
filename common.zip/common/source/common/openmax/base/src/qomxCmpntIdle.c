/*========================================================================

*//** @file qomxCmpntIdle.c 

@par FILE SERVICES:       
      Component Idle State Implementation File.

      This file implements all the methods which are applicable for
      OMX_StateIdle state.
      
      Main functions are Send Command, UseBuffer and AllocateBuffer.
      Functions which are common for all states are implemented in the common
      functions table.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2018 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCmpntIdle.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
11/06/13   am     Support Mark Buffer Command.
10/19/11   zm     Allow flush command.
07/22/10   zm     Add component handle in each base class logging message.
06/10/10   dm     Added return type in event handler.
03/26/10   spl    Modified to support interop-profile.
10/29/09   dm     Allow tunneling on disabled ports in any OMX state.
10/29/09   dm     Disallow port commands in component transitional states.
10/01/09   dm     Split component states.
04/11/09   srk    Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxCmpntCommon.h"
#include "qomxPortUtils.h"

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 * 
 * Forward declaration for the functions statically defined in this file.
 * 
 */

static void    qomx_CmpntIdle_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
);

static void    qomx_CmpntIdle_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
   
);

static OMX_ERRORTYPE    qomx_CmpntIdle_SendCommand
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE         eCmd,
   OMX_IN   OMX_U32                 nParam,
   OMX_IN   OMX_PTR                 pCmdData
);

static OMX_ERRORTYPE    qomx_CmpntIdle_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
);


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_CmpntIdle_LoadStateTable

         DESCRIPTION:
                        This function will load the component state table
                        supported by the Idle state in the object of
                        state table being passed.
            
@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable - Pointer to the state primitive table
                                   object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntIdle_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      component is in QOMX_StateIdle state. NULL entry indicates that the
      specific function call is not allowed in this state, thus component API
      should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/   
   pStTable->GetComponentVersion    = qomx_CmpntCommon_GetComponentVersion;
   pStTable->SendCommand            = qomx_CmpntIdle_SendCommand;
   pStTable->GetParameter           = qomx_CmpntCommon_GetParameter;
   pStTable->SetParameter           = qomx_CmpntCommon_SetParameter;
   pStTable->GetConfig              = qomx_CmpntCommon_GetConfig;
   pStTable->SetConfig              = qomx_CmpntCommon_SetConfig;
   pStTable->GetExtensionIndex      = qomx_CmpntCommon_GetExtensionIndex;
   pStTable->GetState               = qomx_CmpntCommon_GetState;
   pStTable->ComponentTunnelRequest = qomx_CmpntCommon_TunnelRequest;
   pStTable->UseBuffer              = qomx_CmpntCommon_UseBuffer;
   pStTable->AllocateBuffer         = qomx_CmpntCommon_AllocateBuffer;
   pStTable->FreeBuffer             = qomx_CmpntCommon_FreeBuffer;
   pStTable->EmptyThisBuffer        = NULL;
   pStTable->FillThisBuffer         = NULL;
   pStTable->SetCallbacks           = NULL;
   pStTable->ComponentDeInit        = qomx_CmpntCommon_ComponentDeInit;
   pStTable->UseEGLImage            = NULL;
   pStTable->ComponentRoleEnum      = qomx_CmpntCommon_ComponentRoleEnum;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler        = qomx_CmpntIdle_DeviceEventHandler;
   
   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler        = qomx_CmpntIdle_StateEntryHandler;
   pStTable->pfnExitHandler         = qomx_CmpntIdle_StateExitHandler;
   
   return;

} /* end of function qomx_CmpntIdle_LoadStateTable */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntIdle_StateEntryHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateIdle is entered. Entry into the state
                        performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntIdle_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
       "Entering Idle State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Entering Idle State, nEvent = 0x%x", nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pCmpntCtx->eMainState = QOMX_StateIdle;
   pCmpntCtx->eOmxState  = OMX_StateIdle;

   pCmpntCtx->bDeviceStopped = OMX_FALSE;

   return;
   
} /* end of function qomx_CmpntIdle_StateEntryHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntIdle_StateExitHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateIdle is exited. Exit from this state
                        performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntIdle_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent  
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Exiting Idle State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Exiting Idle State, nEvent = 0x%x", nEvent );

   return;   
   
} /* end of function qomx_CmpntIdle_StateExitHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntIdle_SendCommand

         DESCRIPTION:
*//**                   This function is called every time when Send command
                        is invoked in Idle state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.
            @param[in]  eCmd        - Command which is being invoked.
            @param[in]  nParam      - Parameter 1. Refer OMX Spec.
            @param[in]  pCmdData    - Command payload. Refer OMX Spec.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntIdle_SendCommand 
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE            eCmd,
   OMX_IN   OMX_U32                    nParam,
   OMX_IN   OMX_PTR                    pCmdData
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntIdle_SendCommand,"
      " eCmd = 0x%x, nParam = 0x%x", eCmd, nParam );

   /**------------------------------------------------------------------------
      Check the command type.
   -------------------------------------------------------------------------*/
   switch( eCmd ) 
   {
      /**---------------------------------------------------------------------
         Component specific commands which are allowed in this state.
      ----------------------------------------------------------------------*/
      case OMX_CommandStateSet:
         {
            if( OMX_StateLoaded == nParam ) 
            {
               QOMX_MSG_L_MED( pCommonRef, "Set Loaded state." );

               /**------------------------------------------------------------
                  Move to transitional state IdleToLoaded which will check
                  ports population status, wait for buffer release and
                  unload resources.
               -------------------------------------------------------------*/
               ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                              QOMX_StateIdleToLoaded, QOMX_EVENT_UNKNOWN );

            }
            else if( OMX_StateExecuting == nParam )
            {
               QOMX_MSG_L_MED( pCommonRef, "Set Executing state." );

               /**------------------------------------------------------------
                  Move to transitional state IdleToExecuting which will 
                  command device to start buffer processing.
               -------------------------------------------------------------*/
               ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                              QOMX_StateIdleToExecuting, QOMX_EVENT_UNKNOWN );

            }
            else if( OMX_StatePause == nParam )
            {
               QOMX_MSG_L_MED( pCommonRef, "Set Pause state." );

               /**------------------------------------------------------------
                  Move to transitional state IdleToPause which will 
                  command device to pause and queue buffers being sent.
               -------------------------------------------------------------*/
               ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                              QOMX_StateIdleToPause, QOMX_EVENT_UNKNOWN );

            }
            else 
            {
               /**------------------------------------------------------------
                  Call common routine to handle set state command.
               -------------------------------------------------------------*/
               ( void ) qomx_CmpntCommon_CommandStateSet( pCmpntCtx, nParam );

            }

         }

         break;


      /**---------------------------------------------------------------------
         Port specific commands which allowed.
      ----------------------------------------------------------------------*/
      case OMX_CommandPortDisable:
         {
            QOMX_MSG_L_MED( pCommonRef, "Disable Port = 0x%x", nParam );

            /**---------------------------------------------------------------
               Send port disable request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortDisable( pCmpntCtx->hPortCtnr, nParam );

         }

         break;

      case OMX_CommandPortEnable:
         {
            QOMX_MSG_L_MED( pCommonRef, "Enable Port = 0x%x", nParam );

            /**---------------------------------------------------------------
               Send port enable request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortEnable( pCmpntCtx->hPortCtnr, nParam );

         }

         break;

      case OMX_CommandFlush:
         {
            QOMX_MSG_L_MED( pCommonRef, "Flush Port = 0x%x", nParam );

            /**---------------------------------------------------------------
               Send port flush request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortFlush( pCmpntCtx->hPortCtnr, nParam );
         }

         break;

      case OMX_CommandMarkBuffer:
         {
            OMX_MARKTYPE  *pMark = ( OMX_MARKTYPE * ) pCmdData;
            /*--------------------------------------------------------------*/

            QOMX_MSG_L_MED( pCommonRef, "Mark Port = 0x%x", nParam );

            /**---------------------------------------------------------------
               Send mark buffer request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortMarkBuffer( 
                                 pCmpntCtx->hPortCtnr, nParam, pMark );

         }

         break;

      default:
         {
            /**---------------------------------------------------------------
               Call common routine to handle rest of the commands.
            ----------------------------------------------------------------*/
            eRetVal = qomx_CmpntCommon_SendCommand(
                                          pCmpntCtx, eCmd, nParam, pCmdData );

         }

         break;

   } /* end of switch( eCmd ) */

   return( eRetVal );

} /* end  of function qomx_CmpntIdle_SendCommand */


/*==========================================================================

         FUNCTION:      qomx_CmpntIdle_DeviceEventHandler

         DESCRIPTION:
*//**                   This function is called when the device want to 
                        communicate with the component when it is in 
                        Idle state.
         
@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx      -  Context structure pointer.
            @param[in]  nEventCode     -  Event code.
            @param[in]  nEventStatus   -  Event status.
            @param[in]  nParamSize     -  Payload length.
            @param[in]  pParam         -  Payload corresponding to this event.

*//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None
                                                                        
===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntIdle_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntIdle_DeviceEventHandler,"
      " nEventCode = 0x%x, nEventStatus = 0x%x", nEventCode, nEventStatus );

   /**------------------------------------------------------------------------
      If loaded resources are lost, deinit the component by moving to
      Loaded state.
   -------------------------------------------------------------------------*/
   if( MMI_EVT_RESOURCES_LOST == nEventCode )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "MMI_EVT_RESOURCES_LOST event." );

      /**---------------------------------------------------------------------
         Set resources state to lost.
      ----------------------------------------------------------------------*/
      pCmpntCtx->eResState = QOMX_RESOURCES_PERMANENTLY_LOST;

      /**---------------------------------------------------------------------
         Report resources lost error to IL client.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
         "Send OMX_ErrorResourcesLost notification." );

      ( void ) qomx_CmpntNotifyError( 
                        & ( pCmpntCtx->commonRef ), OMX_ErrorResourcesLost );

      /**---------------------------------------------------------------------
         Move to transitional state IdleToLoaded which will check ports
         population status, wait for buffer release and unload resources.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, "Move to QOMX_StateIdleToLoaded." );

      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx,
                              QOMX_StateIdleToLoaded, QOMX_EVENT_UNKNOWN );

   }
   else
   {
      /**---------------------------------------------------------------------
         Pass this to common device handler routine.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntCommon_DeviceEventHandler( pCmpntCtx, 
                              nEventCode, nEventStatus, nParamSize, pParam );

   }

   return( eRetVal );
   
} /* end of function qomx_CmpntIdle_DeviceEventHandler */
