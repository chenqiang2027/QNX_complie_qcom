#ifndef __OMX_PORT_COMMON_H__
#define __OMX_PORT_COMMON_H__

/*========================================================================

*//** @file qomxPortCommon.h 

@par FILE SERVICES:
      Data types common to all port states.

      This file contains the declaration for the macros, data structures
      and the methods which are common for all port states and used by these
      states same way.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxPortCommon.h#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
12/13/13   rz     Fix MarkBuffer implementation
10/19/11   zm     Add dummy flush command handling.
12/02/10   zm     Move TunnelNegotiateBuffers() declaration to .c file. 
08/28/10   zm     Added vendor tunnel setup function.
07/15/10   yt     Added buffer supply/free functions for tunneling.
06/10/10   dm     Added return type in event handler.
03/26/10   spl    Modified to support interop-profile.
11/25/09   dm     Corrected auto port detection behavior.
08/06/09   dm     Added setparameter checks for states.
07/28/09   dm     Refined setparameter handling.
07/21/09   dm     Handled buffer supplier settings.
06/16/09   dm     Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxPortStateTable.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */


/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */


/**
 * 
 *  This macro checks if the component is a sink component i.e. the component
 *  has no output port.
 *    @param[in]  pPortCtnr   - Pointer to the port container.
 *
 */

#define QOMX_COMPONENT_IS_SINK(pPortCtnr)                                    \
         ( 0 == (                                                            \
                  pPortCtnr->audioDomain.nNumOutputPorts +                   \
                  pPortCtnr->videoDomain.nNumOutputPorts +                   \
                  pPortCtnr->imageDomain.nNumOutputPorts +                   \
                  pPortCtnr->otherDomain.nNumOutputPorts ) )

/**
 * 
 *  This macro checks if the port is buffer supplier. A port is a buffer
 *  supplier if either the port direction is input and buffer supplier is
 *  set to be input or the port direction is output and buffer supplier is
 *  set to be output.
 *    @param[in]  pPortCtx    - Pointer to the port context.
 *
 */

#define QOMX_PORT_IS_BUFFER_SUPPLIER(pPortCtx)                               \
         ( ( ( OMX_DirInput == pPortCtx->portDef.eDir )                      \
               && ( OMX_BufferSupplyInput == pPortCtx->eBufferSupplier ) )   \
          || ( ( OMX_DirOutput == pPortCtx->portDef.eDir )                   \
               && ( OMX_BufferSupplyOutput == pPortCtx->eBufferSupplier ) ) )


/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 * 
 *  This enumeration contain port level guards which are used to check port
 *  population status at various stages of component and port state 
 *  transitions.
 * 
 */

typedef enum
{

  QOMX_PORT_GUARD_POPULATED,              /**<
                                          * Guard to check if the port has
                                          * required number of buffers and 
                                          * thus populated.
                                          */
  
  QOMX_PORT_GUARD_UNPOPULATED             /**<
                                          * Guard to check if the port has
                                          * no buffers or all the buffers
                                          * held have been revoked and thus
                                          * unpopulated.
                                          */

} QOMX_PortGuardType;



/**
 * 
 * The following data type defines a stucture which is used to push buffer
 * headers into the queue on UseBuffer / AllocateBuffers calls and pop them
 * out on FreeBuffer calls. Each port maintains its own buffer headers queue.
 * 
 */

typedef struct 
{
   QMM_ListLinkType           link;       /**<
                                          * "Reserved for use by qmmList only"
                                          * This is the link object which is
                                          * used by qmmList interface methods
                                          * to push or pop this buffer header
                                          * object into the queue.
                                          */
   
   OMX_BUFFERHEADERTYPE      *pBufferHdr; /**<
                                          * Object of the buffer header type
                                          * which holds the buffer information
                                          * associated with the buffer being
                                          * allocated or used.
                                          */

   OMX_BOOL                   bDeviceIsBufferAllocator;
                                          /**<
                                          * This flag indicates if the buffer
                                          * associated with the above header
                                          * is allocated by the device through
                                          * AllocateBuffer call.
                                          */

   OMX_BOOL                   bPortIsHeaderAllocator;
                                          /**<
                                          * This flag indicates if the above 
                                          * buffer header is allocated by this 
                                          * port.  This flag will be false for
                                          * tunneled ports that are the buffer 
                                          * allocators.  In this case the peer
                                          * port allocates the buffer header 
                                          * via the OMX_UseBuffer call.  And 
                                          * the same header is shared by both
                                          * ports.
                                          */

} QOMX_PortBufferHdrLink;



/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */



/*==========================================================================

         FUNCTION:      qomx_PortCommon_GetParameter

         DESCRIPTION:
                        Refer to OMX_GetParameter in OMX_Core.h or the OMX IL 
                        specification for details on the GetParameter method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  nParamIndex - Refer OMX_Core.h / OMX IL specification.
            @param[inout] pCmpntParm
                                    - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_GetParameter
(
   OMX_IN      QOMX_PortContainerType       *pPortCtnr,
   OMX_IN      OMX_INDEXTYPE                 nParamIndex,
   OMX_INOUT   OMX_PTR                       pCmpntParm
);


/*==========================================================================

         FUNCTION:      qomx_PortCommon_SetParameter

         DESCRIPTION:
                        Refer to OMX_SetParameter in OMX_Core.h or the OMX IL 
                        specification for details on the SetParameter method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  nParamIndex - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pCmpntParm  - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_SetParameter
(
   OMX_IN      QOMX_PortContainerType       *pPortCtnr,
   OMX_IN      OMX_INDEXTYPE                 nParamIndex,
   OMX_IN      OMX_PTR                       pCmpntParm
);


/*==========================================================================

         FUNCTION:      qomx_PortCommon_GetConfig

         DESCRIPTION:
                        Refer to OMX_GetConfig in OMX_Core.h or the OMX IL 
                        specification for details on the GetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  nCfgIndex   - Refer OMX_Core.h / OMX IL specification.
            @param[inout] pCmpntCfg - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_GetConfig
(
   OMX_IN      QOMX_PortContainerType       *pPortCtnr,
   OMX_IN      OMX_INDEXTYPE                 nCfgIndex,
   OMX_INOUT   OMX_PTR                       pCmpntCfg
);


/*==========================================================================
     
         FUNCTION:      qomx_PortCommon_SetConfig

         DESCRIPTION:
                        Refer to OMX_SetConfig in OMX_Core.h or the OMX IL 
                        specification for details on the SetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  nCfgIndex   - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pCmpntCfg   - Refer OMX_Core.h / OMX IL specification.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_SetConfig
(
   OMX_IN      QOMX_PortContainerType       *pPortCtnr,
   OMX_IN      OMX_INDEXTYPE                 nCfgIndex,
   OMX_IN      OMX_PTR                       pCmpntCfg
);


/*==========================================================================

         FUNCTION:      qomx_PortCommon_Enable

         DESCRIPTION:
*//**                   This function processes port enable request.

@par     DEPENDENCIES:   
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr      - Pointer to the port container.
            @param[in]  pPortCtx       - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_Enable
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
);


/*==========================================================================

         FUNCTION:      qomx_PortCommon_Disable

         DESCRIPTION:                                                       
*//**                   This function processes port disable request.

@par     DEPENDENCIES:   
                        None
*//*                                                
         PARAMETERS:
*//**       @param[in]  pPortCtnr      - Pointer to the port container.
            @param[in]  pPortCtx       - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_Disable
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
);


/*==========================================================================

         FUNCTION:      qomx_PortCommon_DummyFlush

         DESCRIPTION:
*//**                   This function is a dummy funtion created to handle 
                        port flush request in port state table for states
                        EnabledPopulated and DisabledUnpopulated (when 
                        component state is Idle) where flush might be legal, 
                        but should not take any action.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_DummyFlush
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
);


/*==========================================================================

         FUNCTION:      qomx_PortCommon_DeInit

         DESCRIPTION:
*//**                   This function processes deinit request.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_DeInit
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
);


/*==========================================================================

         FUNCTION:      qomx_PortCommon_BufferHdrLinkCmp

         DESCRIPTION:
*//**                   This function compares the data embedded in one queue
                        link against the given value.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pElement       - Pointer to queue element i.e. link
                                         of type QOMX_PortBufferHdrLink.
            @param[in]  pCmpValue      - Pointer to buffer header of type 
                                         OMX_BUFFERHEADERTYPE against which 
                                         data associated with the link need
                                         to be compared.

**//*     RETURN VALUE:
*//**       @return     QMM_LIST_ERROR_PRESENT     - If comparsion is
                                                     successful.
                        QMM_LIST_ERROR_NOT_PRESENT - Otherwise.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
QMM_ListErrorType   qomx_PortCommon_BufferHdrLinkCmp
(
   void     *pElement,
   void     *pCmpValue
);


/*==========================================================================

         FUNCTION:      qomx_PortCommon_DoStateTransition

         DESCRIPTION:
*//**                   This function is generic state transition routine
                        which performs the common transition logic.
            
                        1) State management like calling entry and exit
                           functions.
                        2) Doing the actual transition.
                        3) Logging the transiton.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr      - Pointer to the container object.
            @param[in]  pPortCtx       - Pointer to the port context.
            @param[in]  eToState       - New port state.
            @param[in]  nEvent         - Uniqueue event code.

**//*     RETURN VALUE:
*//**       @return     None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void    qomx_PortCommon_DoStateTransition
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   QOMX_PortStateType            eToState,
   OMX_IN   OMX_U8                        nEvent
);


/*==========================================================================

         FUNCTION:      qomx_PortCommon_CheckGuard

         DESCRIPTION:
*//**                   This function checks the port population status.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtx       - Pointer to the port context.
            @param[in]  ePortGuard     - Port guard to be checked.

**//*     RETURN VALUE:
*//**       @return     OMX_TRUE    - if port guard condition is satisfied.
                        OMX_FALSE   - otherwise.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_BOOL   qomx_PortCommon_CheckGuard
( 
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   QOMX_PortGuardType            ePortGuard
);


/*==========================================================================

         FUNCTION:      qomx_PortGetContext

         DESCRIPTION:
*//**                   This function is used to retrieve port context from
                        container at given port index.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the container object.
            @param[in]  nPortIndex  - Index for the port which should be
                                      enabled.
            @param[out] ppPortCtx   - Pointer to an object of Port Context
                                      which will be filled with appropriate
                                      context upon successful return.
**//*     RETURN VALUE:                                                                   
*//**       @return     Pointer to an object holding function table.

@par     SIDE EFFECTS:   
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortGetContext
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   OMX_U32                       nPortIndex,
   OMX_OUT  QOMX_PortContextType        **ppPortCtx
);


/*==========================================================================

         FUNCTION:      qomx_PortCommon_LoadStateTables

         DESCRIPTION:
                        This function will load all the port state tables
                        in the array of state primitive tables being passed.
                        Memory for this array is pre-allocated in port
                        initialization.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  paStTable   - Pointer to the base of array of state
                                      primitive table objects.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortCommon_LoadStateTables
(
   OMX_IN   QOMX_PortStateTableType      *paStTable
);


/*==========================================================================

         FUNCTION:      qomx_PortCommon_GetStateTable

         DESCRIPTION:
*//**                   This function is used to get function table for
                        port's current state which contains pointers to the
                        functions which should be called for the state
                        operations.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the container object.
            @param[in]  eState      - Current port state.

**//*     RETURN VALUE:
*//**       @return     Pointer to an ojbect holding function table.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
QOMX_PortStateTableType*  qomx_PortCommon_GetStateTable
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortStateType            eState
);


/*==========================================================================

         FUNCTION:      qomx_PortCommon_ProcessBufferHeader

         DESCRIPTION:
*//**                   This function checks the buffer header for marks 
                        and flags and send the appropriate notifications 
                        to the application.  

@par     DEPENDENCIES:   
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the component's port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Buffer header which may contain mark.
            @param[in]  nCmd        - Command code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortCommon_ProcessBufferHeader
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE         *pBufferHdr,
   OMX_IN   OMX_U32                       nCmd
);

/*==========================================================================

         FUNCTION:      qomx_PortCommon_FreeBuffer

         DESCRIPTION:
*//**                   This function processes free buffer request.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.
@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_FreeBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN OMX_BUFFERHEADERTYPE           *pBufferHdr
);

/*==========================================================================

         FUNCTION:      qomx_PortCommon_ConfigChange

         DESCRIPTION:
*//**                   This function processes the port configuration changed
                        event received from the device.

@par     DEPENDENCIES:   
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortCommon_ConfigChange
(
   OMX_IN   QOMX_CommonRefType           *pCommonRef,
   OMX_IN   QOMX_PortContextType         *pPortCtx
);


/*==========================================================================
     
         FUNCTION:      qomx_PortCommon_UpdatePortDefinition

         DESCRIPTION:
                        This function will update the port definition with 
                        latest information retrieved from device.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCommonRef  - Pointer to the object of Common
                                      References which holds device and
                                      application information.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_UpdatePortDefinition
(
   OMX_IN   QOMX_CommonRefType           *pCommonRef,
   OMX_IN   QOMX_PortContextType         *pPortCtx
);


/*==========================================================================

         FUNCTION:      qomx_PortCommon_EnableResp

         DESCRIPTION:
*//**                   This function processes the enable port command
                        response received from the device.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  nStatus     - Event status.
            @param[in]  bCmdStatus  - True if this function is called when
                                      processing device command status which
                                      is returned as function return type.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void     qomx_PortCommon_EnableResp
(
   OMX_IN   QOMX_PortContainerType    *pPortCtnr,
   OMX_IN   QOMX_PortContextType      *pPortCtx,
   OMX_IN   OMX_U32                    nStatus,
   OMX_IN   OMX_BOOL                   bSyncResp
);


/*==========================================================================

         FUNCTION:      qomx_PortCommon_DisableResp

         DESCRIPTION:
*//**                   This function processes the disable port command
                        response received from the device.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  nStatus     - Event status.
            @param[in]  bCmdStatus  - True if this function is called when
                                      processing device command status which
                                      is returned as function return type.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void     qomx_PortCommon_DisableResp
(
   OMX_IN   QOMX_PortContainerType    *pPortCtnr,
   OMX_IN   QOMX_PortContextType      *pPortCtx,
   OMX_IN   OMX_U32                    nStatus,
   OMX_IN   OMX_BOOL                   bSyncResp
);


/*==========================================================================

         FUNCTION:      qomx_PortCommon_Unpopulate

         DESCRIPTION:
                        This function will move the port state to unpopulated.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_Unpopulate
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
);

/*==========================================================================

         FUNCTION:      qomx_PortCommon_DummyUnpopulate

         DESCRIPTION:
                        This function is a dummy funtion created to handle 
                        Unpopulate primitive in port state table for states
                        EnabledDepopulating and EnabledUnpopulated where 
                        Unpopulate might be legal, but should not take any 
                        action.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_DummyUnpopulate
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
);

/*==========================================================================

         FUNCTION:      qomx_PortCommon_EmptyThisBufferResp

         DESCRIPTION:
*//**                   This function processes empty buffer done response
                        from the device.

@par     DEPENDENCIES:   
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Pointer to the buffer header.
            @param [in] nEventStatus- Status of the event.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_EmptyThisBufferResp
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr,
   OMX_IN   OMX_U32                 nEventStatus
);

/*==========================================================================

         FUNCTION:      qomx_PortCommon_EmptyThisBufferRespStopping

         DESCRIPTION:
*//**                   This function processes empty buffer done response
                        from the device when port is stopping.

@par     DEPENDENCIES:   
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Pointer to the buffer header.
            @param [in] nEventStatus- Status of the event.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_EmptyThisBufferRespStopping
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr,
   OMX_IN   OMX_U32                 nEventStatus
);

/*==========================================================================

         FUNCTION:      qomx_PortCommon_FillThisBufferResp

         DESCRIPTION:
*//**                   This function processes fill buffer done response
                        from the device.

@par     DEPENDENCIES:   
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Pointer to the buffer header.
            @param [in] nEventStatus- Status of the event.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_FillThisBufferResp
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr,
   OMX_IN   OMX_U32                 nEventStatus
);

/*==========================================================================

         FUNCTION:      qomx_PortCommon_FillThisBufferRespStopping

         DESCRIPTION:
*//**                   This function processes fill buffer done response
                        from the device when the port is stopping.

@par     DEPENDENCIES:   
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Pointer to the buffer header.
            @param [in] nEventStatus- Status of the event.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE  qomx_PortCommon_FillThisBufferRespStopping
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr,
   OMX_IN   OMX_U32                 nEventStatus
);

/*==========================================================================

         FUNCTION:      qomx_PortCommon_StartTunneledDataFlow

         DESCRIPTION:
                        This function will start data flowing for tunneled 
                        ports.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.            

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_StartTunneledDataFlow
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx   
);

/*==========================================================================

         FUNCTION:      qomx_PortCommon_SetupVendorTunnel

         DESCRIPTION:
						This function attempts to set vendor tunnel between
						the given port and the peer port of the tunneled
						component.

                        a) Check whether both of the devices support vendor
						tunneling.
						b) Get the vendor tunneling device API table and
						device handle of each device.
						c) Exchange the vendor tunneling device API table
						and device handle.

@par     DEPENDENCIES:   
                        None
*//*                                                                        
         PARAMETERS:
*//**       @param[in]  pCommonRef     - Pointer to common reference object.
            @param[in]  pPortCtx       - Pointer to port context object.
            @param[in]  hTunneledComp  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nTunneledPort  - Refer OMX_Core.h / OMX IL spec.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_SetupVendorTunnel
(
 OMX_IN      QOMX_CommonRefType		   *pCommonRef,
 OMX_IN      QOMX_PortContextType      *pPortCtx,
 OMX_IN      OMX_HANDLETYPE             hTunneledComp,
 OMX_IN      OMX_U32                    nTunneledPort
 );

/*==========================================================================

         FUNCTION:      qomx_PortCommon_TunnelRequest

         DESCRIPTION:
                        Refer to OMX_ComponentTunnelRequest in OMX_Core.h
                        or the OMX IL specification for details on the 
                        ComponentTunnelRequest method.

						1. Check port compatibility.

                        2. For an output port:
						   1) Set buffer supplier preferences.
                           2) If tunneled port is a QOMX port, Set race 
						      condition flags.
                           
                           For an input port:
                           1) If tunneled port is a QOMX port, attempt to 
						      setup vendor tunneling.
						   2) Negotiate buffer requirements if it is normal
						      tunneling.
						   3) Read buffer preferences set by the output port.
						   4) If tunneled port is a QOMX port, Set race 
						      condition flags.

@par     DEPENDENCIES:   
                        None
*//*                                                                        
         PARAMETERS:
*//**       @param[in]  pPortCtnr      - Pointer to the port container.
            @param[in]  nPort          - Refer OMX_Core.h / OMX IL spec.
            @param[in]  hTunneledComp  - Refer OMX_Core.h / OMX IL spec.
            @param[in]  nTunneledPort  - Refer OMX_Core.h / OMX IL spec.
            @param[out] pTunnelSetup   - Refer OMX_Core.h / OMX IL spec.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_TunnelRequest
(
 OMX_IN      QOMX_PortContainerType    *pPortCtnr,
 OMX_IN      QOMX_PortContextType      *pPortCtx,
 OMX_IN      OMX_HANDLETYPE             hTunneledComp,
 OMX_IN      OMX_U32                    nTunneledPort,
 OMX_INOUT   OMX_TUNNELSETUPTYPE       *pTunnelSetup
 );

/*==========================================================================

         FUNCTION:      qomx_PortCommon_SupplyTunnelBuffers

         DESCRIPTION:
                        This function will be called for a tunneling supplier 
                        port. It will allocate buffers and pass them on to the
                        peer component.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_SupplyTunnelBuffers
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
);

/*==========================================================================

         FUNCTION:      qomx_PortCommon_FreeTunnelBuffers

         DESCRIPTION:
                        This function will be called for a tunneling supplier 
                        port. It will free buffers it allocated and ask peer
                        to free associated headers.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_FreeTunnelBuffers
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
);

/*==========================================================================

         FUNCTION:      qomx_PortCommon_FreeBufferUnexpected

         DESCRIPTION:
*//**                   This function processes free buffer request when port
                        is in a state in which buffer freeing is not normally 
                        expected such as Running or Populated.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  pBufferHdr  - Refer OMX_Core.h / OMX IL specification.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.
@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_FreeBufferUnexpected
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN OMX_BUFFERHEADERTYPE           *pBufferHdr
);

/*==========================================================================

         FUNCTION:      qomx_PortCommon_CheckStop

         DESCRIPTION:
*//**                   This function checks the port buffer counters to see
                        if stopping process can be completed. If so, 
                        it transitions the port to the next state.

@par     DEPENDENCIES:   
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.            

**//*     RETURN VALUE:
*//**       @return     None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortCommon_CheckStop
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx   
);

/*==========================================================================
     
         FUNCTION:      qomx_PortCommon_SignalTunnelPeer

         DESCRIPTION:
                        This function is used when a non-supplier needs to 
                        signal its status to its tunneling peer using 
                        OMX_SetConfig with IndexConfigTunneledPortStatus. It
                        will typically be called from DFC thread.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  hTunneledComp        - Handle of tunnel peer.
            @param[in]  nTunneledPort        - Peer tunnel port.
            @param[in]  nTunneledPortStatus  - Port status requested to be 
                                               sent.

**//*    RETURN VALUE:
*//**       @return     None                        

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortCommon_SignalTunnelPeer
(
   OMX_IN      OMX_HANDLETYPE       hTunneledComp,
   OMX_IN      OMX_U32              nTunneledPort,
   OMX_IN      OMX_U32              nTunneledPortStatus
);

/*==========================================================================

         FUNCTION:      qomx_PortCommon_DisableFlushResp

         DESCRIPTION:
*//**                   This function processes flush response received from
                        device when port is disabled.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void    qomx_PortCommon_DisableFlushResp
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx
);


/*==========================================================================

         FUNCTION:      qomx_PortCommon_CopyMark

         DESCRIPTION:                                                       
*//**                   This function copy mark from port context to 
                        buffer header.

@par     DEPENDENCIES:   
                        None
*//*                                                
         PARAMETERS:
*//**       @param[in]  pPortCtnr      - Pointer to the port container.
            @param[in]  pPortCtx       - Pointer to the port context.
            @param[in]  pBufferHdr     - Pointer to the port buffer header

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
OMX_ERRORTYPE    qomx_PortCommon_CopyMark
(
   OMX_IN   QOMX_PortContainerType *pPortCtnr,
   OMX_IN   QOMX_PortContextType   *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE   *pBufferHdr
);

#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */


#endif /* end of macro __OMX_PORT_COMMON_H__ */
