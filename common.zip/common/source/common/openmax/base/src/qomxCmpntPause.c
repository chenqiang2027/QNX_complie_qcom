/*========================================================================

*//** @file qomxCmpntPause.c 

@par FILE SERVICES:       
      Component Pause State Implementation File.

      This file implements all the methods which are applicable for
      OMX_StatePause state.
      
      Main functions are Send Command and FreeBuffer. Functions which are
      common for all states are implemented in the common functions table.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2018 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCmpntPause.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
12/13/13   rz     Fix pEventData in OMX_EventMark
08/28/10   zm     Added support for vendor tunneling.
07/22/10   zm     Add component handle in each base class logging message.
06/10/10   dm     Added return type in event handler.
01/20/10   dm     Fix resource loss bug.
10/29/09   dm     Allow tunneling on disabled ports in any OMX state.
10/29/09   dm     Disallow port commands in component transitional states.
10/09/09   dm     Split component states.
08/14/09   dm     Fixed suspension status not getting reset issue.
07/07/09   dm     Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxCmpntCommon.h"
#include "qomxPortUtils.h"

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 * 
 * Forward declaration for the functions statically defined in this file.
 * 
 */

static void    qomx_CmpntPause_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
);

static void    qomx_CmpntPause_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
   
);

static OMX_ERRORTYPE    qomx_CmpntPause_SendCommand
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE         eCmd,
   OMX_IN   OMX_U32                 nParam,
   OMX_IN   OMX_PTR                 pCmdData
);

static OMX_ERRORTYPE    qomx_CmpntPause_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
);

static void    qomx_CmpntPause_SetStateExecuting
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);

static void    qomx_CmpntPause_ResourcesLost
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx
);


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_CmpntPause_LoadStateTable

         DESCRIPTION:
                        This function will load the component state table
                        supported by the Pause state in the object of
                        state table being passed.
            
@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable - Pointer to the state primitive table
                                   object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntPause_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      component is in QOMX_StatePause state. NULL entry indicates that the
      specific function call is not allowed in this state, thus component API
      should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/   
   pStTable->GetComponentVersion    = qomx_CmpntCommon_GetComponentVersion;
   pStTable->SendCommand            = qomx_CmpntPause_SendCommand;
   pStTable->GetParameter           = qomx_CmpntCommon_GetParameter;
   pStTable->SetParameter           = qomx_CmpntCommon_SetParameter;
   pStTable->GetConfig              = qomx_CmpntCommon_GetConfig;
   pStTable->SetConfig              = qomx_CmpntCommon_SetConfig;
   pStTable->GetExtensionIndex      = qomx_CmpntCommon_GetExtensionIndex;
   pStTable->GetState               = qomx_CmpntCommon_GetState;
   pStTable->ComponentTunnelRequest = qomx_CmpntCommon_TunnelRequest;
   pStTable->UseBuffer              = qomx_CmpntCommon_UseBuffer;
   pStTable->AllocateBuffer         = qomx_CmpntCommon_AllocateBuffer;
   pStTable->FreeBuffer             = qomx_CmpntCommon_FreeBuffer;
   pStTable->EmptyThisBuffer        = qomx_CmpntCommon_EmptyThisBuffer;
   pStTable->FillThisBuffer         = qomx_CmpntCommon_FillThisBuffer;
   pStTable->SetCallbacks           = NULL;
   pStTable->ComponentDeInit        = qomx_CmpntCommon_ComponentDeInit;
   pStTable->UseEGLImage            = NULL;
   pStTable->ComponentRoleEnum      = qomx_CmpntCommon_ComponentRoleEnum;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler        = qomx_CmpntPause_DeviceEventHandler;
   
   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler        = qomx_CmpntPause_StateEntryHandler;
   pStTable->pfnExitHandler         = qomx_CmpntPause_StateExitHandler;
   
   return;

} /* end of function qomx_CmpntPause_LoadStateTable */


/*==========================================================================

         FUNCTION:      qomx_CmpntPause_StateEntryHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StatePause is entered. Entry into the state
                        performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntPause_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Entering Pause State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Entering Pause State, nEvent = 0x%x", nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pCmpntCtx->eMainState   = QOMX_StatePause;
   pCmpntCtx->eOmxState    = OMX_StatePause;

   return;

} /* end of function qomx_CmpntPause_StateEntryHandler */


/*==========================================================================

         FUNCTION:      qomx_CmpntPause_StateExitHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateExecuting is exited. Exit from this state
                        performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntPause_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
)
{
  QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Exiting Pause State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Exiting Pause State, nEvent = 0x%x", nEvent );

   return;

} /* end of function qomx_CmpntPause_StateExitHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntPause_SendCommand

         DESCRIPTION:
*//**                   This function is called every time when Send command
                        is invoked in Pause state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.
            @param[in]  eCmd        - Command which is being invoked.
            @param[in]  nParam      - Parameter 1. Refer OMX Spec.
            @param[in]  pCmdData    - Command payload. Refer OMX Spec.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntPause_SendCommand
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx,
   OMX_IN   OMX_COMMANDTYPE            eCmd,
   OMX_IN   OMX_U32                    nParam,
   OMX_IN   OMX_PTR                    pCmdData
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntPause_SendCommand,"
      " eCmd = 0x%x, nParam = 0x%x", eCmd, nParam );

   /**------------------------------------------------------------------------
      Check the command type.
   -------------------------------------------------------------------------*/
   switch( eCmd )
   {
      /**---------------------------------------------------------------------
         Component specific commands which are allowed in this state.
      ----------------------------------------------------------------------*/
      case OMX_CommandStateSet :
         {
            if( OMX_StateIdle == nParam )
            {
               QOMX_MSG_L_MED( pCommonRef, "Set Idle state." );

               /**------------------------------------------------------------
                  Move to transitional state ExecutingToIdle which will 
                  command device to stop buffer processing.                  
               -------------------------------------------------------------*/
               ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                              QOMX_StateExecutingToIdle, QOMX_EVENT_UNKNOWN );

            }
            else if( OMX_StateExecuting == nParam )
            {
               QOMX_MSG_L_MED( pCommonRef, "Set Executing state." );

               /**------------------------------------------------------------
                  Call internal function to do steps to move to Executing
                  state.
               -------------------------------------------------------------*/
               ( void ) qomx_CmpntPause_SetStateExecuting( pCmpntCtx );

            }
            else
            {
               /**------------------------------------------------------------
                  Call common routine to handle set state command.
               -------------------------------------------------------------*/
               ( void ) qomx_CmpntCommon_CommandStateSet( pCmpntCtx, nParam );

            }

         }

         break;

      /**---------------------------------------------------------------------
         Port specific commands which allowed.
      ----------------------------------------------------------------------*/
      case OMX_CommandPortDisable:
         {
            QOMX_MSG_L_MED( pCommonRef, "Disable Port = 0x%x", nParam );

            /**---------------------------------------------------------------
               Send port disable request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortDisable( pCmpntCtx->hPortCtnr, nParam );

         }

         break;

      case OMX_CommandPortEnable:
         {
            QOMX_MSG_L_MED( pCommonRef, "Enable Port = 0x%x", nParam );

            /**---------------------------------------------------------------
               Send port enable request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortEnable( pCmpntCtx->hPortCtnr, nParam );

         }

         break;

      case OMX_CommandFlush :
         {
            QOMX_MSG_L_MED( pCommonRef, "Flush Port = 0x%x", nParam );

            /**---------------------------------------------------------------
               Send port flush request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortFlush( pCmpntCtx->hPortCtnr, nParam );

         }

         break;

      case OMX_CommandMarkBuffer:
         {
            OMX_MARKTYPE  *pMark = ( OMX_MARKTYPE * ) pCmdData;
            /*--------------------------------------------------------------*/

            QOMX_MSG_L_MED( pCommonRef, "Mark Port = 0x%x", nParam );

            /**---------------------------------------------------------------
               Send mark buffer request to the port state machine.
            ----------------------------------------------------------------*/
            eRetVal = qomx_PortMarkBuffer( 
                                 pCmpntCtx->hPortCtnr, nParam, pMark );

         }

         break;

      default:
         {
            /**---------------------------------------------------------------
               Call common routine to handle rest of the commands.
            ----------------------------------------------------------------*/
            eRetVal = qomx_CmpntCommon_SendCommand(
                                          pCmpntCtx, eCmd, nParam, pCmdData );

         }

         break;

   } /* end of switch( eCmd ) */

   return( eRetVal );
 
} /* end of function qomx_CmpntPause_SendCommand */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntPause_DeviceEventHandler

         DESCRIPTION:
*//**                   This function is called when the device want to 
                        communicate with the component when it is in 
                        Executing state.
         
@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx      -  Context structure pointer.
            @param[in]  nEventCode     -  Event code.
            @param[in]  nEventStatus   -  Event status.
            @param[in]  nParamSize     -  Payload length.
            @param[in]  pParam         -  Payload corresponding to this event.

*//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None
                                                                        
===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntPause_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntPause_DeviceEventHandler,"
      " nEventCode = 0x%x, nEventStatus = 0x%x", nEventCode, nEventStatus );

   /**------------------------------------------------------------------------
      Set the suspension status and remain in pause state if resource loss
      is detected while suspension policy allows it. Otherwise transition 
      to Idle -> Loaded state now.
      If resources are acquired again, report it to IL client.
   -------------------------------------------------------------------------*/
   if( MMI_EVT_RESOURCES_LOST == nEventCode )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "MMI_EVT_RESOURCES_LOST event." );

      /**---------------------------------------------------------------------
         Set resources lost status to permanent loss. This status need to 
         be overridden if resource loss message shows as temporary.
      ----------------------------------------------------------------------*/
      pCmpntCtx->eResState = QOMX_RESOURCES_PERMANENTLY_LOST;

      /**---------------------------------------------------------------------
         Validate event handler parameters.
      ----------------------------------------------------------------------*/
      if( ( NULL != pParam )
         && ( nParamSize == sizeof( MMI_ResourceLostMsgType ) ) )
      {
         MMI_ResourceLostMsgType *pResLostMsg
                     = ( MMI_ResourceLostMsgType * ) pParam;
         /*-----------------------------------------------------------------*/         

         /**------------------------------------------------------------------
            Set resource lost state to temporary if it is suspendable,
            and suspension policy allows it.
         -------------------------------------------------------------------*/
         if( ( OMX_TRUE == pResLostMsg->bSuspendable )
            && ( OMX_SuspensionEnabled == pCmpntCtx->ePolicy ) )
         {
            QOMX_MSG_L_HIGH( pCommonRef, "Temporary resource loss." );

            pCmpntCtx->eResState = QOMX_RESOURCES_TEMPORARILY_LOST;

         }

      }
      else
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Invalid resource lost params."
            " Assuming permanent loss." );

      }

      /**---------------------------------------------------------------------
         Process resources lost event now.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntPause_ResourcesLost( pCmpntCtx );

   }
   else if( MMI_EVT_RESOURCES_ACQUIRED == nEventCode )
   {
      QOMX_MSG_L_HIGH( pCommonRef,
         "MMI_EVT_RESOURCES_ACQUIRED event." );

      /**---------------------------------------------------------------------
         Send resources state to reserved again.
      ----------------------------------------------------------------------*/
      pCmpntCtx->eResState = QOMX_RESOURCES_RESERVED;

      /**---------------------------------------------------------------------
         Set suspension status.
      ----------------------------------------------------------------------*/
      pCmpntCtx->eSuspension = OMX_NotSuspended;

      /**---------------------------------------------------------------------
         Send resume event notification now and wait in Pause state itself
         for the IL client instructions.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
         "Send OMX_EventComponentResumed notification." );

      ( void ) qomx_CmpntNotifyEvent( & ( pCmpntCtx->commonRef ), 
                              OMX_EventComponentResumed, 0, 0, NULL );

   }
   else if( MMI_EVT_VENDORTUNNEL_PORT_MARK_BUFFER == nEventCode )
   {
	  if( ( NULL != pParam )
        && ( nParamSize == sizeof( MMI_VendorTunnelMarkBufferCmdType ) ) )
	  {
	     MMI_VendorTunnelMarkBufferCmdType *pMarkBufMsg = 
						( MMI_VendorTunnelMarkBufferCmdType * ) pParam;

		 QOMX_MSG_L_HIGH( pCommonRef, 
          "Received need VENDORTUNNEL_PORT_MARK_BUFFER event." );

		 /**------------------------------------------------------------------
            Send mark buffer notification to the application.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntNotifyEvent( & ( pCmpntCtx->commonRef ), 
            OMX_EventMark, 0, 0, pMarkBufMsg->markBuffer.pMarkData );
	  }

   }
   else
   {
      /**---------------------------------------------------------------------
         Pass this to common device handler routine.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntCommon_DeviceEventHandler( pCmpntCtx, 
                           nEventCode, nEventStatus, nParamSize, pParam );

   }

   return( eRetVal );

} /* end of function qomx_CmpntPause_DeviceEventHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntPause_SetStateExecuting

         DESCRIPTION:
*//**                   This function will check suspension status and 
                        move the component to PauseToExecuting state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntPause_SetStateExecuting
(
   OMX_IN   QOMX_CmpntCtxType         *pCmpntCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntPause_SetStateExecuting" );

   /**------------------------------------------------------------------------
      Component can not be resumed, if resources are not reacquired yet.
   -------------------------------------------------------------------------*/
   if( QOMX_RESOURCES_TEMPORARILY_LOST == pCmpntCtx->eResState )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Resources are not acquired yet." );

      /**---------------------------------------------------------------------
         Report component suspended error.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
         "Send OMX_ErrorComponentSuspended notification." );

      ( void ) qomx_CmpntNotifyError( 
                  & ( pCmpntCtx->commonRef ), OMX_ErrorComponentSuspended );

   }
   else
   {
      /**---------------------------------------------------------------------
         Move to transitional state PauseToExecuting which will command
         device to resume and start buffer processing.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
         "Move to QOMX_StatePauseToExecuting." );

      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                           QOMX_StatePauseToExecuting, QOMX_EVENT_UNKNOWN );

   }

   return;

} /* end of function qomx_CmpntPause_SetStateExecuting */


/*==========================================================================

         FUNCTION:      qomx_CmpntPause_ResourcesLost

         DESCRIPTION:
                        This function will process resources lost event from
                        device.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx   - Pointer to the component context.

**//*    RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntPause_ResourcesLost
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntPause_ResourcesLost" );

   /**------------------------------------------------------------------------
      If the resources loss is temporary and it is resumable from the point
      it lost, remain in Pause state.
      Else start deinitialization process by moving component to Idle ->
      Loaded state.
   -------------------------------------------------------------------------*/
   if( QOMX_RESOURCES_TEMPORARILY_LOST == pCmpntCtx->eResState )
   {
      QOMX_MSG_L_HIGH( pCommonRef,
         "Suspension enabled. Pausing component." );

      /**---------------------------------------------------------------------
         Set suspension status.
      ----------------------------------------------------------------------*/
      pCmpntCtx->eSuspension = OMX_Suspended;

      /**---------------------------------------------------------------------
         Report suspension status to IL client.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
         "Send OMX_ErrorComponentSuspended notification." );

      ( void ) qomx_CmpntNotifyError( 
                  & ( pCmpntCtx->commonRef ), OMX_ErrorComponentSuspended );

   }
   else
   {
      QOMX_MSG_L_HIGH( pCommonRef,
         "Stopping, moving component to Idle state." );

      /**---------------------------------------------------------------------
         Reset suspension status.
      ----------------------------------------------------------------------*/
      pCmpntCtx->eSuspension = OMX_NotSuspended;

      /**---------------------------------------------------------------------
         Report resources preempted error to IL client.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
         "Send OMX_ErrorResourcesPreempted notification." );

      ( void ) qomx_CmpntNotifyError( 
                  & ( pCmpntCtx->commonRef ), OMX_ErrorResourcesPreempted );

      /**---------------------------------------------------------------------
         Move to transition state ExecutingToIdle which will stop the 
         device.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
         "Move to QOMX_StateExecutingToIdle." );

      ( void ) qomx_CmpntCommon_DoStateTransition( 
                  pCmpntCtx, QOMX_StateExecutingToIdle, QOMX_EVENT_UNKNOWN );

   }

   return;

} /* end of function qomx_CmpntPause_ResourcesLost */
