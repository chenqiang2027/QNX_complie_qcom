#ifndef __QOMX_PORT_CONTEXT_H__
#define __QOMX_PORT_CONTEXT_H__

/*========================================================================

*//** @file qomxPortContext.h

@par FILE SERVICES:       
      Port Context Header File.
      
      This file contains the port context which maintains the port state
      machines and other port properties etc.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2013 QUALCOMM Technologies, Incorporated.  All Rights 
    Reserved. QUALCOMM Proprietary. Export of this technology or software is 
    regulated by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxPortContext.h#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
12/16/13   rz     Fix MarkBuffer structure and free MarkBufFullList
11/07/13   am     Fix mark buffer implementation.
08/28/10   zm     Added vendor tunneling race condition flags.
07/22/10   zm     Add utility functions for logging.
07/15/10   yt     Added tunneling race condition flags.
03/26/10   spl    Modified to support interop-profile.
07/21/09   dm     Handled buffer supplier settings.
06/12/09   dm     Initial creation.

========================================================================== */

/*======================================================================== 
 
                     INCLUDE FILES FOR MODULE 
 
========================================================================== */
#include "qomxCommon.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */


/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 * 
 * The following enumeration specifies what type of tunneling is setup for 
 * the port.
 * 
 */

typedef enum
{
   PORT_TUNNELING_DISABLED,               /**<
                                          * Tunneling is disabled.
                                          */

   PORT_TUNNELING_NORMAL,                 /**<
                                          * Normal tunneling is enabled.
                                          */

   PORT_TUNNELING_VENDOR,                 /**<
                                          * Vendor tunneling is enabled.
                                          */

   PORT_TUNNELING_CLOCK,                  /**<
                                          * Tunneled component is a clock.
                                          */

} QOMX_PortTunnnelingType;


typedef struct QOMX_MarkBufferList
{
    QMM_ListLinkType           link;       //**<
                                           // Reserved for use by qmmList only.
                                           // This is the link object which is
                                           // used by qmmList interface methods
                                           // to push or pop this buffer header
                                           // object into the queue.
                                           //**
   
    OMX_MARKTYPE              markBuffer;
                     /**<
                                          * This structure is used when the
                                          * application requests marking a
                                          * buffer.
                                          */
}QOMX_MarkBufferList;

/**
 * 
 * Following stucture defines the individual port context which holds the 
 * port definition, port state machine, buffer queue etc.
 * 
 */

typedef struct
{

   OMX_PARAM_PORTDEFINITIONTYPE     portDef;
                                          /**<
                                          * This is the OMX port definition
                                          * which characterizes the port.
                                          */
   
   QOMX_PortStateType               eState;
                                          /**<
                                          * Current QOMX port state of the
                                          * port state machine.
                                          */

   QMM_ListHandleType               hBufHdrQueue;
                                          /**<
                                          * This is the handle to the buffer
                                          * queue handle which keeps tracks
                                          * of the buffer headers associated
                                          * with this port.
                                          */

   OMX_U32                          nBuffersWithDevice;
                                          /**<
                                          * Total number of buffers being
                                          * processed by the device currently.
                                          * This equals to the number of
                                          * callback pending for the fill or
                                          * empty buffer done.
                                          */

   OMX_S32                          nBuffersWithClient;
                                          /**<
                                          * Total number of buffers, that are 
                                          * being, processed by the client, or 
                                          * the tunneled peer.  This count is 
                                          * incremented when we send a buffer
                                          * to the client/peer via 
                                          * EmptyThisBuffer or FillThisBuffer 
                                          * command responses, or via the
                                          * AllocatBuffer command, and 
                                          * decremented via FillThisBuffer or
                                          * EmptyThisBuffer commands. This count
                                          * can go negative when this component 
                                          * is not the buffer supplier since 
                                          * the AllocateBuffer command is not 
                                          * called in this case.  When this 
                                          * count is zero, it means that this 
                                          * component is not holding any buffers 
                                          * belonging to the client/peer, or
                                          * the client/peer is not holding any 
                                          * buffers belonging to this component.
                                          */

   OMX_BUFFERSUPPLIERTYPE           eBufferSupplier;
                                          /**<
                                          * This enum specifies the buffer
                                          * supplier type whether input port,
                                          * output port or unspecified.
                                          */

   OMX_BOOL                         bAlterCmdFinished;
                                          /**<
                                          * This flag indicates if enable or
                                          * disable port is successfully
                                          * processed by the device and
                                          * callback for the same has been
                                          * received.
                                          */

   OMX_BOOL                         bAlterCmdPending;
                                          /**<
                                          * This flag indicates if enable or
                                          * disable command from the client
                                          * is in process and send command to
                                          * device is pending.
                                          */

   OMX_BOOL                         bAlterRespPending;
                                          /**<
                                          * This flag indicates if enable or
                                          * disable request from the client
                                          * is being processed and callback
                                          * to the application is pending.
                                          */

   OMX_MARKTYPE                     markBuffer;
                                          /**<
                                          * This structure is used when the
                                          * application requests marking a
                                          * buffer.
                                          */

   OMX_HANDLETYPE                   hTunneledComp;
                                          /**<
                                          * When this port is setup for tunneling, 
                                          * this will variable contain the handle 
                                          * to the tunneled component.
                                          */

   OMX_U32                          nTunneledPort;
                                          /**<
                                          * When this port is setup for tunneling, 
                                          * this will variable contain the port index 
                                          * of the tunneled device.
                                          */

   QOMX_PortTunnnelingType          eTunneling;
                                          /**<
                                          * This enum specifies what type of 
                                          * tunneling is enabled.
                                          */
      
   OMX_BOOL                         bTunnelPeerIsQOMX;
                                          /**<
                                          * This flag specifies if tunnel peer port
                                          * is also a Qualcomm component.
                                          */
                                             
   OMX_BOOL                         bTunnelPeerAcceptsUseBuffer;
                                          /**<
                                          * This flag is used to keep status of 
                                          * tunneled peer for UseBuffer calls
                                          * to prevent tunneling race conditions.
                                          */

   OMX_BOOL                         bTunnelPeerAcceptsBufferExchange;
                                          /**<
                                          * This flag is used to keep status of 
                                          * tunneled peer for ETB/FTB calls
                                          * to prevent tunneling race conditions.
                                          */

   OMX_BOOL                         bTunnelPeerAcceptsFreeBuffer;
                                          /**<
                                          * This flag is used to keep status of 
                                          * tunneled peer for FreeBuffer calls
                                          * to prevent tunneling race conditions.
                                          */   
   
   OMX_BOOL							      bVendorTunnelPeerLoadedToIdle;
										            /**<
                                          * This flag is used to keep status of 
                                          * vendor-tunneled peer for receiving 
										            * loaded to idle command to prevent 
										            * tunneling race conditions.
										            *
										            * Base class uses this flag to ensure
										            * that supplier port will not issue
										            * load resources command until it is
										            * signaled from non-supplier port and
										            * non-supplier port will not issue 
										            * load resources command until the
										            * supplier port gets succeeded 
										            * response for its load resources 
										            * command and signals the non-supplier
										            * port.
                                          */ 

   OMX_BOOL							      bVendorTunnelPeerPortEnable;
										            /**<
                                          * This flag is used to keep status of 
                                          * vendor-tunneled peer for receiving
										            * port enable command to prevent 
										            * tunneling race conditions.
										            *
										            * Base class uses this flag to ensure
										            * that supplier port will not issue
										            * port enable command until it is
										            * signaled from non-supplier port and
										            * non-supplier port will not issue 
										            * port enable command until the
										            * supplier port gets succeeded 
										            * response for its port enable 
										            * command and signals the non-supplier
										            * port.
                                          */ 

   OMX_U32                          nRateFirstTS;
                                          /**<
                                          * The wall time in milliseconds for the first packet.  Used in 
                                          * calculating average bit and packet rates for the entire 
                                          * duration.
                                          */

   OMX_U32                          nRateLastTS;
                                          /**<
                                          * The wall time in milliseconds for the last time the average 
                                          * bit and packet rates were calculated.
                                          */

   OMX_U32                          nRateData;
                                          /**<
                                          * This is the amout of data received since the last
                                          * time the average rate was calculated. This value is 
                                          * used in calculating the current average bit rate
                                          */

   OMX_U32                          nRateDataTotal;
                                          /**<
                                          * The total number of packets received.  This value is 
                                          * used in calculating the average packet rate for the entire 
                                          * duration.
                                          */

   OMX_U32                          nRatePackets;
                                          /**<
                                          * This is the number of packets received since the last
                                          * time the average rate was calculated. This value is 
                                          * used in calculating the current average packet rate.
                                          */

   OMX_U32                          nRatePacketsTotal;
                                          /**<
                                          * The total number of packets received.  This value is 
                                          * used in calculating the average packet rate for the entire 
                                          * duration.
                                          */

   OMX_U32                          nCurrentAverageDataRate;
                                          /**<
                                          * The total packet rate over the life of the port.
                                          */

   OMX_U32                          nCurrentAveragePacketRate;
                                          /**<
                                          * The current average data rate (bytes per second) over the last 
                                          * reporting period.  
                                          */
   QMM_ListHandleType               MarkBufFullList;
                                          /**<
                                          * List that contains mark buffer entries that need to propagated via
                                          * port buffers
                                          */
                                          
   QMM_ListHandleType               MarkBufEmptyList;
                                          /**<
                                          * The empty list that carries mark data structure elements for future 
                                          * use of mark buffer cmds on the port.
                                          */
} QOMX_PortContextType;



/**
 * 
 * Following stucture defines the port container which holds the port contexts
 * for all the ports defined by the component for all the domains.
 * 
 */

typedef struct
{

   QOMX_PortContextType            *paPortCtx;
                                          /**<
                                          * Array of audio, video, image, and
                                          * other Input and Output ports.
                                          * Memory allocation for these port
                                          * contexts would be done during
                                          * ports creation.
                                          */

   OMX_U32                          nNumPorts;
                                          /**<
                                          * Total number of ports for which
                                          * array of ports is allocated.
                                          * This is sum of all all audio,
                                          * video, image, and other domains
                                          * Input and Output ports.
                                          */

   /**------------------------------------------------------------------------
      Domain and functionality specific parameters. These are set during
      component creation.
   -------------------------------------------------------------------------*/

   QOMX_PortConfig                  audioDomain;
                                          /**<
                                          * This is configuration structure
                                          * for audio domain ports.
                                          */

   QOMX_PortConfig                  videoDomain;
                                          /**<
                                          * This is configuration structure
                                          * for video domain ports.
                                          * 'nPortStart' member of this
                                          * must be greater than 
                                          * > ( audioDomain.nPortStart
                                          *    + audioDomain.nNumInputPorts
                                          *    + audioDomain.nNumInputPorts )
                                          */

   QOMX_PortConfig                  imageDomain;
                                          /**<
                                          * This is configuration structure
                                          * for video domain ports.
                                          * 'nPortStart' member of this
                                          * must be greater than 
                                          * > ( videoDomain.nPortStart
                                          *    + videoDomain.nNumInputPorts
                                          *    + videoDomain.nNumInputPorts )
                                          */

   QOMX_PortConfig                  otherDomain;
                                          /**<
                                          * This is configuration structure
                                          * for video domain ports.
                                          * 'nPortStart' member of this
                                          * must be greater than 
                                          * > ( imageDomain.nPortStart
                                          *    + imageDomain.nNumInputPorts
                                          *    + imageDomain.nNumInputPorts )
                                          */

   /**------------------------------------------------------------------------
      Port state primitive tables.
   -------------------------------------------------------------------------*/
   
   OMX_HANDLETYPE                   hStateTables; 
                                          /**<
                                          * Handle to the port state primitive
                                          * tables. State tables are loaded
                                          * during ports creation.
                                          */

   /**------------------------------------------------------------------------
      Device and Application references data.
   -------------------------------------------------------------------------*/

   QOMX_CommonRefType              *pCommonRef;
                                          /**<
                                          * Pointer to the common references
                                          * object which holds information
                                          * about the underlying device and
                                          * the application.
                                          * This object is allocated in 
                                          * component context.
                                          */

} QOMX_PortContainerType;


#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */


#endif /* end of macro __QOMX_PORT_CONTEXT_H__ */
