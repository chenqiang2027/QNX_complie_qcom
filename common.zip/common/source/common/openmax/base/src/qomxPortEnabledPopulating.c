/*========================================================================

*//** @file qomxPortEnabledPopulating.c

@par FILE SERVICES:
      Implementation file for Port state QOMX_StatePortEnabledPopulating.

      This file contains the definitions for the port methods which are
      called when port state is QOMX_StatePortEnabledPopulating. This state
      is assumed when port is processing enable command and the buffer
      aquisition is in progress.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxPortEnabledPopulating.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
06/22/16   am     Fix compiler warnings for 64 bit OS environment.
10/23/13   dp     Add missing variable to messages.
03/20/13   am     Rename QOMX_CONFIG_TUNNELEDPORTSTATUSTYPE and associated variables
                  to QC omx extension for 1.1.2
08/08/11   dm     Hardware critical error handling.
11/22/10   zm     Use new QOMX_CMPNT_MALLOC and QOMX_CMPNT_FREEIF macros.
08/28/10   zm     Added peer signaling for vendor tunneling.
08/24/10   dm     Add platform private data for allocated buffers.
07/22/10   zm     Add component handle/port index in base class logging.
07/15/10   yt     Changes for tunneling and new EnabledDepopulating state.
06/10/10   dm     Added return type in event handler.
03/26/10   spl    Modified to support interop-profile.
10/29/09   dm     Fixed usebuffer buffer size bug.
10/20/09   dm     Port state split.
08/06/08   dm     Added check for buffer size in Use and Alloc buffer.
07/21/09   dm     Handled buffer supplier settings.
06/16/09   dm     Initial Creation.

========================================================================== */

/*========================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxPortCommon.h"
#include "qomxPortUtils.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/**
 *
 * Forward declaration for the functions defined statically in this file.
 *
 */

static void    qomx_PortEnabledPopulating_StateEntryHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
);

static void    qomx_PortEnabledPopulating_StateExitHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
);

static OMX_ERRORTYPE    qomx_PortEnabledPopulating_UseBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE        **ppBufferHdr,
   OMX_IN   OMX_PTR                       pAppPrivate,
   OMX_IN   OMX_U32                       nSizeBytes,
   OMX_IN   OMX_U8                       *pBuffer
);

static OMX_ERRORTYPE    qomx_PortEnabledPopulating_AllocateBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE        **ppBufferHdr,
   OMX_IN   OMX_PTR                       pAppPrivate,
   OMX_IN   OMX_U32                       nSizeBytes
);

static OMX_ERRORTYPE    qomx_PortEnabledPopulating_DeviceEventHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEventCode,
   OMX_IN   OMX_U32                       nEventStatus,
   OMX_IN   OMX_U32                       nParamSize,
   OMX_IN   OMX_PTR                      *pParam
);


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledPopulating_LoadStateTable

         DESCRIPTION:
                        This function will load the port state table supported
                        by the QOMX_StatePortEnabledPopulating state in the
                        object of state table being passed.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable    - Pointer to the state primitive table
                                      object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_PortEnabledPopulating_LoadStateTable
(
   OMX_IN   QOMX_PortStateTableType      *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      port is in QOMX_StatePortEnabledPopulating state. NULL entry indicates
      that the specific function call is not allowed in this state, thus
      port utilities should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/
   pStTable->Enable           = NULL;
   pStTable->Disable          = NULL;
   pStTable->TunnelRequest    = NULL;
   pStTable->Populate         = NULL;
   pStTable->Unpopulate       = qomx_PortCommon_Unpopulate;
   pStTable->Run              = NULL;
   pStTable->Stop             = NULL;
   pStTable->UseBuffer        = qomx_PortEnabledPopulating_UseBuffer;
   pStTable->AllocateBuffer   = qomx_PortEnabledPopulating_AllocateBuffer;
   pStTable->FreeBuffer       = qomx_PortCommon_FreeBufferUnexpected;
   pStTable->EmptyThisBuffer  = NULL;
   pStTable->FillThisBuffer   = NULL;
   pStTable->Flush            = NULL;
   pStTable->DeInit           = qomx_PortCommon_DeInit;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler  = qomx_PortEnabledPopulating_DeviceEventHandler;

   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler  = qomx_PortEnabledPopulating_StateEntryHandler;
   pStTable->pfnExitHandler   = qomx_PortEnabledPopulating_StateExitHandler;

   return;

} /* end of function qomx_PortEnabledPopulating_LoadStateTable */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledPopulating_StateEntryHandler

         DESCRIPTION:
*//**                   This function executes initial routines when port
                        moves in QOMX_StatePortEnabledPopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the Port context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_PortEnabledPopulating_StateEntryHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
)
{
   OMX_ERRORTYPE  eRetVal;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Entering EnabledPopulating"
      " State, nPortIndex = 0x%x, nEvent = 0x%x",
      pPortCtx->portDef.nPortIndex, nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pPortCtx->eState = QOMX_StatePortEnabledPopulating;

   /**------------------------------------------------------------------------
      If tunneling, buffer count and size has to be negotiated.
   -------------------------------------------------------------------------*/
   if( ( PORT_TUNNELING_DISABLED != pPortCtx->eTunneling )
         && ( PORT_TUNNELING_VENDOR != pPortCtx->eTunneling ) )
   {
      /**---------------------------------------------------------------------
         If this is a non-vendor tunneling supplier port, allocate buffers and
        pass on to peer component.
      ----------------------------------------------------------------------*/
      if ( QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx ) )
     {
        QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
           "Port is tunneling supplier." );

       if( pPortCtx->bTunnelPeerAcceptsUseBuffer )
       {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
            "Peer already accepts UseBuffer calls." );

         eRetVal = qomx_PortCommon_SupplyTunnelBuffers(pPortCtnr, pPortCtx);

         if( OMX_ErrorNone != eRetVal )
         {
             QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef,
                "SupplyTunnelBuffers failed." );
         }
       }
       else
       {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
            "Port is awaiting peer to signal UseBuffer acceptance." );
       }
     }
     /**------------------------------------------------------------------------
         If this is a non-vendor tunneling non-supplier, signal peer for
        UseBuffer acceptance.
      -------------------------------------------------------------------------*/
     else
     {
        QDFC_ErrorType    eErrVal;
         /*--------------------------------------------------------------------*/

       QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
          "Port is tunneling non-supplier. Signal peer." );

       eErrVal = qdfc_EnqueueArg6Function( pPortCtnr->pCommonRef->hDfc,
               ( qfc_Arg6FpType ) ( qomx_PortCommon_SignalTunnelPeer ),
               ( QDFC_ArgType ) pPortCtx->hTunneledComp,
               ( QDFC_ArgType ) pPortCtx->nTunneledPort,
               ( QDFC_ArgType ) QOMX_PORTSTATUS_ACCEPTSUSEBUFFER,
               ( QDFC_ArgType ) 0,
               ( QDFC_ArgType ) 0,
               ( QDFC_ArgType ) 0 );

       if( QDFC_ERROR_NONE != eErrVal )
       {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef,
            "DFC EnQueue error = %d. Event dropped", eErrVal );

       }
     }
   }
   /**------------------------------------------------------------------------
      If this is a vendor tunneling non-supplier, signal peer based on whether
     port enable command is pending sent to MMI device.
   -------------------------------------------------------------------------*/
   else if( ( PORT_TUNNELING_VENDOR == pPortCtx->eTunneling )
         && ( !QOMX_PORT_IS_BUFFER_SUPPLIER( pPortCtx ) ) )
   {
      QDFC_ErrorType    eErrVal;
      /*--------------------------------------------------------------------*/

     if ( pPortCtx->bAlterCmdPending )
     {
        QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
           "Port is vendor-tunneling non-supplier and port "
           "enable command is pending. Signal peer for port enable "
           "acceptance." );

        /**------------------------------------------------------------------
          If this is a vendor tunneling non-supplier port and port enable
         command is pending, signal peer for port enable acceptance.
         -------------------------------------------------------------------*/
       eErrVal = qdfc_EnqueueArg6Function( pPortCtnr->pCommonRef->hDfc,
                  ( qfc_Arg6FpType ) ( qomx_PortCommon_SignalTunnelPeer ),
                  ( QDFC_ArgType ) pPortCtx->hTunneledComp,
                  ( QDFC_ArgType ) pPortCtx->nTunneledPort,
                  ( QDFC_ArgType ) OMX_PORTSTATUS_VTACCEPTSPORTENABLE,
                  ( QDFC_ArgType ) 0,
                  ( QDFC_ArgType ) 0,
                  ( QDFC_ArgType ) 0 );
     }
     else
     {
        QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef,
           "Port is vendor-tunneling non-supplier. Signal peer "
           "for Loaded->Idle acceptance." );

        /**------------------------------------------------------------------
          If this is a vendor tunneling non-supplier port and there is no
         pending port enable command, signal peer for Loaded->Idle
         acceptance.
         -------------------------------------------------------------------*/
       eErrVal = qdfc_EnqueueArg6Function( pPortCtnr->pCommonRef->hDfc,
                  ( qfc_Arg6FpType ) ( qomx_PortCommon_SignalTunnelPeer ),
                  ( QDFC_ArgType ) pPortCtx->hTunneledComp,
                  ( QDFC_ArgType ) pPortCtx->nTunneledPort,
                  ( QDFC_ArgType ) OMX_PORTSTATUS_VTACCEPTSLOADEDTOIDLE,
                  ( QDFC_ArgType ) 0,
                  ( QDFC_ArgType ) 0,
                  ( QDFC_ArgType ) 0 );
     }

      if( QDFC_ERROR_NONE != eErrVal )
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef,
            "DFC EnQueue error = %d. Event dropped", eErrVal );

      }

   }

   return;

} /* end of function qomx_PortEnabledPopulating_StateEntryHandler */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledPopulating_StateExitHandler

         DESCRIPTION:
*//**                   This function executes initial routines when port
                        moves out of QOMX_StatePortEnabledPopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the Port context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_PortEnabledPopulating_StateExitHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEvent
)
{
   QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "Exiting EnabledPopulating"
      " State, nPortIndex = 0x%x, nEvent = 0x%x",
      pPortCtx->portDef.nPortIndex, nEvent );

   return;

} /* end of function qomx_PortEnabledPopulating_StateExitHandler */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledPopulating_UseBuffer

         DESCRIPTION:
*//**                   This function processes use buffer request when port
                        is in QOMX_StatePortEnabledPopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL specification.
            @param[in]  nSizeBytes  - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pBuffer     - Refer OMX_Core.h / OMX IL specification.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortEnabledPopulating_UseBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE        **ppBufferHdr,
   OMX_IN   OMX_PTR                       pAppPrivate,
   OMX_IN   OMX_U32                       nSizeBytes,
   OMX_IN   OMX_U8                       *pBuffer
)
{
   OMX_ERRORTYPE              eRetVal        = OMX_ErrorNone;
   OMX_U32                    nStatus        = MMI_S_EFAIL;
   QOMX_CommonRefType        *pCommonRef     = pPortCtnr->pCommonRef;
   QOMX_PortBufferHdrLink    *pBufHdrLink    = NULL;
   OMX_BUFFERHEADERTYPE      *pBufferHdr     = NULL;
   QMM_ListHandleType        *pHBufHdrQueue  = & ( pPortCtx->hBufHdrQueue );
   QMM_ListSizeType           nQueueSize;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortEnabledPopulating_UseBuffer"
      " nPortIndex = 0x%x, nSizeBytes = %u", pPortCtx->portDef.nPortIndex,
      nSizeBytes );

   /**------------------------------------------------------------------------
      UseBuffer should not be allowed if current port is buffer allocator or
      buffer header queue size has already reached limit of actual buffer
      count.
   -------------------------------------------------------------------------*/
   if( ( OMX_DirInput == pPortCtx->portDef.eDir )
      && ( OMX_BufferSupplyInput == pPortCtx->eBufferSupplier ) )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Buffer supplier is set as input port,"
         " nPortIndex = 0x%x, eDir = 0x%x", pPortCtx->portDef.nPortIndex,
         pPortCtx->portDef.eDir );

      /**---------------------------------------------------------------------
         This port is an input port and buffer supplier is also set as
         input port. Incorrect state operation.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorIncorrectStateOperation;

   }
   else if( ( OMX_DirOutput == pPortCtx->portDef.eDir )
      && ( OMX_BufferSupplyOutput == pPortCtx->eBufferSupplier ) )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Buffer supplier is set as output port,"
         " nPortIndex = 0x%x, eDir = 0x%x", pPortCtx->portDef.nPortIndex,
         pPortCtx->portDef.eDir );

      /**---------------------------------------------------------------------
         This port is an output port and buffer supplier is also set as
         output port. Incorrect state operation.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorIncorrectStateOperation;

   }
   else if( nSizeBytes < pPortCtx->portDef.nBufferSize )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "nSizeBytes = %u < portDef.nBufferSize"
         " = %u", nSizeBytes, pPortCtx->portDef.nBufferSize );

      /**---------------------------------------------------------------------
         Buffer size requested is lesser than the minimum buffer size exposed
         in the buffer requirement. Return bad parameter.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else if( QMM_LIST_ERROR_NONE != qmm_ListSize(
                                             pHBufHdrQueue, & nQueueSize ) )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "List corruption, Fatal Error,"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Queue is corrupted, Component should move into an invalid state
         which is not recoverable now.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorInvalidState;

   }
   else if( pPortCtx->portDef.nBufferCountActual == nQueueSize )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Buffers = %u are already assigned,"
         " nPortIndex = 0x%x", nQueueSize, pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         All buffers are already set, Port is waiting for enable done
         callback from device. Return incorrect state operation.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorIncorrectStateOperation;

   }


   /**------------------------------------------------------------------------
      Allocate buffer header link.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_MSG_L_MED( pCommonRef, "Allocating buffer header link,"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      pBufHdrLink = ( QOMX_PortBufferHdrLink * ) QOMX_CMPNT_MALLOC(
                        pCommonRef->pfnMalloc, pCommonRef->hHeap, sizeof( QOMX_PortBufferHdrLink ) );

      if( NULL == pBufHdrLink )
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Insufficient memory,"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Failed to allocate buffer header link memory, return error.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorInsufficientResources;

      }
      else
      {
         /**------------------------------------------------------------------
            Initialize memory to 0.
         -------------------------------------------------------------------*/
         QOMX_CMPNT_MEM_SET(
                  pBufHdrLink, 0, sizeof( QOMX_PortBufferHdrLink ) );

         /**------------------------------------------------------------------
            Device is not the buffer allocator for this buffer header.
         -------------------------------------------------------------------*/
         pBufHdrLink->bDeviceIsBufferAllocator = OMX_FALSE;

      }

   }

   /**------------------------------------------------------------------------
      Allocate buffer header object.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_MSG_L_MED( pCommonRef, "Allocating buffer header,"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      pBufferHdr = ( OMX_BUFFERHEADERTYPE * ) QOMX_CMPNT_MALLOC(
                        pCommonRef->pfnMalloc, pCommonRef->hHeap, sizeof( OMX_BUFFERHEADERTYPE ) );

      if( NULL == pBufferHdr )
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Insufficient memory,"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Failed to allocate buffer header memory, return error.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorInsufficientResources;

      }
      else
      {
         /**------------------------------------------------------------------
            Initialize memory to 0.
         -------------------------------------------------------------------*/
         QOMX_CMPNT_MEM_SET( pBufferHdr, 0, sizeof( OMX_BUFFERHEADERTYPE ) );

         /**------------------------------------------------------------------
            Port is the buffer allocator for this buffer header.
         -------------------------------------------------------------------*/
         pBufHdrLink->bPortIsHeaderAllocator = OMX_TRUE;

         /**------------------------------------------------------------------
            Assing buffer header in the header link.
         -------------------------------------------------------------------*/
         pBufHdrLink->pBufferHdr = pBufferHdr;

      }

   }

   /**------------------------------------------------------------------------
      Set buffer header properties and assign it to the caller.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {

      MMI_UseBufferCmdType    useBufferCmd;
      /*--------------------------------------------------------------------*/

      QOMX_MSG_L_MED( pCommonRef, "Setting buffer header properties,"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      if ( OMX_DirInput == pPortCtx->portDef.eDir )
      {
         pBufferHdr->nInputPortIndex  = pPortCtx->portDef.nPortIndex;

         if ( NULL != pPortCtx->hTunneledComp )
         {
            pBufferHdr->nOutputPortIndex = pPortCtx->nTunneledPort;
         }

      }
      else
      {
         pBufferHdr->nOutputPortIndex = pPortCtx->portDef.nPortIndex;

         if ( NULL != pPortCtx->hTunneledComp )
         {
            pBufferHdr->nInputPortIndex = pPortCtx->nTunneledPort;
         }

      }

      /**---------------------------------------------------------------------
         Send this buffer header to the device.
      ----------------------------------------------------------------------*/
      useBufferCmd.nPortIndex = pPortCtx->portDef.nPortIndex;
      useBufferCmd.pBuffer    = pBuffer;
      useBufferCmd.nSize      = nSizeBytes;

      nStatus = pCommonRef->device.pfnCmd(
                        pCommonRef->hFd, MMI_CMD_USE_BUFFER, & useBufferCmd );

      QOMX_MSG_L_HIGH( pCommonRef, "MMI_CMD_USE_BUFFER status = 0x%x,"
         " nPortIndex = 0x%x", nStatus, pPortCtx->portDef.nPortIndex );

      if( MMI_S_COMPLETE != nStatus )
      {
         QOMX_MSG_L_ERROR( pCommonRef, "MMI_CMD_USE_BUFFER failed,"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Use this buffer is rejected by device. Return appropriate error.
         -------------------------------------------------------------------*/
         eRetVal = qomx_GetOMXErrorCode( nStatus );

      }
      else
      {
         pBufferHdr->nSize             = sizeof( OMX_BUFFERHEADERTYPE );
         pBufferHdr->nVersion          = pPortCtx->portDef.nVersion;
         pBufferHdr->pBuffer           = pBuffer;
         pBufferHdr->nAllocLen         = nSizeBytes;
         pBufferHdr->pAppPrivate       = pAppPrivate;
         pBufferHdr->pPlatformPrivate  = useBufferCmd.pPlatformPvt;

         /**------------------------------------------------------------------
            Push this buffer header in queue.
         -------------------------------------------------------------------*/
         ( void ) qmm_ListPushRear( pHBufHdrQueue,  & ( pBufHdrLink->link ) );

      }

      /**---------------------------------------------------------------------
         If all buffers are set, set population flag.
      ----------------------------------------------------------------------*/
      if( ( OMX_ErrorNone == eRetVal )
          && ( OMX_TRUE == qomx_PortCommon_CheckGuard(
                                 pPortCtx, QOMX_PORT_GUARD_POPULATED ) ) )
      {
         QOMX_MSG_L_HIGH( pCommonRef, "Port is populated now."
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         pPortCtx->portDef.bPopulated = OMX_TRUE;

      }

      /**---------------------------------------------------------------------
         If all buffers are populated and device is enabled, transition
         to QOMX_StatePortEnabledPopulated state.
      ----------------------------------------------------------------------*/
      if( ( OMX_TRUE == pPortCtx->portDef.bPopulated )
          && ( OMX_TRUE == pPortCtx->bAlterCmdFinished ) )
      {
         QOMX_CmpntStateType     eCmpntState;
         /*-----------------------------------------------------------------*/

         /**------------------------------------------------------------------
            Get current component state.
         -------------------------------------------------------------------*/
         eCmpntState = qomx_CmpntGetQOMXState( pCommonRef->hCmpnt );

         /**------------------------------------------------------------------
            If component state is Executing or Pause, move port to
            Running state, otherwise move it to Populated.
         -------------------------------------------------------------------*/
         if( ( QOMX_StateExecuting == eCmpntState )
            || ( QOMX_StatePause == eCmpntState ) )
         {
            QOMX_MSG_L_MED( pCommonRef, "Component is Executing/Pause, Move"
               " to EnabledRunning state, nPortIndex = 0x%x",
               pPortCtx->portDef.nPortIndex );

            /**---------------------------------------------------------------
               Complete state transition to Running.
            ----------------------------------------------------------------*/
            ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                              pPortCtx, QOMX_StatePortEnabledRunning, 0 );

         }
         else
         {
            QOMX_MSG_L_MED( pCommonRef, "Component is Idle, Move to"
               " EnabledPopulated state, nPortIndex = 0x%x",
               pPortCtx->portDef.nPortIndex );

            /**---------------------------------------------------------------
               Complete state transition to Populated.
            ----------------------------------------------------------------*/
            ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                              pPortCtx, QOMX_StatePortEnabledPopulated, 0 );

         }


         /**------------------------------------------------------------------
            If enable port command is being processed, send response now.
         -------------------------------------------------------------------*/
         if( OMX_TRUE == pPortCtx->bAlterRespPending )
         {
            QOMX_MSG_L_MED( pCommonRef, "Enabled port successful, Send"
               " OMX_CommandPortEnable notification nPortIndex = 0x%x",
               pPortCtx->portDef.nPortIndex );

            pPortCtx->bAlterRespPending = OMX_FALSE;

            ( void ) qomx_CmpntCmdComplete( pCommonRef, OMX_CommandPortEnable,
                                 pPortCtx->portDef.nPortIndex, NULL );

         }

      }

   }


   /**------------------------------------------------------------------------
      Assing buffer header to out parameter.
      Release allocated memories, if there was any error.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_MSG_L_MED( pCommonRef, "Use buffer finished successfully."
         " nPortIndex = 0x%x, pBufferHdr = 0x%p",
               pPortCtx->portDef.nPortIndex,  pBufferHdr );

      /**---------------------------------------------------------------------
         Assing buffer header to out parameter.
      ----------------------------------------------------------------------*/
      ( *ppBufferHdr ) = pBufferHdr;

   }
   else
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Releasing memory."
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      QOMX_CMPNT_FREEIF( pCommonRef->pfnFree, pCommonRef->hHeap, pBufferHdr );
      QOMX_CMPNT_FREEIF( pCommonRef->pfnFree, pCommonRef->hHeap, pBufHdrLink );

      /**---------------------------------------------------------------------
         Move component to Invalid state on fatal error.
      ----------------------------------------------------------------------*/
      if( OMX_ErrorInvalidState == eRetVal )
      {
         QOMX_MSG_L_HIGH( pCommonRef, "Fatal error, Move to Invalid state"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

      }

   }

   return( eRetVal );

} /* end of function qomx_PortEnabledPopulating_UseBuffer */


/*==========================================================================

         FUNCTION:      qomx_PortEnabledPopulating_AllocateBuffer

         DESCRIPTION:
*//**                   This function processes use buffer request when port
                        is in QOMX_StatePortEnabledPopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[out] ppBufferHdr - Refer OMX_Core.h / OMX IL specification.
            @param[in]  pAppPrivate - Refer OMX_Core.h / OMX IL specification.
            @param[in]  nSizeBytes  - Refer OMX_Core.h / OMX IL specification.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortEnabledPopulating_AllocateBuffer
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_BUFFERHEADERTYPE        **ppBufferHdr,
   OMX_IN   OMX_PTR                       pAppPrivate,
   OMX_IN   OMX_U32                       nSizeBytes
)
{
   OMX_ERRORTYPE              eRetVal        = OMX_ErrorNone;
   QOMX_CommonRefType        *pCommonRef     = pPortCtnr->pCommonRef;
   QMM_ListHandleType        *pHBufHdrQueue  = & ( pPortCtx->hBufHdrQueue );
   QOMX_PortBufferHdrLink    *pBufHdrLink    = NULL;
   OMX_BUFFERHEADERTYPE      *pBufferHdr     = NULL;
   OMX_U32                    nStatus        = MMI_S_EFAIL;
   MMI_AllocBufferCmdType     allocBufferCmd;
   QMM_ListSizeType           nQueueSize;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_PortEnabledPopulating_AllocateBuffer"
      " nPortIndex = 0x%x, nSizeBytes = %u", pPortCtx->portDef.nPortIndex,
      nSizeBytes );

   /**------------------------------------------------------------------------
      AllocateBuffer should not be allowed if current port is not buffer
      allocator or buffer header queue size has already reached limit
      of actual buffer count.
   -------------------------------------------------------------------------*/
   if( ( OMX_DirInput == pPortCtx->portDef.eDir )
      && ( OMX_BufferSupplyOutput == pPortCtx->eBufferSupplier ) )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Buffer supplier is set as input port,"
         " nPortIndex = 0x%x, eDir = 0x%x", pPortCtx->portDef.nPortIndex,
         pPortCtx->portDef.eDir );

      /**---------------------------------------------------------------------
         This port is an input port and buffer supplier is set as an
         output port. Incorrect state operation.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorIncorrectStateOperation;

   }
   else if( ( OMX_DirOutput == pPortCtx->portDef.eDir )
      && ( OMX_BufferSupplyInput == pPortCtx->eBufferSupplier ) )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Buffer supplier is set as output port,"
         " nPortIndex = 0x%x, eDir = 0x%x", pPortCtx->portDef.nPortIndex,
         pPortCtx->portDef.eDir );

      /**---------------------------------------------------------------------
         This port is an output port and buffer supplier is set as an
         input port. Incorrect state operation.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorIncorrectStateOperation;

   }
   else if( nSizeBytes < pPortCtx->portDef.nBufferSize )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "nSizeBytes = %u < portDef.nBufferSize"
         " = %u", nSizeBytes, pPortCtx->portDef.nBufferSize );

      /**---------------------------------------------------------------------
         Buffer size requested is lesser than the minimum buffer size exposed
         in the buffer requirement. Return bad parameter.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorBadParameter;

   }
   else if( QMM_LIST_ERROR_NONE != qmm_ListSize(
                                             pHBufHdrQueue, &nQueueSize ) )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "List corruption, Fatal Error,"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Queue is corrupted, Component should move into an invalid state
         which is not recoverable now.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorInvalidState;

   }
   else if( pPortCtx->portDef.nBufferCountActual == nQueueSize )
   {
      QOMX_MSG_L_ERROR( pCommonRef, "Buffers = %u are already assigned,"
         " nPortIndex = 0x%x", nQueueSize, pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         All buffers are already set, Port is waiting for enable done
         callback from device. Return incorrect state operation.
      ----------------------------------------------------------------------*/
      eRetVal = OMX_ErrorIncorrectStateOperation;

   }


   /**------------------------------------------------------------------------
      Allocate buffer header link.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_MSG_L_MED( pCommonRef, "Allocating buffer header link,"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      pBufHdrLink = ( QOMX_PortBufferHdrLink * ) QOMX_CMPNT_MALLOC(
                        pCommonRef->pfnMalloc, pCommonRef->hHeap, sizeof( QOMX_PortBufferHdrLink ) );

      if( NULL == pBufHdrLink )
      {
         QOMX_MSG_L_ERROR( pCommonRef, "Insufficient memory,"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Failed to allocate buffer header memory, return error.
         -------------------------------------------------------------------*/
         eRetVal = OMX_ErrorInsufficientResources;

      }
      else
      {
         /**------------------------------------------------------------------
            Initialize memory to 0.
         -------------------------------------------------------------------*/
         QOMX_CMPNT_MEM_SET(
                        pBufHdrLink, 0, sizeof( QOMX_PortBufferHdrLink ) );

      }

   }


   /**------------------------------------------------------------------------
      Call Allocate buffer on device for buffer memory.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_MSG_L_MED( pCommonRef, "Allocating buffer memory,"
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      allocBufferCmd.nPortIndex = pPortCtx->portDef.nPortIndex;
      allocBufferCmd.nSize      = nSizeBytes;

      /**---------------------------------------------------------------------
         Device is the buffer allocator for this buffer header.
      ----------------------------------------------------------------------*/
      pBufHdrLink->bDeviceIsBufferAllocator = OMX_TRUE;

      nStatus = pCommonRef->device.pfnCmd( pCommonRef->hFd,
                                 MMI_CMD_ALLOC_BUFFER, & allocBufferCmd );

      QOMX_MSG_L_HIGH( pCommonRef, "MMI_CMD_ALLOC_BUFFER status = 0x%x,"
         " nPortIndex = 0x%x", nStatus, pPortCtx->portDef.nPortIndex );

      if( MMI_S_COMPLETE != nStatus )
      {
         QOMX_MSG_L_ERROR( pCommonRef, "MMI_CMD_ALLOC_BUFFER failed,"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Alloc buffer is rejected by device. Return appropriate error.
         -------------------------------------------------------------------*/
         eRetVal = qomx_GetOMXErrorCode( nStatus );

      }

   }


   /**------------------------------------------------------------------------
      Allocate buffer header object, if non-tunneling.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      if( NULL != pPortCtx->hTunneledComp )
      {
         QOMX_MSG_L_MED( pCommonRef, "Calling use buffer on tunneled port,"
            "hTunneledComp = 0x%p, nTunneledPort = 0x%x",
               pPortCtx->hTunneledComp, pPortCtx->nTunneledPort );

         /**------------------------------------------------------------------
            Call use buffer on tunneled port.
         -------------------------------------------------------------------*/
         eRetVal = OMX_UseBuffer(
                     pPortCtx->hTunneledComp, & pBufHdrLink->pBufferHdr,
                     pPortCtx->nTunneledPort, pAppPrivate,
                     nSizeBytes, allocBufferCmd.pBuffer );

      }
      else
      {
         QOMX_MSG_L_MED( pCommonRef, "Allocating buffer header,"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         pBufferHdr = ( OMX_BUFFERHEADERTYPE * ) QOMX_CMPNT_MALLOC(
                        pCommonRef->pfnMalloc, pCommonRef->hHeap, sizeof( OMX_BUFFERHEADERTYPE ) );

         if( NULL == pBufferHdr )
         {
            QOMX_MSG_L_ERROR( pCommonRef, "Insufficient memory,"
               " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

            /**---------------------------------------------------------------
               Failed to allocate buffer header memory, return error.
            ----------------------------------------------------------------*/
            eRetVal = OMX_ErrorInsufficientResources;

         }
         else
         {
            /**---------------------------------------------------------------
               Initialize memory to 0.
            ----------------------------------------------------------------*/
            QOMX_CMPNT_MEM_SET(
                        pBufferHdr, 0, sizeof( OMX_BUFFERHEADERTYPE ) );

            /**---------------------------------------------------------------
               Port is the buffer allocator for this buffer header.
            ----------------------------------------------------------------*/
            pBufHdrLink->bPortIsHeaderAllocator = OMX_TRUE;

            /**---------------------------------------------------------------
               Assing buffer header in the header link.
            ----------------------------------------------------------------*/
            pBufHdrLink->pBufferHdr = pBufferHdr;

            /**---------------------------------------------------------------
               Set buffer properties.
            ----------------------------------------------------------------*/
            QOMX_MSG_L_MED( pCommonRef, "Setting buffer header properties,"
               " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

            pBufferHdr->nSize             = sizeof( OMX_BUFFERHEADERTYPE );
            pBufferHdr->nVersion          = pPortCtx->portDef.nVersion;
            pBufferHdr->pBuffer           = allocBufferCmd.pBuffer;
            pBufferHdr->pPlatformPrivate  = allocBufferCmd.pPlatformPvt;
            pBufferHdr->nAllocLen         = nSizeBytes;
            pBufferHdr->pAppPrivate       = pAppPrivate;

            if ( OMX_DirInput == pPortCtx->portDef.eDir )
            {
               pBufferHdr->nInputPortIndex  = pPortCtx->portDef.nPortIndex;

            }
            else
            {
               pBufferHdr->nOutputPortIndex = pPortCtx->portDef.nPortIndex;

            }

         }

      }

   }


   /**------------------------------------------------------------------------
      Push this buffer header in queue.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_MSG_L_MED( pCommonRef, "Push buffer header in the queue now,"
               " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Push this buffer header in queue.
      ----------------------------------------------------------------------*/
      ( void ) qmm_ListPushRear( pHBufHdrQueue,  & ( pBufHdrLink->link ) );

      /**---------------------------------------------------------------------
         If all buffers are set, set population flag.
      ----------------------------------------------------------------------*/
      if( OMX_TRUE == qomx_PortCommon_CheckGuard(
                                 pPortCtx, QOMX_PORT_GUARD_POPULATED ) )
      {
         QOMX_MSG_L_HIGH( pCommonRef, "Port is populated now."
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         pPortCtx->portDef.bPopulated = OMX_TRUE;

      }


      /**---------------------------------------------------------------------
         If all buffers are populated and device is enabled, transition
         to QOMX_StatePortEnabledPopulated state.
      ----------------------------------------------------------------------*/
      if( ( OMX_TRUE == pPortCtx->portDef.bPopulated )
          && ( OMX_TRUE == pPortCtx->bAlterCmdFinished ) )
      {
         QOMX_CmpntStateType     eCmpntState;
         /*-----------------------------------------------------------------*/

         /**------------------------------------------------------------------
            Get current component state.
         -------------------------------------------------------------------*/
         eCmpntState = qomx_CmpntGetQOMXState( pCommonRef->hCmpnt );

         /**------------------------------------------------------------------
            If component state is Executing or Pause, move port to
            Running state, otherwise move it to Populated.
         -------------------------------------------------------------------*/
         if( ( QOMX_StateExecuting == eCmpntState )
            || ( QOMX_StatePause == eCmpntState ) )
         {
            QOMX_MSG_L_MED( pCommonRef, "Component is Executing/Pause, Move"
               " to EnabledRunning state, nPortIndex = 0x%x",
               pPortCtx->portDef.nPortIndex );

            /**---------------------------------------------------------------
               Complete state transition to Running.
            ----------------------------------------------------------------*/
            ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                              pPortCtx, QOMX_StatePortEnabledRunning, 0 );

         }
         else
         {
            QOMX_MSG_L_MED( pCommonRef, "Component is Idle, Move to"
               " EnabledPopulated state, nPortIndex = 0x%x",
               pPortCtx->portDef.nPortIndex );

            /**---------------------------------------------------------------
               Complete state transition to Populated.
            ----------------------------------------------------------------*/
            ( void ) qomx_PortCommon_DoStateTransition( pPortCtnr,
                              pPortCtx, QOMX_StatePortEnabledPopulated, 0 );

         }


         /**------------------------------------------------------------------
            If enable port command is being processed, send response now.
         -------------------------------------------------------------------*/
         if( OMX_TRUE == pPortCtx->bAlterRespPending )
         {
            QOMX_MSG_L_MED( pCommonRef, "Enabled port successful, Send"
               " OMX_CommandPortEnable notification nPortIndex = 0x%x",
               pPortCtx->portDef.nPortIndex );

            pPortCtx->bAlterRespPending = OMX_FALSE;

            ( void ) qomx_CmpntCmdComplete( pCommonRef, OMX_CommandPortEnable,
                                 pPortCtx->portDef.nPortIndex, NULL );

         }

      }

   }


   /**------------------------------------------------------------------------
      Assing buffer header to out parameter.
      Release allocated memories, if there was any error.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal )
   {
      QOMX_MSG_L_MED( pCommonRef, "Allocate buffer finished successfully."
         " nPortIndex = 0x%x, pBufferHdr = 0x%p",
               pPortCtx->portDef.nPortIndex, pBufferHdr );

      /**---------------------------------------------------------------------
         Assing buffer header to out parameter.
      ----------------------------------------------------------------------*/
      ( *ppBufferHdr ) = pBufferHdr;

   }
   else
   {
      MMI_FreeBufferCmdType   freeBufferCmd;
      /*--------------------------------------------------------------------*/

      QOMX_MSG_L_HIGH( pCommonRef, "Releasing memory."
         " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

      /**---------------------------------------------------------------------
         Release buffer allocated by device.
      ----------------------------------------------------------------------*/
      if( MMI_S_COMPLETE == nStatus )
      {
         QOMX_MSG_L_HIGH( pCommonRef, "Freeing buffer allocated by device."
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         freeBufferCmd.nPortIndex   = pPortCtx->portDef.nPortIndex;
         freeBufferCmd.pBuffer      = allocBufferCmd.pBuffer;
         freeBufferCmd.pPlatformPvt = allocBufferCmd.pPlatformPvt;

         ( void ) pCommonRef->device.pfnCmd( pCommonRef->hFd,
                                    MMI_CMD_FREE_BUFFER, & freeBufferCmd );

      }

      /**---------------------------------------------------------------------
         Release buffer header.
      ----------------------------------------------------------------------*/
      if( ( NULL != pBufHdrLink )
         && ( OMX_TRUE == pBufHdrLink->bPortIsHeaderAllocator ) )
      {
         QOMX_MSG_L_HIGH( pCommonRef, "Freeing buffer header."
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         QOMX_CMPNT_FREEIF( pCommonRef->pfnFree, pCommonRef->hHeap, pBufferHdr );

      }

      QOMX_CMPNT_FREEIF( pCommonRef->pfnFree, pCommonRef->hHeap, pBufHdrLink );

      /**---------------------------------------------------------------------
         Move component to Invalid state on fatal error.
      ----------------------------------------------------------------------*/
      if( OMX_ErrorInvalidState == eRetVal )
      {
         QOMX_MSG_L_HIGH( pCommonRef, "Fatal error, Move to Invalid state"
            " nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         ( void ) qomx_CmpntStateSetInvalid( pCommonRef->hCmpnt,
                                    qomx_GetQOMXBaseEventCode( nStatus ) );

      }

   }

   return( eRetVal );

} /* end of function qomx_PortEnabledPopulating_AllocateBuffer */

/*==========================================================================

         FUNCTION:      qomx_PortEnabledPopulating_DeviceEventHandler

         DESCRIPTION:
*//**                   This function processes events from device when port
                        is in one of the EnabledPopulating state.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pPortCtnr   - Pointer to the port container.
            @param[in]  pPortCtx    - Pointer to the port context.
            @param[in]  nEventCode  - Event code.
            @param [in] nEventStatus- Status of the event.
            @param [in] nParamSize  - Size in bytes for the event related
                                      data which is pointed by the payload.
            @param [in] pParam      - Event related payload.

**//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE    qomx_PortEnabledPopulating_DeviceEventHandler
(
   OMX_IN   QOMX_PortContainerType       *pPortCtnr,
   OMX_IN   QOMX_PortContextType         *pPortCtx,
   OMX_IN   OMX_U32                       nEventCode,
   OMX_IN   OMX_U32                       nEventStatus,
   OMX_IN   OMX_U32                       nParamSize,
   OMX_IN   OMX_PTR                      *pParam
)
{
   OMX_ERRORTYPE  eRetVal = OMX_ErrorNone;
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pPortCtnr->pCommonRef,
      "qomx_PortEnabledPopulating_DeviceEventHandler, nPortIndex = 0x%x,"
      " nEventCode = 0x%x", pPortCtx->portDef.nPortIndex, nEventCode );

   /**------------------------------------------------------------------------
      Check event code.
   -------------------------------------------------------------------------*/
   switch( nEventCode )
   {
   case MMI_RESP_ENABLE_PORT:
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "MMI_RESP_ENABLE_PORT"
            " event nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Handle enable command response.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_EnableResp(
                              pPortCtnr, pPortCtx, nEventStatus, OMX_FALSE );

      }

      break;

   case MMI_EVT_PORT_CONFIG_CHANGED:
      {
         QOMX_MSG_L_HIGH( pPortCtnr->pCommonRef, "MMI_EVT_PORT_CONFIG_CHANGED"
            " event nPortIndex = 0x%x", pPortCtx->portDef.nPortIndex );

         /**------------------------------------------------------------------
            Process config change event and update port definition.
         -------------------------------------------------------------------*/
         ( void ) qomx_PortCommon_ConfigChange(
                                          pPortCtnr->pCommonRef, pPortCtx );

      }

      break;

   default:
      {
         QOMX_MSG_L_ERROR( pPortCtnr->pCommonRef, "Unexpected parameters in"
            " device event: nEventCode = 0x%x, nPortIndex = 0x%x",
            nEventCode, pPortCtx->portDef.nPortIndex );

      }

      break;

   } /* end of switch( nEventCode ) */

   return( eRetVal );

} /* end of function qomx_PortEnabledPopulating_DeviceEventHandler */
