/*========================================================================

*//** @file qomxCmpntIdleToExecuting.c 

@par FILE SERVICES:       
      Component IdleToExecuting State Implementation File.

      This file implements all the methods which are applicable for
      OMX_StateIdleToExecuting state.
      
      Main functions is Send Command. Functions which are common for all
      states are implemented in the common functions table.

@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2009-2018 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/src/qomxCmpntIdleToExecuting.c#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
04/05/18   rz     Fix print fmt check errors
04/14/15   hc     Fixed sequence call for buffer process which should be after the component started 
03/20/13   am     Rename QOMX_CONFIG_TUNNELEDPORTSTATUSTYPE and associated variables
                  to QC omx extension for 1.1.2
08/08/11   dm     Hardware critical error handling.
10/08/10   zm     Map MMI error to OMX error for START command return code.
08/28/10   zm     Added support for vendor tunneling.
07/22/10   zm     Add component handle in each base class logging message.
06/10/10   dm     Added return type in event handler.
06/07/10   zm     Allow buffer processing in QOMX_StateIdleToExecuting state.
03/26/10   spl    Modified to support interop-profile.
09/30/09   dm     Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#include "qomxCmpntCommon.h"
#include "qomxPortUtils.h"

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/**
 * 
 * Forward declaration for the functions statically defined in this file.
 * 
 */

static void    qomx_CmpntIdleToExecuting_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
);

static void    qomx_CmpntIdleToExecuting_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent   
);

static OMX_ERRORTYPE    qomx_CmpntIdleToExecuting_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
);

static void    qomx_CmpntIdleToExecuting_Start
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);

static void    qomx_CmpntIdleToExecuting_MMIStart
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
);

static void    qomx_CmpntIdleToExecuting_StartResponse
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nStatus
);

static OMX_ERRORTYPE  qomx_CmpntIdleToExecuting_SetConfig
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE           nIndex, 
   OMX_IN   OMX_PTR                 pCmpntCfg
);


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */


/*==========================================================================

         FUNCTION:      qomx_CmpntIdleToExecuting_LoadStateTable

         DESCRIPTION:
                        This function will load the component state table
                        supported by the IdleToExecuting state in the object
                        of state table being passed.
            
@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pStTable - Pointer to the state primitive table
                                   object.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void  qomx_CmpntIdleToExecuting_LoadStateTable
(
   OMX_IN   QOMX_CmpntStateTableType     *pStTable
)
{
   /**------------------------------------------------------------------------
      Fill the funtion pointers table which holds functions to be called when
      component is in QOMX_StateIdleToExecuting state. NULL entry indicates
      that the specific function call is not allowed in this state, thus
      component API should return invalid operation for this case.
   -------------------------------------------------------------------------*/

   /**------------------------------------------------------------------------
      Application APIs
   -------------------------------------------------------------------------*/   
   pStTable->GetComponentVersion    = qomx_CmpntCommon_GetComponentVersion;
   pStTable->SendCommand            = qomx_CmpntCommon_SendCommand;
   pStTable->GetParameter           = qomx_CmpntCommon_GetParameter;
   pStTable->SetParameter           = qomx_CmpntCommon_SetParameter;
   pStTable->GetConfig              = qomx_CmpntCommon_GetConfig;
   pStTable->SetConfig              = qomx_CmpntIdleToExecuting_SetConfig;
   pStTable->GetExtensionIndex      = qomx_CmpntCommon_GetExtensionIndex;
   pStTable->GetState               = qomx_CmpntCommon_GetState;
   pStTable->ComponentTunnelRequest = qomx_CmpntCommon_TunnelRequest;
   pStTable->UseBuffer              = qomx_CmpntCommon_UseBuffer;
   pStTable->AllocateBuffer         = qomx_CmpntCommon_AllocateBuffer;
   pStTable->FreeBuffer             = qomx_CmpntCommon_FreeBuffer;
   pStTable->EmptyThisBuffer        = qomx_CmpntCommon_EmptyThisBuffer;
   pStTable->FillThisBuffer         = qomx_CmpntCommon_FillThisBuffer;
   pStTable->SetCallbacks           = NULL;
   pStTable->ComponentDeInit        = qomx_CmpntCommon_ComponentDeInit;
   pStTable->UseEGLImage            = NULL;
   pStTable->ComponentRoleEnum      = qomx_CmpntCommon_ComponentRoleEnum;

   /**------------------------------------------------------------------------
      Device Event callbacks
   -------------------------------------------------------------------------*/
   pStTable->pfnEventHandler
                        = qomx_CmpntIdleToExecuting_DeviceEventHandler;
   
   /**------------------------------------------------------------------------
      State management functions
   -------------------------------------------------------------------------*/
   pStTable->pfnEntryHandler
                        = qomx_CmpntIdleToExecuting_StateEntryHandler;
   pStTable->pfnExitHandler
                        = qomx_CmpntIdleToExecuting_StateExitHandler;
   
   return;

} /* end of function qomx_CmpntIdleToExecuting_LoadStateTable */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntIdleToExecuting_StateEntryHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateIdleToExecuting is entered. Entry into the
                        state performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntIdleToExecuting_StateEntryHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Entering IdleToExecuting State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Entering IdleToExecuting State, nEvent = 0x%x", nEvent );

   /**------------------------------------------------------------------------
      Perform the state transition.
   -------------------------------------------------------------------------*/
   pCmpntCtx->eMainState = QOMX_StateIdleToExecuting;

   /**------------------------------------------------------------------------
      Command device to start.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntIdleToExecuting_Start( pCmpntCtx );

   return;

} /* end of function qomx_CmpntIdleToExecuting_StateEntryHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntIdleToExecuting_StateExitHandler

         DESCRIPTION:
*//**                   This function which is invoked every time QOMX state
                        QOMX_StateIdleToExecuting is exited. Exit from this
                        state performs all event agnostic execution.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   - Component state machine context.
            @param[in]  nEvent      - Event code.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntIdleToExecuting_StateExitHandler
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEvent 
)
{
   QOMX_STATS_MSG( & ( pCmpntCtx->commonRef ), QOMX_MSG_PRIORITY_HIGH,
      "Exiting IdleToExecuting State, nEvent = 0x%x", nEvent );
   QOMX_MSG_L_HIGH( & ( pCmpntCtx->commonRef ), 
      "Exiting IdleToExecuting State, nEvent = 0x%x", nEvent );

   return;   
   
} /* end of function qomx_CmpntIdleToExecuting_StateExitHandler */


/*==========================================================================

         FUNCTION:      qomx_CmpntIdleToExecuting_DeviceEventHandler

         DESCRIPTION:
*//**                   This function is called when the device want to 
                        communicate with the component when it is in 
                        IdleToExecuting state.
         
@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx      -  Context structure pointer.
            @param[in]  nEventCode     -  Event code.
            @param[in]  nEventStatus   -  Event status.
            @param[in]  nParamSize     -  Payload length.
            @param[in]  pParam         -  Payload corresponding to this event.

*//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None
                                                                        
===========================================================================*/
static OMX_ERRORTYPE    qomx_CmpntIdleToExecuting_DeviceEventHandler
( 
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nEventCode,
   OMX_IN   OMX_U32                 nEventStatus,
   OMX_IN   OMX_U32                 nParamSize,
   OMX_IN   OMX_PTR                *pParam
)
{
   OMX_ERRORTYPE        eRetVal     = OMX_ErrorNone;
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef,
      "qomx_CmpntIdleToExecuting_DeviceEventHandler, nEventCode = 0x%x,"
         " nEventStatus = 0x%x", nEventCode, nEventStatus );

   /**------------------------------------------------------------------------
      Finish moving to Executing state on successful start response.
   -------------------------------------------------------------------------*/
   if( MMI_RESP_START == nEventCode ) 
   {
      QOMX_MSG_L_HIGH( pCommonRef, "MMI_RESP_START event." );

      /**---------------------------------------------------------------------
         Process the start command status now.
      ----------------------------------------------------------------------*/
      ( void ) qomx_CmpntIdleToExecuting_StartResponse( 
                                                pCmpntCtx, nEventStatus );

   }
   else if( MMI_EVT_RESOURCES_LOST == nEventCode )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "MMI_EVT_RESOURCES_LOST event." );

      /**---------------------------------------------------------------------
         Set resources state to lost.
      ----------------------------------------------------------------------*/
      pCmpntCtx->eResState = QOMX_RESOURCES_PERMANENTLY_LOST;

      /**---------------------------------------------------------------------
         Report resources lost error to IL client.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
         "Send OMX_ErrorResourcesLost notification." );

      ( void ) qomx_CmpntNotifyError( 
                     & ( pCmpntCtx->commonRef ), OMX_ErrorResourcesLost );
	  
      /**---------------------------------------------------------------------
         Command ports to stop buffer processing.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, "Stop buffer processing." );

	  ( void ) qomx_PortStopBufferProcessing( pCmpntCtx->hPortCtnr );

      /**---------------------------------------------------------------------
         Move to transitional state IdleToLoaded which will check ports
         population status, wait for buffer release and unload resources.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, "Move to QOMX_StateIdleToLoaded." );

      ( void ) qomx_CmpntCommon_DoStateTransition( 
                     pCmpntCtx, QOMX_StateIdleToLoaded, QOMX_EVENT_UNKNOWN );

   }
   else
   {
      /**---------------------------------------------------------------------
         Pass this to common device handler routine.
      ----------------------------------------------------------------------*/
      eRetVal = qomx_CmpntCommon_DeviceEventHandler( pCmpntCtx, 
                              nEventCode, nEventStatus, nParamSize, pParam );

   }

   return( eRetVal );

} /* end of function qomx_CmpntIdleToExecuting_DeviceEventHandler */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntIdleToExecuting_Start

         DESCRIPTION:
*//**                   This function will start the device and move component
                        to Executing state based on the device return code.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntIdleToExecuting_Start
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, "qomx_CmpntIdleToExecuting_Start" );



   /**------------------------------------------------------------------------
      If the component is not vendor tunneled; or its vendor tunneled peer 
	  component has received idle to executing command , complete transition 
	  to executing.
   -------------------------------------------------------------------------*/
   ( void ) qomx_CmpntIdleToExecuting_MMIStart(pCmpntCtx);

   return;

} /* end of function qomx_CmpntIdleToExecuting_Start */


/*==========================================================================
     
         FUNCTION:      qomx_CmpntIdleToExecuting_MMIStart

         DESCRIPTION:
*//**                   This function will issue start command to the device 
						and move component to Executing state based on the 
						device return code.

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
            @param[in]  pCmpntCtx   - Compnent state machine context.

**//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static void    qomx_CmpntIdleToExecuting_MMIStart
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_HIGH( pCommonRef, 
      "qomx_CmpntIdleToExecuting_MMIStart called ." );

   /**------------------------------------------------------------------------
      Send start command to MMI device.
   -------------------------------------------------------------------------*/
   if( OMX_TRUE == qomx_GuardIsTrue( pCommonRef->hCmpnt,
                      QOMX_GUARD_ALL_ENABLED_VTPORTS_PEER_ACCEPTS_MMISTART ) )
   {
      OMX_U32  nStatus     = MMI_S_EFAIL;
	  /*--------------------------------------------------------------------*/

	  nStatus = pCommonRef->device.pfnCmd( 
                                 pCommonRef->hFd, MMI_CMD_START, NULL );

	  QOMX_MSG_L_HIGH( pCommonRef, "Start status = 0x%x ", nStatus );

	  /**---------------------------------------------------------------------
		 If device is processing the command asynchronously, wait for the
		 callback, otherwise process the response.
	  ----------------------------------------------------------------------*/
		
	  if( MMI_S_PENDING != nStatus )
	  {
		/**-------------------------------------------------------------------
           Process the start command status now.
		--------------------------------------------------------------------*/
		( void ) qomx_CmpntIdleToExecuting_StartResponse( pCmpntCtx, nStatus );

	  }

   }

   return;

} /* end of function qomx_CmpntIdleToExecuting_MMIStart */


/*==========================================================================

         FUNCTION:      qomx_CmpntIdleToExecuting_StartResponse

         DESCRIPTION:
*//**                   This function processes the start command response
                        received from the device.
         
@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  pCmpntCtx   -  Context structure pointer.
            @param[in]  nStatus     -  Event / Response status.

*//*     RETURN VALUE:
                        None

@par     SIDE EFFECTS:
                        None
                                                                        
===========================================================================*/
static void    qomx_CmpntIdleToExecuting_StartResponse
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_U32                 nStatus
)
{
   QOMX_CommonRefType  *pCommonRef  = & ( pCmpntCtx->commonRef );
   /*-----------------------------------------------------------------------*/

   QOMX_MSG_L_MED( pCommonRef, 
      "qomx_CmpntIdleToExecuting_StartResponse" );

   if( MMI_S_COMPLETE == nStatus )
   {
      QOMX_MSG_L_HIGH( pCommonRef, "Start successful." );
	  
	  /**------------------------------------------------------------------------
      Command ports to start buffer processing.
      -------------------------------------------------------------------------*/
       QOMX_MSG_L_MED( pCommonRef, "Start buffer processing." );

      ( void ) qomx_PortStartBufferProcessing( pCmpntCtx->hPortCtnr );
      /**---------------------------------------------------------------------
         Start is successful. Move to destination state QOMX_StateExecuting.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, "Move to QOMX_StateExecuting." );

      ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                                    QOMX_StateExecuting, QOMX_EVENT_UNKNOWN );

      /**---------------------------------------------------------------------
         Send state transition success callback.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, 
            "Send OMX_StateExecuting transition callback." );

      ( void ) qomx_CmpntCommon_StateTransitionCallback( 
                                    pCmpntCtx, OMX_StateExecuting );

   }
   else 
   {
      /**---------------------------------------------------------------------
         Command ports to stop buffer processing.
      ----------------------------------------------------------------------*/
      QOMX_MSG_L_MED( pCommonRef, "Stop buffer processing." );

	   ( void ) qomx_PortStopBufferProcessing( pCmpntCtx->hPortCtnr );

      if( ( MMI_S_EFATAL == nStatus )
         || ( MMI_S_EFATALHW == nStatus ) )
      {
         QOMX_MSG_L_ERROR( 
            pCommonRef, "Critical error = %d during executing.", nStatus );

         /**------------------------------------------------------------------
            Irrecoverable error. Move component to Invalid state.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                           QOMX_StateInvalid, 
                           qomx_GetQOMXBaseEventCode( nStatus ) );

      }
      else
      {
         OMX_ERRORTYPE eRetVal = qomx_GetOMXErrorCode( nStatus );
         /*-----------------------------------------------------------------*/

         QOMX_MSG_L_ERROR( pCommonRef, "Unexpected status in start response."
            "nStatus = 0x%x, Transition back to Idle state.", nStatus );

         /**------------------------------------------------------------------
            Move back the component to Idle state.
         -------------------------------------------------------------------*/
         ( void ) qomx_CmpntCommon_DoStateTransition( pCmpntCtx, 
                                      QOMX_StateIdle, QOMX_EVENT_UNKNOWN );

         /**------------------------------------------------------------------
            Report hardware error for this command failure.
         -------------------------------------------------------------------*/
         QOMX_MSG_L_MED( pCommonRef, 
            "Send OMX_ErrorType = 0x%x notification.", eRetVal );

         ( void ) qomx_CmpntNotifyError( 
                              & ( pCmpntCtx->commonRef ), eRetVal );

	  }

   }

   return;

} /* end of function qomx_CmpntIdleToExecuting_StartResponse */


/*==========================================================================

         FUNCTION:      qomx_CmpntIdleToLoaded_SetConfig

         DESCRIPTION:
                        Refer to OMX_SetConfig in OMX_Core.h or the
                        OMX IL specification for details on the 
                        SetConfig method.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS: *//*
*//**       @param[in]  pCmpntCtx      - Pointer to the component context.
            @param[in]  nIndex         - Refer OMX_Core.h or OMX IL
                                         specification.
            @param[in]  pCmpntCfg      - Refer OMX_Core.h or OMX IL
                                         specification.
**//*    RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.

@par     SIDE EFFECTS:
                        None

===========================================================================*/
static OMX_ERRORTYPE  qomx_CmpntIdleToExecuting_SetConfig
(
   OMX_IN   QOMX_CmpntCtxType      *pCmpntCtx,
   OMX_IN   OMX_INDEXTYPE           nIndex, 
   OMX_IN   OMX_PTR                 pCmpntCfg
)
{
   OMX_ERRORTYPE  eRetVal = OMX_ErrorNone;
   /*-----------------------------------------------------------------------*/

   eRetVal = qomx_CmpntCommon_SetConfig( pCmpntCtx, nIndex, pCmpntCfg);

   /**------------------------------------------------------------------------
      If this is a signal from vendor-tunneled peer, need to check guards 
	  again and send start command to device.
   -------------------------------------------------------------------------*/
   if( OMX_ErrorNone == eRetVal && 
       ((OMX_U32)QOMX_IndexConfigTunneledPortStatus) == ((OMX_U32)nIndex) )
   {
      QOMX_CONFIG_TUNNELEDPORTSTATUSTYPE *pTunneledPortStatus = 
						(QOMX_CONFIG_TUNNELEDPORTSTATUSTYPE *) pCmpntCfg;
	  /*--------------------------------------------------------------------*/

      if ( OMX_PORTSTATUS_VTACCEPTSBUFFEREXCHANGE == 
					pTunneledPortStatus->nTunneledPortStatus )
	  {
		 ( void ) qomx_CmpntIdleToExecuting_MMIStart(pCmpntCtx);

	  }

   }

   return eRetVal;
} /* end of function qomx_CmpntIdleToLoaded_SetConfig */
