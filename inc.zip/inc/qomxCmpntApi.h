#ifndef __H_QOMX_CMPNT_API_H__
#define __H_QOMX_CMPNT_API_H__

/*========================================================================

*//** @file qomxCmpntApi.h 

@par FILE SERVICES:
      Interface file for QOMX base class component.

      This file contains the structure definitions and interfaces for the
      base class configuration and initialization.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2009-2010 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/protected/qomxCmpntApi.h#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
11/22/10   zm     Added new qomxCmpntInit2 API.
09/30/10   zm     Remove QOMX string name size macro.
10/29/09   dm     Moved tunneling data types to new header file.
06/24/09   dm     Merged configuration structure and interface headers.
06/12/09   dm     Init prototype redefined.
06/01/09   dm     Initial Creation.

========================================================================== */

/*======================================================================== 
 
                     INCLUDE FILES FOR MODULE 
 
========================================================================== */
#include <OMX_Types.h>
#include <OMX_Core.h>
#include <OMX_Component.h>
#include "mmiDeviceApi.h"

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */


/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */


/** 
  * 
  * This data type encapsulates the port indexes properties pertaining to
  * a particular domain.
  * This structure is used by QOMX_CmpntStateType to define audio, video,
  * image and other domain port properties.
  *
  */

typedef struct
{
   OMX_BOOL          bConfigSet;          /**
                                          * This is a boolean variable which
                                          * is if set, indicates that the
                                          * specific domain is used and ports
                                          * should be configured. If the value
                                          * is false, port configuration is 
                                          * ignored assuming ports for this
                                          * domain should not be configured.
                                          */

   OMX_U32           nPortStart;          /**<
                                          * It is the base for the ports of
                                          * the of the specified domain.
                                          * It is defined to be the 
                                          * 'nStartPortNumber' value
                                          * returned on a query of the param
                                          * 'OMX_IndexParam<Domain>Init'.
                                          */

   OMX_U8            nNumInputPorts;      /**< 
                                          * It is the total number of input
                                          * ports for the specified domain
                                          * that the device can support.
                                          * Indexes for these input ports
                                          * would begin at
                                          * = ( nPortStart
                                          *     + Input Port No )
                                          */

   OMX_U8            nNumOutputPorts;     /**< 
                                          * It is the total number of output
                                          * ports for the specified domain
                                          * that the device can support.
                                          * Indexes for these output ports
                                          * would begin at
                                          * = ( nPortStart
                                          *     + nNumInputPorts
                                          *     + Output Port No )
                                          */

} QOMX_PortConfig;


/** 
  * 
  * This data type gives the configuration of the il component. It has to be
  * understood that port numbers are allocated as given in the structure.
  * Underlying MMI device should consider this mapping so every time a port ID
  * is given out it has to be related to this. 
  * Port speific primitives, parameters etc is expected to have a port id. 
  * Base class can not and do not distinguish ports based on domains. It is 
  * the job of the supporting MMI. Simple devices which has one input and 
  * output can ignore the port numbers given the input output separation is 
  * enough. 
  *
  */

typedef struct
{
   /**------------------------------------------------------------------------
      Component characterstics.
   -------------------------------------------------------------------------*/

   OMX_STRING        pCmpnntName;         /**<
                                          * Pointer to the component name
                                          * string. Must not be NULL.
                                          * Base class would create a
                                          * copy of this in its own memory.
                                          */

   OMX_UUIDTYPE     *pCmpnntUUID;         /**<
                                          * Pointer to the component unique
                                          * identifier object. Must not be
                                          * NULL.
                                          * Base class would create a
                                          * copy of this in its own memory.
                                          */

   /**------------------------------------------------------------------------
      Domain and functionality specific parameters.
   -------------------------------------------------------------------------*/

   QOMX_PortConfig   audioDomain;         /**<
                                          * This is configuration structure
                                          * for audio domain ports.
                                          */

   QOMX_PortConfig   videoDomain;         /**<
                                          * This is configuration structure
                                          * for video domain ports.
                                          * 'nPortStart' member of this
                                          * must be greater than 
                                          * > ( audioDomain.nPortStart
                                          *    + audioDomain.nNumInputPorts
                                          *    + audioDomain.nNumInputPorts )
                                          */

   QOMX_PortConfig   imageDomain;         /**<
                                          * This is configuration structure
                                          * for video domain ports.
                                          * 'nPortStart' member of this
                                          * must be greater than 
                                          * > ( videoDomain.nPortStart
                                          *    + videoDomain.nNumInputPorts
                                          *    + videoDomain.nNumInputPorts )
                                          */

   QOMX_PortConfig   otherDomain;         /**<
                                          * This is configuration structure
                                          * for video domain ports.
                                          * 'nPortStart' member of this
                                          * must be greater than 
                                          * > ( imageDomain.nPortStart
                                          *    + imageDomain.nNumInputPorts
                                          *    + imageDomain.nNumInputPorts )
                                          */

   /**------------------------------------------------------------------------
      Implementation customization.
   -------------------------------------------------------------------------*/

   OMX_BOOL          bSupportPortBasedResources;
                                          /**<
                                          * This allows the component to
                                          * cusomize port Enable and Disable
                                          * commands. If this is false then
                                          * Enable / Disable commands will not
                                          * funnel into device other than for
                                          * freeing memory. Base class runs
                                          * the state machine to do Buffer
                                          * counting and Enable / Disable
                                          * callback.
                                          */

} QOMX_CmpntConfig;

/** 
  * This is the macro for component config version 1.
  * This version string (V1) is used as the shared version for two structures 
  * QOMX_CmpntConfig_V1 and QOMX_CmpntPlatformConfig_V1 defined below.
  *
  * Later if any of the structures needs to be extended to a newer version, 
  * a new version string with incremented version number will be used with 
  * corresponding config structures.
  *
  */
#define QOMX_COMPONENT_CONFIG_VERSION_1    "OMX.Base.Component.Config.Version.1"


/** 
  * 
  * This data type gives the V1 configuration of the il component. It contains
  * the generic QOMX_CmpntConfig config and the structure size. 
  * Later versions can extend this to include more component specific config
  * fields.
  *
  */
typedef struct
{
   OMX_U32           nSize;               /**< 
                                          * Size of this structure in bytes.
                                          */ 

   QOMX_CmpntConfig  sConfig;             /**<
                                          * This is configuration structure.
                                          * Every version of component config
                                          * should have this as the minimum.
                                          */

} QOMX_CmpntConfig_V1;


/** 
  * 
  * This data type gives the V1 platform specific configuration of the il 
  * component. It contains function pointers to the four customized heap 
  * memory management routines and the structure size. 
  * Important NOTE: IL client should either provide all the four pointers
  * or none of them; in other words, all of the four pointers should be
  * NULL (which means to use the default functions) or none of them should
  * be NULL (which means to use customized functions).
  * Later versions can extend this to include more platform specific config
  * fields.
  *
  */
typedef struct
{
   OMX_U32                       nSize;                /**< 
                                                       * Size of this structure
                                                       * in bytes.
                                                       */ 

   MMI_GetHeapHandleType         pfnGetHeapHandle;     /**< 
                                                       * Funciton pointer to
                                                       * GetHeapHandle routine.
                                                       */ 

   MMI_ReleaseHeapHandleType     pfnReleaseHeapHandle; /**< 
                                                       * Funciton pointer to
                                                       * ReleaseHeapHanle routine.
                                                       */ 

   MMI_MallocType                pfnMalloc;            /**< 
                                                       * Funciton pointer to
                                                       * Malloc routine.
                                                       */

   MMI_FreeType                  pfnFree;              /**< 
                                                       * Funciton pointer to
                                                       * Free routine.
                                                       */

} QOMX_CmpntPlatformConfig_V1;



/* -----------------------------------------------------------------------
** Functions
** ----------------------------------------------------------------------- */


/*==========================================================================

         FUNCTION:      qomx_ComponentInit
                                                
         DESCRIPTION:
*//**
                        This function will create the component instance which
                        would be populated in component handler's component
                        private data.

                        Ports are created and initialized based on the
                        configuration specified.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  pConfig        -  Port and related information for
                                          component initialization.
            @param[in]  pDev           -  Device function table. 
            @param[in]  hCmpnt         -  Handle to already Allocated IL
                                          component structure.

*//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.
@par     SIDE EFFECTS:
                        None
===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntInit
(
   OMX_IN   QOMX_CmpntConfig          *pConfig,
   OMX_IN   MMI_DeviceType            *pDev,
   OMX_IN   OMX_HANDLETYPE             hCmpnt
);


/*==========================================================================

         FUNCTION:      qomx_ComponentInit2
                                                
         DESCRIPTION:
*//**
                        This function will create the component instance which
                        would be populated in component handler's component
                        private data.

                        Ports are created and initialized based on the
                        configuration specified.

                        This is the new CmpntInit API which introduces the 
                        config version and the platform specific config 
                        structure; this is the recommended API to init 
                        component.
                        The old qomx_CmpntInit() is still supported.

@par     DEPENDENCIES:
                        None

*//*
         PARAMETERS:
*//**       @param[in]  pCmpntConfigVersion -  String for config version.
            @param[in]  pConfig             -  Port and related information 
                                               for component initialization.
            @param[in]  pPlatformConfig     -  Platform specific information 
                                               for component initialization.
            @param[in]  pDev                -  Device function table. 
            @param[in]  hCmpnt              -  Handle to already Allocated IL
                                               component structure.

*//*     RETURN VALUE:
*//**       @return     OMX_ErrorNone  - on success.
                        OMX Error code - As appropriate on failures.
@par     SIDE EFFECTS:
                        None
===========================================================================*/
OMX_ERRORTYPE  qomx_CmpntInit2
(
   OMX_IN   OMX_STRING                    pCmpntConfigVersion,                    
   OMX_IN   OMX_PTR                       pCmpntConfig,
   OMX_IN   OMX_PTR                       pPlatformConfig,
   OMX_IN   MMI_DeviceType                *pDev,
   OMX_IN   OMX_HANDLETYPE                hCmpnt
);


#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */


#endif  /* end of macro __H_QOMX_CMPNT_API_H__ */
