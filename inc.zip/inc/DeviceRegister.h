/*
 * DeviceRegister.h
 *
 *  Created on: Dec 1, 2010
 *      Author: che
 */

#ifndef DEVICE_REGISTER_H_
#define DEVICE_REGISTER_H_

#include "ioctlServer.h"

class DeviceRegister
{
public:
	DeviceRegister(ioctl_device_t* aDevice)
	{
		register_ioctl_device(aDevice);
	}

};

#endif /* DEVICE_REGISTER_H_ */
