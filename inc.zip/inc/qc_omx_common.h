/*============================================================================
                            O p e n M A X   w r a p p e r s
                             O p e n  M A X   C o r e

*//** @file qc_omx_common.h
  This module contains the definitions of the OpenMAX core.

Copyright (c) 2006-2008 Qualcomm Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*============================================================================
                              Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/core/protected/qc_omx_common.h#1 $
when       who     what, where, why
--------   ---     -------------------------------------------------------
06/30/08   ssk     Created file.
07/08/08   bc      Generic logging, may need to update this later.
06/16/09   che     new il core data structure
04/13/10   RK     redefined DEBUG_PRINT and DEBUG_PRINT_ERROR for wince

============================================================================*/

#ifndef QC_OMX_COMMON_H
#define QC_OMX_COMMON_H


#include <stdio.h>           // Standard IO
#include "OMX_Core.h"        // OMX API 
#include <OMX_Component.h>
#include "MMDebugMsg.h"


#define OMX_SPEC_VERSION       0x01020101 // OMX Version 

#ifdef __cplusplus
extern "C" {
#endif

typedef struct OMXILCORE_COMPONENTINFOTYPE
{
    OMX_U8 cName[OMX_MAX_STRINGNAME_SIZE];
    OMX_COMPONENTINITTYPE pInitialize;
    OMX_U32 nNumRoles;
    OMX_U8** ppRoles;

} OMXILCORE_COMPONENTINFOTYPE;


#ifdef __cplusplus
}
#endif

#endif 

