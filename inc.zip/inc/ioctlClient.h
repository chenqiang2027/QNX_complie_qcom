/*===========================================================================
                        
*//** @file ioctlClient.h
  This file declares interface functions & structure for ioctl client

Copyright (c) 2011 - 2012 Qualcomm Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/


/*===========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/1.0/source/qnx/ioctl/ioctlClient/ioctlClient/protected/ioctlClient.h#none $

when        who        what, where, why
--------   --------    -------------------------------------------------------
10/24/13    rs         Added device_get_last_error function
06/21/13    rz         Added device_ping
10/31/12    sk         Added shim layer
11/13/10    che        Initial version

============================================================================*/
#ifndef IOCTLCLIENT_H_
#define IOCTLCLIENT_H_


#ifdef __cplusplus
extern "C" {
#endif

#ifndef IOHANDLE
#define IOHANDLE
typedef void* IO_HANDLE;
#endif

typedef struct ioctl_session_t ioctl_session_t;
typedef void* IOCTL_CLT_LIB_HANDLE;

typedef int (*callback_handler_t)
(
    uint8* msg,
    uint32 length,
    void* cd
);

typedef struct
{
    callback_handler_t handler;
    void* data;
} ioctl_callback_t;

ioctl_session_t* device_open(char* name, ioctl_callback_t* cb);
int device_close(ioctl_session_t* aIoSession);

// return the number of bytes actually read
int device_read(ioctl_session_t* aIoSession, uint8* aBuf, uint32 aBufSize);

// return the number of bytes actually write
int device_write(ioctl_session_t* aIoSession, uint8* aBuf, uint32 aBufSize);

int device_ioctl
(
    ioctl_session_t* aIoSession,
    uint32 aCommand,
    uint8 *aInBuf,
    uint32 aInBufSize,
    uint8* aOutBuf,
    uint32 aOutBufSize
);

/* ping the device with cmd and input data. Once receviing the ping, the device is
*  expected to return the response in order to unblock client followed by
*  processing input data
*/
int device_ping
(
    ioctl_session_t* aIoSession,
    uint32 aCommand,
    uint8 *aBuf,
    uint32 aBufSize
);

/* return the last error raised by the device_ioctl function */
int device_get_last_error
(
    ioctl_session_t* aIoSession
);

#ifdef __cplusplus
}
#endif

#endif /* IOCTLCLIENT_H_ */
