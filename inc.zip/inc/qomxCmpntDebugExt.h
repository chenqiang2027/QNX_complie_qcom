#ifndef __H_QOMX_CMPNT_DEBUG_EXT_H__
#define __H_QOMX_CMPNT_DEBUG_EXT_H__

/*========================================================================

*//** @file qomxCmpntExt.h 

@par FILE SERVICES:
      QOMX base class extension file.

      This file contains the structure definitions and interfaces for base
	  class debugging extensions.

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2009-2010 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/base/protected/qomxCmpntDebugExt.h#1 $

when       who    what, where, why
--------   ---    -------------------------------------------------------
09/30/10   zm     Use string name size macro defined in OMX_Core.h.
08/31/10   dm     Initial Creation.

========================================================================== */

/*======================================================================== 
 
                     INCLUDE FILES FOR MODULE 
 
========================================================================== */
#include <OMX_Types.h>
#include <OMX_Core.h>
#include <OMX_Component.h>

/*========================================================================

                      DEFINITIONS AND DECLARATIONS

========================================================================== */

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */


/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/** 
  * 
  * This macro defines the name of the custom OMX parameter value which is
  * used to get the Throughput Metrics from the specified port.
  * When OMX_GetExtensionIndex is called with this name, QOMX base class will
  * return the index corresponding to this parameter name.  
  *
  * Associated Structure: QOMX_ParamPortThroughput
  *
  */

#define QOMX_PARAM_NAME_PORT_THROUGHPUT  \
                        "OMX.QCOM.Base.index.param.PortThroughput"

/** 
  * 
  * This macro defines the names of the custom OMX parameter value which is
  * used to configure debug message properties for this instance of base class.
  * When OMX_GetExtensionIndex is called with this name, QOMX base class will
  * return the index corresponding to this parameter name.  
  *
  * Associated Structure: QOMX_ConfigDebugMsg
  *
  */
#define QOMX_CONFIG_NAME_DEBUG_MSG        \
                        "OMX.QCOM.Base.index.config.DebugMsg"

/*--------------------------------------------------------------------------*/



/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/**
 * 
 *  This enumeration contain debug message levels which an IL client can
 * configure for this instance of base class.
 * 
 */

typedef enum
{
   QOMX_DebugMsgLevelStartUnused = 0x07000000,
                                          /**
                                          * This is base index, not to be
                                          * referred.
                                          */
   /*-----------------------------------------------------------------------*/


   QOMX_DebugMsgLevelDisableAll,
                                          /**
                                          * Disable all messages for this
                                          * instance of base class.
                                          */

   QOMX_DebugMsgLevelCritical,
                                          /**
                                          * Only fatal / critical error
                                          * messages will be printed for
                                          * this instance of base class.
                                          */

   QOMX_DebugMsgLevelHigh,
                                          /**
                                          * High and critical priority
                                          * messages will be printed for
                                          * this instance of base class.
                                          */

   QOMX_DebugMsgLevelMedium,
                                          /**
                                          * Medium, High and critical
                                          * priority messages will be
                                          * printed for this instance
                                          * of base class.
                                          */
   QOMX_DebugMsgLevelEnableAll,
                                          /**
                                          * Messages with all priorities
                                          * will be printed for this
                                          * instance of base class.
                                          */

   /*-----------------------------------------------------------------------*/
   QOMX_DebugMsgLevelMaxUnused,
                                          /**
                                          * This is max index, not to be
                                          * referred.
                                          */

} QOMX_DebugMsgLevel;


/** 
  * 
  * This data type is used to get the Throughput Metrics information from 
  * the specified port. This data type is used with the index corresponding to
  * QOMX_PARAM_NAME_PORT_THROUGHPUT.
  * This is a get only structure.
  *
  */

typedef struct 
{
   OMX_U32           nSize;               /**
                                          * This is size of the structure in
                                          * bytes.
                                          */

   OMX_VERSIONTYPE   nVersion;            /**
                                          * This is OMX spec version info.
                                          */

   OMX_U32           nPortIndex;          /**
                                          * Port index to use.
                                          */
 
   OMX_U32           nCurrentByteRate;    /**
                                          * Average number of bytes processed
                                          * per second over the last
                                          * measurement period.
                                          */

   OMX_U32           nTotalByteRate;      /**
                                          * Average number of bytes processed 
                                          * per second for the life of the
                                          * port.
                                          */

   OMX_U32           nCurrentPacketRate;  /**
                                          * Average number of packets 
                                          * processed per second over the last
                                          * measurement period.  This value is
                                          * stored in Q16 integer floating
                                          * point format.  Divide to 65536
                                          * (1<<16) to get floating point
                                          * result.
                                          */

   OMX_U32           nTotalPacketRate;    /**
                                          * Average number of packets 
                                          * processed per second for the life
                                          * of the port. This value is stored 
                                          * in Q16 integer floating point 
                                          * format.  Divide to 65536 (1<<16)
                                          * to get floating point result.
                                          */

   OMX_U32           nTotalBytes;         /**
                                          * Total number of bytes received for
                                          * the life of the port.
                                          */

   OMX_U32           nTotalPackets;       /**
                                          * Total number of packets received
                                          * for the life of the port.
                                          */

} QOMX_ParamPortThroughput;


/** 
  * 
  * This data type is used to configure the logging messages printed from the
  * base class. This data type is used with the index corresponding to
  * QOMX_CONFIG_NAME_DEBUG_MSG.
  *
  */

typedef struct 
{
   OMX_U32              nSize;            /**
                                          * This is size of the structure in
                                          * bytes.
                                          */

   OMX_VERSIONTYPE      nVersion;         /**
                                          * This is OMX spec version info.
                                          */

   QOMX_DebugMsgLevel   eDebugMsgLevel;   /**
                                          * Level of debug messages for this
                                          * instance of base class.
                                          * Default Setting:
                                          *      QOMX_DebugMsgLevelEnableAll
                                          */

   OMX_BOOL             bEnableCompName;  /**
                                          * OMX_TRUE, if component name need
                                          * to be prefixed before its handle.
                                          * Default Setting: OMX_FALSE
                                          */

   OMX_U8               acCustomName[ OMX_MAX_STRINGNAME_SIZE ];
                                          /**
                                          * Custom name which can be prefixed
                                          * before component handle. This is
                                          * useful when large component names
                                          * need to be trimmed so that overall
                                          * message length can be reduced.
                                          * If it is specified as NULL, by 
                                          * default, base class will pick full
                                          * component name for printing.
                                          * Maximum length = 127 bytes.
                                          */

} QOMX_ConfigDebugMsg;


#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */


#endif  /* end of macro __H_QOMX_CMPNT_DEBUG_EXT_H__ */
