#ifndef __PMEM_EX_H__
#define __PMEM_EX_H__

/*===========================================================================
 PMEM extension

 *//** @file pmemext.h
 This file defines functions to map the virtual address between source process/calling process

 Copyright (c) 2008 - 2018 QUALCOMM Technologies Incorporated.
 All Rights Reserved. Qualcomm Proprietary and Confidential.
 *//*========================================================================*/

/*===========================================================================
 Edit History

 $Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/pmemext/protected/pmemext.h#1 $

 when       who         what, where, why
 --------   ---         -------------------------------------------------------
 07/23/18   rz          Consolidate add_from/to APIs with map_from/to APIs
 06/12/18   rz          Add pmem_map_init/deinit APIs 
 06/07/18   rx          Move pmem_map_cleanup to internal
 10/02/17   rz          Added AEEStdDef.h for uint32 data type
 09/21/16   rz          Added ext interface to support cache flags

 ============================================================================*/

#ifdef __cplusplus
extern "C"
{
#endif


#include "AEEStdDef.h"

#define PMEMEXT_MAP_FLAG_CACHE      0x00000001          /* Enabling caching of the mem region */   

#define pmem_map_add_to_pid      pmem_map_to_pid
#define pmem_map_add_from_pid    pmem_map_from_pid

/*
 * This data type stores remote process pid and va
 */
struct buffer_list
{
    uint32  va;
    uint32  pid;
    struct buffer_list *next;
    struct buffer_list *prev;
};

/**===========================================================================

FUNCTION pmem_map_init

@brief  This funcation initializes pmemext service including enabling logging

@param  None

@dependencies
        None

@return
        0 for success otherwise error code

===========================================================================*/
int pmem_map_init
(
   void
);

/**===========================================================================

FUNCTION pmem_map_deinit

@brief  This funcation deinitializes pmemext service

@param  None

@dependencies
        None

@return
        0 for success otherwise error code

===========================================================================*/
int pmem_map_deinit
(
   void
);

/**===========================================================================

FUNCTION pmem_map_from_pid

@brief  Given a virtual address from the address of the source process
  identified by the spid, map it into the address space of the calling process

@param [in] virt  the virtual address to map into the calling process
@param [in] size  Size of memory chunk to be mapped
@param [in] spid  process id for the source process.

@dependencies
  None

@return
  Returns virtual address pointer to mapped into the calling process

===========================================================================*/
void* pmem_map_from_pid
(
    void* virt,
    uint32 size,   /* Size of the memory chunk to be allocated */
    uint32 spid    /* the process id of the source process */
);

/**===========================================================================

FUNCTION pmem_map_from_pid_ex

@brief  Given a virtual address from the address of the source process
  identified by the spid, map it into the address space of the calling process

@param [in] virt  the virtual address to map into the calling process
@param [in] size  Size of memory chunk to be mapped
@param [in] spid  process id for the source process 
@param [in] flags flags containing map attributes
 

@dependencies
  None

@return
  Returns virtual address pointer to mapped into the calling process

===========================================================================*/
void* pmem_map_from_pid_ex
(
    void* virt,
    uint32 size,   /* Size of the memory chunk to be allocated */
    uint32 spid,   /* the process id of the source process */
    uint32 flags   /* map attribute */
);

/**===========================================================================

FUNCTION pmem_map_to_pid

@brief  Given a virtual address in the calling process and its size,
   map it into the address space identified by the destination pid

@param [in] virt  the virtual address to map into the destination process
@param [in] size  Size of memory chunk to be mapped
@param [in] dpid  process id for destination process

@dependencies
  None

@return
  Returns virtual address pointer mapped into the destination process


===========================================================================*/
void* pmem_map_to_pid
(
    void* virt,
    uint32 size,   /* Size of the memory chunk to be allocated */
    uint32 dpid    /* the process id of the destination process */
);

/**===========================================================================

FUNCTION pmem_map_to_pid_ex

@brief  Given a virtual address in the calling process and its size,
   map it into the address space identified by the destination pid

@param [in] virt  the virtual address to map into the destination process
@param [in] size  Size of memory chunk to be mapped
@param [in] dpid  process id for destination process
@param [in] flags flags containing map attributes

@dependencies
  None

@return
  Returns virtual address pointer mapped into the destination process


===========================================================================*/
void* pmem_map_to_pid_ex
(
    void* virt,
    uint32 size,   /* Size of the memory chunk to be allocated */
    uint32 dpid,   /* the process id of the destination process */
    uint32 flags   /* map attribute */
);

/**===========================================================================

FUNCTION pmem_map_free

@brief  Given a virtual address in the calling process
        free its cached map entry if there is any

@param [in] virt  the virtual address that was cached

@dependencies
  None

@return
  Returns 0 for success, -1 otherwise

===========================================================================*/
int pmem_map_free(void* virt);

/**===========================================================================

FUNCTION pmem_map_lookup_from_pid

@brief

   Given a virtual address from the source process, this lookup the mapped virtual address
   in the calling process

@param [in] virt  the virtual address to map into the calling process
@param [in] spid  process id for the source process.

@dependencies
  None

@return
  Returns virtual address pointer to mapped into the calling process

===========================================================================*/
void* pmem_map_lookup_from_pid
(
    void* virt,
    uint32 spid    /* the process id of the source process */
);


/**===========================================================================

FUNCTION pmem_map_lookup_to_pid

@brief

   Given a virtual address in the calling process, this lookup the virtual
   address mapped in the destination process

@param [in] virt  the virtual address to map into the calling process
@param [in] dpid  process id for the source process.

@dependencies
  None

@return
  Returns virtual address pointer to mapped into the calling process

===========================================================================*/
void* pmem_map_lookup_to_pid
(
    void* virt,
    uint32 dpid    /* the process id of the source process */
);

/*==========================================================================

         FUNCTION:      pmem_append_buffer

         DESCRIPTION:
*//**                   This function will append buffer to the linked list

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  buffer_info - pointer to buffer info structure

*//*     RETURN VALUE:
*//**       @return     None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void pmem_append_buffer
(
   struct buffer_list *buffer_info
);

/*==========================================================================

         FUNCTION:      pmem_delete_buffer

         DESCRIPTION:
*//**                   This function will remove buffer from the linked list

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param[in]  buffer_info - pointer to buffer info structure

*//*     RETURN VALUE:
*//**       @return     None

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void pmem_delete_buffer
(
   struct buffer_list *buffer_info
);

/*==========================================================================

         FUNCTION:      pmem_get_buffer

         DESCRIPTION:
*//**                   This function will find a buffer from the linked list
                            by virtual address and pid of remote process

@par     DEPENDENCIES:
                        None
*//*
         PARAMETERS:
*//**       @param [in] va  the virtual address from remote process
            @param [in] pid  remote process pid

*//*     RETURN VALUE:
*//**       @return     buffer_list pointer

@par     SIDE EFFECTS:
                        None

===========================================================================*/
struct buffer_list *pmem_get_buffer
(
   uint32 va,
   uint32 pid
);

#ifdef __cplusplus
}
#endif

#endif
