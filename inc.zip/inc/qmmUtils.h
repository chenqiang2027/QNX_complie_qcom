#ifndef __QMM_UTILS_H__
#define __QMM_UTILS_H__
/*========================================================================

*//** @file qmmUtils.h

@par DESCRIPTION:
    This file contains MM specific utility functions.




@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2012-2017 QUALCOMM Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/utils/protected/qmmUtils.h#1 $

when       who     what, where, why
--------   ---     -------------------------------------------------------
01/17/17   rz      Fix compilation warning with printf format check
01/28/14   dp      Use AEEstd lib and NULL out pointers after free.
10/01/13   uc      'ASIC_FAMILY_A' has been updated to include 'ASIC_TYPE_8230'.
06/27/13   am      8064 asic support.
06/25/13   am      Add 8064 support.
12/13/12   am      Change from 8x30 to 8930
12/13/12   jl      Added ASIC type defines and made lib load mode
                   independent of OS define change
11/06/12   sk      Added mode for opening library
11/01/12   sk      Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */

#include <dlfcn.h>
#include "AEEstd.h" /* std typedefs, ie. byte, uint16, uint32, etc. and memcpy, memset */
#include "MMMalloc.h"
#include "MMDebugMsg.h"

/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */
#define QMM_UTILS_MSG( xx_fmt, ...) \
    MM_MSG_PRIO_EX(MM_VIDEO_TASK, MM_PRIO_HIGH, xx_fmt, ## __VA_ARGS__)

#define QMM_UTILS_Malloc(n)                     MM_Malloc((n))
#define QMM_UTILS_FreeIf(p)                     { if((p)) MM_Free(p); \
                                                  (p) = NULL; }
/* general utility for memory set and copy */
#define QMM_UTILS_MEMSET(src, value, len)       std_memset((src), (value), (len))
#define QMM_UTILS_MEMCPY(dest, src, len)        std_memmove((dest), (src), (len))

/**
 *
 * QMM_Mode
 *
 */
#define QMM_MODE_NOW    ( RTLD_NOW    )
#define QMM_MODE_GLOBAL ( RTLD_GLOBAL )
#define QMM_MODE_LOCAL  ( RTLD_LOCAL  )
#define QMM_MODE_GROUP  ( RTLD_GROUP  )
#define QMM_MODE_WORLD  ( RTLD_WORLD  )

/* The definitions of the ASCI type must be mutually exclusive so that they can
 * be grouped as a family */
#define  ASIC_TYPE_8960    ( 1 << 0 )
#define  ASIC_TYPE_8960AB  ( 1 << 1 )
#define  ASIC_TYPE_8930    ( 1 << 2 )
#define  ASIC_TYPE_8974    ( 1 << 3 )
#define  ASIC_TYPE_8064    ( 1 << 4 )
#define  ASIC_TYPE_8230    ( 1 << 5 )
#define  ASIC_TYPE_8096    ( 1 << 6 )

#define  ASIC_FAMILY_A     ( ASIC_TYPE_8960 | ASIC_TYPE_8960AB | ASIC_TYPE_8930 | ASIC_TYPE_8230 | ASIC_TYPE_8064 )
#define  ASIC_FAMILY_B     ( ASIC_TYPE_8974 | ASIC_TYPE_8096)

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/**
 *
 * Typedef for QMM_AsicInfo
 *
 */
typedef struct QMM_AsicInfo
{
    char* machineName;
    char* familyName;
    char* asicName;
    int   asicType;
} QMM_AsicInfo;

/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */

/*==========================================================================
         FUNCTION:      qmmUtil_LoadLib

         DESCRIPTION:
*//**       This function will load asic specific lib

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out]
*//**       @param[in]  inlibName : Name of the lib without asic
*//**       @param[in]  modeVal   : Value of mode for relocation/visibility


**//*     RETURN VALUE:
*//**       @return  : Returns handle of the opened library

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void* qmmUtil_LoadLib
(
   const char* inlibName,
   int modeVal
);

/*==========================================================================

         FUNCTION:      qmmUtil_LoadLib_Ex

         DESCRIPTION:
*//**       This function will load lib with a specfic library name without
            searching through platform-specific suffix.

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out]
*//**       @param[in]  inlibName : Name of the lib without asic
*//**       @param[in]  modeVal   : Value of mode for relocation/visibility

**//*     RETURN VALUE:
*//**       @return  : Returns hLib of the opened library or
                               NULL in case of an error

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void* qmmUtil_LoadLib_Ex
(
   const char* inlibName,
   int modeVal
);

/*==========================================================================

         FUNCTION:      qmmUtil_UnloadLib

         DESCRIPTION:
*//**       This function will unload asic specific lib

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out]
*//**       @param[in]  inlibName : Name of the lib without asic

**//*     RETURN VALUE:
*//**       @return  : Returns hLib of the opened library

@par     SIDE EFFECTS:
                        None

===========================================================================*/
int qmmUtil_UnloadLib
(
  void* hLib
);


/*==========================================================================

         FUNCTION:      qmmUtil_MapLibSym

         DESCRIPTION:
*//**       This function will get the address of a symbl in shared lib

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**       @param[out]
*//**       @param[in]  hLib : Handle of prev opened lib
*//**       @param[in]  symbName : Name of symbol, for which address is needed

**//*     RETURN VALUE:
*//**       @return  : Returns address of the mapped symbol

@par     SIDE EFFECTS:
                        None

===========================================================================*/
void* qmmUtil_MapLibSym
(
  void* hLib,
  const char * symbName
);


/*==========================================================================

         FUNCTION:      qmmUtil_GetAsicType

         DESCRIPTION:
*//**       This function returns an ASIC type of the target

@par     DEPENDENCIES:
               None
*//*
         PARAMETERS:
*//**          None

**//*     RETURN VALUE:
*//**       @return  : ASIC type or -1 if ASIC type is not found

@par     SIDE EFFECTS:
                        None

===========================================================================*/
int qmmUtil_GetAsicType();

#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */


#endif /* __QMM_UTILS_H__ */
