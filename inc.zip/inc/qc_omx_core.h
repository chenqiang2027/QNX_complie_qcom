/*============================================================================
                            O p e n M A X   w r a p p e r s
                             O p e n  M A X   C o r e

*//** @file qc_omx_core.h
  This module contains the definitions of the OpenMAX core.

Copyright (c) 2006-2013 QUALCOMM Technologies, Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/

/*============================================================================
                              Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/common/openmax/core/protected/qc_omx_core.h#1 $
when       who     what, where, why
--------   ---     -------------------------------------------------------
07/04/13   dp      Use std typedefs.
06/17/09   che     New il core arch
06/30/08   ssk     Created file.

============================================================================*/

#ifndef QC_OMX_CORE_H
#define QC_OMX_CORE_H

#include "qc_omx_common.h"        // OMX API
#include "AEEstd.h" /* std typedefs, ie. byte, uint16, uint32, etc. and memcpy, memset */
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct OMXILCCORE_TYPE
{
   OMX_ERRORTYPE (*Init) ();
   OMX_ERRORTYPE (*DeInit) ();
   OMX_ERRORTYPE (*UpdateTable) ();
   OMX_ERRORTYPE (*ReadTable)
   (
      OMX_OUT OMX_U32 *pNumEntries,
      OMX_OUT OMXILCORE_COMPONENTINFOTYPE** pComponentInfo
   );
   OMX_ERRORTYPE (*ReleaseTable) ();
} OMXILCCORE_TYPE;

#define OMXILCORE_Init(hCore) \
   ((OMXILCCORE_TYPE*)(hCore))->Init()

#define OMXILCORE_DeInit(hCore) \
   ((OMXILCCORE_TYPE*)(hCore))->DeInit()

#define OMXILCORE_UpdateTable(hCore) \
   ((OMXILCCORE_TYPE*)(hCore))->UpdateTable()

#define OMXILCORE_ReadTable(hCore, pNumEntries, pComponentInfo) \
   ((OMXILCCORE_TYPE*)(hCore))->ReadTable((pNumEntries), (pComponentInfo))

#define OMXILCORE_ReleaseTable(hCore) \
   ((OMXILCCORE_TYPE*)(hCore))->ReleaseTable ()

/* general utility for memory set and copy */
#define OMXILCORE_MEMSET(src, value, len)          std_memset((src), (value), (len))
#define OMXILCORE_MEMCPY(dest, src, len)           std_memmove((dest), (src), (len))

/**
* This function is used to register a component at run time. The function needs to be called before OMX_Init
* is called for the componet to be added to the registry
*
*  @param[in] aCompnent
*     The component to resiter. The function will use the passed role string table as is. No memory will be allocated for them.
*     Caller has to make sure the memory for the pCompnentInfo pointer and role strings are valid before OMX_Deinit is called
*
*  @return
*     OMX_ErrorNone if successful.
*
*/

extern void omx_core_lock();
extern void omx_core_unlock();
extern OMX_ERRORTYPE QOMX_RegisterComponent(OMXILCORE_COMPONENTINFOTYPE* pCompnentInfo);

#ifdef __cplusplus
}
class OmxComponentRegister
{
public:
   OmxComponentRegister(OMXILCORE_COMPONENTINFOTYPE* pCompnentInfo)
   {
      QOMX_RegisterComponent(pCompnentInfo);
   }
};
#endif

#endif /* QC_OMX_CORE_H */
