/**================================================================================================
@file
    devio_client.h

@brief
    This file declares interface functions & structures for DevIOClient

Copyright (c) 2021-2022 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.
================================================================================================**/

#ifndef DEVIO_CLIENT_H_
#define DEVIO_CLIENT_H_

/**================================================================================================
                     INCLUDE FILES FOR MODULE
================================================================================================**/
#ifdef __cplusplus
extern "C" {
#endif

/**================================================================================================
                      DEFINITIONS AND DECLARATIONS
================================================================================================**/

/**================================================================================================
** Constants and Macros
================================================================================================**/

/**================================================================================================
** Typedefs
================================================================================================**/

typedef void* IoctlSessionHdl_t;

/**********************************************************************************************//**
@brief
    IO domain type
**************************************************************************************************/
typedef enum
{
    IO_DOMAIN_EVA = 0,              /**< EVA domain */
    IO_DOMAIN_MAX = 0x7FFFFFFF
} IoDomain_e;

/**********************************************************************************************//**
@brief
    Pointer to the callback function for communication from device driver to the application.
**************************************************************************************************/
typedef int32_t (*IoctlCallbackHandler_t)
(
    void    *pMsg,          /**< Pointer to the callback message which the client can parse */
    uint64_t nMsgSize,      /**< Size of the callback message */
    void    *pClientData    /**< Pointer to client userdata */
);

/**********************************************************************************************//**
@brief
    Structure containing the callback function and client userdata
**************************************************************************************************/
typedef struct
{
    IoctlCallbackHandler_t   fHandler;          /**< Pointer to the callback function */
    void                    *pClientData;       /**< Pointer to client userdata */
} IoctlCallbackStruct_t;

/**================================================================================================
                        FUNCTION DECLARATIONS
================================================================================================**/

/**********************************************************************************************//**
@brief
    API for the client to obtain a handle to an AIOCTL session

@param pName
    The name of the device driver to be opened, in the format serverName/deviceName.
    For EVA, this should be �evaCore/eva�.

@param eDomain
    IO Domain type

@param pCbStruct
    Pointer to the callback structure of type AIOCTLCallbackStruct_t

@param nFlags
    Flags which can be set from the application to the AIOCTL library.
    Unused at present.

@return
    On success, returns a handle to an AIOCTL session.
    On failure, returns NULL.
**************************************************************************************************/
IoctlSessionHdl_t DeviceOpen
(
    const char* pName,
    IoDomain_e eDomain,
    IoctlCallbackStruct_t *pCbStruct,
    uint32_t nFlags
);

/**********************************************************************************************//**
@brief
    API for the client to close an AIOCTL session

@param handle
    Handle to the AIOCTL session to be closed, which was originally returned by DeviceOpen.

@return
    On success, returns 0.
    On an error received from the driver, returns a non-zero positive value which will be equal to
        one of the error codes published by the driver.
    On an error received from OS APIs which would be set in errno variable, returns -1.
**************************************************************************************************/
int32_t DeviceClose(IoctlSessionHdl_t handle);

/**********************************************************************************************//**
@brief
    API to read a specified number of bytes from the driver.
    This can be used for debug purposes.

@param handle
    Handle to the AIOCTL session, which was returned by DeviceOpen

@param pBuf
    Buffer into which data is to be read

@param nBufSize
    Size of the data

@return
    On success, returns 0.
    On an error received from the driver, returns a non-zero positive value which will be equal to
        one of the error codes published by the driver.
    On an error received from OS APIs which would be set in errno variable, returns -1. The
        client should follow up with a call to DeviceGetLastError in this case,
        to retrieve the OS error code.
**************************************************************************************************/
int32_t DeviceRead(IoctlSessionHdl_t handle, uint8_t *pBuf, uint64_t nBufSize);

/**********************************************************************************************//**
@brief
    API to write a specified number of bytes to the driver

@param handle
    Handle to the AIOCTL session, which was returned by DeviceOpen

@param pBuf
    Buffer from which data is to be written

@param nBufSize
    Size of the data

@return
    On success, returns 0.
    On an error received from the driver, returns a non-zero positive value which will be equal to
        one of the error codes published by the driver.
    On an error received from OS APIs which would be set in errno variable, returns -1. The
        client should follow up with a call to DeviceGetLastError in this case,
        to retrieve the OS error code.
**************************************************************************************************/
int32_t DeviceWrite(IoctlSessionHdl_t handle, uint8_t *pBuf, uint64_t nBufSize);

/**********************************************************************************************//**
@brief
    API for the client to send an IOCTL command to the driver

@param handle
    Handle to the AIOCTL session, which was returned by DeviceOpen.

@param nCommand
    IOCTL command to be sent to the driver

@param pInBuf
    Buffer containing input data to be sent to the driver

@param nInBufSize
    Size of input buffer

@param pOutBuf
    Buffer containing output data to be received from the driver

@param nOutBufSize
    Size of output buffer

@return
    On success, returns 0.
    On an error received from the driver, returns a non-zero positive value which will be equal to
        one of the error codes published by the driver.
    On an error received from OS APIs which would be set in errno variable, returns -1. The
        client should follow up with a call to DeviceGetLastError in this case,
        to retrieve the OS error code.
**************************************************************************************************/
int32_t DeviceIoctl
(
    IoctlSessionHdl_t   handle,
    uint32_t            nCommand,
    void               *pInBuf,
    uint64_t            nInBufSize,
    void               *pOutBuf,
    uint64_t            nOutBufSize
);

/**********************************************************************************************//**
@brief
    API for the client to retrieve the last error from the OS if DeviceIoctl API
    returned -1 earlier.

@param handle
    Handle to the AIOCTL session, which was returned by DeviceOpen.

@return
    The error code which was set by the OS in errno variable during the last API call.
**************************************************************************************************/
int32_t DeviceGetLastError
(
    IoctlSessionHdl_t handle
);

#ifdef __cplusplus
}
#endif

#endif /* DEVIO_CLIENT_H_ */
