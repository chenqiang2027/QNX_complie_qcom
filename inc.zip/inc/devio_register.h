/**================================================================================================
@file
    devio_register.h

@brief
    This file declares datatypes and prototypes to register device to the server

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.
================================================================================================**/

#ifndef DEVIO_REGISTER_H_
#define DEVIO_REGISTER_H_

/**================================================================================================
                     INCLUDE FILES
================================================================================================**/
#include "devio_server.h"

/**================================================================================================
                     DECLARATIONS
================================================================================================**/
/**********************************************************************************************//**
@brief
    Class to be instantiated by the driver to register the device with AIOCTL library.
    The constructor in turn calls the device registration function.

@param pDevice
    Pointer to the device structure.

@return
    None.
**************************************************************************************************/
class DeviceRegister
{
public:
    int32_t initStatus;
    DeviceRegister(IoctlDevice_t *pDevice)
    {
        initStatus = RegisterIoctlDevice(pDevice);
    }
};

#endif /* DEVIO_REGISTER_H_ */
