/**================================================================================================
@file
    devio_server.h

@brief
    This file declares interface functions & structure for devio server

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.
================================================================================================**/

#ifndef DEVIO_SERVER_H_
#define DEVIO_SERVER_H_

#ifdef __cplusplus
extern "C" {
#endif

/**================================================================================================
                     INCLUDE FILES
================================================================================================**/
#include "AEEStdDef.h"

/**================================================================================================
** Typedefs
================================================================================================**/
#ifndef IOHANDLE
#define IOHANDLE
typedef void* IoHandle_t;
#endif

typedef void* IoctlCallbackHdl_t;

/**********************************************************************************************//**
@brief
    Function pointer for device open

@param hIoctlCallback
    Callback handle to be passed by the AIOCTL library

@return
    On success, returns a valid handle to the AIOCTL session.
    On failure, returns NULL.
**************************************************************************************************/
typedef IoHandle_t (*DeviceOpen_t)(IoctlCallbackHdl_t hIoctlCallback);

/**********************************************************************************************//**
@brief
    Function pointer for device close

@param handle
    Handle to the AIOCTL session.

@return
    On success, returns 0.
    On failure, returns -1.
**************************************************************************************************/
typedef int32_t (*DeviceClose_t)(IoHandle_t handle);

/**********************************************************************************************//**
@brief
    Function pointer for device read

@param handle
    Handle to the AIOCTL session.

@param pBuf
    Buffer into which data is to be read.

@param nBufSize
    Size of the buffer.

@return
    On success, returns 0.
    On failure, returns -1.
**************************************************************************************************/
typedef int32_t (*DeviceRead_t)(IoHandle_t handle, void *pBuf, uint64_t nBufSize);

/**********************************************************************************************//**
@brief
    Function pointer for device write

@param handle
    Handle to the AIOCTL session.

@param pBuf
    Buffer from which data is to be written.

@param nBufSize
    Size of the buffer.

@return
    On success, returns 0.
    On failure, returns -1.
**************************************************************************************************/
typedef int32_t (*DeviceWrite_t)(IoHandle_t handle, const void *pBuf, uint64_t nBufSize);

/**********************************************************************************************//**
@brief
    Function pointer for device write

@param handle
    Handle to the AIOCTL session.

@param nCommand
    IOCTL command to be sent to the driver

@param pInBuf
    Buffer containing input data to be sent to the driver

@param nInBufSize
    Size of input buffer

@param pOutBuf
    Buffer containing output data to be received from the driver

@param nOutBufSize
    Size of output buffer

@param pOutSizeReturn
    Pointer to return the number of bytes actually written in the output buffer

@return
    On success, returns 0.
    On failure, returns -1.
**************************************************************************************************/
typedef int32_t (*DeviceIoctl_t)
(
    IoHandle_t  handle,
    uint32_t    nCommand,
    void        *pInBuf,
    uint64_t    nInBufSize,
    void       *pOutBuf,
    uint64_t    nOutBufSize,
    uint64_t   *pOutSizeReturn
);

/**********************************************************************************************//**
@brief
    Function pointer for device attach

@param None

@return
    On success, returns 0.
    On failure, returns -1.
**************************************************************************************************/
typedef int32_t (*DeviceAttach_t)();

/**********************************************************************************************//**
@brief
    Function pointer for device detach

@param None

@return
    On success, returns 0.
    On failure, returns -1.
**************************************************************************************************/
typedef int32_t (*DeviceDetach_t)();

/**********************************************************************************************//**
@brief
    Structure containing the IO function table
**************************************************************************************************/
typedef struct
{
    DeviceOpen_t pfOpen;
    DeviceClose_t pfClose;
    DeviceRead_t pfRead;
    DeviceWrite_t pfWrite;
    DeviceIoctl_t pfIoctl;
    DeviceAttach_t pfAttach;
    DeviceDetach_t pfDetach;
} DeviceIoVtbl_t;

/**********************************************************************************************//**
@brief
    Structure containing the device info passed by the device driver
**************************************************************************************************/
typedef struct
{
    const char *pName;     /**< Unique name of the device */
    uint32_t numThreads;   /**< Number of threads to launch, to handle commands from devices.
                                Only 1 is supported at present, this parameter is don’t care. */
    uint32_t stackSize;     /**< Stack size for each thread in bytes.
                                 Recommended value is 16384. */
    int32_t priority;       /**< Priority of each thread. Recommended value is
                                 g_AOThreadRealtimePriority (defined in AOSAL). */
    DeviceIoVtbl_t vtbl;    /**< IO function table for the device */
} IoctlDevice_t;

/**================================================================================================
                        FUNCTION DECLARATIONS
================================================================================================**/
/**********************************************************************************************//**
@brief
    API for the driver to register the device with AIOCTL library

@param pDevice
    Pointer to the device structure.

@return
    On success, returns 0.
    On failure, returns -1.
**************************************************************************************************/
int32_t RegisterIoctlDevice(IoctlDevice_t *pDevice);

/**********************************************************************************************//**
@brief
    API for the driver to start the AIOCTL device manager and register with QNX resource manager

@param pServerName
    Name of the server

@return
    On success, returns 0.
    On failure, returns -1.
**************************************************************************************************/
int32_t StartDeviceManager(const char *pServerName);

/**********************************************************************************************//**
@brief
    API for the driver to wait for the AIOCTL device manager threads to exit

@param None

@return
    On success, returns 0.
    On failure, returns -1.
**************************************************************************************************/
int32_t JoinDeviceManager(void);

/**********************************************************************************************//**
@brief
    API for the driver to send a callback message to the client

@param hIoctlCallback
    Callback handle passed at open by the AIOCTL library

@param pCallbackMsg
    Pointer to the callback message

@param nMsgLength
    Size of the callback message

@return
    On success, returns 0.
    On failure, returns -1.
**************************************************************************************************/
int32_t SendCallBackMessage
(
    IoctlCallbackHdl_t hIoctlCallback,
    uint8_t *pCallbackMsg,
    uint64_t nMsgLength
);

#ifdef __cplusplus
}
#endif

#endif /* DEVIO_SERVER_H_ */
