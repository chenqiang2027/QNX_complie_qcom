/*===========================================================================

*//** @file ioctlMsg.h
  This file declares datatypes and prototypes for ioctl Msgs

Copyright (c) 2010 - 2016 QUALCOMM Technologies Incorporated.
All Rights Reserved. Qualcomm Proprietary and Confidential.
*//*========================================================================*/


/*===========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/1.0/source/qnx/ioctl/ioctlClient/ioctlClient/protected/ioctlMsg.h#none $

when        who        what, where, why
--------   --------    -------------------------------------------------------
06/22/16    am         Fix compiler warnings 
06/21/13    rz         Added device_ping
02/03/11    rz         replace shared mem with mq
11/13/10    che        Initial version

============================================================================*/


#ifndef IOCTLMSG_H_
#define IOCTLMSG_H_

#include <sys/iomsg.h>
#include <signal.h>
#include "AEEStdDef.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef IOHANDLE
#define IOHANDLE
typedef void * IO_HANDLE;
#endif

#define MAX_NAME_LENGTH  64

enum
{
    MSG_TYPE_ATTACH = _IO_MAX + 1,
    MSG_TYPE_DETACH,
    MSG_TYPE_OPEN,
    MSG_TYPE_IOCTL,
    MSG_TYPE_PING,
    MSG_TYPE_GET_CB_MSG,
} ;

typedef struct
{
    uint16 type;    // msgType must be the first item in any message structure
    uint32 inSize;  // the input buf size
    uint32 outSize; // the output buffer size
} msg_hdr_type_t;

typedef struct
{
    msg_hdr_type_t hdr;     // msg header for the open call
    pid_t pid;
    int deliver_event;
    struct sigevent event;  // the pulse for the server to deliver when callback msg is available
} msg_open_type_t;

typedef struct
{
    msg_hdr_type_t hdr;     // msg header for the open call
    int dcb;                // device dcb
} msg_detach_type_t;

typedef struct
{
    msg_hdr_type_t hdr;
    IO_HANDLE handle;   // ioctl session handle
    uint32   command;   // the ioctl command
} msg_ioctl_type_t;

typedef union
{
    uint16 type;
    struct _pulse pulse;
    msg_hdr_type_t hdr;
    msg_open_type_t open;
    msg_detach_type_t detach;
    msg_ioctl_type_t ioctl;
} msg_buf_t;

typedef struct _io_msg_type_t
{
    struct _io_msg io;
    msg_buf_t buf;
} io_msg_type_t;

#define IOCTL_SERVER_MGR_ID (_IOMGR_PRIVATE_BASE + 100)

#define DCMD_IOCTL_SERVER_CMD  __DIOTF(_DCMD_MISC, 1, msg_buf_t)

#define CALLBACK_EVENT_PULSE _PULSE_CODE_MINAVAIL+100
#define DEVICE_DETACH_PULSE _PULSE_CODE_MINAVAIL+101

#ifdef __cplusplus
}
#endif

#endif /* IOCTLMSG_H_ */
