#ifndef __QMM_DFC_API_H__
#define __QMM_DFC_API_H__
/*========================================================================

*//** @file qmmDfcApi.h

@par FILE SERVICES:       
      This file contains deferred function call interface.

@par DESCRIPTION:

	User defined function which has generic event handling can be 
	queueud into this utility library. 

	Typical usage will be event handlers and light duty thread offloading
	It is recommended that applications run a dedicated thread when the 
	processing heavy and function arguments have implicit payloads.


     
    
@par EXTERNALIZED FUNCTIONS:    
      See below.

    Copyright (c) 2010 Qualcomm Technologies, Incorporated.  All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/utils/protected/qmmDfcApi.h#1 $

when       who     what, where, why
--------   ---     -------------------------------------------------------
03/05/10   srk      Created file.

========================================================================== */

/* =======================================================================

                     INCLUDE FILES FOR MODULE

========================================================================== */
/*===========================================================================

                      DEFINITIONS AND DECLARATIONS

===========================================================================*/

#if defined( __cplusplus )
extern "C"
{
#endif /* end of macro __cplusplus */


/* -----------------------------------------------------------------------
** Constant and Macros
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Variables
** ----------------------------------------------------------------------- */

/* -----------------------------------------------------------------------
** Typedefs
** ----------------------------------------------------------------------- */

/**
 * Macros for TRUE and FALSE
 */
#define  QDFC_TRUE      1
#define  QDFC_FALSE     0

/**
 * Macros NULL
 */
#define  QDFC_NULL      0


/**
 * Enumeration defines the standard dfc Errors.
 */
typedef enum
{
   /**< No Error */
   QDFC_ERROR_NONE = 0,

   /**< Bad Parameters detected */
   QDFC_ERROR_BAD_PARM,

	/**< Unsupported feature detected */
   QDFC_ERROR_UNSUPPORTED,

   /**< DFC is corrupted detected */
   QDFC_ERROR_CORRUPTION,

  /**< DFC is corrupted detected */
  QDFC_ERROR_NORESOURCES,
   

} QDFC_ErrorType;

/**
 * 
 * Typedef for linked list element size
 * 
 */
typedef  unsigned char  QDFC_BooleanType;

/**
 * 
 * Typedef for linked list element size
 * 
 */
typedef  unsigned long   QDFC_ArgType;

/**
 * type for QDFC Handle
 */
typedef void *QDFC_HandleType;


typedef void (*qfc_Arg6FpType) 
              ( 
               QDFC_ArgType, 
               QDFC_ArgType, 
               QDFC_ArgType,
               QDFC_ArgType,
               QDFC_ArgType, 
               QDFC_ArgType 
               );

typedef struct
{
	QDFC_BooleanType sharedThread;/*<<
								                 * Set True if the DFC creation can share 
                                 * with system wide DFC thread. If the 
                                 * latency requirement does not warrant an 
                                 * individual thread then this is the 
                                 * recommended option. It overall
									               * reduces the number of threads invoked.
									               */
	unsigned int 	 nQueDepth;     /*<<
								                 *
                                 * Maximum number of outstanding elements 
                                 * in the queue.	 
									               */

} QDFC_ConfigType;


/* ------------------------------------------------------------------------
** Functions
** ------------------------------------------------------------------------ */

/*==========================================================================
     
         FUNCTION:      qdfc_Init
                                                                        
         DESCRIPTION:                                                       
*//**       This function will initiazes a DFC instance for application use.
			A handle to a DFC instance is returned on successful created of DFC.


@par     DEPENDENCIES:   
               None
*//*                                                                        
         PARAMETERS:
*//**       @param[out]  hDFC     - Pointer to the list object.
*//**       @param[in]   pConfig  - A pointer to DFC configuration
                                    structure.
                     
**//*     RETURN VALUE:                                                                   
*//**       @return    QMM Error code 

@par     SIDE EFFECTS:   
                        None
                                                                        
===========================================================================*/
QDFC_ErrorType   qdfc_Init
(
   QDFC_HandleType  *hDFC,
   QDFC_ConfigType  *pConfig
);

/*==========================================================================
     
         FUNCTION:      qdfc_EnqueueArg6Function
                                                                        
         DESCRIPTION:                                                       
*//**       This function will queue a deferred fucntion call to the DFC 
            instace passed as the argument. This function is dedicated to 
            queueing multiple argument functions up to 6 arguements. In the 
            case of function which requires less than 6 arguments this 
            function be used as long as the remainaing aruments are ignored
            when the API is called asynchronously.


@par     DEPENDENCIES:   
               None
*//*                                                                        
         PARAMETERS:
*//**       @param[in]  hDfc       	      - handle to a valid DFC.
            @param[in]  pfDeferredFunc    - function pointer of matching 
                                            signature in this case function 
                                            should be taking one argument 
                                            unsigned int
            @param[in]  nArg1             - Argument 1 to be passed when the 
                                            deferred function is called. If 
                                            this is a pointer use cuation. 
                                            Any stack variable will 
                                            no maintain its value while dfc 
                                            calls it. In general some generic 
                                            event code or some preallocate 
                                            memory us ownership is 
                                            transferred to callee should be 
                                            used.

            @param[in]  nArg2             - Argument 2 to be passed when the 
                                            deferred function is called. If 
                                            this is a pointer use cuation. 
                                            Any stack variable will 
                                            no maintain its value while dfc 
                                            calls it. In general some generic 
                                            event code or some preallocate 
                                            memory us ownership is 
                                            transferred to callee should be 
                                            used.
            @param[in]  nArg3             - Argument 3 to be passed when the 
                                            deferred function is called. If 
                                            this is a pointer use cuation. 
                                            Any stack variable will 
                                            no maintain its value while dfc 
                                            calls it. In general some generic 
                                            event code or some preallocate 
                                            memory us ownership is 
                                            transferred to callee should be 
                                            used.
            @param[in]  nArg4             - Argument 4 to be passed when the 
                                            deferred function is called. If 
                                            this is a pointer use cuation. 
                                            Any stack variable will 
                                            no maintain its value while dfc 
                                            calls it. In general some generic 
                                            event code or some preallocate 
                                            memory us ownership is 
                                            transferred to callee should be 
                                            used.

**//*     RETURN VALUE:                                                                   
*//**       @return    QDFC Error code 

@par     SIDE EFFECTS:   
                        None
                                                                        
===========================================================================*/
QDFC_ErrorType   qdfc_EnqueueArg6Function
(
   QDFC_HandleType     hDfc,
   qfc_Arg6FpType      pfDeferredFunc,
   QDFC_ArgType        nArg1,
   QDFC_ArgType        nArg2,
   QDFC_ArgType        nArg3,
   QDFC_ArgType        nArg4,
   QDFC_ArgType        nArg5,
   QDFC_ArgType        nArg6
);



/*==========================================================================
     
         FUNCTION:      qmm_DeInit
                                                                        
         DESCRIPTION:                                                       
*//**       This function will de-initialize the given dfc instance.

@par     DEPENDENCIES:   
               None
*//*                                                                        
         PARAMETERS:
*//**       @param[in]  hDfc       - Handle to DFC queue which is previously
                                     initialized.
                     
**//*     RETURN VALUE:                                                                   
*//**       @return    QDFC Error code 

@par     SIDE EFFECTS:   
                        None
                                                                        
===========================================================================*/
QDFC_ErrorType   qdfc_DeInit
(
   QDFC_HandleType  hDfc
);

#if defined( __cplusplus )
}
#endif /* end of macro __cplusplus */


#endif /* __QMM_DFC_API_H__ */
