#ifndef IOCTLSERVER_H_
#define IOCTLSERVER_H_
/*========================================================================

*//** @file ioctlServer.h

@par FILE SERVICES:

@par EXTERNALIZED FUNCTIONS:
      See below.

    Copyright (c) 2012-2013,2021 QUALCOMM Technologies, Incorporated. All Rights Reserved.
    QUALCOMM Proprietary. Export of this technology or software is regulated
    by the U.S. Government, Diversion contrary to U.S. law prohibited.

*//*====================================================================== */

/*========================================================================
                             Edit History

$Header: //components/rel/multimedia_common.qxa_qa/2.0.c4.2/source/qnx/ioctl/ioctlServer/protected/ioctlServer.h#1 $

when       who     what, where, why
--------   ---     -------------------------------------------------------
07/13/21   dr      Fix static analysis tool issue
07/10/13   dp      Client authentication on ioctlServer
06/21/13   rz      Added device_ping
03/15/12   hm      Adding attach and detach function into virtual table

========================================================================== */
#include "AEEStdDef.h" /* std typedefs, ie. byte, uint16, uint32, etc. */

#ifdef __cplusplus
extern "C" {
#endif

typedef struct ioctl_session_t ioctl_session_t;

#ifndef IOHANDLE
#define IOHANDLE
typedef void* IO_HANDLE;
#endif

typedef int (*device_attach_t)();
typedef int (*device_detach_t)();
typedef IO_HANDLE (*device_open_t)(ioctl_session_t* session);
typedef int (*device_close_t)(IO_HANDLE);
typedef int (*device_read_t)(IO_HANDLE, uint8* aBuf, uint32 aBufSize);
typedef int (*device_write_t)(IO_HANDLE, uint8* aBuf, uint32 aBufSize);

typedef int (*device_ioctl_t)
(
    IO_HANDLE handle,
    uint32 aCommand,
    uint8* aInBuf,
    uint32 aInSize,
    uint8* aOutBuf,
    uint32 aOutBufSize,
    uint32* outSizeReturn
);

typedef int (*device_ping_t)
(
    IO_HANDLE handle,
    uint32 aCommand,
    uint8* aInBuf,
    uint32 aInSize
);

typedef struct
{
    device_open_t open;
    device_close_t close;
    device_read_t  read;
    device_write_t write;
    device_ioctl_t ioctl;
    device_ping_t  ping;
    device_attach_t attach;
    device_detach_t detach;
} DeviceIoVtbl;

typedef struct
{
    char* name;            /**< the unique name of the driver */
    uint32 count;          /**< how many server receiving loops threads to launch */
    uint32 stackSize;      /**< server receiving loop thread stack size */
    int priority;          /**< server receiving loop thread priority */
    DeviceIoVtbl vtbl;     /**< device io vtble */
    void* pGroupList;
} ioctl_device_t;

int send_callback_messaage
(
    ioctl_session_t* session,
    uint8* msg,
    uint32 length
);

int register_ioctl_device(ioctl_device_t* aDevice);

int ioctl_server_get_client_pid(ioctl_session_t* session);
int join_device_manager(void);

#ifdef __cplusplus
}
#endif

#endif /* IOCTLSERVER_H_ */
