/**================================================================================================
@file
    devio_msg.h

@brief
    This file declares datatypes and messages for AIOCTL library

Copyright (c) 2021 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.
================================================================================================**/

#ifndef DEVIO_MSG_H_
#define DEVIO_MSG_H_

/**================================================================================================
                     INCLUDE FILES
================================================================================================**/
#include <sys/iomsg.h>
#include <signal.h>
#include "AEEStdDef.h"

#ifdef __cplusplus
extern "C" {
#endif

/**================================================================================================
** Constants and Macros
================================================================================================**/
#define IOCTL_SERVER_MGR_ID  (_IOMGR_PRIVATE_BASE + 200)

#define CALLBACK_EVENT_PULSE (_PULSE_CODE_MINAVAIL + 100)
#define DEVICE_DETACH_PULSE  (_PULSE_CODE_MINAVAIL + 101)
#define THREAD_EXIT_PULSE    (_PULSE_CODE_MINAVAIL + 102)

#define MAX_NAME_LENGTH      (64)
#define MAX_MSG_SIZE         (2048)

#define MAX_CB_MSG_SIZE      (256)

/**================================================================================================
** Typedefs
================================================================================================**/
#ifndef IOHANDLE
#define IOHANDLE
typedef void* IoHandle_t;
#endif

/**********************************************************************************************//**
@brief
    User-defined IO message types
**************************************************************************************************/
typedef enum
{
    MSG_TYPE_ATTACH = _IO_MAX + 1,
    MSG_TYPE_DETACH,
    MSG_TYPE_OPEN,
    MSG_TYPE_IOCTL,
    MSG_TYPE_PING,
    MSG_TYPE_GET_CB_MSG,
    MSG_TYPE_MAX = 0x7FFFFFFF
} MsgType_e;

/**********************************************************************************************//**
@brief
    User-defined IO message types
**************************************************************************************************/
typedef struct
{
    uint16_t type;          /**< Type of the message */
    uint64_t inSize;        /**< input buffer size */
    uint64_t outSize;       /**< output buffer size */
} MsgHdrType_t;

typedef struct
{
    MsgHdrType_t hdr;       /**< msg header */
    struct sigevent event;  /**< pulse for the server to deliver when callback msg is available */
} MsgOpenType_t;

typedef struct
{
    MsgHdrType_t hdr;       /**< msg header */
    int32_t dcb;            /**< device dcb */
} MsgDetachType_t;

typedef struct
{
    MsgHdrType_t hdr;       /**< msg header */
    IoHandle_t handle;      /**< ioctl session handle */
    uint32_t command;       /**< the ioctl command */
} MsgIoctlType_t;

typedef union
{
    MsgHdrType_t hdr;       /**< msg header type, no data following. Used for MSG_TYPE_ATTACH. */
    MsgOpenType_t open;     /**< open msg */
    MsgDetachType_t detach; /**< detach msg */
    MsgIoctlType_t ioctl;   /**< ioctl msg */
} MsgBuf_t;

typedef struct
{
    struct _io_msg io;      /**< IO msg struct */
    MsgBuf_t buf;           /**< msg buffer */
} IOMsgType_t;

#ifdef __cplusplus
}
#endif

#endif /* DEVIO_MSG_H_ */
